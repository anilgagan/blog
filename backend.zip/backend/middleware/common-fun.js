const config = require("../config");
const Promise = require("bluebird");
var mongoose = require("mongoose");
var AWS = require("aws-sdk");
const fs = require("fs");
const uModal = require("./../modules/user/userModal");
const iModal = require("./../modules/inventory/inventoryModal");
const account = require("./../modules/account/accountModal");
const recieptm = require("./../modules/reciept/recieptModal");
const salereciept = require("./../modules/saleReciept/saleRecieptModal");
const orderModel = require("./../modules/order/orderModel");
const auction = require("./../modules/auction/auctionModal");
const { getUniqueVoucherNo } = require("../services/voucher.service");
const {
  makeObjectId,
  ceilToDecimal,
  isArrayWithLength,
  getFivePercentVatWithAmount,
  roundToDecimal,
  toUpperCase,
} = require("../functions/global.functions");
const {
  FindOneWithKey,
  FindByIdWithKey,
  Aggregate,
  Create,
} = require("../models/factory");
const {
  getSellerGatePassExpiryDate,
} = require("../services/inventory.service");
const { CustomInvoice } = require("../models");
const {
  Lookup,
  Unwind,
  ExactMatch,
  Project,
} = require("../functions/mongoose.functions");
const logger = require("../config/logger");

var s3 = new AWS.S3({
  accessKeyId: process.env.AWS_ACCESSKEYID,
  secretAccessKey: process.env.AWS_SECRETACCESSKEY,
});
var aws_bucket = process.env.AWS_BUCKET;
module.exports = {
  pageOffset: function (page, pageLimit) {
    if (!pageLimit) {
      pageLimit = config.pageLimit;
    }

    if (page == 1 || page == 0) {
      return 0;
    }
    return (page - 1) * pageLimit;
  },
  pageLimit: function (pageLimit) {
    if (pageLimit) {
      return parseInt(pageLimit);
    }

    return config.pageLimit;
  },
  hasMoreCount: function (count, page, pageLimit) {
    pageLimit = pageLimit ? pageLimit : config.pageLimit;
    let numOfPage = Math.ceil(count / pageLimit);
    if (page < numOfPage) {
      return true;
    } else {
      return false;
    }
  },
  uplaodfilesAWS: function (fileName, filePath, uploadPath, cType) {
    let seq = new Date().getTime();
    let currentDate = new Date();
    return new Promise(function (resolve, reject) {
      if (
        uploadPath == "assets" ||
        uploadPath == "videos" ||
        uploadPath == "pdf"
      ) {
        uploadPath =
          uploadPath +
          "/" +
          currentDate.getFullYear() +
          "/" +
          (parseInt(currentDate.getMonth()) + 1) +
          "/" +
          currentDate.getDate();
      }
      const params = {
        Bucket: aws_bucket + "/" + uploadPath,
        Key: seq + "-" + String(fileName),
        Body: fs.createReadStream(filePath),
        ACL: "public-read",
        ContentType: cType,
      };
      s3.upload(params, function (s3Err, data) {
        if (s3Err) {
          reject(s3Err);
        } else {
          fs.unlink(filePath, function (err) {});
          resolve(data);
        }
      });
    });
  },
  makerandomString: function (length) {
    var result = "";
    var characters =
      "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    var charactersLength = characters.length;
    for (var i = 0; i < length; i++) {
      result += characters.charAt(Math.floor(Math.random() * charactersLength));
    }
    return result;
  },
  returnSuccess: function (res, result, hasMore, message, totalCount) {
    if (arguments.length == 5) {
      res.status(200).json({
        status: true,
        result: result,
        message: message,
        hasMore: hasMore,
        totalCount: totalCount,
      });
    } else if (arguments.length == 4) {
      res.status(200).json({
        status: true,
        result: result,
        message: message,
        hasMore: hasMore,
      });
    } else if (arguments.length == 3) {
      res.status(200).json({ status: true, result: result, hasMore: hasMore });
    } else {
      res.status(200).json({ status: true, result: result });
    }
  },
  returrnErrorMessage(res, message) {
    res.status(200).json({ status: false, message: message });
  },
  returnSreverError: function (res, message, error, errorCode) {
    if (config.errorShow) {
      // console.log("returnSreverError Error=>>", error);
      if (arguments.length == 4) {
        res.status(500).json({
          status: false,
          message: message,
          errorCode: errorCode,
          error: error,
        });
      } else if (arguments.length == 3) {
        res.status(500).json({ status: false, message: message });
      } else {
        res.status(500).json({ status: false, message: message });
      }
    } else {
      if (arguments.length == 3) {
        res
          .status(500)
          .json({ status: false, message: message, errorCode: errorCode });
      } else if (arguments.length == 2) {
        res.status(500).json({ status: false, message: message });
      } else {
        res.status(500).json({ status: false, message: message });
      }
    }
  },
  returnNotFoundError: function (res, message, error, errorCode) {
    if (config.errorShow) {
      // console.log("returnNotFoundError Error=>>", error);
      if (arguments.length == 4) {
        res.status(400).json({
          status: false,
          message: message,
          errorCode: errorCode,
          //error: error,
        });
      } else if (arguments.length == 3) {
        res.status(400).json({ status: false, message: message, error: error });
      } else {
        res.status(400).json({ status: false, message: message });
      }
    } else {
      if (arguments.length == 3) {
        res
          .status(400)
          .json({ status: false, message: message, errorCode: errorCode });
      } else if (arguments.length == 2) {
        res.status(400).json({ status: false, message: message });
      } else {
        res.status(400).json({ status: false, message: message });
      }
    }
  },
  abbrNum: function (number, decPlaces) {
    decPlaces = Math.pow(10, decPlaces);
    let abbrev = ["K", "M", "B", "T"];

    for (var i = abbrev.length - 1; i >= 0; i--) {
      // Convert array index to "1000", "1000000", etc
      var size = Math.pow(10, (i + 1) * 3);

      // If the number is bigger or equal do the abbreviation
      if (size <= number) {
        // Here, we multiply by decPlaces, round, and then divide by decPlaces.
        // This gives us nice rounding to a particular decimal place.
        number = Math.round((number * decPlaces) / size) / decPlaces;

        // Add the letter for the abbreviation
        number += abbrev[i];

        // We are done... stop
        break;
      }
    }

    return number;
  },
  startTimeString: function (sTime) {
    let month = parseInt(sTime.getMonth()) + parseInt(1);
    let sTString =
      sTime.getFullYear() +
      "-" +
      ((month < 10 ? "0" : "") + month) +
      "-" +
      ((sTime.getDate() < 10 ? "0" : "") + sTime.getDate()) +
      "T" +
      "00:00:00.000Z";

    return sTString;
  },
  endTimeString: function (sTime) {
    let month = parseInt(sTime.getMonth()) + parseInt(1);
    let eTString =
      sTime.getFullYear() +
      "-" +
      ((month < 10 ? "0" : "") + month) +
      "-" +
      ((sTime.getDate() < 10 ? "0" : "") + sTime.getDate()) +
      "T" +
      "23:59:59.999Z";
    return eTString;
  },
  addDays: function (date, days) {
    var result = new Date(date);
    result.setDate(result.getDate() + days);
    return result;
  },
  recalculateInvoice: function (data, type) {
    // calculation for other figure amount
    let totalExcAmount = parseInt(data.saleAmount);
    let discount = parseInt(data.discount);
    let storageAmount = Math.round(data.storageAmount);
    let storageVat = 0;
    let storageDisc = parseInt(data?.storageDisc ? data?.storageDisc : 0);
    let securityAmount = parseInt(data.securityAmount);
    let taxType = data?.taxType ? data?.taxType : "";
    let totalInclAmount = totalExcAmount;
    if (discount > 0) {
      totalExcAmount = totalExcAmount - discount;
    }
    if (storageAmount > 0) {
      if (storageDisc > 0) {
        storageAmount = storageAmount - storageDisc;
      }
      storageVat = Math.round((storageAmount * 5) / 100);
      if (type === "discount") {
        const { vat } = getFivePercentVatWithAmount(storageAmount);
        storageVat = roundToDecimal(vat);
      }
    }

    if (taxType == "tax") {
      let vat = Math.round((totalExcAmount * 5) / 100);
      securityAmount = vat;
      totalInclAmount = totalExcAmount + vat;
    } else {
      totalInclAmount = totalExcAmount;
    }
    //add storage charge after adding vat. now storage amount not include in main invoice from 28-04-2023
    totalInclAmount = totalInclAmount + storageAmount + storageVat;

    let totalNetAmount = totalInclAmount;
    if (taxType == "security") {
      securityAmount = Math.round((totalExcAmount * 5) / 100);
      totalNetAmount = totalNetAmount + securityAmount;
    }
    //after all security calculate or tax calculate. calculate seperate total exclusive amount
    totalExcAmount = totalExcAmount + storageAmount;
    if (data?.cashDiscount > 0) {
      totalNetAmount = totalNetAmount - parseInt(data?.cashDiscount);
    }
    let allAmount = {
      totalExcAmount: totalExcAmount,
      storageAmount: storageAmount,
      storageVat: storageVat,
      storageDisc: storageDisc,
      discount: discount,
      securityAmount: securityAmount,
      totalInclAmount: totalInclAmount,
      totalNetAmount: totalNetAmount,
    };
    return allAmount;
    // end calculation for other figure amount
  },
  getStoargeRemainingPay: async function (id) {
    let recipetData = await recieptm.Reciept.findOne(
      { _id: mongoose.Types.ObjectId(id) },
      {
        recieptNo: 1,
        totalNetAmount: 1,
        paidAmount: 1,
        storageAmount: 1,
        storageVat: 1,
      }
    ).sort({ createdAt: -1 });
    //get paid storage data.
    const accountIdData = await account.Accountmaster.findOne(
      { markAccountId: "storage" },
      {
        markAccountId: 1,
      }
    ).sort({ createdAt: -1 });
    let storageAccountId = accountIdData?._id;
    let queryCond = [];
    queryCond.push({
      $match: {
        $and: [
          { glAccountId: mongoose.Types.ObjectId(storageAccountId) },
          { transactionType: "cr" },
          { referenceType: "reciept" },
          { referenceNo: recipetData?.recieptNo },
        ],
      },
    });
    queryCond.push({
      $group: {
        _id: storageAccountId,
        payAmount: { $sum: "$payAmount" },
      },
    });
    const accountStorageData = await account.Accountledger.aggregate(queryCond);
    let unpaidStorage = 0;
    let unpaidVatStorage = 0;
    if (accountStorageData[0]?.payAmount) {
      unpaidStorage =
        parseInt(recipetData?.storageAmount) -
        parseInt(accountStorageData[0]?.payAmount);
      unpaidVatStorage = Math.round((unpaidStorage * 5) / 100);
    } else {
      unpaidStorage = parseInt(recipetData?.storageAmount);
      unpaidVatStorage = parseInt(recipetData?.storageVat);
    }

    let storageDataAmount = {};

    storageDataAmount["storageAmount"] = unpaidStorage;
    storageDataAmount["storageVat"] = unpaidVatStorage;
    // console.log("washis",storageDataAmount);
    return storageDataAmount;
  },
  commentsLog: function (referenceType, referenceId) {
    let queryCond = {
      referenceType: referenceType,
      referenceId: mongoose.Types.ObjectId(referenceId),
    };
    let getalldata = uModal.Commentlog.find(queryCond).exec();
    return getalldata;
  },
  sendSMS: function (mobile, message) {
    const accountSid = config.twilliosms.accountSid;
    const authToken = config.twilliosms.authToken;
    const fromNumber = config.twilliosms.fromActiveNumber;
    const twilioClient = require("twilio")(accountSid, authToken);

    twilioClient.messages.create(
      {
        body: message, //'This is the ship that made the Kessel Run in fourteen parsecs?',
        to: mobile, //'+15558675310'
        from: fromNumber, //'+15017122661',
      },
      function (err, message) {
        if (err) {
          return "Error";
        } else {
          return message;
        }
      }
    );
  },
  addcommentsLog: function (postData) {
    const newCommentlog = new uModal.Commentlog(postData);
    //let savealldata = newCommentlog.save(postData);
    const addCommentsData = newCommentlog.save(postData);
    if (addCommentsData) {
      return "Error";
    } else {
      return addCommentsData;
    }
  },
  addclosingNotesDetails: function (postData) {
    const newCommentlog = new account.Closingnotesdetail(postData);
    //let savealldata = newCommentlog.save(postData);
    const addCommentsData = newCommentlog.save(postData);
    if (addCommentsData) {
      return "Error";
    } else {
      return addCommentsData;
    }
  },
  addmovedataininventory: function (postData) {
    const newAddmovedatalog = new iModal.Inventory(postData);
    const newAddmoveData = newAddmovedatalog.save(postData);
    if (!newAddmoveData) {
      return "Error";
    } else {
      return newAddmoveData;
    }
  },
  addgetPass: function (postData) {
    const newgetPassLog = new iModal.Getpass(postData);
    const addgetPassData = newgetPassLog.save(postData);
    if (addgetPassData) {
      return "Error";
    } else {
      return addgetPassData;
    }
  },
  addgetDocument: function (postData) {
    const newgetDocument = new iModal.Getdocument(postData);
    const addgetDocumentData = newgetDocument.save(postData);
    if (addgetDocumentData) {
      return "Error";
    } else {
      return addgetDocumentData;
    }
  },
  checkuserPlan: async function (userId, branchId) {
    let queryCond = {
      $and: [
        {
          sellerId: mongoose.Types.ObjectId(userId),
          branchId: mongoose.Types.ObjectId(branchId),
        },
      ],
    };
    let checkuserexist = await iModal.Sellermappingbranch.findOne(queryCond, {
      planId: 1,
    });
    //console.log('=============>', checkuserexist);
    if (checkuserexist?.planId) {
      return true;
    } else {
      return false;
    }
  },
  buildTree: function (list) {
    const root = [];
    // console.log("kkkk");
    list.forEach((node) => {
      // No parentId means top level
      if (!node.parentId) return root.push(node);

      // Insert node as child of parent in flat array
      const parentIndex = list.findIndex(
        (el) => String(el._id) === String(node.parentId)
      );
      if (!list[parentIndex].children) {
        return (list[parentIndex].children = [node]);
      }

      list[parentIndex].children.push(node);
    });
    return root;
  },
  getLotNo: async function () {
    /*generate unique lot no */
    let queryUnique = {
      $and: [{ lotNo: { $exists: true } }, { voucherNo: { $ne: null } }],
    };
    let lotNoUnique = 0;
    let stockData = await iModal.Inventory.findOne(queryUnique, {
      lotNo: 1,
    }).sort({ lotNo: -1 });
    if (stockData) {
      if (stockData.lotNo == 0 || !stockData.lotNo) {
        lotNoUnique = 100101;
      } else {
        lotNoUnique = stockData.lotNo + 1;
      }
    } else {
      lotNoUnique = 100101;
    }
    /*generate unique lot no */
    return lotNoUnique;
  },
  getDocNo: async function (referenceType) {
    const filter = {
      $and: [
        { referenecType: referenceType },
        { voucherNo: { $exists: true, $nin: ["", null] } },
      ],
    };

    const prefix = config.docPrefix[referenceType];

    const voucherNo = await FindOneWithKey(
      account.Outgoingcash,
      filter,
      "voucherNo",
      config.defaultSort
    );

    const voucherNO = await getUniqueVoucherNo(prefix, voucherNo);

    return voucherNO;
  },
  getPassNo: async function () {
    const filter = { passNo: { $exists: true, $nin: ["", null] } };

    const {
      docPrefix: { gatePass },
    } = config;

    const passNo = await FindOneWithKey(
      iModal.Getpass,
      filter,
      "passNo",
      config.defaultSort
    );

    const passNO = await getUniqueVoucherNo(gatePass, passNo);

    return passNO;
  },
  getDocumentpass: async function () {
    const filter = { passNo: { $exists: true, $nin: ["", null] } };

    const {
      docPrefix: { documentPass },
    } = config;

    const passNo = await FindOneWithKey(
      iModal.Getdocument,
      filter,
      "passNo",
      config.defaultSort
    );

    const passNO = await getUniqueVoucherNo(documentPass, passNo);

    return passNO;
  },
  getVoucherNo: async function () {
    const filter = { voucherNo: { $exists: true, $nin: ["", null] } };

    const {
      docPrefix: { voucher },
    } = config;

    const voucherNo = await FindOneWithKey(
      account.Accountledger,
      filter,
      "voucherNo",
      config.defaultSort
    );

    const voucherNO = await getUniqueVoucherNo(voucher, voucherNo);

    return voucherNO;
  },
  getSellerNo: async function () {
    const filter = {
      uniqueIdentifier: { $exists: true, $nin: ["", null] },
      userType: { $in: [2, 3] },
    };

    const {
      docPrefix: { seller },
    } = config;

    const uniqueIdentifier = await FindOneWithKey(
      uModal.User,
      filter,
      "uniqueIdentifier",
      config.defaultSort
    );

    const sellerUniqueIdentifier = await getUniqueVoucherNo(
      seller,
      uniqueIdentifier
    );

    return sellerUniqueIdentifier;
  },
  getBuyerNo: async function () {
    const filter = {
      uniqueIdentifier: { $exists: true, $nin: ["", null] },
      userType: { $in: [4, 5] },
    };

    const {
      docPrefix: { buyer },
    } = config;

    const uniqueIdentifier = await FindOneWithKey(
      uModal.User,
      filter,
      "uniqueIdentifier",
      config.defaultSort
    );

    const buyerUniqueIdentifier = await getUniqueVoucherNo(
      buyer,
      uniqueIdentifier
    );

    return buyerUniqueIdentifier;
  },
  getRecieptNo: async function () {
    const filter = { recieptNo: { $exists: true, $nin: ["", null] } };

    const {
      docPrefix: { reciept },
    } = config;

    const receiptNo = await FindOneWithKey(
      recieptm.Reciept,
      filter,
      "recieptNo",
      config.defaultSort
    );

    const receiptNO = await getUniqueVoucherNo(reciept, receiptNo);

    return receiptNO;
  },
  getSalesRecieptNo: async function () {
    const filter = { saleRecieptNo: { $exists: true, $nin: ["", null] } };

    const {
      docPrefix: { sellerreceipt },
    } = config;

    const saleReceiptNo = await FindOneWithKey(
      salereciept.Salereciept,
      filter,
      "saleRecieptNo",
      config.defaultSort
    );

    const saleReceiptNO = await getUniqueVoucherNo(
      sellerreceipt,
      saleReceiptNo
    );

    return saleReceiptNO;
  },
  getSaleOrderNo: async function () {
    const filter = { saleOrderNo: { $exists: true, $nin: ["", null] } };

    const {
      docPrefix: { salesreceipt },
    } = config;

    const saleOrderNo = await FindOneWithKey(
      salereciept.Sellerservice,
      filter,
      "saleOrderNo",
      config.defaultSort
    );

    const saleOrderNO = await getUniqueVoucherNo(salesreceipt, saleOrderNo);

    return saleOrderNO;
  },
  getUserOrderNo: async function () {
    const filter = { orderNo: { $exists: true, $nin: ["", null] } };

    const {
      docPrefix: { order },
    } = config;

    const orderNo = await FindOneWithKey(
      orderModel.Order,
      filter,
      "orderNo",
      config.defaultSort
    );

    const orderNO = await getUniqueVoucherNo(order, orderNo);

    return orderNO;
  },
  getCustomInvoiceNo: async function () {
    const filter = { invoiceNo: { $exists: true, $nin: ["", null] } };

    const {
      docPrefix: { customInvoice },
    } = config;

    const invoiceNo = await FindOneWithKey(
      CustomInvoice,
      filter,
      "invoiceNo",
      config.defaultSort
    );

    const invoiceNO = await getUniqueVoucherNo(customInvoice, invoiceNo);

    return invoiceNO;
  },
  getSalesReturnNo: async function () {
    const filter = { salesReturnNo: { $exists: true, $nin: ["", null] } };

    const {
      docPrefix: { salesReturn },
    } = config;

    const salesReturnNo = await FindOneWithKey(
      recieptm.Salesreturn,
      filter,
      "salesReturnNo",
      config.defaultSort
    );

    const salesReturnNO = await getUniqueVoucherNo(salesReturn, salesReturnNo);

    return salesReturnNO;
  },
  accountPayable: async function () {
    const filter = { refno: { $exists: true, $nin: ["", null] } };

    const {
      docPrefix: { accountPayable },
    } = config;

    const refNo = await FindOneWithKey(
      account.AccountPayable,
      filter,
      "refno",
      config.defaultSort
    );

    const refNO = await getUniqueVoucherNo(accountPayable, refNo);

    return refNO;
  },
  addPayable: async function () {
    const filter = { payableNo: { $exists: true, $nin: ["", null] } };

    const {
      docPrefix: { addPayable },
    } = config;

    const payableNo = await FindOneWithKey(
      salereciept.SellerPayable,
      filter,
      "payableNo",
      config.defaultSort
    );

    const payableNO = await getUniqueVoucherNo(addPayable, payableNo);

    return payableNO;
  },
  getempGlNo: async function () {
    const filter = { voucherNo: { $exists: true, $nin: ["", null] } };

    const {
      docPrefix: { getempglno },
    } = config;

    const voucherNo = await FindOneWithKey(
      account.Accountledgertemp,
      filter,
      "voucherNo",
      config.defaultSort
    );

    const voucherNO = await getUniqueVoucherNo(getempglno, voucherNo);

    return voucherNO;
  },
  checkVinNoWithStatus: async function (vinNo) {
    let remarksArr = {};

    if (vinNo) {
      var regexvin = new RegExp(vinNo, "i");
      let vinquery = {
        $and: [
          { vin: { $regex: regexvin } },
          {
            $or: [
              { inventoryStatus: 0 },
              { inventoryStatus: 1 },
              { inventoryStatus: 2 },
              { inventoryStatus: 3 },
              { inventoryStatus: 4 },
            ],
          },
        ],
      };

      let vinData = await iModal.Inventory.findOne(vinquery, {
        vin: 1,
        inventoryStatus: 1,
      }).sort({ createdAt: -1 });

      if (vinData) {
        if (vinData?.inventoryStatus == 0) {
          remarksArr = {
            status: true,
            message: vinNo + " is in approval state",
          };
        } else if (vinData?.inventoryStatus == 1) {
          remarksArr = {
            status: true,
            vinId: vinData.vin,
            message: vinNo + " is dublicate data",
          };
        } else if (vinData?.inventoryStatus == 2) {
          remarksArr = { status: true, message: vinNo + " is in auction" };
        } else if (vinData?.inventoryStatus == 3) {
          const status = {
            pending: true,
            "in warehouse": true,
            "out of stock": false,
            "not found": true,
          };
          const message = {
            pending: "is sold but payment not cleared (GatePass - pending)",
            "in warehouse":
              "is sold but not released (GatePass - in warehouse)",
            "out of stock": "new entry",
            "not found": "invalid entry, kindly contact admin!",
          };
          const filter = {
            inventoryId: vinData._id,
            direction: "out",
          };
          let getPassStatus = await FindOneWithKey(
            iModal.Getpass,
            filter,
            "status",
            config.defaultSort
          );

          getPassStatus = getPassStatus ?? "not found";
          remarksArr = {
            status: status[getPassStatus],
            vinId: vinData.vin,
            message: ` ${vinNo} ${message[getPassStatus]}`,
          };
        } else if (vinData?.inventoryStatus == 4) {
          const status = {
            pending: true,
            "in warehouse": true,
            "out of stock": false,
            "not found": true,
          };
          const message = {
            pending: "is unsold but payment not cleared (GatePass - pending)",
            "in warehouse":
              "is unsold but not released (GatePass - in warehouse)",
            "out of stock": "new entry",
            "not found": "invalid entry, kindly contact admin!",
          };
          const filter = {
            inventoryId: vinData._id,
            direction: "out",
          };
          let getPassStatus = await FindOneWithKey(
            iModal.Getpass,
            filter,
            "status",
            config.defaultSort
          );

          getPassStatus = getPassStatus ?? "not found";
          remarksArr = {
            status: status[getPassStatus],
            vinId: vinData.vin,
            message: ` ${vinNo} ${message[getPassStatus]}`,
          };
        }
      } else {
        remarksArr = { status: false, vinId: "", message: " new entry" };
      }
    }

    return remarksArr;
  },
  vinnosixDigit: async function (vinNo) {
    //vinNo = vinNo.trim();
    let checkmaxlength = await vinNo.toString().length;
    let vinum;
    /* if (checkmaxlength == 3) {
       vinum = "000" + vinNo;
     } else if (checkmaxlength == 4) {
       vinum = "00" + vinNo;
     } else if (checkmaxlength == 5) {
       vinum = "0" + vinNo;
     } else if (checkmaxlength == 2) {
       vinum = "0000" + vinNo;
     } else if (checkmaxlength == 1) {
       vinum = "00000" + vinNo;
     } else {
       vinum = vinNo;
     }*/
    if (checkmaxlength == 17) {
      vinum = true;
    } else {
      vinum = false;
    }
    return vinum;
  },
  checksaleDates: async function (data) {
    //console.log("data==========>",data);
    //return false;
    let recipetData = await recieptm.Reciept.findOne(
      { _id: mongoose.Types.ObjectId(data.recieptId) },
      { transDate: 1 }
    ).sort({ createdAt: -1 });
    //console.log("recipetData==========>",recipetData);
    //return false;
    let checktrue;

    const date1 = new Date(data.saledate);
    const date2 = new Date(recipetData.transDate);

    if (recipetData) {
      if (date1 >= date2) {
        checktrue = true;
      } else {
        checktrue = false;
      }
    }
    //console.log("checktrue==========>",checktrue);
    return checktrue;
  },
  sidebarFilterList: async function (
    fueltype,
    fueltypeId = "640eed452e6dbb9991b20ff3"
  ) {
    let query = [];
    if (fueltype == "fueltypes") {
      query.push({
        $lookup: {
          from: "fueltypes",
          localField: "fueltypeId",
          foreignField: "_id",
          as: "fueltypes",
        },
      });
      query.push({
        $unwind: { path: "$fueltypes", preserveNullAndEmptyArrays: true },
      });
      query.push({
        $match: {
          $and: [{ fueltypeId: mongoose.Types.ObjectId(fueltypeId) }],
        },
      });
      query.push({
        $addFields: {
          fueltypesName: $fueltypes.fueltypeName,
        },
      });
      query.push({
        $project: {
          fueltypesName: 1,
        },
      });
      const allLedgersData = await iModal.Inventory.aggregate(query);

      console.log("test-0001", allLedgersData);
    }
  },
  getauctionNo: async function () {
    const filter = { auctionNo: { $exists: true, $nin: ["", null] } };

    const {
      docPrefix: { auction: auctionPrefix },
    } = config;

    const auctionNo = await FindOneWithKey(
      auction.Auction,
      filter,
      "auctionNo",
      config.defaultSort
    );

    const auctionNO = await getUniqueVoucherNo(auctionPrefix, auctionNo);

    return auctionNO;
  },
  reverseGl: async function (
    recieptId,
    salesReturnNo,
    type,
    getGLByPaymentMethod
  ) {
    // * receipt
    const receiptNo = await FindByIdWithKey(
      recieptm.Reciept,
      recieptId,
      "recieptNo"
    );

    // * salesReturn
    const sFilter = { salesReturnNo };
    const salesReturnTransDate = await FindOneWithKey(
      recieptm.Salesreturn,
      sFilter,
      "transDate"
    );

    const voucherNoUnique = await this.getVoucherNo();

    // #region - // * REVERSE LEDGER ENTRIES
    const pipeline = [];
    const reverseLedgerArr = [];

    // * accountMaster
    Lookup(pipeline, "accountmasters", "glAccountId", "_id", "accountMaster");
    Unwind(pipeline, "$accountMaster");

    // * match
    ExactMatch(pipeline, "referenceNo", receiptNo);

    // * project
    Project(pipeline, {
      branchId: 1,
      voucherNo: 1,
      glAccountId: 1,
      transactionType: 1,
      paymentType: 1,
      payAmount: 1,
      description: 1,
      referenceType: 1,
      referenceNo: 1,
      referenceNo2: 1,
      balanceAmount: 1,
      createdBy: 1,
      closingStatus: 1,
      transDate: 1,
      buyerNo: 1,
      sellerNo: 1,
      transactionOf: 1,
      markAccountId: "$accountMaster.markAccountId",
      accountName: "$accountMaster.accountName",
    });

    const ledgers = await Aggregate(account.Accountledger, pipeline);

    if (!isArrayWithLength(ledgers)) {
      logger.error("no ledger data found!");
      return;
    }

    const excludedAccounts = [
      "cash-in-bank",
      "cash-in-bank-sajja",
      "cash-in-bank-ind",
      "cash-in-bank-sharj",
      "transaction-fee",
      "cash-in-hand",
    ];
    let glAccountId;

    for (let i = 0; i < ledgers.length; i++) {
      const transactionType =
        ledgers[i]?.transactionType === "cr" ? "dr" : "cr";

      if (excludedAccounts.includes(ledgers[i]?.markAccountId)) {
        continue;
      } else {
        glAccountId = ledgers[i]?.glAccountId;
      }

      reverseLedgerArr.push({
        branchId: ledgers[i]?.branchId,
        voucherNo: voucherNoUnique,
        glAccountId,
        transactionType: transactionType,
        paymentType: ledgers[i]?.paymentType,
        payAmount: ledgers[i]?.payAmount,
        description: ledgers[i]?.description ? ledgers[i]?.description : "",
        referenceType: ledgers[i]?.referenceType,
        referenceNo: ledgers[i]?.referenceNo,
        referenceNo2: ledgers[i]?.referenceNo2,
        balanceAmount: ledgers[i]?.balanceAmount,
        createdBy: ledgers[i]?.createdBy,
        closingStatus: 0,
        transDate: salesReturnTransDate,
        buyerNo: ledgers[i]?.buyerNo,
        sellerNo: ledgers[i]?.sellerNo,
        transactionOf: ledgers[i]?.transactionOf,
      });
    }

    if (isArrayWithLength(reverseLedgerArr)) {
      await account.Accountledger.insertMany(reverseLedgerArr);
    }
    // #endregion

    // #region - // * SALES RETURN LEDGER ENTRIES
    const query = [];
    const refundLedgerData = [];

    // * receipts
    Lookup(query, "reciepts", "recieptId", "_id", "receipts");
    Unwind(query, "$receipts");

    // * match
    ExactMatch(query, "salesReturnNo", salesReturnNo);

    // * project
    Project(query, {
      paidAmount: "$receipts.paidAmount",
      branchId: "$receipts.branchId",
      refundStatus: 1,
      returnAmount: 1,
    });

    const saleReturns = await Aggregate(recieptm.Salesreturn, query);

    if (!isArrayWithLength(saleReturns)) {
      logger.error("no sale returns data found!");
      return;
    }

    const [ledger] = ledgers;
    const [salesReturn] = saleReturns;

    const {
      _id: salesReturnId,
      refundStatus,
      paidAmount,
      returnAmount,
      branchId,
    } = salesReturn;
    const { referenceNo2, sellerNo, buyerNo } = ledger;

    if (refundStatus === "yes" || refundStatus === "no") {
      const incomeAmount = parseInt(paidAmount) - parseInt(returnAmount);

      // * selfBid
      if (type === "selfbid" && paidAmount > 0) {
        const payableToSellerAccountId = await getGLByPaymentMethod(
          "payable-to-seller"
        );

        refundLedgerData.push({
          branchId: mongoose.Types.ObjectId(branchId),
          glAccountId: mongoose.Types.ObjectId(payableToSellerAccountId),
          voucherNo: voucherNoUnique,
          transactionType: "cr",
          paymentType: "cash",
          payAmount: Number(paidAmount),
          referenceType: "sales return",
          referenceNo: receiptNo,
          referenceNo2,
          buyerNo: "",
          sellerNo: sellerNo,
          description: `transfer amount from ${buyerNo} to ${sellerNo}`,
          createdBy: "system",
          transDate: salesReturnTransDate,
          transactionOf: "seller",
        });
      } else if (type === "return" && returnAmount > 0) {
        const accountLedgerTempArr = [];

        let buyerName = await FindOneWithKey(
          uModal.User,
          { uniqueIdentifier: buyerNo },
          "name"
        );
        buyerName = toUpperCase(buyerName);

        let sellerName = await FindOneWithKey(
          uModal.User,
          { uniqueIdentifier: sellerNo },
          "name"
        );
        sellerName = toUpperCase(sellerName);

        const receivableDescription = `TO RECORD RECEIVABLE OF ${
          buyerName || ""
        } AGAINST ${
          sellerName || ""
        } VIN# ${referenceNo2} INV NO# ${receiptNo}`;

        // * receivable
        const recievableAccountId = await getGLByPaymentMethod("receivable");

        refundLedgerData.push({
          branchId: mongoose.Types.ObjectId(branchId),
          glAccountId: mongoose.Types.ObjectId(recievableAccountId),
          voucherNo: voucherNoUnique,
          transactionType: "cr",
          paymentType: "cash",
          payAmount: Number(returnAmount),
          description: receivableDescription,
          referenceType: "sales return",
          referenceNo: receiptNo,
          referenceNo2: referenceNo2,
          buyerNo: buyerNo,
          sellerNo: sellerNo,
          createdBy: "system",
          transDate: salesReturnTransDate,
          transactionOf: "seller",
        });

        // #region - // * OP Entries
        const description = `TO RECORD SALES RETURN OF ${
          buyerName || ""
        } AGAINST ${
          sellerName || ""
        } VIN# ${referenceNo2} INV NO# ${receiptNo}`;

        const tempVoucherNo = await this.getempGlNo();
        const cashInhandAccountId = await getGLByPaymentMethod("cash-in-hand");

        // * cash-in-hand
        accountLedgerTempArr.push({
          branchId,
          voucherNo: tempVoucherNo,
          glAccountId: cashInhandAccountId,
          transactionType: "cr",
          paymentType: "cash",
          payAmount: Number(returnAmount),
          description,
          referenceType: "sales return",
          referenceId: salesReturnId,
          referenceNo: salesReturnNo,
          referenceNo2: referenceNo2,
          balanceAmount: Number(returnAmount),
          createdBy: "system",
          transDate: salesReturnTransDate,
          addedFrom: "op",
          createdFrom: "Sales Return",
          status: "approved",
          buyerNo,
          transactionOf: "buyer",
        });

        // * receivable
        accountLedgerTempArr.push({
          branchId,
          voucherNo: tempVoucherNo,
          glAccountId: recievableAccountId,
          transactionType: "dr",
          paymentType: "cash",
          payAmount: Number(returnAmount),
          description,
          referenceType: "sales return",
          referenceId: salesReturnId,
          referenceNo: salesReturnNo,
          referenceNo2: referenceNo2,
          balanceAmount: Number(returnAmount),
          createdBy: "system",
          transDate: salesReturnTransDate,
          addedFrom: "op",
          createdFrom: "Sales Return",
          status: "approved",
          buyerNo,
          transactionOf: "buyer",
        });

        if (isArrayWithLength(accountLedgerTempArr)) {
          await Create(account.Accountledgertemp, accountLedgerTempArr);
        }
        // #endregion
      }

      // * salesReturn
      if (incomeAmount > 0 && type !== "selfbid") {
        const storage = Math.round(incomeAmount / 1.05);
        const storageVat = parseInt(incomeAmount) - parseInt(storage);

        const storageAccountId = await getGLByPaymentMethod("storage");
        const storageVatAccountId = await getGLByPaymentMethod("storage-vat");

        refundLedgerData.push({
          branchId: mongoose.Types.ObjectId(branchId),
          glAccountId: mongoose.Types.ObjectId(storageAccountId),
          voucherNo: voucherNoUnique,
          transactionType: "cr",
          paymentType: "",
          payAmount: Number(storage),
          referenceType: "reciept",
          referenceNo: receiptNo,
          referenceNo2: referenceNo2,
          buyerNo: buyerNo,
          sellerNo: sellerNo,
          createdBy: "system",
          transDate: salesReturnTransDate,
          transactionOf: "seller",
        });

        refundLedgerData.push({
          branchId: mongoose.Types.ObjectId(branchId),
          glAccountId: mongoose.Types.ObjectId(storageVatAccountId),
          voucherNo: voucherNoUnique,
          transactionType: "cr",
          paymentType: "",
          payAmount: Number(storageVat),
          referenceType: "reciept",
          referenceNo: receiptNo,
          referenceNo2: referenceNo2,
          buyerNo: buyerNo,
          sellerNo: sellerNo,
          createdBy: "system",
          transDate: salesReturnTransDate,
          transactionOf: "seller",
        });
      }

      if (isArrayWithLength(refundLedgerData)) {
        await account.Accountledger.insertMany(refundLedgerData);
      }
    }
    // #endregion

    return true;
  },
  checkVehicleUnsold: async function (auctionId, inventoryIdArr) {
    for (var i = 0; i < inventoryIdArr.length; i++) {
      let inventoryId = inventoryIdArr[i];
      let planConsume = false;
      // auctionId: mongoose.Types.ObjectId(auctionId),
      let totalUnsoldCar = await auction.Auctionvehicle.find({
        inventoryId: mongoose.Types.ObjectId(inventoryId),
        status: "unsold",
      }).count();
      // console.log("washi",totalUnsoldCar)

      //count from seller plan
      let query = [];
      query.push({
        $lookup: {
          from: "inventorys",
          localField: "inventoryId",
          foreignField: "_id",
          as: "inventorys",
        },
      });
      query.push({
        $unwind: { path: "$inventorys", preserveNullAndEmptyArrays: true },
      });
      query.push({
        $match: {
          $and: [{ inventoryId: mongoose.Types.ObjectId(inventoryId) }],
        },
      });
      query.push({
        $project: {
          runs: 1,
          listingFee: 1,
          sellerId: 1,
          vinNo: "$inventorys.vin",
        },
      });
      let plandata = await iModal.Carwisesellerplan.aggregate(query);
      //console.log("checkp===========--------",plandata);
      if (plandata?.length > 0) {
        if (plandata[0]?.runs <= totalUnsoldCar) {
          planConsume = true;
        }
      }
      await iModal.Inventory.updateOne(
        { _id: mongoose.Types.ObjectId(inventoryId) },
        { $set: { completeRuns: totalUnsoldCar } }
      );
      //console.log("planConsume===========--------",planConsume);
      let inventoryStatus = 1;
      if (planConsume) {
        await this.unsoldcalauctionwithsellerservice(
          inventoryId,
          plandata[0]?.sellerId,
          auctionId
        );
        inventoryStatus = 4;
        //call gatepass from here.
        const vinData = await iModal.Inventory.findOne(
          { _id: mongoose.Types.ObjectId(inventoryId) },
          {
            vin: 1,
            branchId: 1,
            warehosId: 1,
          }
        ).sort({ createdAt: -1 });

        const gatePassExpired = await getSellerGatePassExpiryDate(inventoryId);
        // Add get pass
        let passNoUnique = await this.getPassNo();
        let savegetPassData = {
          passNo: passNoUnique,
          direction: "out",
          referenceType: "inventory",
          referenceNo: vinData?.vin,
          inventoryId: mongoose.Types.ObjectId(inventoryId),
          status: "pending",
          gatePassExpired,
          gatePassExpiredDate: gatePassExpired,
          createdBy: "system",
        };
        // console.log("gatepass",savegetPassData);
        await this.addgetPass(savegetPassData);

        // Add get document
        let docNoUnique = await this.getDocumentpass();
        let savegetDocumentData = {
          passNo: docNoUnique,
          direction: "out",
          referenceType: "inventory",
          referenceNo: vinData?.vin,
          status: "pending",
          inventoryId: mongoose.Types.ObjectId(inventoryId),
          branchId: mongoose.Types.ObjectId(vinData?.branchId),
          warehosId: mongoose.Types.ObjectId(vinData?.warehosId),
          createdBy: "system",
        };
        // console.log("documentPass",savegetDocumentData);
        await this.addgetDocument(savegetDocumentData);
        //console.log('-------------------->inner',plandata);
        let salesrecieptNoUnique = await this.getSalesRecieptNo();
        let salerecieptData = {
          saleRecieptNo: salesrecieptNoUnique, //n
          listingFee: plandata[0]?.listingFee, //y
          inventoryId: mongoose.Types.ObjectId(inventoryId), //y
          salerId: mongoose.Types.ObjectId(plandata[0]?.sellerId), //y
          //recieptId: mongoose.Types.ObjectId(element?.recieptId),
          //paybleAmount: paybleAmount, //listingfrre
        };
        //console.log('-------------------->inner',salerecieptData);
        await salereciept.Salereciept.insertMany(salerecieptData);
      }

      //update inventory according to plan.
      await iModal.Inventory.updateOne(
        { _id: mongoose.Types.ObjectId(inventoryId) },
        { $set: { inventoryStatus: inventoryStatus } }
      );

      //--------------------------------------------------------

      //------------------------------------------------------
    }
    return true;
  },
  calculateauctioncharge: async function (inventoryId, soldcarlaue) {
    let query = [];
    let retrundata = {};
    let listingfee = 0;
    let auctionprice = 0;
    let vatamount = 0;
    let servicecharge = 0;
    let totalpayment = 0;

    let chargedata = await iModal.Carwisesellerplan.findOne({
      inventoryId: mongoose.Types.ObjectId(inventoryId),
    })
      .sort({ createdAt: -1 })
      .limit(1);

    if (chargedata?.auctionTypeFee == "limited") {
      const staticAmountValue = chargedata?.amountValue;
      let increment = chargedata?.increment;
      let amountValue = chargedata?.amountValue;
      let fee = chargedata?.initialfee;
      listingfee = chargedata?.listingFee;

      let start = 0;

      if (amountValue > 0) {
        while (true) {
          if (start <= soldcarlaue && soldcarlaue <= amountValue) {
            auctionprice = fee;
            break;
          }
          start = amountValue + 1; // start
          amountValue = amountValue + staticAmountValue; // toRange
          fee += increment; // fee
        }
      }

      vatamount = ((auctionprice + listingfee) * 5) / 100;
      vatamount = ceilToDecimal(vatamount);
      servicecharge = auctionprice + listingfee;
      totalpayment = auctionprice + listingfee + vatamount;
    }

    retrundata["auctionprice"] = auctionprice;
    retrundata["listingfee"] = listingfee;
    retrundata["vatamount"] = vatamount;
    retrundata["servicecharge"] = servicecharge;
    retrundata["totalpayment"] = totalpayment;

    return retrundata;
  },
  unsoldcalauctionCharge: async function (inventoryId, soldcarlaue, type) {
    let query = [];
    let retrundata = {};
    let listingfee = 0;
    let auctionprice = 0;
    let vatamount = 0;
    let servicecharge = 0;
    let totalpayment = 0;

    let chargedata = await iModal.Carwisesellerplan.findOne({
      inventoryId: mongoose.Types.ObjectId(inventoryId),
    })
      .sort({ createdAt: -1 })
      .limit(1);

    if (chargedata?.auctionTypeFee == "limited") {
      const staticAmountValue = chargedata?.amountValue;
      let increment = chargedata?.increment;
      let amountValue = chargedata?.amountValue;
      let fee = chargedata?.initialfee;
      listingfee = chargedata?.listingFee;

      let start = 0;

      if (amountValue && soldcarlaue > 0) {
        while (true) {
          if (start <= soldcarlaue && soldcarlaue <= amountValue) {
            auctionprice = fee;
            break;
          }
          start = amountValue + 1; // start
          amountValue = amountValue + staticAmountValue; // toRange
          fee += increment; // fee
        }
      }

      if (type === "sold") {
        auctionprice = fee;
      }

      vatamount = ((auctionprice + listingfee) * 5) / 100;
      vatamount = ceilToDecimal(vatamount);
      servicecharge = auctionprice + listingfee;
      totalpayment = auctionprice + listingfee + vatamount;
    }

    retrundata["auctionprice"] = auctionprice;
    retrundata["listingfee"] = listingfee;
    retrundata["vatamount"] = vatamount;
    retrundata["servicecharge"] = servicecharge;
    retrundata["totalpayment"] = totalpayment;

    return retrundata;
  },
  unsoldcalauctionwithsellerservice: async function (
    inventoryId,
    sellerId,
    auctionId,
    type
  ) {
    let calauctiondata = await this.unsoldcalauctionCharge(
      inventoryId,
      (saleAmount = 0),
      type
    );

    vatAmounts = calauctiondata?.vatamount ? calauctiondata?.vatamount : 0;
    saleAmounts = saleAmount;
    soldtotalpayment = parseFloat(saleAmounts) + parseFloat(vatAmounts);

    let auctionprices = calauctiondata?.auctionprice
      ? calauctiondata?.auctionprice
      : 0;
    listingfees = calauctiondata?.listingfee ? calauctiondata?.listingfee : 0;
    auctiontotalpayment =
      parseFloat(auctionprices) +
      parseFloat(listingfees) +
      parseFloat(vatAmounts);

    const serviceBasedAuctionCharge = type === "sold" ? auctionprices : 0;

    let sellerOrderNo = await this.getSaleOrderNo();
    sallerData2 = {
      saleOrderNo: sellerOrderNo, //n
      sellerId: makeObjectId(sellerId), //y
      inventoryId: makeObjectId(inventoryId), //n
      auctionId: makeObjectId(auctionId), //n
      serviceType: "auction",
      serviceStatus: "unsold",
      saleAmount: 0, //n,
      auctionFee: serviceBasedAuctionCharge, //n
      listingFee: calauctiondata?.listingfee, //y
      serviceCharge: calauctiondata?.servicecharge,
      vatAmount: calauctiondata?.vatamount, //n
      securityDeposit: 0,
      totalPayment: auctiontotalpayment,
    };
    const newsellerdata2 = new salereciept.Sellerservice(sallerData2);
    return await newsellerdata2.save(sallerData2);
  },
  selfBidcalauctionwithsellerservice: async function (
    inventoryId,
    recieptId,
    auctionId,
    refundStatus = ""
  ) {
    let querysaler = {
      $and: [{ _id: mongoose.Types.ObjectId(inventoryId) }],
    };
    const userData = await iModal.Inventory.findOne(querysaler, {
      vin: 1,
      branchId: 1,
      warehosId: 1,
      sellerId: 1,
    }).sort({ createdAt: -1 });

    let sellerId = userData.sellerId;

    let recieptQuery = {
      $and: [{ _id: mongoose.Types.ObjectId(recieptId) }],
    };
    const recieptData = await recieptm.Reciept.findOne(recieptQuery, {
      saleAmount: 1,
      paidAmount: 1,
      buyerId: 1,
    });
    let saleAmount = recieptData?.saleAmount;
    const paidAmount = recieptData?.paidAmount;
    let calauctiondata = await this.unsoldcalauctionCharge(
      inventoryId,
      saleAmount
    );

    vatAmounts = calauctiondata?.vatamount ? calauctiondata?.vatamount : 0;
    saleAmounts = saleAmount;
    soldtotalpayment = parseFloat(saleAmounts) + parseFloat(vatAmounts);

    auctionprices = calauctiondata?.auctionprice
      ? calauctiondata?.auctionprice
      : 0;
    listingfees = calauctiondata?.listingfee ? calauctiondata?.listingfee : 0;
    auctiontotalpayment =
      parseFloat(auctionprices) +
      parseFloat(listingfees) +
      parseFloat(vatAmounts);

    let sellerOrderNo = await this.getSaleOrderNo();
    sallerData2 = {
      saleOrderNo: sellerOrderNo, //n
      sellerId: makeObjectId(sellerId), //y
      buyerId: makeObjectId(recieptData?.buyerId),
      recieptId: makeObjectId(recieptId),
      inventoryId: makeObjectId(inventoryId), //n
      auctionId: makeObjectId(auctionId), //n
      serviceType: "auction",
      serviceStatus: "selfBid",
      saleAmount: 0, //n,
      saleTotalAmount: paidAmount,
      auctionFee: calauctiondata?.auctionprice, //n
      listingFee: calauctiondata?.listingfee, //y
      serviceCharge: calauctiondata?.servicecharge,
      vatAmount: calauctiondata?.vatamount, //n
      securityDeposit: 0,
      totalPayment: auctiontotalpayment,
      refundStatus,
    };
    const newsellerdata2 = new salereciept.Sellerservice(sallerData2);
    await newsellerdata2.save(sallerData2);

    // * Self-Bid Buyer Paid Amount
    const buyerPaidAmount = {
      saleOrderNo: sellerOrderNo, //n
      sellerId: makeObjectId(sellerId), //y
      buyerId: makeObjectId(recieptData?.buyerId),
      recieptId: makeObjectId(recieptId),
      inventoryId: makeObjectId(inventoryId), //n
      auctionId: makeObjectId(auctionId), //n
      serviceType: "sold",
      serviceStatus: "selfBid",
      saleAmount: paidAmount, //n,
      auctionFee: 0, //n
      listingFee: 0, //y
      serviceCharge: 0,
      vatAmount: 0, //n
      securityDeposit: 0,
      totalPayment: paidAmount,
      refundStatus,
    };
    const newsellerdata3 = new salereciept.Sellerservice(buyerPaidAmount);
    await newsellerdata3.save(buyerPaidAmount);

    const gatePassExpired = await getSellerGatePassExpiryDate(inventoryId);

    let passNoUnique = await this.getPassNo();
    let savegetPassData = {
      passNo: passNoUnique,
      direction: "out",
      referenceType: "inventory",
      referenceNo: userData?.vin,
      inventoryId: mongoose.Types.ObjectId(inventoryId),
      status: "pending",
      gatePassExpired,
      gatePassExpiredDate: gatePassExpired,
      createdBy: "system",
    };
    // console.log("gatepass",savegetPassData);
    await this.addgetPass(savegetPassData);

    // Add get document
    let docNoUnique = await this.getDocumentpass();
    let savegetDocumentData = {
      passNo: docNoUnique,
      direction: "out",
      referenceType: "inventory",
      referenceNo: userData?.vin,
      status: "pending",
      inventoryId: mongoose.Types.ObjectId(inventoryId),
      branchId: mongoose.Types.ObjectId(userData?.branchId),
      warehosId: mongoose.Types.ObjectId(userData?.warehosId),
      createdBy: "system",
    };
    // console.log("documentPass",savegetDocumentData);
    await this.addgetDocument(savegetDocumentData);

    // * update gate pass and document pass with status: gatePassStatus and inventoryId
    const filter = {
      direction: "out",
      inventoryId: makeObjectId(inventoryId),
      referenceId: makeObjectId(recieptId),
    };
    const update = {
      $set: { status: "cancelled" },
    };

    await iModal.Getpass.updateOne(filter, update);
    await iModal.Getdocument.updateOne(filter, update);

    await iModal.Inventory.updateOne(
      { _id: mongoose.Types.ObjectId(inventoryId) },
      { $set: { inventoryStatus: 4 } }
    );

    return sellerOrderNo;
  },
};
