//const redisClustr = require('redis-clustr');
const redisClient = require("redis");
const Redis = require("ioredis");
const debug = require("debug")("app:redisHelper");
const buffer = require("buffer/").Buffer;
const config = require("../config");
const User = require("../modules/user/userModal");
const { json } = require("express");
const { stubFalse } = require("lodash");
var client = null;
module.exports.connect = async () => {
  if (config.redisFlag) {
    console.log("process.env.REDIS_CONNECTION",process.env.REDIS_CONNECTION)
    try {
     
      // client = redisClient.createClient({ host: process.env.REDIS_CONNECTION, port: 6379, db: '', password: process.env.REDIS_PASS }); //  productiom

      client = redisClient.createClient({ url: 'redis://:'+process.env.REDIS_PASSOWRD+'@'+process.env.REDIS_CONNECTION+':6379' });


      // client = new Redis.Cluster([
      //   {
      //     host: process.env.REDIS_CONNECTION, // Configuration endpoint address from Elasticache
      //     port: 6379,
      //   },
      // ]);
      client.on("error", (err) => console.log("Redis Client Error", err));
      client.on("connect", (ack) => console.log("Redis Client connected"));
      await client.connect();
      
    } catch (e) {
      //client=null
      console.log("Redis Client  connection Error", e);
    }
  } else {
    return false;
  }
};

module.exports.storeHash = async (key, value) => {
  if (config.redisFlag) {
    try {
     // console.log("client!============>",client)
      if (!client) await client.connect();
      return await client.set(key, JSON.stringify(value));
    } catch (e) {
      console.log("Redis storeHash Error", e);
      return false;
    }
  } else {
    return false;
  }
};

module.exports.getHash = async (key) => {
  if (config.redisFlag) {
    try {
      console.log("client!============>",!client)
      if (!client) await client.connect();
      console.log("GET Key : ", key);
      return JSON.parse(await client.get(key));
    } catch (e) {
      console.log("Redis getHash Error", e);
      return false;
    }
  } else {
    return false;
  }
};

module.exports.encrypt = async (req) => {
  // console.log("checking Prefix==>",req.baseUrl.split("/")[2])
  return (
    req.baseUrl.split("/")[2] +
    ":" +
    buffer.from(JSON.stringify(req.body)).toString("base64")
  );
};

module.exports.deleteUser = async (key) => {
  if (config.redisFlag) {
    try {
      if (!client) await client.connect();
      let index = String(key).split(".");
      let NOCK_ID = index - (index % 100);
      await client.del("NOCK-" + NOCK_ID);
      let total = await User.User.find(
        {},
        { _id: 1, userId: 1, fcmToken: 1, name: 1, NotifyType: 1 }
      )
        .skip(NOCK_ID)
        .limit(100);
      await this.storeHash("NOCK-" + NOCK_ID, total);
      return true;
    } catch (e) {
      console.log("Redis deleteUser Error", e);
      return false;
    }
  } else {
    return false;
  }
};

module.exports.deleteHash = async (req) => {
  if (config.redisFlag) {
    try {
      if (!client) await client.connect();
      /* client.flushall('ASYNC', function (err, succeeded) {
        console.log(succeeded); // will be true if successfull
      }); */
      // let keys = await client.keys("*" + req.baseUrl.split("/")[2] + "*");
      client.keys(req.baseUrl.split("/")[2] + ":*").then(function (keys) {
        // Use pipeline instead of sending
        // one command each time to improve the
        // performance.
        var pipeline = client.pipeline();
        keys.forEach(function (key) {
          pipeline.del(key);
        });
        return pipeline.exec();
      });
      try{
        client.flushall("ASYNC", function (err, succeeded) {
          return "Flush successfully done";
        });
      }catch(err){
        client.keys("*").then(function (keys) {
          keys.forEach(function (key) {
            client.del(key);
          })
        })
      }
      return true;
    } catch (e) {
      console.log("Redis deleteHash Error", e);
      return false;
    }
  } else {
    return false;
  }
};

module.exports.customDelete = async (key) => {
  if (config.redisFlag) {
    try {
      if (!client) await client.connect();
      /* let keys = await client.keys("*" + key + "*");
      if (keys.length > 0) {
        await client.del(keys);
      }*/
      client.keys(key + ":*").then(function (keys) {
        // Use pipeline instead of sending
        // one command each time to improve the
        // performance.
        var pipeline = client.pipeline();
        keys.forEach(function (key) {
          pipeline.del(key);
        });
        return pipeline.exec();
      });

      try{
          
      client.flushall("ASYNC", function (err, succeeded) {
        return "Flush successfully done";
      });

      }catch(err){
        client.keys("*").then(function (keys) {
          keys.forEach(function (key) {
            client.del(key);
          })
        })
      }
      return true;
    } catch (e) {
      console.log("Redis customDelete Error", e);
      return true;
    }
  } else {
    return false;
  }
};

module.exports.redisFlushAll = async () => {
  if (config.redisFlag) {
    try {
      if (!client) await client.connect();
      //let ack = await client.flushAll("");
      client.flushall("ASYNC", function (err, succeeded) {
        return "Flush successfully done";
      });

      /* if (ack == "OK") {
        return "Flush successfully done";
      } else {
        return "Some error occurred!";
      } */
    } catch (e) {
      console.log("Redis redisFlushAll Error", e);
      return true;
    }
  } else {
    return "Redis feature is disable";
  }
};
