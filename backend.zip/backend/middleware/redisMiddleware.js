const { storeHash, getHash, encrypt } = require("./redisConnection");
const cmethod = require("../middleware/common-fun");
const buffer = require('buffer/').Buffer;
const eventDao = require("../modules/event/eventDao");
const categroyDao = require("../modules/category/categoryDao");
const pointOfInterestDao = require("../modules/pointOfInterest/interestDao")
const treasureDao = require("../modules/treasureHunt/treasureDao")
const config = require("../config");


module.exports.getDataFromRedis = async (req, res, next)=>{
   try{
       let postData= req.body
       let lang = req.headers["lang"] || config.lang;
       req.body.lang = lang
       if(config.redisFlag){
           
           let data = await getHash(await encrypt(req))
          
           if(data){
               console.log('running.... redis')
               if(data.router=='eventList'){
                   cmethod.returnSuccess( res,  eventDao.convertDataLang(data.data, "event", lang), cmethod.hasMoreCount(data.total, postData.page, postData.pageLimit), "", data.total );
               }else if(data.router=='categoryList'){
                   console.log("data",data)
                   cmethod.returnSuccess( res,  categroyDao.convertDataLang(data.data, postData, lang), cmethod.hasMoreCount(data.total, postData.page, postData.pageLimit), "", data.total );
               }else if(data.router=='homeList'){
                cmethod.returnSuccess( res,  categroyDao.convertHomeScreenDataLang(data.data,lang), cmethod.hasMoreCount(data.total, postData.page, postData.pageLimit), "", data.total );
               }else if(data.router == 'pointOfIntrest'){
                cmethod.returnSuccess( res,  pointOfInterestDao.convertDataLang(data.data,lang), cmethod.hasMoreCount(data.total, postData.page, postData.pageLimit), "", data.total );
               }else if(data.router == 'treasureHunt'){
                cmethod.returnSuccess( res,  treasureDao.convertDataLang(data.data,lang), cmethod.hasMoreCount(data.total, postData.page, postData.pageLimit), "", data.total );
               }else if(data.router == 'eventListDateWise'){
                  // console.log(data.router)
                cmethod.returnSuccess( res,  eventDao.convertDataLangDateWise(data.data, "event", lang), cmethod.hasMoreCount(data.total, postData.page, postData.pageLimit), "", data.total );
               }else if(data.router == 'HomePage'){                 
                res.status(200).json({status: true,result: data.data,sponsor: data.sponsor});
               }else{
                cmethod.returnSuccess( res, data.data, cmethod.hasMoreCount(data.total, postData.page, postData.pageLimit), "", data.total );
               }              
           }else{
               console.log('key not Fount.....running.... next')
               next()
           }
       }else{
           console.log('redis is disable running.... next')
           next()
       }
   }catch (e) {
       console.log(e)
       next()
   }
    //next()
}
