const { inventoryStatus } = require("../config");

const getInventoryStatus = (status) => {
  return inventoryStatus[status] || "Unknown";
};

module.exports = {
  getInventoryStatus,
};
