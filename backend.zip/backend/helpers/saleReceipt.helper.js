const logger = require("../config/logger");
const {
  checkRequiredArguments,
  makeObjectId,
  roundToDecimal,
} = require("../functions/global.functions");
const { Sellerservice } = require("../modules/saleReciept/saleRecieptModal");

const modifySellerPayableList = async (results) => {
  if (!results.length) return results;

  for (const result of results) {
    const { inventoryId, makes, models, year, lotNo, vinNo } = result;

    const obj = {
      inventoryId: inventoryId.join(", "),
      makes: makes.join(", "),
      models: models.join(", "),
      year: year.join(", "),
      lotNo: lotNo.join(", "),
      vinNo: vinNo.join(", "),
    };

    result.commaSeparated = obj;

    return results;
  }
};

// * Auction
const calculateAuctionServiceCharges = (
  auctionCharge,
  listingCharge,
  auctionDiscount,
  listingDiscount,
  vat = 5
) => {
  const auctionDiscountedAmount = auctionCharge - auctionDiscount;
  const listingDiscountedAmount = listingCharge - listingDiscount;
  const totalDiscount = auctionDiscount + listingDiscount;
  const totalPayment = auctionDiscountedAmount + listingDiscountedAmount;
  const vatAmount = (totalPayment * vat) / 100;
  const grandTotal = totalPayment + vatAmount;

  return {
    auctionDiscountedAmount,
    listingDiscountedAmount,
    totalDiscount,
    totalPayment,
    vatAmount,
    grandTotal,
  };
};

// * Auction Update
const updateSellerServiceAuctionEntries = async (
  inventoryId,
  sellerId,
  auctionObj
) => {
  try {
    if (!checkRequiredArguments(inventoryId, sellerId, auctionObj)) return;

    const {
      auctionDiscountedAmount,
      listingDiscountedAmount,
      auctionDiscount,
      listingDiscount,
      totalDiscount,
      totalPayment,
      vatAmount,
      grandTotal,
    } = auctionObj;

    const filter = {
      inventoryId: makeObjectId(inventoryId),
      sellerId: makeObjectId(sellerId),
      serviceType: "auction",
    };

    const update = {
      $set: {
        auctionFee: auctionDiscountedAmount,
        listingFee: listingDiscountedAmount,
        auctionDiscount,
        listingDiscount,
        totalDiscount,
        serviceCharge: totalPayment,
        vatAmount,
        totalPayment: grandTotal,
      },
    };

    await Sellerservice.updateMany(filter, update);
  } catch (error) {
    logger.error(error);
  }
};

// * Auction Reverse
const reverseCalculateAuctionServiceCharges = async (
  inventoryId,
  sellerId,
  sellerServiceOrderNumbers
) => {
  try {
    if (
      !checkRequiredArguments(inventoryId, sellerId, sellerServiceOrderNumbers)
    )
      return;

    const filter = {
      inventoryId: makeObjectId(inventoryId),
      sellerId: makeObjectId(sellerId),
      saleOrderNo: { $in: sellerServiceOrderNumbers },
      serviceType: "auction",
    };

    const auctionSellerService = await Sellerservice.findOne(filter);

    if (!auctionSellerService) {
      logger.error("Auction seller service not found!");
      return;
    }

    const {
      auctionFee: auctionDiscountedAmount,
      listingFee: listingDiscountedAmount,
      auctionDiscount,
      listingDiscount,
    } = auctionSellerService;

    const previousAuctionAmount = auctionDiscountedAmount + auctionDiscount;
    const previousListingAmount = listingDiscountedAmount + listingDiscount;

    const previousAuctionTotalPayment =
      previousAuctionAmount + previousListingAmount;

    const previousAuctionVAT = roundToDecimal(
      0.05 * (previousAuctionAmount + previousListingAmount)
    );

    const previousAuctionGrandTotal =
      previousAuctionTotalPayment + previousAuctionVAT;

    const auctionObj = {
      auctionDiscountedAmount: previousAuctionAmount,
      listingDiscountedAmount: previousListingAmount,
      auctionDiscount: 0,
      listingDiscount: 0,
      totalDiscount: 0,
      totalPayment: previousAuctionTotalPayment,
      vatAmount: previousAuctionVAT,
      grandTotal: previousAuctionGrandTotal,
    };

    await updateSellerServiceAuctionEntries(inventoryId, sellerId, auctionObj);
  } catch (error) {
    logger.error(error);
  }
};

// * Storage
const calculateStorageServiceCharges = (
  storageCharge,
  storageDiscount,
  vat = 5
) => {
  const storageDiscountedAmount = storageCharge - storageDiscount;
  const vatAmount = (storageDiscountedAmount * vat) / 100;
  const grandTotal = storageDiscountedAmount + vatAmount;

  return {
    storageDiscountedAmount,
    vatAmount,
    grandTotal,
  };
};

// * Storage Update
const updateSellerServiceStorageEntries = async (
  inventoryId,
  sellerId,
  storageObj
) => {
  try {
    if (!checkRequiredArguments(inventoryId, sellerId, storageObj)) return;

    const { storageDiscountedAmount, storageDiscount, vatAmount, grandTotal } =
      storageObj;

    const filter = {
      inventoryId: makeObjectId(inventoryId),
      sellerId: makeObjectId(sellerId),
      serviceType: "storage",
    };

    const update = {
      $set: {
        serviceCharge: storageDiscountedAmount,
        storageDiscount,
        vatAmount,
        totalPayment: grandTotal,
      },
    };

    await Sellerservice.updateMany(filter, update);
  } catch (error) {
    logger.error(error);
  }
};

// * Storage Reverse
const reverseCalculateStorageServiceCharges = async (
  inventoryId,
  sellerId,
  sellerServiceOrderNumbers
) => {
  try {
    if (
      !checkRequiredArguments(inventoryId, sellerId, sellerServiceOrderNumbers)
    )
      return;

    const filter = {
      inventoryId: makeObjectId(inventoryId),
      sellerId: makeObjectId(sellerId),
      saleOrderNo: { $in: sellerServiceOrderNumbers },
      serviceType: "storage",
    };

    const storageSellerService = await Sellerservice.findOne(filter);

    if (!storageSellerService) {
      logger.error("Storage seller service not found!");
      return;
    }

    const {
      serviceCharge: storageDiscountedAmount,
      storageDiscount: storageDiscount,
    } = storageSellerService;

    const previousStorageAmount = storageDiscountedAmount + storageDiscount;
    const previousStorageVAT = roundToDecimal(0.05 * previousStorageAmount);
    const previousStorageGrandTotal =
      previousStorageAmount + previousStorageVAT;

    const storageObj = {
      storageDiscountedAmount: previousStorageAmount,
      storageDiscount: 0,
      vatAmount: previousStorageVAT,
      grandTotal: previousStorageGrandTotal,
    };

    await updateSellerServiceStorageEntries(inventoryId, sellerId, storageObj);
  } catch (error) {
    logger.error(error);
  }
};

module.exports = {
  modifySellerPayableList,
  calculateAuctionServiceCharges,
  reverseCalculateAuctionServiceCharges,
  calculateStorageServiceCharges,
  reverseCalculateStorageServiceCharges,
  updateSellerServiceAuctionEntries,
  updateSellerServiceStorageEntries,
};
