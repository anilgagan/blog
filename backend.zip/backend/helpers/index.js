module.exports.inventoryHelper = require("./inventory.helper");
