const mongoose = require("mongoose");
const { default: axios } = require("axios");
const { log: info, error: _error } = console;
const fs = require("fs");
const path = require("path");
const sharp = require("sharp");
const Papa = require("papaparse");
const config = require("../config");
const logger = require("../config/logger");
const {
  add,
  sub,
  format,
  parseISO,
  differenceInCalendarDays,
} = require("date-fns");

const isNumberLessThanZero = (number) => number < 0;
const makeAbsoluteNumber = (number) => Math.abs(number);
const regexSearch = (str) => ({ $regex: str, $options: "i" });
const isArrayWithLength = (arr) => Array.isArray(arr) && arr.length > 0;
const sendDummyResponse = (res) => res.status(200).send("OK!");
const isEmptyArray = (value) => Array.isArray(value) && value.length === 0;
const isUndefined = (value) => value === undefined;
const isNull = (value) => value === null;
const isMongooseObjectId = (value) => mongoose.Types.ObjectId.isValid(value);

const makeObjectId = (id) => {
  if (!id) return;

  return mongoose.Types.ObjectId(id);
};

const getFivePercentVat = (amount) => {
  const vat = 0.05 * amount;
  return roundToDecimal(vat, 2);
};

const getFivePercentVatWithAmount = (
  totalAmount,
  vatRate = config.defaultVat
) => {
  if (totalAmount <= 0 || vatRate <= 0)
    return {
      amount: 0,
      vat: 0,
    };

  const amount = totalAmount / (1 + vatRate / 100);
  const vat = totalAmount - amount;

  return {
    amount,
    vat,
  };
};

const combineObjects = (data) => {
  return data.reduce((combinedObject, currentObject) => {
    return { ...combinedObject, ...currentObject };
  }, {});
};

const createNewMongoDoc = (doc) => {
  const { _id, createdAt, updatedAt, __v, ...rest } = doc.toObject();
  return rest;
};

const removeFieldsFromObject = (object, ...keys) =>
  keys.reduce((obj, key) => {
    const { [key]: _, ...rest } = obj;
    return rest;
  }, object);

const checkBoolean = (input) => {
  if (!input) return;

  if (typeof input === "boolean") return input;

  if (typeof input === "string") {
    if (input === "true") return true;
    else if (input === "false") return false;
  }
};

const generateOTP = (length) => {
  const characters = "0123456789";
  let otp = "";

  for (let i = 0; i < length; i++) {
    const randomIndex = Math.floor(Math.random() * characters.length);
    otp += characters[randomIndex];
  }

  return otp;
};

const parseCSVFile = async (filePath) => {
  if (!filePath) return;

  try {
    const data = await fs.readFileSync(filePath, "utf8");

    const results = await new Promise((resolve, reject) => {
      Papa.parse(data, {
        header: true,
        dynamicTyping: false,
        skipEmptyLines: true,
        complete: function (results) {
          resolve(results.data);
        },
        error: function (error) {
          reject(error.message);
        },
      });
    });

    return results;
  } catch (error) {
    _error("error in parseCSVFile with: ", error.message);
  }
};

const fileCleaner = async (file) => {
  if (!file) return;

  try {
    await fs.unlink(`./${file.path}`, (err) => {
      if (err) {
        _error(
          `Error while cleaning single file with this path ===>- ./${file.path}`
        );
      } else {
        info(`File deleted on this path ===> - ./${file.path}`);
      }
    });
  } catch (error) {
    _error(
      `Error catch while cleaning single file with this path - ./${file.path}`
    );
  }
};

const removeFileByPath = (filePath) => {
  try {
    fs.unlinkSync(filePath);
    info(`File ${filePath} has been removed successfully.`);
  } catch (err) {
    _error(`Error removing file ${filePath}: ${err.message}`);
  }
};

const findAndJoinByKey = (arr, key) => {
  if (!arr.length) return [];

  const values = arr.map((obj) => obj[key]);
  const joinedValues = values.join(", ");

  return joinedValues;
};

const joinWithSymbol = (symbol, ...args) => {
  const strings = args.filter((str) => str !== "" && str !== null);

  if (strings.length === 0) return "";

  const joinedString = strings.join(`${symbol}`);
  return joinedString;
};

const isEmptyString = (value) => {
  return typeof value === "string" && value.trim() === "";
};

const isEmptyObject = (value) => {
  return (
    typeof value === "object" &&
    Object.keys(value).length === 0 &&
    !(value instanceof mongoose.Types.ObjectId)
  );
};

const checkRequiredArguments = (...args) => {
  return args.every(
    (arg) =>
      !isUndefined(arg) &&
      !isNull(arg) &&
      !isEmptyString(arg) &&
      !isEmptyObject(arg) &&
      !isEmptyArray(arg)
  );
};

const createDirectory = (dir) => {
  try {
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  } catch (err) {
    _error(`Error creating directory: ${err.message}`);
  }
};

const resizeImage = async (imagePath, outputDir) => {
  try {
    if (!checkRequiredArguments(imagePath, outputDir)) return;
    createDirectory(outputDir);

    const { imageResizeDimensions: dimensions } = config;
    const image = sharp(imagePath);

    const resizedImagePaths = [];

    for (const dimension of dimensions) {
      const { name, width, height } = dimension;
      const outputFilename = `${name}-${path.basename(imagePath)}`;
      const outputPath = path.join(outputDir, outputFilename);
      const options = {
        fit: "inside",
        withoutEnlargement: true,
      };

      try {
        await image.resize(width, height, options).toFile(outputPath);

        resizedImagePaths.push({
          path: outputPath,
          size: name,
        });
      } catch (err) {
        _error(`Error resizing image to ${width}x${height}: ${err.message}`);
      }
    }

    removeFileByPath(imagePath);
    return resizedImagePaths;
  } catch (err) {
    _error(`Error resizing image: ${err.message}`);
    return [];
  }
};

const getValuesByKey = (arr, key, mode) => {
  if (!checkRequiredArguments(arr, key, mode)) return;

  const values = arr
    .map((obj) => obj[key])
    .filter((value) => value !== undefined);

  const [value = ""] = values;
  return mode === "single" ? value : values;
};

const customSort = (key, order) => {
  return (a, b) => {
    const indexA = order.indexOf(a[key]);
    const indexB = order.indexOf(b[key]);

    if (indexA === -1) return 1;
    if (indexB === -1) return -1;

    return indexA - indexB;
  };
};

const roundToDecimal = (number, decimalPlaces = 0) => {
  const factor = 10 ** decimalPlaces;
  return Math.round(number * factor) / factor;
};

const ceilToDecimal = (number, decimalPlaces = 0) => {
  const factor = 10 ** decimalPlaces;
  return Math.ceil(number * factor) / factor;
};

const customSlice = (str, type, count) => {
  if (!checkRequiredArguments(str, type, count)) return;

  if (type === "start") {
    return str.slice(0, count);
  } else if (type === "end") {
    return str.slice(-count);
  } else {
    return "Invalid type!";
  }
};

const formatDate = (date, formate = config.dateFormats.ISO8601) => {
  if (!date) return;

  const parsedDate = typeof date === "string" ? parseISO(date) : date;
  if (isNaN(parsedDate)) return "Invalid date!";
  return format(parsedDate, formate);
};

const daysPassedFromToday = (targetDate) => {
  if (!targetDate) return;

  const currentDate = new Date();
  const daysPassed = differenceInCalendarDays(currentDate, targetDate);
  return daysPassed;
};

const manipulateDate = (
  date,
  operation,
  value,
  formate = config.dateFormats.ISO8601
) => {
  const parsedDate = typeof date === "string" ? parseISO(date) : date;

  if (isNaN(parsedDate)) return "Invalid date!";

  let manipulatedDate;
  if (operation === "add") {
    manipulatedDate = add(parsedDate, { days: value });
  } else if (operation === "subtract") {
    manipulatedDate = sub(parsedDate, { days: value });
  } else {
    return 'Invalid operation. Use "add" or "subtract"';
  }

  return format(manipulatedDate, formate);
};

const todayDate = (formate = config.dateFormats.ISO8601) => {
  const date = new Date();
  const formattedDate = format(date, formate);
  return formattedDate;
};

const uniqueItemsToArray = (...args) => {
  return Array.from(new Set(args)).filter(Boolean);
};

const removeSpaces = (str) => {
  if (!checkRequiredArguments(str)) return;

  return str.replace(/ /g, "");
};

const makeObjectIds = (ids) => {
  if (!checkRequiredArguments(ids)) return;

  return ids.map((id) => mongoose.Types.ObjectId(id));
};

const makeAxiosRequest = async (
  url,
  method,
  data = null,
  headers = {},
  params = {}
) => {
  // info(`sending axios request to url: ${url}`);
  // info(`sending axios request with method: ${method}`);
  // info(`sending axios request with data: ${JSON.stringify(data)}`);
  // info(`sending axios request with headers: ${JSON.stringify(headers)}`);
  // info(`sending axios request with params: ${JSON.stringify(params)}`);

  try {
    const response = await axios({
      url,
      method,
      data,
      headers,
      params,
    });

    return response.data;
  } catch (error) {
    // _error(error);
    return error;
  }
};

const bearerToken = (token) => {
  if (!checkRequiredArguments(token)) return;

  return {
    Authorization: `Bearer ${token}`,
  };
};

const isValidEmail = (email) => {
  if (!checkRequiredArguments(email)) return;

  const regex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
  return regex.test(email);
};

const removeSpecialCharacters = (str) => {
  if (!checkRequiredArguments(str)) return;

  return str.replace(/[^\w\s]/g, "");
};

const onlyNumbersString = (str) => {
  if (!checkRequiredArguments(str)) return;

  const pattern = /^\d+$/;
  return pattern.test(str);
};

const baseUrlWithoutParams = (url) => {
  if (!checkRequiredArguments(url)) return;

  const baseUrl = url.replace(/\/\w+$/, "");
  return baseUrl;
};

const toUpperCase = (str) => {
  if (!checkRequiredArguments(str)) return;

  return str.toUpperCase();
};

const findByKeyValue = (arr, key, value) => {
  if (!checkRequiredArguments(arr, key, value)) return;

  return arr.find((obj) => {
    if (obj[key] instanceof mongoose.Types.ObjectId) {
      return obj[key].equals(value);
    } else {
      return obj[key] === value;
    }
  });
};

const filterFalsyValues = (arr) => {
  if (!checkRequiredArguments(arr)) return;

  return Array.isArray(arr) ? arr.filter(Boolean) : [];
};

module.exports = {
  isNumberLessThanZero,
  makeAbsoluteNumber,
  combineObjects,
  createNewMongoDoc,
  removeFieldsFromObject,
  checkBoolean,
  generateOTP,
  makeObjectId,
  getFivePercentVat,
  parseCSVFile,
  fileCleaner,
  removeFileByPath,
  findAndJoinByKey,
  joinWithSymbol,
  checkRequiredArguments,
  createDirectory,
  resizeImage,
  getValuesByKey,
  sendDummyResponse,
  regexSearch,
  isArrayWithLength,
  isUndefined,
  isNull,
  isEmptyString,
  isEmptyObject,
  isEmptyArray,
  isMongooseObjectId,
  customSort,
  roundToDecimal,
  ceilToDecimal,
  customSlice,
  formatDate,
  daysPassedFromToday,
  manipulateDate,
  todayDate,
  getFivePercentVatWithAmount,
  uniqueItemsToArray,
  removeSpaces,
  makeObjectIds,
  makeAxiosRequest,
  bearerToken,
  isValidEmail,
  removeSpecialCharacters,
  onlyNumbersString,
  baseUrlWithoutParams,
  toUpperCase,
  findByKeyValue,
  filterFalsyValues,
};
