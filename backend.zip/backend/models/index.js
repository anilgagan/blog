module.exports.Voucher = require("./voucher.model");
module.exports.Closing = require("./closing.model");
module.exports.OTP = require("./otp.model");
module.exports.Token = require("./token.model");
module.exports.Inspection = require("./inspection.model");
module.exports.CustomInvoice = require("./customInvoice.model");
