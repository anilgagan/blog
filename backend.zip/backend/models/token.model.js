const mongoose = require("mongoose");
const { connWrite } = require("../config/database");
const { tokenTypes } = require("../config/tokens");

const tokenSchema = new mongoose.Schema(
  {
    token: {
      type: String,
      required: true,
      index: true,
    },
    type: {
      type: String,
      enum: [tokenTypes.SMS],
      required: true,
      index: true,
    },
  },
  {
    timestamps: true,
  }
);

const Token = connWrite.model("Token", tokenSchema);

module.exports = Token;
