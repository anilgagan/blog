const mongoose = require("mongoose");
const { connWrite } = require("../config/database");

const componentSchema = new mongoose.Schema({
  status: { type: Boolean, default: null },
  notes: { type: String, default: null },
});

const component = { _id: false, type: componentSchema, default: () => ({}) };

const inspectionSchema = new mongoose.Schema(
  {
    inventoryId: {
      type: mongoose.SchemaTypes.ObjectId,
      ref: "inventorys",
      required: true,
      unique: true,
    },
    inspectedAt: { type: Date, default: null },
    inspectedBy: { type: String, default: null },
    components: {
      car: component,
      chassisNumber: component,
      radar: component,
      wheel: component,
      bumper: component,
      battery: component,
      mat: component,
      screen: component,
      key: component,
      catalyticConverter: component,
      finder: component,
      antenna: component,
      trunk: component,
      stopLight: component,
      door: component,
      masterDoor: component,
      doorHandle: component,
      sideMirror: component,
      frontGlass: component,
      backGlass: component,
      fogLight: component,
      headLight: component,
      frontBumper: component,
      rearBumper: component,
      tyre: component,
      wheel: component,
      marka: component,
      wipersFront: component,
      wipersBack: component,
    },
  },
  {
    timestamps: true,
  }
);

const Inspection = connWrite.model("Inspection", inspectionSchema);

module.exports = Inspection;
