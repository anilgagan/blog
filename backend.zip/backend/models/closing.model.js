const mongoose = require("mongoose");
const { connWrite } = require("../config/database");
const {
  userTypes: { SELLER, BUYER },
} = require("../config");

// * schema for daily closing balances

const closingSchema = new mongoose.Schema(
  {
    type: {
      type: String,
      enum: [SELLER, BUYER],
      required: true,
    },
    typeId: {
      type: String,
      required: true,
    },
    date: {
      type: Date,
      required: true,
    },
    openingBalance: {
      type: Number,
      required: true,
    },
    closingBalance: {
      type: Number,
      required: true,
    },
  },
  {
    timestamps: true,
  }
);

closingSchema.index({ typeId: 1, date: 1 }, { unique: true });

const Closing = connWrite.model("closing", closingSchema);

module.exports = Closing;
