const mongoose = require("mongoose");
const { connWrite } = require("../config/database");

const customInvoiceSchema = new mongoose.Schema(
  {
    invoiceNo: { type: String, required: true, index: true },
    serviceName: { type: String, required: true, index: true },
    serviceId: {
      type: mongoose.Types.ObjectId,
      ref: "CustomService",
      default: null,
      index: true,
    },
    serviceGlId: {
      type: mongoose.Types.ObjectId,
      ref: "accountmasters",
      required: true,
      index: true,
    },
    branchId: {
      type: mongoose.Types.ObjectId,
      ref: "branchs",
      required: true,
      index: true,
    },
    userId: {
      type: mongoose.Types.ObjectId,
      ref: "users",
      required: true,
      index: true,
    },
    serviceCharges: { type: Number, required: true },
    serviceVat: { type: Number, required: true },
    total: { type: Number, required: true },
    status: { type: String, default: "pending", index: true }, // * pending|approved|rejected|paid
    createdBy: { type: String, default: "" },
    description: { type: String, default: "" },
    processedBy: { type: String, default: "" },
    processedDate: { type: Date, default: null },
    processedComments: { type: String, default: "" },
  },
  {
    timestamps: true,
  }
);

customInvoiceSchema.pre("findOneAndUpdate", async function (next) {
  try {
    const filter = this.getQuery();
    const update = this.getUpdate();

    if (filter && update) {
      const doc = await this.model.findOne(filter);

      if (!doc) {
        throw new Error("doc not found for update!");
      }

      if (doc.status === update.status) {
        throw new Error("cannot update with the same payload for the status!");
      }
    }
    next();
  } catch (error) {
    next(error);
  }
});

const CustomInvoice = connWrite.model("CustomInvoice", customInvoiceSchema);

module.exports = CustomInvoice;
