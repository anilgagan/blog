const mongoose = require("mongoose");
const { connWrite } = require("../config/database");

const otpSchema = new mongoose.Schema({
  email: {
    type: String,
    required: false,
  },
  phone: {
    type: String,
    required: false,
  },
  otp: {
    type: String,
    required: true,
  },
  createdAt: {
    type: Date,
    default: Date.now,
    expires: "5m",
  },
});

const OTP = connWrite.model("OTP", otpSchema);

module.exports = OTP;
