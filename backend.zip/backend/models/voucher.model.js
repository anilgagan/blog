const mongoose = require("mongoose");
const { connWrite } = require("../config/database");

const voucherSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
      unique: true,
      index: true,
    },
    prefix: {
      type: String,
      required: true,
      index: true,
    },
    value: {
      type: Number,
      required: true,
      index: true,
    },
    uniqueNo: {
      type: String,
      required: true,
      index: true,
    },
  },
  {
    timestamps: true,
  }
);

const Voucher = connWrite.model("Voucher", voucherSchema);

module.exports = Voucher;
