module.exports.voucherController = require("./voucher.controller");
module.exports.analyticsController = require("./analytics.controller");
module.exports.commentController = require("./comment.controller");
module.exports.termsconditionController = require("./termscondition.controller");
module.exports.masterController = require("./master.controller");
module.exports.customInvoiceController = require("./customInvoice.controller");
module.exports.receiptController = require("./receipt.controller");
