const config = require("../config");
const message = require("../config/message");
const cMethod = require("../middleware/common-fun");
const { voucherService } = require("../services");

const createVouchers = async (req, res) => {
  try {
    const { body } = req;
    let lang = req.headers["lang"] || config.lang;

    const vouchers = await voucherService.createVouchers(body);

    cMethod.returnSuccess(res, vouchers, false, message["eng"].created);
  } catch (error) {
    cMethod.returnSreverError(res, error.message);
  }
};

module.exports = {
  createVouchers,
};
