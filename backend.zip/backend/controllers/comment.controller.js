const logger = require("../config/logger");
const message = require("../config/message");
const cMethod = require("../middleware/common-fun");

const { getValuesByKey } = require("../functions/global.functions");
const { commentService } = require("../services");

const createComment = async (req, res) => {
  const { body } = req;

  try {
    const comment = await commentService.createComment(body);

    cMethod.returnSuccess(res, comment, false, message["eng"].created);
  } catch (error) {
    cMethod.returnSreverError(res, error.message);
  }
};

const getCombinedComment = async (req, res) => {
  const { body } = req;

  try {
    const filter = {};
    const { referenceId, referenceType } = body;
    filter.referenceId = { $in: referenceId };
    filter.referenceType = { $in: referenceType };

    const comment = await commentService.getComment(filter);

    cMethod.returnSuccess(res, comment, false);
  } catch (error) {
    cMethod.returnSreverError(res, error.message);
  }
};

const getCommentHierarchy = async (req, res) => {
  const { query } = req;

  try {
    const comments = await commentService.getCommentHierarchy(query);

    if (!comments.length) {
      return cMethod.returrnErrorMessage(res, "comments not found!");
    }

    const hierarchy = getValuesByKey(comments, "hierarchy", "single");

    res.status(200).json({
      status: true,
      result: hierarchy,
      totalCount: hierarchy.length,
    });
  } catch (error) {
    logger.error(error);
    cMethod.returnSreverError(res, error);
  }
};

module.exports = {
  createComment,
  getCombinedComment,
  getCommentHierarchy,
};
