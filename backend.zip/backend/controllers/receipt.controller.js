const logger = require("../config/logger");
const config = require("../config");
const message = require("../config/message");
const common = require("../middleware/common-fun");

const { receiptService } = require("../services");

const createTaxReceipt = async (req, res) => {
  const { body, headers } = req;
  const lang = headers.lang || config.lang;

  try {
    const taxReceipt = await receiptService.createTaxReceipt(body);

    if (!taxReceipt) {
      return common.returrnErrorMessage(res, message[lang].technicalError);
    }

    common.returnSuccess(res, taxReceipt, false, message[lang].created);
  } catch (error) {
    logger.error(error.message);
    common.returnSreverError(res, message[lang]?.technicalError, error);
  }
};

const getTaxReceipts = async (req, res) => {
  const { query } = req;

  try {
    const taxReceipts = await receiptService.getTaxReceipts(query);

    res.status(200).json({
      status: true,
      result: taxReceipts,
    });
  } catch (error) {
    logger.error(error);
    common.returnSreverError(res, error);
  }
};

const updateReceipt = async (req, res) => {
  const { body, params, headers } = req;
  const lang = headers.lang || config.lang;

  const { id } = params;

  try {
    if (!id) return common.returrnErrorMessage(res, "id is required!");

    const receipt = await receiptService.updateReceipt(id, body);

    if (!receipt) {
      return common.returrnErrorMessage(res, "Failed to update!");
    }

    common.returnSuccess(res, receipt, false, message[lang].profileUpdate);
  } catch (error) {
    common.returnSreverError(res, message[lang]?.technicalError, error);
  }
};

module.exports = {
  createTaxReceipt,
  getTaxReceipts,
  updateReceipt,
};
