const config = require("../config");
const logger = require("../config/logger");
const message = require("../config/message");
const common = require("../middleware/common-fun");

const { accountService } = require("../services");

const addPaymentStorage = async (req, res) => {
  const { body, headers } = req;
  const lang = headers.lang || config.lang;

  try {
    const storagePayment = await accountService.addStoragePayment(body);

    common.returnSuccess(res, storagePayment, false, message[lang].created);
  } catch (error) {
    logger.error(error.message);
    common.returnSreverError(res, message[lang]?.technicalError, error);
  }
};

module.exports = {
  addPaymentStorage,
};
