const config = require("../config");
const cMethod = require("../middleware/common-fun");
const { termsconService } = require("../services");
const { UserTnm, bidHistoryLog } = require("../modules/bid/bidModal");

const createTermsandConditions = async (req, res) => {
  try {
    let lang = req.headers["lang"] || config.lang;

    const saveUserTrn =
      await termsconService.getcreateUserTrn(req.body);

    cMethod.returnSuccess(res, saveUserTrn, false);
  } catch (error) {
    cMethod.returnSreverError(res, error.message);
  }
};
const getTermsandConditions = async (req, res) => {
  try {

    let checkstatus = req.body;
    const Status = {};
    if (checkstatus.status) {
      Status.status = checkstatus.status;
    } else {      
      console.log("---------------else");
    }
    const termsandcondition = await termsconService.gettermsandConditions(Status);

    cMethod.returnSuccess(res, termsandcondition, false);
  } catch (error) {
    cMethod.returnSreverError(res, error.message);
  }
};
const acceptTermsandConditions = async (req, res) => {
  try {
    let lang = req.headers["lang"] || config.lang;

    const saveUserTrn =
      await termsconService.acceptUser(req.body);

    cMethod.returnSuccess(res, saveUserTrn, false);
  } catch (error) {
    cMethod.returnSreverError(res, error.message);
  }
};
module.exports = {
  createTermsandConditions,
  getTermsandConditions,
  acceptTermsandConditions
};
