const config = require("../config");
const cMethod = require("../middleware/common-fun");
const { analyticsService } = require("../services");

const getSellerDashboardAnalytics = async (req, res) => {
  try {
    const {
      body: { userId },
    } = req;
    let lang = req.headers["lang"] || config.lang;

    const dashboardAnalytics =
      await analyticsService.getSellerDashboardAnalytics(userId);

    cMethod.returnSuccess(res, dashboardAnalytics, false);
  } catch (error) {
    cMethod.returnSreverError(res, error.message);
  }
};

module.exports = {
  getSellerDashboardAnalytics,
};
