const config = require("../config");
const logger = require("../config/logger");
const message = require("../config/message");
const common = require("../middleware/common-fun");

const { customInvoiceService } = require("../services");
const { createCommonLog } = require("../services/comment.service");

const createCustomInvoice = async (req, res) => {
  const { body, headers } = req;
  const lang = headers.lang || config.lang;

  try {
    const { createdBy = "system" } = body;

    const invoiceNo = await common.getCustomInvoiceNo();
    body.invoiceNo = invoiceNo;

    const customInvoice = await customInvoiceService.createCustomInvoice(body);

    if (!customInvoice) {
      return common.returrnErrorMessage(res, message[lang].technicalError);
    }

    const { _id: referenceId, invoiceNo: no } = customInvoice;

    await createCommonLog({
      action: "Created",
      from: "Account(Custom Invoice)",
      id: referenceId,
      of: "account",
      no,
      by: createdBy,
    });

    common.returnSuccess(res, customInvoice, false, message[lang].created);
  } catch (error) {
    logger.error(error.message);
    common.returnSreverError(res, message[lang]?.technicalError, error);
  }
};

const getCustomInvoices = async (req, res) => {
  const { query } = req;

  const { page, pageLimit } = query;

  try {
    const customInvoices = await customInvoiceService.getCustomInvoices(query);

    const { result = [], totalCount } = customInvoices || {};

    res.status(200).json({
      status: true,
      result,
      hasMore: common.hasMoreCount(totalCount, page, pageLimit),
      totalCount,
    });
  } catch (error) {
    logger.error(error);
    common.returnSreverError(res, error);
  }
};

const getCustomInvoice = async (req, res) => {
  const { params } = req;

  const { id } = params;

  try {
    if (!id) return common.returrnErrorMessage(res, "id is required!");

    const customInvoice = await customInvoiceService.getCustomInvoice(id);

    if (!customInvoice) {
      return common.returrnErrorMessage(res, "Custom invoice not found!");
    }

    res.status(200).json({
      status: true,
      result: customInvoice,
      hasMore: false,
    });
  } catch (error) {
    logger.error(error);
    common.returnSreverError(res, error);
  }
};

const updateCustomInvoice = async (req, res) => {
  const { body, params, headers } = req;
  const lang = headers.lang || config.lang;

  const { id } = params;

  try {
    if (!id) return common.returrnErrorMessage(res, "id is required!");

    const customInvoice = await customInvoiceService.updateCustomInvoice(
      id,
      body
    );

    if (!customInvoice) {
      return common.returrnErrorMessage(res, "Failed to update!");
    }

    common.returnSuccess(
      res,
      customInvoice,
      false,
      message[lang].profileUpdate
    );
  } catch (error) {
    common.returnSreverError(res, message[lang]?.technicalError, error);
  }
};

const deleteCustomInvoice = async (req, res) => {
  const { params, headers } = req;
  const lang = headers.lang || config.lang;

  const { id } = params;
  try {
    if (!id) return common.returrnErrorMessage(res, "id is required!");

    const customInvoice = await customInvoiceService.deleteCustomInvoice(id);

    if (!customInvoice) {
      return common.returrnErrorMessage(res, "Failed to delete!");
    }

    common.returnSuccess(res, message[lang].Deleteed);
  } catch (error) {
    common.returnSreverError(res, error.message);
  }
};

const getCustomDocs = async (req, res) => {
  const { params } = req;

  const { id } = params;

  try {
    const customInvoices = await customInvoiceService.getCustomDocs(id);

    const [invoice = {}] = customInvoices;

    res.status(200).json({
      status: true,
      result: invoice,
    });
  } catch (error) {
    logger.error(error);
    common.returnSreverError(res, error);
  }
};

module.exports = {
  createCustomInvoice,
  getCustomInvoices,
  getCustomInvoice,
  updateCustomInvoice,
  deleteCustomInvoice,
  getCustomDocs,
};
