const config = require("../config");
const logger = require("../config/logger");
const message = require("../config/message");
const common = require("../middleware/common-fun");

const { masterService } = require("../services");

const createCustomService = async (req, res) => {
  const { body, headers } = req;
  const lang = headers.lang || config.lang;

  try {
    const customService = await masterService.createCustomService(body);

    if (!customService) {
      return common.returrnErrorMessage(res, message[lang].technicalError);
    }

    common.returnSuccess(res, customService, false, message[lang].created);
  } catch (error) {
    logger.error(error.message);
    common.returnSreverError(res, message[lang]?.technicalError, error);
  }
};

const getCustomServices = async (req, res) => {
  const { query } = req;

  const { page, pageLimit } = query;

  try {
    const customServices = await masterService.getCustomServices(query);

    const { result = [], totalCount } = customServices || {};

    res.status(200).json({
      status: true,
      result,
      hasMore: common.hasMoreCount(totalCount, page, pageLimit),
      totalCount,
    });
  } catch (error) {
    logger.error(error);
    common.returnSreverError(res, error);
  }
};

const getCustomService = async (req, res) => {
  const { params } = req;

  const { id } = params;

  try {
    if (!id) return common.returrnErrorMessage(res, "id is required!");

    const customService = await masterService.getCustomService(id);

    if (!customService) {
      return common.returrnErrorMessage(res, "Custom service not found!");
    }

    res.status(200).json({
      status: true,
      result: customService,
      hasMore: false,
    });
  } catch (error) {
    logger.error(error);
    common.returnSreverError(res, error);
  }
};

const updateCustomService = async (req, res) => {
  const { body, params, headers } = req;
  const lang = headers.lang || config.lang;

  const { id } = params;

  try {
    if (!id) return common.returrnErrorMessage(res, "id is required!");

    const customService = await masterService.updateCustomService(id, body);

    if (!customService) {
      return common.returrnErrorMessage(res, "Failed to update!");
    }

    common.returnSuccess(
      res,
      customService,
      false,
      message[lang].profileUpdate
    );
  } catch (error) {
    common.returnSreverError(res, message[lang]?.technicalError, error);
  }
};

const deleteCustomService = async (req, res) => {
  const { params, headers } = req;
  const lang = headers.lang || config.lang;

  const { id } = params;
  try {
    if (!id) return common.returrnErrorMessage(res, "id is required!");

    const customService = await masterService.deleteCustomService(id);

    if (!customService) {
      return common.returrnErrorMessage(res, "Failed to delete!");
    }

    common.returnSuccess(res, message[lang].Deleteed);
  } catch (error) {
    common.returnSreverError(res, error.message);
  }
};

module.exports = {
  createCustomService,
  getCustomServices,
  getCustomService,
  updateCustomService,
  deleteCustomService,
};
