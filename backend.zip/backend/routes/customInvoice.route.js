const express = require("express");
const { validateFieldValue } = require("../middleware/validation");
const { customInvoiceController } = require("../controllers");

const router = express.Router();

const requiredFields = [
  "serviceName",
  "serviceGlId",
  "branchId",
  "userId",
  "createdBy",
  "serviceCharges",
  "serviceVat",
  "total",
];

router
  .route("/invoice")
  .post(
    [validateFieldValue(requiredFields, requiredFields)],
    customInvoiceController.createCustomInvoice
  )
  .get(customInvoiceController.getCustomInvoices);

router
  .route("/invoice/:id")
  .get(customInvoiceController.getCustomInvoice)
  .patch(customInvoiceController.updateCustomInvoice)
  .delete(customInvoiceController.deleteCustomInvoice);

router.get("/invoice/docs/:id", customInvoiceController.getCustomDocs);

module.exports = router;

/**
 * @swagger
 * /api/custom/invoice:
 *   post:
 *     tags: [Custom Invoice]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: serviceName
 *         in: formData
 *         type: string
 *         required: true
 *       - name: serviceId
 *         in: formData
 *         type: string
 *         required: false
 *       - name: serviceGlId
 *         in: formData
 *         type: string
 *         required: true
 *       - name: branchId
 *         in: formData
 *         type: string
 *         required: true
 *       - name: userId
 *         in: formData
 *         type: string
 *         required: true
 *       - name: createdBy
 *         in: formData
 *         type: string
 *         required: true
 *       - name: serviceCharges
 *         in: formData
 *         type: number
 *         required: true
 *       - name: serviceVat
 *         in: formData
 *         type: number
 *         required: true
 *       - name: total
 *         in: formData
 *         type: number
 *         required: true
 *       - name: description
 *         in: formData
 *         type: string
 *         required: false
 *     responses:
 *       200:
 *         description: Custom Invoice - Create
 */

/**
 * @swagger
 * /api/custom/invoice:
 *   get:
 *     tags: [Custom Invoice]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: customInvoiceId
 *         in: query
 *         type: string
 *         required: false
 *       - name: pageLimit
 *         in: query
 *         type: number
 *         required: true
 *       - name: page
 *         in: query
 *         type: string
 *         required: true
 *     responses:
 *       200:
 *         description: Custom Invoice - Get
 */

/**
 * @swagger
 * /api/custom/invoice/{id}:
 *   get:
 *     tags: [Custom Invoice]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: id
 *         in: path
 *         type: string
 *         required: false
 *     responses:
 *       200:
 *         description: Custom Invoice - Get One
 */

/**
 * @swagger
 * /api/custom/invoice/{id}:
 *   patch:
 *     tags: [Custom Invoice]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: id
 *         in: path
 *         type: string
 *         required: false
 *       - name: status
 *         in: formData
 *         type: string
 *         required: false
 *     responses:
 *       200:
 *         description: Custom Invoice - Update
 */

/**
 * @swagger
 * /api/custom/invoice/{id}:
 *   delete:
 *     tags: [Custom Invoice]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: id
 *         in: path
 *         type: string
 *         required: false
 *     responses:
 *       200:
 *         description: Custom Invoice - Delete
 */

/**
 * @swagger
 * /api/custom/invoice/docs/{id}:
 *   get:
 *     tags: [Custom Invoice]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: id
 *         in: path
 *         type: string
 *         required: true
 *     responses:
 *       200:
 *         description: Custom Invoice - Get Docs (Tax Invoice/Payment Voucher)
 */
