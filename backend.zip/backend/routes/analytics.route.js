const express = require("express");
const { validateFieldValue } = require("../middleware/validation");
const { analyticsController } = require("../controllers");

const router = express.Router();

router.post(
  "/seller-dashboard-analytics",
  [validateFieldValue(["userId"], ["userId"])],
  analyticsController.getSellerDashboardAnalytics
);

module.exports = router;

/**
 * @swagger
 * /api/analytics/seller-dashboard-analytics:
 *   post:
 *     tags: [Analytics]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: userId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: Analytics - Get Seller Dashboard Analytics
 */
