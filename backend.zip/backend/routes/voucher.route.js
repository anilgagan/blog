const express = require("express");
const { validateFieldValue } = require("../middleware/validation");
const { voucherController } = require("../controllers");

const router = express.Router();

router.post(
  "/create-vouchers",
  [validateFieldValue([], [])],
  voucherController.createVouchers
);

module.exports = router;

/**
 * @swagger
 * /api/voucher/create-vouchers:
 *   post:
 *     tags: [Voucher]
 *     produces:
 *       - application/json
 *     responses:
 *       200:
 *         description: Vouchers - Create
 */
