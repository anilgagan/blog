const express = require("express");
const { validateFieldValue } = require("../middleware/validation");
const { termsconditionController } = require("../controllers");

const router = express.Router();

router.post(
  "/add-terms-condition",
  //[validateFieldValue(["userId"], ["userId"])],
  termsconditionController.createTermsandConditions
);
router.post(
  "/get-terms-condition",
  //[validateFieldValue(["userId"], ["userId"])],
  termsconditionController.getTermsandConditions
);
router.post(
  "/accept-terms-condition",
  //[validateFieldValue(["userId"], ["userId"])],
  termsconditionController.acceptTermsandConditions
);
module.exports = router;

/**
 * @swagger
 * /api/termscondition/add-terms-condition:
 *   post:
 *     tags: [Termscondition]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: title_eng
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: title_arbic
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: description_eng
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: decription_arbic
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: Termscondition - Termscondition
 */
/**
 * @swagger
 * /api/termscondition/get-terms-condition:
 *   post:
 *     tags: [Termscondition]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: status
 *         in: formData
 *         type: Number
 *         required: false
 *         description: 0,1
 *     responses:
 *       200:
 *         description: Termscondition - Termscondition
 */
/**
 * @swagger
 * /api/termscondition/accept-terms-condition:
 *   post:
 *     tags: [Termscondition]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: userId
 *         in: formData
 *         type: string
 *         required: true
 *       - name: tnmId
 *         in: formData
 *         type: string
 *         required: true
 *     responses:
 *       200:
 *         description: Termscondition - Termscondition
 */