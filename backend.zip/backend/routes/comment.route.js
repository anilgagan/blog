const express = require("express");
const { commentController } = require("../controllers");

const router = express.Router();

router.post("/create", commentController.createComment);

router.post("/get-combined", commentController.getCombinedComment);

router.get("/get-comment-hierarchy", commentController.getCommentHierarchy);

module.exports = router;

/**
 * @swagger
 * /api/comment/create:
 *   post:
 *     tags: [Comment]
 *     produces:
 *       - application/json
 *     responses:
 *       200:
 *         description: Comment - Create
 */

/**
 * @swagger
 * /api/comment/get-combined:
 *   post:
 *     tags: [Comment]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: referenceId[]
 *         in: formData
 *         type: array
 *         items:
 *           type: string
 *         collectionFormat: multi
 *       - name: referenceType[]
 *         in: formData
 *         type: array
 *         items:
 *           type: string
 *         collectionFormat: multi
 *     responses:
 *       200:
 *         description: Comment - Combine
 */

/**
 * @swagger
 * /api/comment/get-comment-hierarchy:
 *   get:
 *     tags: [Comment]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: referenceName
 *         in: query
 *         type: string
 *     responses:
 *       200:
 *         description: Comment - Get Hierarchy
 */
