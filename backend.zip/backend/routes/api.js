const userModule = require("../modules/user");
const inventoryModule = require("../modules/inventory");
const auctionModule = require("../modules/auction");
const recieptModule = require("../modules/reciept");
const salerecieptModule = require("../modules/saleReciept");
const vinModule = require("../modules/vin");
const carModule = require("../modules/car");
const masterModule = require("../modules/master");
const sapModule = require("../modules/sap");
const accountModule = require("../modules/account");
const qwaitingModule = require("../modules/qwaiting");
const uploadModule = require("../modules/upload");
const { create } = require("express-handlebars");
const bidAPIs = require("./../modules/bid/apiRoute");
const Order = require("./../modules/order");
const {
  voucherRoute,
  analyticsRoute,
  commentRoute,
  termsconditionRoute,
  customInvoiceRoute,
} = require(".");

module.exports = function (app) {
  app.use("/api/user", userModule);
  app.use("/api/inventory", inventoryModule);
  app.use("/api/auction", auctionModule);
  app.use("/api/reciept", recieptModule);
  app.use("/api/salereciept", salerecieptModule);
  app.use("/api/vin", vinModule);
  app.use("/api/car", carModule);
  app.use("/api/upload", uploadModule);
  app.use("/api/master", masterModule);
  app.use("/api/sap", sapModule);
  app.use("/api/account", accountModule);
  app.use("/api/qwaiting", qwaitingModule);
  app.use("/api/order", Order);
  app.use("/api/bid", bidAPIs);
  app.use("/api/voucher", voucherRoute);
  app.use("/api/analytics", analyticsRoute);
  app.use("/api/comment", commentRoute);
  app.use("/api/termscondition", termsconditionRoute);
  app.use("/api/custom", customInvoiceRoute);
};
