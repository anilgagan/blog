module.exports.voucherRoute = require("./voucher.route");
module.exports.analyticsRoute = require("./analytics.route");
module.exports.commentRoute = require("./comment.route");
module.exports.termsconditionRoute = require("./termscondition.route");
module.exports.customInvoiceRoute = require("./customInvoice.route");
