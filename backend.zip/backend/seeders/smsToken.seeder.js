const mongoose = require("mongoose");

const logger = require("../config/logger");
const { smLogin } = require("../services/sms.service");
const { updateToken } = require("../services/token.service");

const {
  tokenTypes: { SMS },
} = require("../config/tokens");

const seedSMSToken = async () => {
  logger.info("STARTING SMS TOKEN SEEDER!");

  const generateToken = await smLogin();

  if (!generateToken) {
    logger.error(
      "Failed to generate token, kindly contact smart messaging service!"
    );
    return;
  }

  const data = {
    token: generateToken,
    type: SMS,
  };

  try {
    const filter = { type: SMS };
    const options = {
      upsert: true,
      new: true,
      setDefaultsOnInsert: true,
    };

    await updateToken(filter, data, options);
    logger.info("SMS Token has been created successfully!");
  } catch (error) {
    console.error("Error seeding the token:", error);
  } finally {
    mongoose.connection.close();
  }
};

mongoose.connect(process.env.MONGODB_WRITE_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

seedSMSToken();
