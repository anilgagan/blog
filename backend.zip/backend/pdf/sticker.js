const fs = require("fs");
const path = require("path");
const { PDFDocument, PageSizes } = require("pdf-lib");
const fontkit = require("fontkit");
const logger = require("../config/logger");
const { customSlice } = require("../functions/global.functions");

// * constants
const HEADER_HEIGHT = 80;
const FOOTER_HEIGHT = 180;

const FONT_SMALL = 35;
const FONT_LARGE = 60;

const MARGIN = 20;

const generateStickerPDF = async (data, outputPath) => {
  try {
    const doc = await PDFDocument.create();
    doc.registerFontkit(fontkit);

    const header = path.join(process.cwd(), "public/images/header.png");
    const footer = path.join(process.cwd(), "public/images/footer.png");

    const regularPath = path.join(
      process.cwd(),
      "pdf/fonts/calibri/regular.ttf"
    );
    const boldPath = path.join(process.cwd(), "pdf/fonts/calibri/bold.ttf");
    const regularBytes = fs.readFileSync(regularPath);
    const boldBytes = fs.readFileSync(boldPath);

    // * fonts
    const regular = await doc.embedFont(regularBytes);
    const bold = await doc.embedFont(boldBytes);

    const drawCenteredText = async (page, text, vertical, fontSize, font) => {
      const { width, height } = page.getSize();

      const textWidth = font.widthOfTextAtSize(text, fontSize);
      const centerX = (width - textWidth) / 2;
      const y = height - vertical;

      page.drawText(text, {
        x: centerX,
        y: y,
        size: fontSize,
        font: font,
      });
    };

    // * header
    const addHeader = async (page) => {
      const { width, height } = page.getSize();
      const headerImage = await doc.embedPng(fs.readFileSync(header));

      page.drawImage(headerImage, {
        x: MARGIN,
        y: height - HEADER_HEIGHT - MARGIN,
        width: width - 2 * MARGIN,
        height: HEADER_HEIGHT,
      });
    };

    // * footer
    const addFooter = async (page) => {
      const { width } = page.getSize();
      const footerImage = await doc.embedPng(fs.readFileSync(footer));

      page.drawImage(footerImage, {
        x: MARGIN,
        y: MARGIN,
        width: width - 2 * MARGIN,
        height: FOOTER_HEIGHT,
      });
    };

    for (const item of data) {
      const page = doc.addPage(PageSizes.A4);

      const truncVin = customSlice(item.vin, "end", 6);

      const year = item.year || "";
      const make = item.make || "";
      const model = item.model || "";
      const lotVinDisplay = `LOT (${item.lotNo || ""}) SEQ (${
        item.displayNo || ""
      }) VIN (${truncVin || ""})`;
      const startBid = `${item.startingBid || 0} AED`;

      await addHeader(page);
      await drawCenteredText(page, year, 180, FONT_LARGE, bold);
      await drawCenteredText(page, make, 280, FONT_LARGE, bold);
      await drawCenteredText(page, model, 380, FONT_LARGE, bold);
      await drawCenteredText(page, lotVinDisplay, 470, FONT_SMALL, regular);
      await drawCenteredText(page, startBid, 580, FONT_LARGE, bold);
      await addFooter(page);
    }

    fs.writeFileSync(outputPath, await doc.save());

    logger.info(`Generated PDF: ${outputPath}`);

    return outputPath;
  } catch (error) {
    logger.error(error);
  }
};

module.exports = generateStickerPDF;
