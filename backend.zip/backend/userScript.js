const User = require('./modules/user/userModal')
const { storeHash, encrypt} = require("./middleware/redisConnection");
const config = require("./config");
module.exports.init = async () => {
    if(config.redisFlag){
        try {
            let status=true
            let skip=0;
            while(status){
                let total = await User.User.find({}, {_id:1, userId:1, fcmToken:1,name:1, NotifyType:1 }).skip(skip).limit(100)
                if(total.length > 0){
                    await storeHash('NOCK-'+skip, total)
                }else{
                    status=false
                }
                skip+=100;
            }
        } catch (e) {
            console.log(e)
        }
    }else{
        return false
    }

};

module.exports.reCreate = async (skip) => {
    if(config.redisFlag){
        try {
            let total = await User.User.find({notifyStatus:true, fcmToken:{$ne:""}}, {_id:1, userId:1, fcmToken:1,name:1, NotifyType:1 }).skip(skip).limit(100)
            await storeHash('NOCK-'+skip, total)
        } catch (e) {
            console.log(e)
        }
    }else{
       return false
    }

};