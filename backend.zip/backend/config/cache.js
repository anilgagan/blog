const NodeCache = require("node-cache");

const cacheTime = 3600; // * 60 min (1 hour)

const cache = new NodeCache({ stdTTL: cacheTime }); // * 1 day (24 hours)

const getCachedData = (cacheKey) => {
  const cachedData = cache.get(cacheKey);
  return cachedData || false;
};

const setCachedData = (cacheKey, data, ttl = cacheTime) => {
  cache.set(cacheKey, data, ttl);
};

const getAllCacheKeys = () => {
  return cache.keys();
};

const flushAllKeys = () => {
  cache.flushAll();
  return cache.keys().length === 0;
};

const cacheMiddleware = (req, res, next) => {
  const { path } = req;

  const cachedData = getCachedData(path);

  if (cachedData) return res.status(200).json(cachedData);

  next();
};

module.exports = {
  cacheMiddleware,
  getCachedData,
  setCachedData,
  getAllCacheKeys,
  flushAllKeys,
};
