const users = [];

// Join user to chat
function newAuctionUser(id, username, room) {
    const user = { id, username, room };

    // Clean the data
    username = username.trim().toLowerCase()
    room = room.trim().toLowerCase()

    // Validate the data
    if (!username || !room) {
        return {
            error: 'Username and room are required!'
        }
    }

    // Check for existing user
    const existingUser = users.find((user) => {
        return user.room === room && user.username === username
    })

    // Validate username
    if (existingUser) {
        return {
            error: 'Username is in use!'
        }
    }
    

    users.push(user);

    return user;
}

// Get current user
function getActiveUser(id) {
    return users.find((user) => user.id === id);
}

// User leaves chat
function exitRoom(id) {
    const index = users.findIndex((user) => user.id === id);

    if (index !== -1) {
        return users.splice(index, 1)[0];
    }
}

// Get room users
function getIndividualAuctionUsers(room) {
    return users.filter((user) => user.room === room);
}

module.exports = {
    newAuctionUser,
    getActiveUser,
    exitRoom,
    getIndividualAuctionUsers,
};
