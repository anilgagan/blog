const tokenTypes = {
  SMS: "sms",
};

module.exports = {
  tokenTypes,
};
