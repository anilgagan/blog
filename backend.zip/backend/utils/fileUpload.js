const multer = require("multer");
const path = require("path");

const filePath = "public/temp";

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, filePath);
  },

  filename: (req, file, cb) => {
    cb(
      null,
      file.fieldname + "-" + Date.now() + path.extname(file.originalname)
    );
  },
});

const fileUpload = multer({ storage });

const imageFilter = (req, file, cb) => {
  if (
    !file.originalname.match(
      /\.(jpg|JPG|jpeg|JPEG|png|PNG|gif|GIF|mp4|mp3|csv|xlsx)$/
    )
  ) {
    req.fileValidationError = "Only image and csv files are allowed!";
    return cb(new Error("Only image and csv files are allowed!"), false);
  }
  cb(null, true);
};

module.exports = {
  fileUpload,
  imageFilter,
};
