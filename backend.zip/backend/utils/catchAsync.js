const fs = require("fs");
const { log: info, error: _error } = console;

const singleFileCleaner = async (file) => {
  if (!file) return;

  try {
    await fs.unlink(`./${file.path}`, (err) => {
      if (err) {
        _error(
          `Error while cleaning single file with this path ===>- ./${file.path}`
        );
      } else {
        info(`File deleted on this path ===> - ./${file.path}`);
      }
    });
  } catch (error) {
    _error(
      `Error catch while cleaning single file with this path - ./${file.path}`
    );
  }
};

const multiFileCleaner = async (files) => {
  if (!files.length) return;

  let i = 0;

  try {
    for (i; i < files.length; i += 1) {
      (async () => {
        await fs.unlink(`./${files[i].path}`, (err) => {
          if (err) {
            _error(
              `Error while cleaning multiple file with this path ===>- ./${files[i].path}`
            );
          } else {
            info(`File deleted on this path ===> - ./${files[i].path}`);
          }
        });
      })();
    }
  } catch (error) {
    _error(
      `Error while cleaning multiple file with this path - ./${files[i].path}`
    );
  }
};

const catchAsync = (fn) => (req, res, next) => {
  Promise.resolve(fn(req, res, next)).catch((err) => {
    logger.error("Catching Global Async Error: ", err);
    next(err);

    const { file, files } = req;

    if (file && Object.keys(file).length) singleFileCleaner(file);
    if (files && files.length) multiFileCleaner(files);
  });
};

module.exports = { catchAsync, singleFileCleaner, multiFileCleaner };
