const reciept = require("../reciept/recieptModal");
const inventory = require("../inventory/inventoryModal");
const user = require("../user/userModal");
const account = require("../account/accountModal");
const message = require("../../config/message");
const jwt = require("jsonwebtoken");
const config = require("../../config");
const midleware = require("../../middleware/validation");
const cmethod = require("../../middleware/common-fun");
var mongoose = require("mongoose");
const { connWrite } = require("./../../config/database");
const auctionModal = require("../auction/auctionModal");
const sapDao = require("../sap/sapDao");
const {
  toUpperCase,
  isEmptyObject,
} = require("../../functions/global.functions");
const { addReceiptPayment } = require("../../services/receipt.service");
const logger = require("../../config/logger");

const recieptAdd = async function (res, postData) {
  const { cardPayment = {} } = postData;

  const newReceipt = new reciept.Reciept(postData);

  newReceipt.save(postData, async function (err, data) {
    if (err) {
      cmethod.returnSreverError(res, message.technicalError, err);
    } else {
      // * inventory
      const vinData = await inventory.Inventory.findOne(
        { _id: mongoose.Types.ObjectId(data?.inventoryId) },
        {
          vin: 1,
          sellerId: 1,
          warehosId: 1,
        }
      ).sort({ createdAt: -1 });

      // * seller
      const sellerData = await user.User.findOne(
        { _id: mongoose.Types.ObjectId(vinData?.sellerId) },
        {
          uniqueIdentifier: 1,
          name: 1,
        }
      ).sort({ createdAt: -1 });
      let sellerNo;
      let sellerName = "";
      if (sellerData) {
        sellerNo = sellerData?.uniqueIdentifier;
        sellerName = sellerData?.name;
        sellerName = toUpperCase(sellerName);
      }

      // * buyer
      const buyerData = await user.User.findOne(
        { _id: mongoose.Types.ObjectId(data?.buyerId) },
        {
          uniqueIdentifier: 1,
          name: 1,
        }
      ).sort({ createdAt: -1 });
      let buyerNo;
      let buyerName = "";
      if (buyerData) {
        buyerNo = buyerData?.uniqueIdentifier;
        buyerName = buyerData?.name;
        buyerName = toUpperCase(buyerName);
      }

      let vinNo = vinData?.vin;
      if (data.recieptType == "sold") {
        const paidAmount = data.paidAmount;
        const description = `TO RECORD ADVANCE RECEIVED FROM ${buyerName} AGAINST ${sellerName} VIN# ${vinNo} INV NO# ${data.recieptNo}`;
        let ledgerData = [];

        // * auction vehicle
        await auctionModal.Auctionvehicle.updateOne(
          { _id: mongoose.Types.ObjectId(postData?.auctionVehicleId) },
          { $set: { status: "sold" } }
        );

        // * inventory
        await inventory.Inventory.updateOne(
          { _id: mongoose.Types.ObjectId(data.inventoryId) },
          { $set: { inventoryStatus: 3 } }
        );

        // * account ledger
        let voucherNoUnique = await cmethod.getVoucherNo();

        // * transaction-fee
        let transactionFee = 0;
        if (data.paymentMethod == "card" && paidAmount > 0) {
          const accountTransactData = await account.Accountmaster.findOne(
            { markAccountId: "transaction-fee" },
            {
              markAccountId: 1,
            }
          ).sort({ createdAt: -1 });
          let transactionAccountId = accountTransactData?._id;

          transactionFee = Math.round((data?.paidAmount * 2) / 100);
          ledgerData.push({
            branchId: mongoose.Types.ObjectId(data.branchId),
            glAccountId: mongoose.Types.ObjectId(transactionAccountId),
            voucherNo: voucherNoUnique,
            transactionType: "cr",
            paymentType: data.paymentMethod,
            payAmount: Number(transactionFee),
            referenceType: "reciept",
            description,
            //referenceId: mongoose.Types.ObjectId(data._id),
            referenceNo: data.recieptNo,
            referenceNo2: vinNo,
            buyerNo: buyerNo,
            sellerNo: sellerNo,
            createdBy: data?.createdBy,
            transDate: data?.transDate,
            transactionOf: "buyer",
          });
        }

        // * (cash + card + online)
        let accountType;
        let advanceAccountId;
        if (paidAmount > 0) {
          if (data.paymentMethod == "cash") {
            accountType = "cash-in-hand";
            const accountData = await account.Accountmaster.findOne(
              { markAccountId: accountType },
              {
                markAccountId: 1,
              }
            ).sort({ createdAt: -1 });
            advanceAccountId = accountData?._id;
          } else if (data.paymentMethod == "card") {
            accountType = [
              "cash-in-bank-sajja",
              "cash-in-bank-ind",
              "cash-in-bank-sharj",
            ];
            const accountData = await account.Accountmaster.findOne(
              {
                markAccountId: { $in: accountType },
                branchId: mongoose.Types.ObjectId(data?.branchId),
              },
              {
                markAccountId: 1,
              }
            ).sort({ createdAt: -1 });
            advanceAccountId = accountData?._id;
          } else {
            accountType = "cash-in-bank";
            const accountData = await account.Accountmaster.findOne(
              { markAccountId: accountType },
              {
                markAccountId: 1,
              }
            ).sort({ createdAt: -1 });
            advanceAccountId = accountData?._id;
          }

          ledgerData.push({
            branchId: mongoose.Types.ObjectId(data.branchId),
            glAccountId: mongoose.Types.ObjectId(advanceAccountId),
            voucherNo: voucherNoUnique,
            transactionType: "dr",
            paymentType: data.paymentMethod,
            payAmount: Number(data.paidAmount) + transactionFee,
            referenceType: "reciept",
            description,
            referenceNo: data.recieptNo,
            referenceNo2: vinNo,
            buyerNo: buyerNo,
            sellerNo: sellerNo,
            createdBy: data?.createdBy,
            transDate: data?.transDate,
            transactionOf: "buyer",
          });
        }

        // * receivable
        const accountRecievableData = await account.Accountmaster.findOne(
          { markAccountId: "receivable" },
          {
            markAccountId: 1,
          }
        ).sort({ createdAt: -1 });
        let recievableAccountId = accountRecievableData?._id;
        ledgerData.push({
          branchId: mongoose.Types.ObjectId(data.branchId),
          glAccountId: mongoose.Types.ObjectId(recievableAccountId),
          voucherNo: voucherNoUnique,
          transactionType: "dr",
          paymentType: data.paymentMethod,
          payAmount: Number(data?.totalNetAmount) - Number(data?.paidAmount),
          referenceType: "reciept",
          description,
          // referenceId: mongoose.Types.ObjectId(data._id),
          referenceNo: data.recieptNo,
          referenceNo2: vinNo,
          buyerNo: buyerNo,
          sellerNo: sellerNo,
          createdBy: data?.createdBy,
          transDate: data?.transDate,
          transactionOf: "buyer",
        });

        // * sales
        const accountSalesData = await account.Accountmaster.findOne(
          { markAccountId: "sales" },
          {
            markAccountId: 1,
          }
        ).sort({ createdAt: -1 });
        let salesAccountId = accountSalesData?._id;
        ledgerData.push({
          branchId: mongoose.Types.ObjectId(data.branchId),
          glAccountId: mongoose.Types.ObjectId(salesAccountId),
          voucherNo: voucherNoUnique,
          transactionType: "cr",
          paymentType: data.paymentMethod,
          payAmount: Number(data?.saleAmount) - Number(data?.discount),
          referenceType: "reciept",
          description,
          //referenceId: mongoose.Types.ObjectId(data._id),
          referenceNo: data.recieptNo,
          referenceNo2: vinNo,
          buyerNo: buyerNo,
          sellerNo: sellerNo,
          createdBy: data?.createdBy,
          transDate: data?.transDate,
          transactionOf: "buyer",
        });

        // * vat
        if (data?.taxType == "tax" || data?.taxType == "security") {
          let groupAcoountId;
          let groupAcoountType;

          if (data?.taxType == "tax") {
            groupAcoountType = "vat";
          } else {
            groupAcoountType = "security";
          }
          const accountGroupData = await account.Accountmaster.findOne(
            { markAccountId: groupAcoountType },
            {
              markAccountId: 1,
            }
          ).sort({ createdAt: -1 });
          groupAcoountId = accountGroupData?._id;
          ledgerData.push({
            branchId: mongoose.Types.ObjectId(data.branchId),
            glAccountId: mongoose.Types.ObjectId(groupAcoountId),
            voucherNo: voucherNoUnique,
            transactionType: "cr",
            paymentType: data.paymentMethod,
            payAmount: Number(data?.securityAmount),
            referenceType: "reciept",
            description,
            //referenceId: mongoose.Types.ObjectId(data._id),
            referenceNo: data.recieptNo,
            referenceNo2: vinNo,
            buyerNo: buyerNo,
            sellerNo: sellerNo,
            createdBy: data?.createdBy,
            transDate: data?.transDate,
            transactionOf: "buyer",
          });
        }

        await account.Accountledger.insertMany(ledgerData);
        // await sapDao.sapincomingPaymnent(voucherNoUnique);

        // * document pass
        let docNoUnique = await cmethod.getDocumentpass();
        let savegetDocumentData = {
          passNo: docNoUnique,
          direction: "out",
          referenceType: "reciept",
          referenceNo: data?.recieptNo,
          status: "pending",
          referenceId: mongoose.Types.ObjectId(data?._id),
          inventoryId: mongoose.Types.ObjectId(data?.inventoryId),
          branchId: mongoose.Types.ObjectId(data.branchId),
          warehosId: mongoose.Types.ObjectId(vinData?.warehosId),
          createdBy: data?.createdBy,
        };
        await cmethod.addgetDocument(savegetDocumentData);

        // * gate pass
        let passNoUnique = await cmethod.getPassNo();
        let savegetPassData = {
          passNo: passNoUnique,
          direction: "out",
          referenceType: "reciept",
          referenceNo: data?.recieptNo,
          referenceId: mongoose.Types.ObjectId(data?._id),
          inventoryId: mongoose.Types.ObjectId(data?.inventoryId),
          status: "pending",
          gatePassExpired: postData?.gatePassExpired,
          gatePassExpiredDate: postData?.gatePassExpired,
          createdBy: data?.createdBy,
        };
        await cmethod.addgetPass(savegetPassData);
      }

      if (postData?.deleteRecieptId) {
        let cond = { _id: mongoose.Types.ObjectId(postData?.deleteRecieptId) };
        reciept.Reciept.deleteOne(cond, function (err, data) {});
      }

      // * comment
      let saveCommentLogData = {
        referenceType: "reciept",
        referenceId: data?._id,
        message: "reciept created by washi",
        commentBy: data?.createdBy,
      };
      cmethod.addcommentsLog(saveCommentLogData);

      // * card simultaneous payment
      if (!isEmptyObject(cardPayment)) {
        if (!data) {
          logger.error("Error creating receipt!");
          return;
        }

        const { paidAmount, paymentMethod } = cardPayment;

        const totalAmountPaid = paidAmount + data.paidAmount;
        const totalAmountDue = data.dueBalance - paidAmount;

        const paymentData = {
          recieptId: [data._id],
          payAmount: [paidAmount],
          payStorageAmount: [null],
          paidAmount: [totalAmountPaid],
          dueAmount: [totalAmountDue],
          paymentMethod: [paymentMethod],
          createdBy: [data.createdBy],
          transDate: [data.transDate],
          branchId: null,
        };

        await addReceiptPayment(paymentData);
      }

      cmethod.returnSuccess(res, data, false, message.successfully);
    }
  });
};
const findRecieptWithFiled = async function (query) {
  return new Promise(function (resolve, reject) {
    reciept.Reciept.find(
      { costPrice: { $exists: true } },
      { make: 1, model: 1 },
      function (err, data) {
        if (err) {
          reject(err);
        } else {
          resolve(data);
        }
      }
    );
  });
};
const findRecieptAggregation = function (query) {
  return new Promise(function (resolve, reject) {
    reciept.Reciept.aggregate(query, function (err, data) {
      if (err) {
        reject(err);
      } else {
        resolve(data);
      }
    });
  });
};
const findLedgerAggregation = function (query) {
  return new Promise(function (resolve, reject) {
    reciept.Ledger.aggregate(query, function (err, data) {
      if (err) {
        reject(err);
      } else {
        resolve(data);
      }
    });
  });
};

const ledgerAdd = async function (res, postData) {
  const newLedger = new reciept.Ledger(postData);

  newLedger.save(postData, async function (err, data) {
    if (err) {
      cmethod.returnSreverError(res, message.technicalError, err);
    } else {
      cmethod.returnSuccess(res, data, false, message.successfully);
    }
  });
};

const findSalesReturnAggregation = function (query) {
  return new Promise(function (resolve, reject) {
    reciept.Salesreturn.aggregate(query, function (err, data) {
      if (err) {
        reject(err);
      } else {
        resolve(data);
      }
    });
  });
};

//incoming Cash
const incomingCachAdd = async function (res, postData) {
  const newMaster = new reciept.IncomingCash(postData);
  newMaster.save(postData, async function (err, data) {
    if (err) {
      cmethod.returnSreverError(res, message.technicalError, err);
    } else {
      //insert ledger
      // let ledgerData = [];
      // let queryCond = {
      //   $and: [{ entryType: "ledger" }],
      // };

      // const ledgerDatadb = await reciept.Ledger.findOne(queryCond, {
      //   balanceAmount: 1,
      // }).sort({ createdAt: -1 });
      // let balanceAmount = 0;
      // if (ledgerDatadb?.balanceAmount) {
      //   //only for cash rest as it is
      //   if (data.paymentType == "cash") {
      //     if(data.transactionType=='dr'){
      //       balanceAmount =
      //       Number(data.amount) + ledgerDatadb?.balanceAmount;
      //     } else {
      //       balanceAmount =
      //       ledgerDatadb?.balanceAmount-Number(data.amount);
      //     }

      //   } else {
      //     balanceAmount = ledgerDatadb?.balanceAmount;
      //   }
      // } else if (data.paymentType == "cash") {
      //   //only for cash rest as it is
      //   balanceAmount = Number(data.amount);
      // }
      // /*for get and add totalBalance */
      // ledgerData.push({
      //   recieptId: mongoose.Types.ObjectId(data._id),
      //   entryType: "ledger",
      //   ledgerType: "inOutCash",
      //   type: "inOutCash",
      //   transactionType: data.transactionType,
      //   paymentType: data.paymentType,
      //   payAmount: Number(data.amount),
      //   balanceAmount: balanceAmount,
      //   createdBy: "",
      // });

      // if (data.paymentType == "card") {
      //   let transactionCharge = Math.round(
      //     (Number(data.amount) * 2) / 100
      //   );
      //   ledgerData.push({
      //     recieptId: mongoose.Types.ObjectId(data._id),
      //     entryType: "ledger",
      //     ledgerType: "inOutCash",
      //     type: "transactionFee",
      //     transactionType: data.transactionType,
      //     paymentType: data.paymentType,
      //     payAmount: transactionCharge,
      //     balanceAmount: balanceAmount,
      //     createdBy: "",
      //   });
      // }
      // reciept.Ledger.insertMany(ledgerData);
      //end insert ledger
      cmethod.returnSuccess(res, data, false, message.signupsuccess);
    }
  });
};

const findincomingCachWithFiled = async function (query) {
  return new Promise(function (resolve, reject) {
    reciept.IncomngCashSchema.find(
      { _id: { $exists: true } },
      { vin: 1 },
      function (err, data) {
        if (err) {
          reject(err);
        } else {
          resolve(data);
        }
      }
    );
  });
};
const findincomingCachAggregation = function (query) {
  return new Promise(function (resolve, reject) {
    reciept.IncomngCashSchema.aggregate(query, function (err, data) {
      if (err) {
        reject(err);
      } else {
        resolve(data);
      }
    });
  });
};
const findincomingcashAggregation = function (query) {
  return new Promise(function (resolve, reject) {
    reciept.IncomingCash.aggregate(query, function (err, data) {
      if (err) {
        reject(err);
      } else {
        resolve(data);
      }
    });
  });
};
const checkvinbyTransdate = async function (query) {
  return new Promise(function (resolve, reject) {
    reciept.Reciept.find(query, function (err, data) {
      if (data.length > 0) {
        resolve("exist");
      } else {
        resolve("notexist");
      }
    });
  });
};
const convertRecieptAdd = async function (res, postData) {
  const newMaster = new reciept.Reciept(postData);
  newMaster.save(postData, async function (err, data) {
    if (err) {
      cmethod.returnSreverError(res, message.technicalError, err);
    } else {
      cmethod.returnSuccess(res, data, false, message.signupsuccess);
    }
  });
};
module.exports = {
  recieptAdd,
  findRecieptWithFiled,
  findRecieptAggregation,
  findLedgerAggregation,
  ledgerAdd,
  findSalesReturnAggregation,
  incomingCachAdd,
  findincomingCachWithFiled,
  findincomingCachAggregation,
  findincomingcashAggregation,
  checkvinbyTransdate,
  convertRecieptAdd,
};
