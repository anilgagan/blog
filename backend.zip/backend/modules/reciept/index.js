const express = require("express");
const router = express.Router();
const recieptModal = require("../reciept/recieptModal");
const userModal = require("../user/userModal");
const saleRecieptModal = require("../saleReciept/saleRecieptModal");
const inventoryModal = require("../inventory/inventoryModal");
const accountModal = require("../account/accountModal");
const message = require("../../config/message");
const config = require("../../config");
const midleware = require("../../middleware/validation");
const cmethod = require("../../middleware/common-fun");
const recieptDao = require("./recieptDao");
var mongoose = require("mongoose");
const { now } = require("lodash");
const { middleware } = require("json2xls");
const { Auctionvehicle } = require("../auction/auctionModal");
const sapDao = require("../sap/sapDao");
const {
  makeObjectId,
  formatDate,
  daysPassedFromToday,
  getFivePercentVatWithAmount,
  roundToDecimal,
  toUpperCase,
  isArrayWithLength,
} = require("../../functions/global.functions");
const {
  addCustomerPayment,
  adjustSelfBidAuctionCharges,
  addReceiptPayment,
} = require("../../services/receipt.service");
const {
  makeInventoryRelatedCopies,
} = require("../../services/inventory.service");
const logger = require("../../config/logger");
const {
  ExactMatch,
  Match,
  Lookup,
  Unwind,
  Project,
  Sort,
  RegexSearch,
  IDMatch,
  LookupWithPipeline,
  RegexMatch,
} = require("../../functions/mongoose.functions");
const {
  getTaxReceipts,
  createTaxReceipt,
  updateReceipt,
} = require("../../controllers/receipt.controller");
const {
  Find,
  FindById,
  FindByIdAndUpdate,
  UpdateOne,
  FindByIdWithKey,
  Count,
  Create,
} = require("../../models/factory");
const {
  createCommonLog,
  updateCommonLog,
} = require("../../services/comment.service");
const { getGLByPaymentMethod } = require("../../services/account.service");

// * list
router.post("/list", async (req, res) => {
  const {
    body: postData,
    headers: { lang = config.lang },
  } = req;

  const query = [];

  try {
    // * match
    if (postData.fromData && postData.toData) {
      query.push({
        $match: {
          $and: [
            {
              createdAt: {
                $gte: new Date(
                  cmethod.startTimeString(new Date(postData.fromData))
                ),
              },
            },
            {
              createdAt: {
                $lte: new Date(
                  cmethod.endTimeString(new Date(postData.toData))
                ),
              },
            },
          ],
        },
      });
    }
    if (postData.fromTransDate && postData.toTransDate) {
      query.push({
        $match: {
          $and: [
            {
              transDate: {
                $gte: new Date(
                  cmethod.startTimeString(new Date(postData.fromTransDate))
                ),
              },
            },
            {
              transDate: {
                $lte: new Date(
                  cmethod.endTimeString(new Date(postData.toTransDate))
                ),
              },
            },
          ],
        },
      });
    }
    if (postData.paymentStatus) {
      // ! paymentStatus should be string, if number the condition will be evaluated to false
      query.push({
        $match: {
          $and: [{ payStatus: Number(postData.paymentStatus) }],
        },
      });
    }
    if (postData.securityClaim) {
      query.push({
        $match: {
          $and: [{ securityClaim: Number(postData.securityClaim) }],
        },
      });
    }
    if (postData.notCancelled) {
      query.push({
        $match: {
          $and: [{ invoiceStatus: { $ne: "cancelled" } }],
        },
      });
    }
    if (postData.recieptId) {
      query.push({
        $match: {
          $and: [{ _id: mongoose.Types.ObjectId(postData.recieptId) }],
        },
      });
    }
    if (postData.recieptType) {
      query.push({
        $match: {
          $and: [{ recieptType: postData.recieptType }],
        },
      });
    }
    if (postData.payStatus) {
      query.push({
        $match: {
          $and: [{ payStatus: postData.payStatus }],
        },
      });
    }
    if (postData.documentIssue) {
      query.push({
        $match: {
          $and: [{ documentIssue: postData.documentIssue }],
        },
      });
    }
    if (postData.taxType) {
      query.push({
        $match: {
          $and: [{ taxType: postData.taxType }],
        },
      });
    }
    let branchData = [];
    if (postData?.branchId?.length > 0) {
      let pdata = postData.branchId;
      for (let i in pdata) {
        branchData.push(mongoose.Types.ObjectId(pdata[i]));
      }
      query.push({
        $match: {
          $and: [
            {
              branchId: {
                $in: branchData,
              },
            },
          ],
        },
      });
    }

    // * inventorys
    query.push({
      $lookup: {
        from: "inventorys",
        localField: "inventoryId",
        foreignField: "_id",
        as: "inventorys",
      },
    });
    query.push({
      $unwind: { path: "$inventorys", preserveNullAndEmptyArrays: true },
    });

    // * branchs
    query.push({
      $lookup: {
        from: "branchs",
        localField: "branchId",
        foreignField: "_id",
        as: "branchs",
      },
    });
    query.push({
      $unwind: { path: "$branchs", preserveNullAndEmptyArrays: true },
    });

    // * interiorcolors
    query.push({
      $lookup: {
        from: "interiorcolors",
        localField: "inventorys.interiorcolorId",
        foreignField: "_id",
        as: "interiorcolors",
      },
    });
    query.push({
      $unwind: { path: "$interiorcolors", preserveNullAndEmptyArrays: true },
    });

    // * exteriorcolors
    query.push({
      $lookup: {
        from: "exteriorcolors",
        localField: "inventorys.exteriorcolorId",
        foreignField: "_id",
        as: "exteriorcolors",
      },
    });
    query.push({
      $unwind: { path: "$exteriorcolors", preserveNullAndEmptyArrays: true },
    });

    // * makes
    query.push({
      $lookup: {
        from: "makes",
        localField: "inventorys.make",
        foreignField: "_id",
        as: "makes",
      },
    });
    query.push({
      $unwind: { path: "$makes", preserveNullAndEmptyArrays: true },
    });

    // * models
    query.push({
      $lookup: {
        from: "models",
        localField: "inventorys.model",
        foreignField: "_id",
        as: "models",
      },
    });
    query.push({
      $unwind: { path: "$models", preserveNullAndEmptyArrays: true },
    });

    // * bodys
    query.push({
      $lookup: {
        from: "bodys",
        localField: "inventorys.bodyId",
        foreignField: "_id",
        as: "bodys",
      },
    });
    query.push({
      $unwind: { path: "$bodys", preserveNullAndEmptyArrays: true },
    });

    // * drivetypes
    query.push({
      $lookup: {
        from: "drivetypes",
        localField: "inventorys.drivetypeId",
        foreignField: "_id",
        as: "drivetypes",
      },
    });
    query.push({
      $unwind: { path: "$drivetypes", preserveNullAndEmptyArrays: true },
    });

    // * series
    query.push({
      $lookup: {
        from: "series",
        localField: "inventorys.seriesId",
        foreignField: "_id",
        as: "series",
      },
    });
    query.push({
      $unwind: { path: "$series", preserveNullAndEmptyArrays: true },
    });

    // * fueltypes
    query.push({
      $lookup: {
        from: "fueltypes",
        localField: "inventorys.fueltypeId",
        foreignField: "_id",
        as: "fueltypes",
      },
    });
    query.push({
      $unwind: { path: "$fueltypes", preserveNullAndEmptyArrays: true },
    });

    // * drivetypes
    query.push({
      $lookup: {
        from: "drivetypes",
        localField: "inventorys.drivetypeId",
        foreignField: "_id",
        as: "drivetypes",
      },
    });
    query.push({
      $unwind: { path: "$drivetypes", preserveNullAndEmptyArrays: true },
    });

    // * engines
    query.push({
      $lookup: {
        from: "engines",
        localField: "inventorys.engineId",
        foreignField: "_id",
        as: "engines",
      },
    });
    query.push({
      $unwind: { path: "$engines", preserveNullAndEmptyArrays: true },
    });

    // * sellerUsers
    query.push({
      $lookup: {
        from: "users",
        localField: "inventorys.sellerId",
        foreignField: "_id",
        as: "sellerUsers",
      },
    });
    query.push({
      $unwind: { path: "$sellerUsers", preserveNullAndEmptyArrays: true },
    });

    // * buyerUsers
    query.push({
      $lookup: {
        from: "users",
        localField: "buyerId",
        foreignField: "_id",
        as: "buyerUsers",
      },
    });
    query.push({
      $unwind: { path: "$buyerUsers", preserveNullAndEmptyArrays: true },
    });

    // * getpasses
    query.push({
      $lookup: {
        from: "getpasses",
        let: {
          passtId: "$_id",
          referenceId: "$referenceId",
        },
        pipeline: [
          {
            $match: {
              $expr: {
                $and: [{ $eq: ["$referenceId", "$$passtId"] }],
              },
            },
          },
        ],
        as: "getpasses",
      },
    });

    // * getdocuments
    query.push({
      $lookup: {
        from: "getdocuments",
        let: {
          docId: "$_id",
          referenceId: "$referenceId",
        },
        pipeline: [
          {
            $match: {
              $expr: {
                $and: [{ $eq: ["$referenceId", "$$docId"] }],
              },
            },
          },
        ],
        as: "getdocuments",
      },
    });

    // * singlevinimages
    query.push({
      $lookup: {
        from: "vinimages",
        let: {
          inventoryId: "$inventoryId",
          imageType: "inventory",
          type: "carimage",
        },
        pipeline: [
          {
            $match: {
              $expr: {
                $and: [
                  { $eq: ["$imageType", "$$imageType"] },
                  { $eq: ["$type", "$$type"] },
                  { $eq: ["$referenceId", "$$inventoryId"] },
                ],
              },
            },
          },
        ],
        as: "singlevinimages",
      },
    });

    // * bidHistoryLogs
    LookupWithPipeline(
      query,
      "bidhistorylogs",
      {
        inventoryId: "$inventoryId",
        auctionId: "$auctionId",
        userId: "$buyerId",
        status: "Sold",
      },
      [
        {
          $match: {
            $expr: {
              $and: [
                {
                  $eq: ["$inventoryId", "$$inventoryId"],
                },
                {
                  $eq: ["$auctionId", "$$auctionId"],
                },
                { $eq: ["$userId", "$$userId"] },
                { $eq: ["$status", "$$status"] },
              ],
            },
          },
        },
      ],
      "bidHistoryLogs"
    );

    // * match
    if (postData.search) {
      query.push(
        {
          $addFields: {
            a_s: { $convert: { input: "$buyerUsers.name", to: "string" } },
          },
        },
        {
          $match: {
            $and: [
              {
                $or: [
                  {
                    "makes.makeName": {
                      $regex: postData.search,
                      $options: "i",
                    },
                  },
                  {
                    "models.modelName": {
                      $regex: postData.search,
                      $options: "i",
                    },
                  },
                  { recieptNo: { $regex: postData.search, $options: "i" } },
                  {
                    "inventorys.vin": {
                      $regex: postData.search,
                      $options: "i",
                    },
                  },
                  {
                    "buyerUsers.name": {
                      $regex: postData.search,
                      $options: "i",
                    },
                  },
                  { a_s: { $regex: postData.search, $options: "i" } },
                  {
                    "buyerUsers.eid": {
                      $regex: postData.search,
                      $options: "i",
                    },
                  },
                ],
              },
            ],
          },
        }
      );
    }
    if (postData.getpassStatus) {
      query.push({
        $match: {
          $and: [{ "getpasses.status": postData.getpassStatus }],
        },
      });
    }
    if (postData.sellerUserId) {
      query.push({
        $match: {
          $and: [
            {
              "sellerUsers._id": mongoose.Types.ObjectId(postData.sellerUserId),
            },
          ],
        },
      });
    }
    if (postData.buyerUserId) {
      query.push({
        $match: {
          $and: [
            { "buyerUsers._id": mongoose.Types.ObjectId(postData.buyerUserId) },
          ],
        },
      });
    }
    if (postData.ledgerData) {
      //get markAccountId and get all payment
      let allMarkAccountId = await accountModal.Accountmaster.find({
        markAccountId: {
          $in: [
            "cash-in-hand",
            "cash-in-bank",
            "cash-in-bank-sajja",
            "cash-in-bank-ind",
            "cash-in-bank-sharj",
          ],
        },
      }).sort({ createdAt: 1 });
      let glAccountId = [];
      if (allMarkAccountId?.length > 0) {
        for (let i in allMarkAccountId) {
          glAccountId[i] = mongoose.Types.ObjectId(allMarkAccountId[i]?._id);
        }
      }

      query.push({
        $lookup: {
          from: "accountledgers",
          let: {
            recieptNo: "$recieptNo",
            referenceType: "$referenceType",
          },
          pipeline: [
            {
              $match: {
                $expr: {
                  $and: [
                    { $eq: ["reciept", "$referenceType"] },
                    { $eq: ["$referenceNo", "$$recieptNo"] },
                    { $in: ["$glAccountId", glAccountId] },
                    { $ne: ["$accountMasterType", "storage"] },
                  ],
                },
              },
            },
          ],
          as: "ledgers",
        },
      });
    }
    if (postData.storageLedgerData) {
      let accountIds = [];

      const filter = {
        markAccountId: {
          $in: [
            "cash-in-hand",
            "cash-in-bank",
            "cash-in-bank-sajja",
            "cash-in-bank-ind",
            "cash-in-bank-sharj",
          ],
        },
      };
      const accountMasters = await Find(
        accountModal.Accountmaster,
        filter,
        {},
        config.defaultSort
      );

      if (isArrayWithLength(accountMasters)) {
        accountMasters.forEach((account) =>
          accountIds.push(makeObjectId(account._id))
        );
      }

      query.push({
        $lookup: {
          from: "accountledgers",
          let: {
            recieptNo: "$recieptNo",
            referenceType: "$referenceType",
          },
          pipeline: [
            {
              $match: {
                $expr: {
                  $and: [
                    { $eq: ["reciept", "$referenceType"] },
                    { $eq: ["$referenceNo", "$$recieptNo"] },
                    { $in: ["$glAccountId", accountIds] },
                    { $eq: ["$accountMasterType", "storage"] },
                  ],
                },
              },
            },
          ],
          as: "storageLedgers",
        },
      });
    }
    if (postData.gatePass) {
      query.push({
        $match: {
          $expr: {
            $and: [
              {
                $eq: [
                  { $arrayElemAt: ["$getpasses.status", 0] },
                  postData.gatePass,
                ],
              },
            ],
          },
        },
      });
    }

    // * sort
    query.push({ $sort: { createdAt: -1 } });

    // * count
    const sQuery = [...query];
    sQuery.push({ $count: "totalCount" });

    // * pagination
    if (postData.page) {
      query.push({
        $skip: cmethod.pageOffset(postData.page, postData.pageLimit),
      });
      query.push({ $limit: cmethod.pageLimit(postData.pageLimit) });
    }

    // * project
    const apiType = postData.apiType;
    if (apiType == "web") {
      query.push({
        $project: {
          lotNo: "$inventorys.lotNo",
          vin: "$inventorys.vin",
          branchData: "$branchs",
          branchs: "$branchs.branchName",
          branchId: "$branchs._id",
          bodys: "$bodys.bodyName",
          bodyId: "$bodys._id",
          drivetypes: "$drivetypes.drivetypeName",
          drivetypeId: "$drivetypes._id",
          fueltypes: "$fueltypes.fueltypeName",
          fueltypeId: "$fueltypes._id",
          series: "$series.seriesName",
          seriesId: "$series._id",
          engines: "$engines.engineName",
          enginesId: "$engines._id",
          year: "$inventorys.year",
          color: "$exteriorcolors.colorName",
          exteriorcolorId: "$exteriorcolors._id",
          interiorcolors: "$interiorcolors.colorName",
          interiorcolorId: "$interiorcolors._id",
          make: "$makes.makeName",
          makeId: "$makes._id",
          model: "$models.modelName",
          modelId: "$models._id",
          warehouses: "$warehouses.warehouseName",
          warehosId: "$warehouses._id",
          specification: 1,
          auctionId: 1,
          //branchId: "$branchs._id",
          //branchName: "$branchs.branchName",

          //branchs: 1,
          dys: 1,
          //drivetypes: 1,
          //fueltypes: 1,
          //series: 1,
          //engines: 1,
          // year: 1,
          //color: "$interiorcolors",
          //exteriorcolors: 1,
          // make: "$makes",
          // model: "$models",
          // makeName: "$makes.makeName",
          // modelName: "$models.modelName",
          //warehouses: 1,
          // branchId: "$branchs._id",
          // branchName: "$branchs.branchName",
          // warehosId: "$warehouses._id",
          sellerUsers: 1,
          buyerUsers: 1,
          recieptNo: 1,
          //inventorys: 1,
          saleAmount: 1,
          paidAmount: 1,
          dueBalance: 1,
          securityAmount: 1,
          storageAmount: 1,
          storageVat: 1,
          storageDisc: 1,
          discount: 1,
          cashDiscount: 1,
          totalAmount: 1,
          totalExcAmount: 1,
          totalInclAmount: 1,
          totalNetAmount: 1,
          payStatus: 1,
          taxType: 1,
          exportCountry: 1,
          recieptType: 1,
          securityClaim: 1,
          paymentMethod: 1,
          invoiceStatus: 1,
          invoiceDate: 1,
          singleImages: {
            $cond: {
              if: { $eq: ["$singlevinimages", []] },
              then: config.defaultInventoryImage,
              else: { $arrayElemAt: ["$singlevinimages.image", 0] },
            },
          },
          //gatePassReady: 1,
          //documentReady: 1,
          documentIssue: { $arrayElemAt: ["$getdocuments.status", 0] },
          gatePass: { $arrayElemAt: ["$getpasses.status", 0] },
          gatePassExpired: { $arrayElemAt: ["$getpasses.gatePassExpired", 0] },
          parkingDays: { $arrayElemAt: ["$getpasses.parkingDays", 0] },
          parkedDays: { $arrayElemAt: ["$getpasses.parkedDays", 0] },
          createdAt: 1,
          ledgers: 1,
          createdBy: 1,
          transDate: 1,
          carDescription: {
            $concat: [
              { $ifNull: ["$inventorys.year", ""] },
              " ",
              { $ifNull: ["$makes.makeName", ""] },
              " ",
              { $ifNull: ["$models.modelName", ""] },
              //" ",
              //{ $ifNull: ["$exteriorcolors.colorName", ""] },
            ],
          },
          keyNo: "$inventorys.keyNo",
          saleDueAmount: {
            $max: [
              0,
              {
                $subtract: [
                  {
                    $subtract: [
                      "$totalAmount",
                      {
                        $add: [
                          {
                            $ifNull: ["$paidAmount", 0],
                          },
                          "$cashDiscount",
                        ],
                      },
                    ],
                  },
                  "$totalStoragePaid",
                ],
              },
            ],
          },
          totalDueAmount: {
            $subtract: ["$totalNetAmount", { $ifNull: ["$paidAmount", 0] }],
          },
          totalStorageDue: {
            $subtract: ["$totalStorage", "$totalStoragePaid"],
          },
          totalStoragePaid: 1,
          sellerInvoice: 1,
          storageLedgers: 1,
        },
      });
    } else if (postData?.addSalesReturn) {
      const project = {
        recieptNo: 1,
        saleAmount: 1,
        paidAmount: 1,
        dueBalance: 1,
        inventorys: {
          vin: "$inventorys.vin",
          year: "$inventorys.year",
          specification: "$inventorys.specification",
          keyNo: "$inventorys.keyNo",
        },
        buyerUsers: {
          name: "$buyerUsers.name",
          phone: "$buyerUsers.phone",
          uniqueIdentifier: "$buyerUsers.uniqueIdentifier",
          userType: "$buyerUsers.userType",
          companyDetails: "$buyerUsers.companyDetails",
        },
        sellerUsers: {
          name: "$sellerUsers.name",
          phone: "$sellerUsers.phone",
          uniqueIdentifier: "$sellerUsers.uniqueIdentifier",
          userType: "$sellerUsers.userType",
          companyDetails: "$sellerUsers.companyDetails",
        },
        make: {
          makeName: "$makes.makeName",
        },
        model: {
          modelName: "$models.modelName",
        },
        color: {
          colorName: "$interiorcolors.colorName",
        },
      };

      Project(query, project);
    } else {
      query.push({
        $project: {
          make: "$makes",
          model: "$models",
          branchId: "$branchs._id",
          branchs: 1,
          bodys: 1,
          drivetypes: 1,
          fueltypes: 1,
          series: 1,
          engines: 1,
          year: 1,
          color: "$interiorcolors",
          interiorColor: "$interiorcolors.colorName",
          exteriorColor: "$exteriorcolors.colorName",
          exteriorcolors: 1,
          sellerUsers: 1,
          buyerUsers: 1,
          recieptNo: 1,
          inventorys: 1,
          saleAmount: 1,
          paidAmount: 1,
          dueBalance: 1,
          securityAmount: 1,
          storageAmount: 1,
          storageVat: 1,
          storageDisc: 1,
          totalStorage: 1,
          totalStoragePaid: 1,
          discount: 1,
          cashDiscount: 1,
          totalAmount: 1,
          totalExcAmount: 1,
          totalInclAmount: 1,
          totalNetAmount: 1,
          payStatus: 1,
          taxType: 1,
          exportCountry: 1,
          recieptType: 1,
          securityClaim: 1,
          paymentMethod: 1,
          invoiceStatus: 1,
          invoiceDate: 1,
          auctionId: 1,
          singleImages: {
            $cond: {
              if: { $eq: ["$singlevinimages", []] },
              then: config.defaultInventoryImage,
              else: { $arrayElemAt: ["$singlevinimages.image", 0] },
            },
          },
          documentIssue: { $arrayElemAt: ["$getdocuments.status", 0] },
          gatePass: { $arrayElemAt: ["$getpasses.status", 0] },
          gatePassExpired: { $arrayElemAt: ["$getpasses.gatePassExpired", 0] },
          parkingDays: { $arrayElemAt: ["$getpasses.parkingDays", 0] },
          parkedDays: { $arrayElemAt: ["$getpasses.parkedDays", 0] },
          createdAt: 1,
          ledgers: 1,
          createdBy: 1,
          transDate: 1,
          dueAmount: {
            $round: [{ $subtract: ["$totalNetAmount", "$paidAmount"] }, 1],
          },
          keyNo: "$inventorys.keyNo",
          bidId: { $arrayElemAt: ["$bidHistoryLogs._id", 0] },
          buyerId: 1,
          sellerInvoice: 1,
        },
      });
    }

    // * results
    let [result, [{ totalCount } = {}] = []] = await Promise.all([
      recieptModal.Reciept.aggregate(query),
      recieptModal.Reciept.aggregate(sQuery),
    ]);

    if (apiType === "web" && result.length > 0) {
      result = result.map((item) => ({
        saleDate: item?.transDate,
        price: item?.paidAmount,
        status: item?.payStatus,
        pickupstatus: item?.gatePass,
        ...item,
      }));
    }

    res.status(200).json({
      status: true,
      result,
      message: "",
      hasMore: cmethod.hasMoreCount(
        totalCount,
        postData.page,
        postData.pageLimit
      ),
      totalCount,
    });
  } catch (error) {
    logger.error(error);
    cmethod.returnSreverError(res, message[lang]?.technicalError, error);
  }
});
router.post(
  "/add",
  [
    midleware.validateFieldValue(
      [
        "inventoryId",
        "buyerId",
        "saleAmount",
        "paidAmount",
        "dueBalance",
        "securityAmount",
        "totalAmount",
        "recieptType",
      ],
      [
        "inventoryId",
        "buyerId",
        "saleAmount",
        "paidAmount",
        "dueBalance",
        "recieptType",
      ]
    ),
  ],
  async (req, res) => {
    const postData = req.body;
    let lang = req.headers["lang"] || config.lang;

    // * gate pass expired date
    let recieptNoUnique = null;
    if (postData) {
      if (postData.recieptType == "sold") {
        const gatePassExpiryDate = formatDate(postData?.transDate);
        let gatePassExpired = cmethod.addDays(gatePassExpiryDate, 7);
        postData.gatePassExpired = gatePassExpired;
        recieptNoUnique = await cmethod.getRecieptNo();
      }
    }

    // * calculation
    let amountCalData = {
      saleAmount: postData.saleAmount,
      discount: postData?.discount ? postData?.discount : 0,
      storageAmount: 0,
      securityAmount: postData.securityAmount,
      taxType: postData.taxType,
    };

    let calData = cmethod.recalculateInvoice(amountCalData);
    postData.totalExcAmount = calData.totalExcAmount;
    postData.storageAmount = calData.storageAmount;
    postData.storageVat = calData.storageVat;
    postData.discount = calData.discount;
    postData.securityAmount = calData.securityAmount;
    postData.totalInclAmount = calData.totalInclAmount;
    postData.totalNetAmount = calData.totalNetAmount;

    postData.recieptNo = recieptNoUnique;
    if (postData.export === "") postData.export = false;
    if (Number(postData.dueBalance) === 0) postData.payStatus = 1;

    // * check already exist
    let query = {
      transDate: postData.transDate,
      inventoryId: mongoose.Types.ObjectId(postData.inventoryId),
      recieptType: "sold",
    };

    recieptDao.checkvinbyTransdate(query).then(function (doc) {
      if (doc == "exist") {
        cmethod.returnSreverError(res, message[lang].recieptExist);
      } else {
        recieptDao.recieptAdd(res, postData);
      }
    });
  }
);
router.delete(
  "/delete",
  [midleware.validateFieldValue(["recieptId"], ["recieptId"])],
  async (req, res) => {
    let postData = req.body;
    let cond = { _id: mongoose.Types.ObjectId(postData.recieptId) };
    let lang = req.headers["lang"] || config.lang;

    recieptModal.Reciept.deleteOne(cond, postData)
      .then(async (data) => {
        cmethod.returnSuccess(res, [], false, message[lang].Deleteed);
      })
      .catch((err) => {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      });
  }
);

router.post(
  "/addSalesReturn",
  [
    midleware.validateFieldValue(
      ["recieptId", "status"],
      ["recieptId", "status"]
    ),
  ],
  async (req, res) => {
    const { body, headers } = req;
    const lang = headers.lang || config.lang;

    const { recieptId, status, createdBy, transDate } = body;

    try {
      const isReceiptAmountPaid = await FindByIdWithKey(
        recieptModal.Reciept,
        recieptId,
        "paidAmount"
      );

      if (!isReceiptAmountPaid) {
        return cmethod.returrnErrorMessage(
          res,
          "No amount has been paid against this receipt"
        );
      }

      const filter = { recieptId: makeObjectId(recieptId) };
      const isDuplicateReturn = await Count(recieptModal.Salesreturn, filter);

      if (isDuplicateReturn) {
        return cmethod.returrnErrorMessage(
          res,
          "Sales Return already exist for this receipt"
        );
      }

      const salesReturnNo = await cmethod.getSalesReturnNo();
      const saleReturn = {
        salesReturnNo,
        recieptId: makeObjectId(recieptId),
        status,
        createdBy,
        transDate,
      };

      const salesReturn = await Create(recieptModal.Salesreturn, saleReturn);

      if (!salesReturn) {
        return cmethod.returrnErrorMessage(res, message[lang].technicalError);
      }

      const { _id: salesReturnId, salesReturnNo: no } = salesReturn;

      // * log
      await createCommonLog({
        action: "Created",
        from: "Sales(Sales Return)",
        id: salesReturnId,
        of: "seller",
        no,
        by: createdBy,
      });

      cmethod.returnSuccess(
        res,
        salesReturn,
        false,
        "Sales Return added successfully!"
      );
    } catch (error) {
      logger.error(error.message);
      cmethod.returnSreverError(res, message[lang]?.technicalError, error);
    }
  }
);

router.patch(
  "/updateSalesReturn",
  [midleware.validateFieldValue(["id", "status"], ["id", "status"])],
  async (req, res) => {
    const { body, headers } = req;
    const lang = headers.lang || config.lang;

    const { status } = body;

    const {
      id: salesReturnId,
      salesReturnNo,
      inventoryId,
      approvedBy,
      ...rest
    } = body;

    try {
      // #region - // * DATA FORMATION
      if (status === "approved") rest.returnDate = now();

      const Model = recieptModal.Salesreturn;
      const projection = { new: true };
      const salesReturn = await FindByIdAndUpdate(
        Model,
        salesReturnId,
        rest,
        projection
      );

      if (!salesReturn) {
        logger.error("sales return not found or failed to update!");
        return cmethod.returrnErrorMessage(
          res,
          "sales return not found or failed to update!"
        );
      }
      // #endregion

      // #region - // * APPROVED CASE
      if (status === "approved") {
        // * salesReturn
        const {
          _id: salesReturnId,
          recieptId,
          salesReturnNo,
          type,
          refundStatus,
          returnAmount,
        } = salesReturn;

        // * receipt
        const rUpdate = {
          invoiceStatus: "cancelled",
          recieptType: "cancelled",
        };
        const projection = { new: true };

        const receipt = await FindByIdAndUpdate(
          recieptModal.Reciept,
          recieptId,
          rUpdate,
          projection
        );
        const { auctionId, inventoryId } = receipt;

        // * auctionVehicle
        const filter = {
          auctionId: makeObjectId(auctionId),
          inventoryId: makeObjectId(inventoryId),
          status: "sold",
        };
        const returnType = type === "return" ? "salesReturn" : "selfBid";
        const update = { status: returnType };
        await UpdateOne(Auctionvehicle, filter, update);

        // * inventoryCopy
        if (type === "return") {
          await makeInventoryRelatedCopies(inventoryId, type, approvedBy);
        }

        // * reverseGL
        await cmethod.reverseGl(
          recieptId,
          salesReturnNo,
          type,
          getGLByPaymentMethod
        );

        // * selfBid
        if (type == "selfbid") {
          const saleOrderNo = await cmethod.selfBidcalauctionwithsellerservice(
            inventoryId,
            recieptId,
            auctionId,
            refundStatus
          );

          const noRefund =
            saleOrderNo && refundStatus === "no" && returnAmount === 0;

          if (noRefund) await adjustSelfBidAuctionCharges(saleOrderNo);
        }

        // * log
        await updateCommonLog({
          action: "Approved",
          from: "Sales(Sales Return)",
          id: salesReturnId,
          no: salesReturnNo,
          by: approvedBy,
        });
      }
      // #endregion

      cmethod.returnSuccess(res, salesReturn, false, message[lang].Updated);
    } catch (error) {
      logger.error(error.message);
      cmethod.returnSreverError(res, message[lang]?.technicalError, error);
    }
  }
);

//sales return list
router.post(
  "/salesReturnlist",
  [midleware.validateFieldValue(["pageLimit", "page"], ["page"])],
  (req, res) => {
    let lang = req.headers["lang"] || config.lang;
    let postData = req.body;
    let query = [];

    if (postData.fromDate && postData.toDate) {
      query.push({
        $match: {
          $and: [
            {
              transDate: {
                $gte: new Date(
                  cmethod.startTimeString(new Date(postData.fromDate))
                ),
              },
            },
            {
              transDate: {
                $lte: new Date(
                  cmethod.endTimeString(new Date(postData.toDate))
                ),
              },
            },
          ],
        },
      });
    }

    // * reciepts
    query.push({
      $lookup: {
        from: "reciepts",
        localField: "recieptId",
        foreignField: "_id",
        as: "reciepts",
      },
    });
    query.push({
      $unwind: { path: "$reciepts", preserveNullAndEmptyArrays: true },
    });

    // * inventorys
    query.push({
      $lookup: {
        from: "inventorys",
        localField: "reciepts.inventoryId",
        foreignField: "_id",
        as: "inventorys",
      },
    });
    query.push({
      $unwind: { path: "$inventorys", preserveNullAndEmptyArrays: true },
    });

    // * exteriorcolors
    query.push({
      $lookup: {
        from: "exteriorcolors",
        localField: "inventorys.exteriorcolorId",
        foreignField: "_id",
        as: "exteriorcolors",
      },
    });
    query.push({
      $unwind: { path: "$exteriorcolors", preserveNullAndEmptyArrays: true },
    });

    // * makes
    query.push({
      $lookup: {
        from: "makes",
        localField: "inventorys.make",
        foreignField: "_id",
        as: "makes",
      },
    });
    query.push({
      $unwind: { path: "$makes", preserveNullAndEmptyArrays: true },
    });

    // * models
    query.push({
      $lookup: {
        from: "models",
        localField: "inventorys.model",
        foreignField: "_id",
        as: "models",
      },
    });
    query.push({
      $unwind: { path: "$models", preserveNullAndEmptyArrays: true },
    });

    // * branchs
    query.push({
      $lookup: {
        from: "branchs",
        localField: "inventorys.branchId",
        foreignField: "_id",
        as: "branchs",
      },
    });
    query.push({
      $unwind: { path: "$branchs", preserveNullAndEmptyArrays: true },
    });

    // * sellerUsers
    query.push({
      $lookup: {
        from: "users",
        localField: "inventorys.sellerId",
        foreignField: "_id",
        as: "sellerUsers",
      },
    });
    query.push({
      $unwind: { path: "$sellerUsers", preserveNullAndEmptyArrays: true },
    });

    // * buyerUsers
    query.push({
      $lookup: {
        from: "users",
        localField: "reciepts.buyerId",
        foreignField: "_id",
        as: "buyerUsers",
      },
    });
    query.push({
      $unwind: { path: "$buyerUsers", preserveNullAndEmptyArrays: true },
    });

    if (postData.vin) {
      RegexMatch(query, "inventorys.vin", postData.vin);
    }

    if (postData.search) {
      query.push(
        {
          $addFields: {
            a_s: { $convert: { input: "$buyerUsers.phone", to: "string" } },
          },
        },
        {
          $addFields: {
            r_s: { $convert: { input: "$reciepts.recieptNo", to: "string" } },
          },
        },
        {
          $addFields: {
            s_rs: { $convert: { input: "$salesReturnNo", to: "string" } },
          },
        },
        {
          $match: {
            $and: [
              {
                $or: [
                  { r_s: { $regex: postData.search, $options: "i" } },
                  { s_rs: { $regex: postData.search, $options: "i" } },
                  {
                    "inventorys.vin": {
                      $regex: postData.search,
                      $options: "i",
                    },
                  },
                  {
                    "buyerUsers.name": {
                      $regex: postData.search,
                      $options: "i",
                    },
                  },
                  { a_s: { $regex: postData.search, $options: "i" } },
                  // { 'buyerUsers.phone': '/'+parseInt(postData.search)+'/' },
                  // {a_s:'/'+postData.search+'/'},
                  {
                    "buyerUsers.eid": {
                      $regex: postData.search,
                      $options: "i",
                    },
                  },
                ],
              },
            ],
          },
        }
      );
    }

    if (postData.sellerUserId) {
      query.push({
        $match: {
          $and: [
            {
              "sellerUsers._id": mongoose.Types.ObjectId(postData.sellerUserId),
            },
          ],
        },
      });
    }

    if (postData.buyerUserId) {
      query.push({
        $match: {
          $and: [
            { "buyerUsers._id": mongoose.Types.ObjectId(postData.buyerUserId) },
          ],
        },
      });
    }

    if (postData.salesReturnId) {
      query.push({
        $match: {
          $and: [{ _id: mongoose.Types.ObjectId(postData.salesReturnId) }],
        },
      });
    }

    let branchData = [];
    if (postData?.branchId?.length > 0) {
      let pdata = postData.branchId;
      for (let i in pdata) {
        branchData.push(mongoose.Types.ObjectId(pdata[i]));
      }
      //console.log("reciept====>", branchData);
      query.push({
        $match: {
          $and: [
            {
              "reciepts.branchId": {
                $in: branchData,
              },
            },
          ],
        },
      });
    }

    if (postData.status) {
      query.push({
        $match: {
          $and: [{ status: postData.status }],
        },
      });
    }

    const sQuery = [...query];

    // * project
    query.push({
      $project: {
        salesReturnNo: 1,
        recieptId: 1,
        branchId: "$branchs._id",
        status: 1,
        refundStatus: 1,
        returnAmount: 1,
        otherIncome: 1,
        returnDate: 1,
        createdBy: 1,
        sellerUsers: 1,
        buyerUsers: 1,
        reciepts: 1,
        inventorys: 1,
        branchs: 1,
        transDate: 1,
        branchName: "$branchs.branchName",
        make: "$makes.makeName",
        model: "$models.modelName",
        exteriorColor: "$exteriorcolors.colorName",
        //branchId: 1,
        carDescription: {
          $concat: [
            "$inventorys.year",
            " ",
            "$makes.makeName",
            " ",
            "$models.modelName",
          ],
        },
        createdAt: 1,
        returnType: "$type",
      },
    });

    query.push({ $sort: { createdAt: -1 } });
    sQuery.push({ $count: "recordCount" });

    if (postData.page) {
      query.push({
        $skip: cmethod.pageOffset(postData.page, postData.pageLimit),
      });
      query.push({ $limit: cmethod.pageLimit(postData.pageLimit) });
    }

    recieptDao
      .findSalesReturnAggregation(query)
      .then(function (data) {
        recieptDao
          .findSalesReturnAggregation(sQuery)
          .then(async function (dcount) {
            let tptCnt = 0;
            if (dcount.length > 0) {
              tptCnt = dcount[0].recordCount;
            }
            res.status(200).json({
              status: true,
              result: data,
              message: "",
              hasMore: cmethod.hasMoreCount(
                tptCnt,
                postData.page,
                postData.pageLimit
              ),
              totalCount: tptCnt,
            });
          })
          .catch((err) => {
            cmethod.returnSreverError(res, message[lang].technicalError, err);
          });
      })
      .catch((err) => {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      });
  }
);
router.post(
  "/addLedger",
  [
    midleware.validateFieldValue(
      ["recieptId", "payAmount"],
      ["recieptId", "payAmount"]
    ),
  ],
  async (req, res) => {
    const { body, headers } = req;
    const lang = headers.lang || config.lang;

    try {
      const addPayment = await addReceiptPayment(body);

      if (!addPayment) {
        return cmethod.returrnErrorMessage(res, "Error adding payment!");
      }

      res.status(200).json({
        status: true,
        result: true,
        message: "Payment Added Successfully!",
      });
    } catch (error) {
      logger.error(error.message);
      cmethod.returnSreverError(res, message[lang]?.technicalError, error);
    }
  }
);
router.patch(
  "/updateDiscount",
  [
    midleware.validateFieldValue(
      ["recieptId", "discount"],
      ["recieptId", "discount"]
    ),
  ],
  async (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;

    let queryCond = {
      $and: [{ _id: mongoose.Types.ObjectId(postData.recieptId) }],
    };

    const recieptData = await recieptModal.Reciept.findOne(queryCond, {
      saleAmount: 1,
      discount: 1,
      cashDiscount: 1,
      storageAmount: 1,
      storageVat: 1,
      storageDisc: 1,
      securityAmount: 1,
      taxType: 1,
    }).sort({ createdAt: -1 });
    // calculation for other figure amount
    //cashDiscount: postData.discount,
    //storageDisc:recieptData?.storageDisc ? recieptData?.storageDisc : 0,
    let amountCalData = {
      saleAmount: recieptData.saleAmount,
      discount: recieptData?.discount ? recieptData?.discount : 0,
      storageAmount:
        parseInt(recieptData?.storageAmount) +
        parseInt(recieptData?.storageDisc ? recieptData?.storageDisc : 0),
      securityAmount: recieptData?.securityAmount,
      taxType: recieptData?.taxType,
    };
    //append discount according to discount Type
    if (postData?.discountType == "storage") {
      amountCalData["cashDiscount"] = recieptData?.cashDiscount
        ? recieptData?.cashDiscount
        : 0;
      amountCalData["storageDisc"] =
        parseInt(postData.discount) +
        parseInt(recieptData?.storageDisc ? recieptData?.storageDisc : 0);
    } else {
      amountCalData["cashDiscount"] = postData.discount;
      amountCalData["storageDisc"] = recieptData?.storageDisc
        ? recieptData?.storageDisc
        : 0;
    }

    let calData = cmethod.recalculateInvoice(amountCalData, "discount");
    // end calculation for other figure amount

    let setData = {
      totalExcAmount: calData.totalExcAmount,
      storageAmount: calData.storageAmount,
      storageVat: calData.storageVat,
      totalStorage:
        parseInt(calData.storageAmount) + parseInt(calData.storageVat),
      securityAmount: calData.securityAmount,
      totalInclAmount: calData.totalInclAmount,
      totalNetAmount: calData.totalNetAmount,
    };
    if (postData?.discountType == "storage") {
      setData["storageDisc"] =
        parseInt(postData.discount) +
        parseInt(recieptData?.storageDisc ? recieptData?.storageDisc : 0);
    } else {
      setData["cashDiscount"] = postData.discount;
    }

    recieptModal.Reciept.findOneAndUpdate(
      queryCond,
      { $set: setData },
      async function (err, data) {
        if (err) {
          cmethod.returnSreverError(res, message[lang].technicalError, err);
        } else {
          /**add ledger entry here */
          let voucherNoUnique = await cmethod.getVoucherNo();
          //get branch id using reciept Id
          const branchData = await recieptModal.Reciept.findOne(
            { _id: mongoose.Types.ObjectId(data?._id) },
            {
              branchId: 1,
              totalNetAmount: 1,
              paidAmount: 1,
              inventoryId: 1,
              recieptNo: 1,
              buyerId: 1,
            }
          ).sort({ createdAt: -1 });
          /**check due is clear then update payStaus=1 and update gatepass status */
          if (branchData?.totalNetAmount == branchData?.paidAmount) {
            await recieptModal.Reciept.updateOne(
              { _id: mongoose.Types.ObjectId(branchData?._id) },
              {
                $set: {
                  payStatus: 1,
                  dueBalance: 0,
                },
              }
            );
            // get pass
            await inventoryModal.Getpass.updateOne(
              { referenceId: mongoose.Types.ObjectId(branchData?._id) },
              { $set: { status: "in warehouse" } }
            );
          }

          // #region - // * INVENTORY
          const inventoryProjection = { vin: 1, sellerId: 1 };
          const inventory = await FindById(
            inventoryModal.Inventory,
            branchData.inventoryId,
            inventoryProjection
          );

          if (!inventory) {
            logger.error("Inventory not found!");
            return;
          }

          const { vin: vinNo, sellerId } = inventory;
          // #endregion

          // #region - // * SELLER
          const userProjection = {
            name: 1,
            uniqueIdentifier: 1,
          };
          const seller = await FindById(
            userModal.User,
            sellerId,
            userProjection
          );

          const { name: sellerNAME = "" } = seller || {};
          const sellerName = toUpperCase(sellerNAME);
          // #endregion

          // #region - // * BUYER
          const buyer = await FindById(
            userModal.User,
            branchData?.buyerId,
            userProjection
          );
          const { name: buyerNAME = "" } = buyer || {};
          const buyerName = toUpperCase(buyerNAME);
          // #endregion

          /**check due is clear then update payStaus=1 and update gatepass status */
          let branchId = branchData?.branchId;
          let jvNoDb;
          let newPostData = [];
          const description = `TO RECORD DISCOUNT GIVEN TO ${buyerName} AGAINST ${sellerName} VIN# ${vinNo} INV NO# ${branchData.recieptNo}`;
          /*get discount account id */
          const accountDiscountData = await accountModal.Accountmaster.findOne(
            { markAccountId: "discount" },
            {
              markAccountId: 1,
            }
          ).sort({ createdAt: -1 });
          let discountAccountId = accountDiscountData?._id;
          /*get discount account id base of payment type */
          //for discount amount.
          let queryCheck = {
            $and: [
              { referenceId: mongoose.Types.ObjectId(data?._id) },
              { referenceType: "reciept" },
              { glAccountId: mongoose.Types.ObjectId(discountAccountId) },
            ],
          };
          const checkJl1 = await accountModal.Accountledger.findOne(
            queryCheck,
            {
              voucherNo: 1,
            }
          ).sort({ createdAt: -1 });
          if (checkJl1) {
            jvNoDb = checkJl1?.voucherNo;
            await accountModal.Accountledger.updateOne(
              { _id: mongoose.Types.ObjectId(checkJl1?._id) },
              { $set: { payAmount: postData?.discount } }
            );
          } else {
            newPostData.push({
              branchId: mongoose.Types.ObjectId(branchId),
              glAccountId: mongoose.Types.ObjectId(discountAccountId),
              voucherNo: voucherNoUnique,
              transactionType: "dr",
              paymentType: "cash",
              payAmount: postData?.discount,
              referenceType: "reciept",
              description,
              //referenceId: mongoose.Types.ObjectId(data?._id),
              referenceNo: data?.recieptNo,
              referenceNo2: vinNo,
              createdBy: postData?.createdBy || "system",
              transDate: new Date(),
              transactionOf: "buyer",
            });
          }

          /*get recieviable account id base of payment type */
          const accountRecievableData =
            await accountModal.Accountmaster.findOne(
              { markAccountId: "receivable" },
              {
                markAccountId: 1,
              }
            ).sort({ createdAt: -1 });
          let recievableAccountId = accountRecievableData?._id;
          /*get account id base of payment type */
          //for recievable amount or due amount.
          let queryCheck1 = {
            $and: [
              { referenceId: mongoose.Types.ObjectId(data?._id) },
              { voucherNo: jvNoDb },
              { referenceType: "reciept" },
              { glAccountId: mongoose.Types.ObjectId(recievableAccountId) },
            ],
          };
          const checkJl2 = await accountModal.Accountledger.findOne(
            queryCheck1,
            {
              branchId: 1,
            }
          ).sort({ createdAt: -1 });
          if (checkJl2) {
            await accountModal.Accountledger.updateOne(
              { _id: mongoose.Types.ObjectId(checkJl2?._id) },
              { $set: { payAmount: postData?.discount } }
            );
          } else {
            newPostData.push({
              branchId: mongoose.Types.ObjectId(branchId),
              glAccountId: mongoose.Types.ObjectId(recievableAccountId),
              voucherNo: voucherNoUnique,
              transactionType: "cr",
              paymentType: "cash",
              payAmount: postData?.discount,
              referenceType: "reciept",
              description,
              //referenceId: mongoose.Types.ObjectId(data?._id),
              referenceNo: data?.recieptNo,
              referenceNo2: vinNo,
              createdBy: postData?.createdBy || "system",
              transDate: new Date(),
              transactionOf: "buyer",
            });
          }
          if (newPostData.length > 0) {
            await accountModal.Accountledger.insertMany(newPostData);
          }

          /**add ledger entry here */
          cmethod.returnSuccess(res, data, false, message[lang].Updated);
        }
      }
    );
  }
);
async function addSalerSale(recieptId, callback) {
  let query = {
    $and: [{ _id: mongoose.Types.ObjectId(recieptId) }],
  };
  // ["salerId","buyerId","inventoryId","recieptId","saleAmount","paybleAmount"],
  const recieptData = await recieptModal.Reciept.find(query, {
    buyerId: 1,
    inventoryId: 1,
    saleAmount: 1,
  }).sort({ createdAt: -1 });

  if (recieptData) {
    recieptData.forEach(async (element) => {
      let querysaler = {
        $and: [{ _id: mongoose.Types.ObjectId(element?.inventoryId) }],
      };
      const userData = await inventoryModal.Inventory.findOne(querysaler, {
        sellerId: 1,
      }).sort({ createdAt: -1 });
      // console.log(userData);
      let paybleAmount = parseInt(element?.saleAmount) + 700;
      let saleData = [];
      saleData.push({
        salerId: mongoose.Types.ObjectId(userData?.sellerId),
        buyerId: mongoose.Types.ObjectId(element?.buyerId),
        inventoryId: mongoose.Types.ObjectId(element?.inventoryId),
        recieptId: mongoose.Types.ObjectId(element?.recieptId),
        saleAmount: element?.saleAmount,
        paybleAmount: paybleAmount,
      });
      await saleRecieptModal.Salereciept.insertMany(saleData);
      // await recieptModal.Reciept.updateOne({  _id: mongoose.Types.ObjectId(element?._id) }, { $set: { storageAmount:totalStorage,payStatus:0 }});
    });
  }
  return callback(true);
}

router.get("/checkStorageUpdate", [], async (req, res) => {
  const today = formatDate(new Date());

  let query = {
    $and: [
      { gatePassExpired: { $lt: today } }, // * less than today
      { direction: "out" },
      { referenceType: "reciept" },
      {
        $or: [{ status: "pending" }, { status: "in warehouse" }],
      },
    ],
  };

  const allExpiredGatepass = await inventoryModal.Getpass.find(query, {
    gatePassExpired: 1,
    parkingDays: 1,
    referenceId: 1,
  }).sort({ createdAt: -1 });

  if (allExpiredGatepass) {
    allExpiredGatepass.forEach(async (element) => {
      let expiredDate = new Date(element?.gatePassExpired);
      const Difference_In_Days = daysPassedFromToday(expiredDate);

      const shouldUpdate = Difference_In_Days - (element.parkingDays ?? 0) > 0;

      if (shouldUpdate) {
        let queryCond = {
          $and: [{ _id: mongoose.Types.ObjectId(element?.referenceId) }],
        };
        const recieptData = await recieptModal.Reciept.findOne(queryCond, {
          saleAmount: 1,
          storageAmount: 1,
          storageVat: 1,
          storageDisc: 1,
          securityAmount: 1,
          taxType: 1,
          discount: 1,
          cashDiscount: 1,
          branchId: 1,
          recieptNo: 1,
          totalStorage: 1,
        }).sort({ createdAt: -1 });

        if (!recieptData) return;

        const storage = getFivePercentVatWithAmount(recieptData.totalStorage);
        const storageAmount = roundToDecimal(storage.amount, 2);

        //* 33.33 = 35 / (1 + (5 / 100)) = 35/1.05
        let totalStorage = 33.33 + storageAmount;

        if (recieptData) {
          let amountCalData = {
            saleAmount: recieptData?.saleAmount,
            discount: recieptData?.discount ? recieptData?.discount : 0,
            cashDiscount: recieptData?.cashDiscount
              ? recieptData?.cashDiscount
              : 0,
            storageAmount: totalStorage,
            storageDisc: recieptData?.storageDisc
              ? recieptData?.storageDisc
              : 0,
            securityAmount: recieptData?.securityAmount,
            taxType: recieptData?.taxType,
          };
          let calData = cmethod.recalculateInvoice(amountCalData);
          // end calculation for other figure amount

          let setData = {
            discount: calData.discount,
            totalExcAmount: calData.totalExcAmount,
            storageAmount: calData.storageAmount,
            storageVat: calData.storageVat,
            totalStorage:
              parseInt(calData.storageAmount) + parseInt(calData.storageVat),
            storageDisc: calData.storageDisc,
            securityAmount: calData.securityAmount,
            totalInclAmount: calData.totalInclAmount,
            totalNetAmount: calData.totalNetAmount,
            payStatus: 0,
          };

          // calculation for other figure amount
          await recieptModal.Reciept.updateOne(
            { _id: mongoose.Types.ObjectId(recieptData?._id) },
            { $set: setData }
          );

          const gatePassExpireDate = new Date(element?.gatePassExpiredDate);
          const parkedDays = daysPassedFromToday(gatePassExpireDate);

          await inventoryModal.Getpass.updateOne(
            { _id: mongoose.Types.ObjectId(element._id) },
            {
              $set: {
                parkingDays: Difference_In_Days, // * temp parking days, will reset after payment
                status: "pending",
                parkedDays, // * total parked days
              },
            }
          );
        }
      }
    });

    cmethod.returnSuccess(res, [], false, "all storage updated successfully.");
  }
});

router.patch(
  "/updateRecieptStatus",
  [
    midleware.validateFieldValue(
      ["recieptId", "statusType", "status"],
      ["recieptId", "statusType", "status"]
    ),
  ],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let xtoken = req.headers["x-access-token"];
    //{ token: xtoken },
    let queryCond = {
      $and: [{ _id: mongoose.Types.ObjectId(postData.recieptId) }],
    };
    let setData;
    if (
      postData.statusType == "document" &&
      ["pending", "given"].includes(postData.status)
    ) {
      setData = { documentIssue: postData.status };
    } else if (
      postData.statusType == "gatepass" &&
      ["in warehouse", "out of stock"].includes(postData.status)
    ) {
      setData = { gatePass: postData.status };
    } else if (
      postData.statusType == "gatePassReady" &&
      ["pending", "issued"].includes(postData.status)
    ) {
      setData = { gatePassReady: postData.status, gatePass: "in warehouse" };
    } else if (
      postData.statusType == "documentReady" &&
      ["pending", "issued"].includes(postData.status)
    ) {
      setData = { documentReady: postData.status, documentIssue: "pending" };
    } else {
      cmethod.returnSreverError(res, message[lang].recieptStatusError, []);
      return;
    }
    recieptModal.Reciept.findOneAndUpdate(
      queryCond,
      { $set: setData },
      { new: true },
      async function (err, data) {
        if (err) {
          cmethod.returnSreverError(res, message[lang].technicalError, err);
        } else {
          //add sale for saler
          if (
            postData.statusType == "gatepass" &&
            postData.status == "out of stock"
          ) {
            var result = addSalerSale(postData.recieptId, function (result) {});
          }
          //end add sale for saler
          cmethod.returnSuccess(res, data, false, message[lang].Updated);
        }
      }
    );
  }
);

router.post("/dayend-report", [], async (req, res) => {
  let lang = req.headers["lang"] || config.lang;
  let masterReport = {};
  let totalCashSale = 0;
  let totalOnlineSale = 0;
  let totalSellerPayment = 0;
  let totalNetAmount = 0;
  let totalAuctionFee = 0;
  let totalHandlingFee = 0;
  let totalVat = 0;
  let startTime = cmethod.startTimeString(new Date());
  let endTime = cmethod.endTimeString(new Date());
  let query = {
    $and: [
      { createdAt: { $gte: startTime } },
      { createdAt: { $lte: endTime } },
      { entryType: "invoice" },
    ],
  };
  const allLedger = await recieptModal.Ledger.find(query, {}).sort({
    createdAt: -1,
  });
  // console.log(allLedger);
  allLedger.forEach((element) => {
    if (element.ledgerType == "buyersale" && element.transactionType == "dr") {
      if (element.paymentType == "cash") {
        totalCashSale = totalCashSale + parseInt(element.payAmount);
      } else {
        totalOnlineSale = totalOnlineSale + parseInt(element.payAmount);
      }
    } else if (
      element.ledgerType == "salersale" &&
      element.transactionType == "dr"
    ) {
      totalSellerPayment = totalSellerPayment - parseInt(element.payAmount);
    }
  });
  totalNetAmount =
    parseInt(totalCashSale) +
    parseInt(totalOnlineSale) -
    parseInt(totalSellerPayment);
  masterReport["cashSale"] = totalCashSale;
  masterReport["onlineSale"] = totalOnlineSale;
  masterReport["sellerPayment"] = totalSellerPayment;
  masterReport["netAmount"] = totalNetAmount;

  masterReport["auctionFee"] = totalAuctionFee;
  masterReport["handlingFee"] = totalHandlingFee;
  masterReport["vat"] = totalVat;
  // console.log(masterReport);
  cmethod.returnSuccess(res, masterReport, false, message[lang].successfully);
});

//work on 20-02-2023
router.post(
  "/cashinhand",
  [
    midleware.validateFieldValue(
      ["pageLimit", "page", "recieptType", "paymentType"],
      ["page", "recieptType", "paymentType"]
    ),
  ],
  (req, res) => {
    // console.log("washi first routing")
    let lang = req.headers["lang"] || config.lang;
    let postData = req.body;
    let query = [];

    query.push({
      $lookup: {
        from: "reciepts",
        localField: "recieptId",
        foreignField: "_id",
        as: "reciepts",
      },
    });
    query.push({
      $unwind: { path: "$reciepts", preserveNullAndEmptyArrays: true },
    });
    query.push({
      $lookup: {
        from: "inventorys",
        localField: "reciepts.inventoryId",
        foreignField: "_id",
        as: "inventorys",
      },
    });
    query.push({
      $unwind: { path: "$inventorys", preserveNullAndEmptyArrays: true },
    });
    query.push({
      $lookup: {
        from: "users",
        localField: "reciepts.buyerId",
        foreignField: "_id",
        as: "buyers",
      },
    });
    query.push({
      $unwind: { path: "$buyers", preserveNullAndEmptyArrays: true },
    });

    query.push({
      $lookup: {
        from: "makes",
        localField: "inventorys.make",
        foreignField: "_id",
        as: "makes",
      },
    });
    query.push({
      $unwind: { path: "$makes", preserveNullAndEmptyArrays: true },
    });
    query.push({
      $lookup: {
        from: "models",
        localField: "inventorys.model",
        foreignField: "_id",
        as: "models",
      },
    });

    query.push({
      $unwind: { path: "$models", preserveNullAndEmptyArrays: true },
    });

    query.push({
      $lookup: {
        from: "branchs",
        localField: "reciepts.branchId",
        foreignField: "_id",
        as: "branchs",
      },
    });
    query.push({
      $unwind: { path: "$branchs", preserveNullAndEmptyArrays: true },
    });

    let newbranchData = [];
    if (postData?.branchId?.length > 0) {
      let pdata = postData.branchId;
      for (let i in pdata) {
        newbranchData.push(mongoose.Types.ObjectId(pdata[i]));
      }
      //console.log("reciept====>", newbranchData);
      query.push({
        $match: {
          $and: [
            {
              "reciepts.branchId": {
                $in: newbranchData,
              },
            },
          ],
        },
      });
    }
    // query.push({
    //   $lookup: {
    //     from: "users",
    //     localField: "inventorys.sellerId",
    //     foreignField: "_id",
    //     as: "sellerUsers",
    //   },
    // });

    // query.push({
    //   $unwind: { path: "$sellerUsers", preserveNullAndEmptyArrays: true },
    // });
    // query.push({
    //   $lookup: {
    //     from: "users",
    //     localField: "buyerId",
    //     foreignField: "_id",
    //     as: "buyerUsers",
    //   },
    // });
    // query.push({
    //   $unwind: { path: "$buyerUsers", preserveNullAndEmptyArrays: true },
    // });
    // db.foo.aggregate([{$addFields:{a_s:{$convert:{input:'$a',to:'string'}}}},{$match:{a_s:/1/}}])
    if (postData.fromData && postData.toData) {
      query.push({
        $match: {
          $and: [
            {
              createdAt: {
                $gte: new Date(
                  cmethod.startTimeString(new Date(postData.fromData))
                ),
              },
            },
            {
              createdAt: {
                $lte: new Date(
                  cmethod.endTimeString(new Date(postData.toData))
                ),
              },
            },
          ],
        },
      });
    }
    // if (postData.recieptType) {
    //   query.push({
    //     $match: {
    //       $and: [{ "reciepts.recieptType": postData.recieptType }],
    //     },
    //   });
    // }
    if (postData.entryType) {
      query.push({
        $match: {
          $and: [{ entryType: postData.entryType }],
        },
      });
    }
    if (postData.paymentType) {
      query.push({
        $match: {
          $and: [{ paymentType: postData.paymentType }],
        },
      });
    }
    if (postData.search) {
      query.push(
        {
          $addFields: {
            a_s: { $convert: { input: "$buyerUsers.phone", to: "string" } },
          },
        },
        {
          $addFields: {
            r_s: { $convert: { input: "$recieptNo", to: "string" } },
          },
        },
        {
          $match: {
            $and: [
              {
                $or: [
                  { r_s: { $regex: postData.search, $options: "i" } },
                  {
                    "inventorys.vin": {
                      $regex: postData.search,
                      $options: "i",
                    },
                  },
                ],
              },
            ],
          },
        }
      );
    }

    const sQuery = [...query];
    query.push({
      $project: {
        carDesc: {
          $concat: [
            "$inventorys.year",
            " ",
            "$makes.makeName",
            " ",
            "$models.modelName",
          ],
        },
        recieptNo: "$reciepts.recieptNo",
        vin: "$inventorys.vin",
        buyerName: "$buyers.name",
        recieptId: 1,
        entryType: 1,
        ledgerType: 1,
        type: 1,
        transactionType: 1,
        paymentType: 1,
        payAmount: 1,
        balanceAmount: 1,
        description: 1,
        createdAt: 1,
        branchId: "$branchs._id",
        branchs: 1,
      },
    });

    query.push({ $sort: { createdAt: 1 } });
    sQuery.push({ $count: "recordCount" });

    if (postData.page) {
      query.push({
        $skip: cmethod.pageOffset(postData.page, postData.pageLimit),
      });
      query.push({ $limit: cmethod.pageLimit(postData.pageLimit) });
    }

    recieptDao
      .findLedgerAggregation(query)
      .then(function (data) {
        recieptDao
          .findLedgerAggregation(sQuery)
          .then(async function (dcount) {
            let tptCnt = 0;
            if (dcount.length > 0) {
              tptCnt = dcount[0].recordCount;
            }
            res.status(200).json({
              status: true,
              result: data,
              message: "",
              hasMore: cmethod.hasMoreCount(
                tptCnt,
                postData.page,
                postData.pageLimit
              ),
              totalCount: tptCnt,
            });
          })
          .catch((err) => {
            console.log(err);
            cmethod.returnSreverError(res, message[lang].technicalError, err);
          });
      })
      .catch((err) => {
        console.log(err);
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      });
  }
);
router.post(
  "/bankTransfer",
  [
    midleware.validateFieldValue(
      ["bank", "amount", "createdBy"],
      ["bank", "amount", "createdBy"]
    ),
  ],
  async (req, res) => {
    //console.log("washi",req.body);
    const postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let amount = postData.amount;
    let newPostData = [];
    amount = Number(amount);
    if (amount > 0) {
      /*for get and add totalBalance */
      let queryCond = {
        $and: [{ entryType: "ledger" }],
      };

      const ledgerData = await recieptModal.Ledger.findOne(queryCond, {
        balanceAmount: 1,
      }).sort({ createdAt: -1 });
      let balanceAmount = 0;
      if (ledgerData?.balanceAmount) {
        balanceAmount = ledgerData?.balanceAmount - amount;
      } else {
        balanceAmount = amount;
      }
      /*for get and add totalBalance */
      //for ledger
      newPostData.push({
        entryType: "ledger",
        ledgerType: "bankDeposit",
        type: "bankTransfer",
        transactionType: "cr",
        paymentType: "cash",
        payAmount: amount,
        balanceAmount: balanceAmount,
        description: postData.bank,
        createdBy: postData.createdBy,
      });
      //for sales entry
    }
    // allAuctionId.push(mongoose.Types.ObjectId(postData.auctionId[i]));
    // console.log(updateRecieptData); console.log(newPostData);
    if (newPostData.length > 0) {
      recieptModal.Ledger.insertMany(newPostData, (err, data) => {
        if (err) {
          cmethod.returnSreverError(res, message[lang].technicalError, err);
        } else {
          cmethod.returnSuccess(
            res,
            data,
            false,
            "payment transfer added successfully."
          );
        }
      });
    } else {
      cmethod.returnSreverError(res, "amount can not be empty.", "");
    }
  }
);
router.post(
  "/cashSummary",
  [
    midleware.validateFieldValue(
      ["entryType", "fromData", "toData"],
      ["entryType", "fromData", "toData"]
    ),
  ],
  (req, res) => {
    // console.log("washi first routing")
    let lang = req.headers["lang"] || config.lang;
    let postData = req.body;
    let query = [];

    if (postData.fromData && postData.toData) {
      query.push({
        $match: {
          $and: [
            {
              createdAt: {
                $gte: new Date(
                  cmethod.startTimeString(new Date(postData.fromData))
                ),
              },
            },
            {
              createdAt: {
                $lte: new Date(
                  cmethod.endTimeString(new Date(postData.toData))
                ),
              },
            },
          ],
        },
      });
    }
    if (postData.entryType) {
      query.push({
        $match: {
          $and: [{ entryType: postData.entryType }],
        },
      });
    }
    query.push({
      $group: {
        _id: "$ledgerType",
        totalAmount: { $sum: "$payAmount" },
      },
    });
    const sQuery = [...query];
    query.push({
      $project: {
        entryType: 1,
        ledgerType: 1,
        type: 1,
        transactionType: 1,
        paymentType: 1,
        payAmount: 1,
        balanceAmount: 1,
        createdAt: 1,
        totalAmount: 1,
      },
    });

    query.push({ $sort: { createdAt: -1 } });
    sQuery.push({ $count: "recordCount" });

    if (postData.page) {
      query.push({
        $skip: cmethod.pageOffset(postData.page, postData.pageLimit),
      });
      query.push({ $limit: cmethod.pageLimit(postData.pageLimit) });
    }

    recieptDao
      .findLedgerAggregation(query)
      .then(async function (data) {
        /*get last cah in hand */
        let queryCond = {
          $and: [{ entryType: "ledger" }],
        };

        const ledgerData = await recieptModal.Ledger.findOne(queryCond, {
          balanceAmount: 1,
        }).sort({ createdAt: -1 });
        data.push({
          _id: "cashInhand",
          totalAmount: ledgerData.balanceAmount,
        });
        /*end get last cash in hand */
        res.status(200).json({
          status: true,
          result: data,
          message: "",
          hasMore: false,
          totalCount: 1,
        });
      })
      .catch((err) => {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      });
  }
);

//IncomingCash
router.post(
  "/incomingcashadd",
  [
    midleware.validateFieldValue(
      [
        "referenceNo",
        "transactionType",
        "amount",
        "description",
        "createdBy",
        "status",
      ],
      [
        "referenceNo",
        "transactionType",
        "amount",
        "description",
        "createdBy",
        "status",
      ]
    ),
  ],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    recieptDao.incomingCachAdd(res, postData);
  }
);
router.post(
  "/incomingcashlist",
  [midleware.validateFieldValue(["pageLimit", "page"], ["page"])],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let query = [];
    if (postData.search) {
      query.push({
        $match: {
          $and: [
            {
              $or: [
                { referenceNo: { $regex: postData.search, $options: "i" } },
                { transactionType: { $regex: postData.search, $options: "i" } },
                { description: { $regex: postData.search, $options: "i" } },
              ],
            },
          ],
        },
      });
    }
    query.push({
      $project: {
        referenceNo: 1,
        userName: 1,
        paymentType: 1,
        transactionType: 1,
        description: 1,
        amount: 1,
        createdBy: 1,
        status: 1,
        createdAt: 1,
      },
    });
    const sQuery = [...query];
    query.push({ $sort: { createdAt: -1 } });
    sQuery.push({ $count: "recordCount" });

    if (postData.page) {
      query.push({
        $skip: cmethod.pageOffset(postData.page, postData.pageLimit),
      });
      query.push({ $limit: cmethod.pageLimit(postData.pageLimit) });
    }

    recieptDao
      .findincomingcashAggregation(query)
      .then(function (data) {
        recieptDao
          .findincomingcashAggregation(sQuery)
          .then(async function (dcount) {
            let tptCnt = 0;
            if (dcount.length > 0) {
              tptCnt = dcount[0].recordCount;
            }
            res.status(200).json({
              status: true,
              result: data,
              message: "",
              hasMore: cmethod.hasMoreCount(
                tptCnt,
                postData.page,
                postData.pageLimit
              ),
              totalCount: tptCnt,
            });
          })
          .catch((err) => {
            cmethod.returnSreverError(res, message[lang].technicalError, err);
          });
      })
      .catch((err) => {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      });
  }
);
//IncomingCash
router.post(
  "/convertReciept",
  [
    midleware.validateFieldValue(
      ["inventoryId", "auctionId"],
      ["inventoryId", "auctionId"]
    ),
  ],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    recieptDao.convertRecieptAdd(res, postData);
  }
);

// * add-customer-payment
router.post(
  "/add-customer-payment",
  [
    midleware.validateFieldValue(
      ["recieptId", "payAmount"],
      ["recieptId", "payAmount"]
    ),
  ],
  async (req, res) => {
    const { body } = req;
    let lang = req.headers["lang"] || config.lang;

    const {
      recieptId: receiptIds,
      payAmount: totalPaidAmount,
      dueAmount: totalDueAmount,
      paymentMethod,
      createdBy,
      transDate,
    } = body;

    let updateRecieptData = [];
    let newPostData = [];

    for (let i = 0; i < receiptIds.length; i++) {
      let paidAmount = Number(totalPaidAmount[i]);
      let dueAmount = Number(totalDueAmount[i]);

      if (paidAmount > 0) {
        // * receipt
        const receiptData = await recieptModal.Reciept.findOne(
          { _id: mongoose.Types.ObjectId(receiptIds[i]) },
          {
            branchId: 1,
            recieptNo: 1,
            inventoryId: 1,
            buyerId: 1,
            saleAmount: 1,
            isCreditApplied: 1,
          }
        ).sort({ createdAt: -1 });

        const {
          recieptNo,
          inventoryId,
          branchId,
          buyerId,
          saleAmount,
          isCreditApplied,
        } = receiptData;

        // * buyer
        const buyerData = await userModal.User.findOne(
          { _id: mongoose.Types.ObjectId(buyerId) },
          {
            uniqueIdentifier: 1,
            walletAmount: 1,
            name: 1,
          }
        ).sort({ createdAt: -1 });

        const buyerNo = buyerData?.uniqueIdentifier;
        const buyerName = toUpperCase(buyerData?.name);
        const buyerWalletAmount = buyerData?.walletAmount;

        if (buyerWalletAmount < paidAmount) {
          return cmethod.returrnErrorMessage(
            res,
            "Insufficient Wallet Amount!",
            ""
          );
        }

        // * inventory
        const vinData = await inventoryModal.Inventory.findOne(
          { _id: mongoose.Types.ObjectId(inventoryId) },
          {
            vin: 1,
            sellerId: 1,
          }
        ).sort({ createdAt: -1 });

        const { vin: vinNo, sellerId } = vinData;

        // * seller
        const sellerData = await userModal.User.findOne(
          { _id: mongoose.Types.ObjectId(sellerId) },
          {
            uniqueIdentifier: 1,
            name: 1,
          }
        ).sort({ createdAt: -1 });

        const sellerNo = sellerData?.uniqueIdentifier;
        const sellerName = toUpperCase(sellerData?.name);

        const description = `TO RECORD BALANCE RECEIVED FROM ${buyerName} AGAINST ${sellerName} VIN# ${vinNo} INV NO# ${recieptNo}`;

        const voucherNoUnique = await cmethod.getVoucherNo();

        let accountType;
        let groupAccountId;
        if (paymentMethod[i] == "wallet") {
          accountType = "wallet";
          const accountData = await accountModal.Accountmaster.findOne(
            { markAccountId: accountType },
            {
              markAccountId: 1,
            }
          ).sort({ createdAt: -1 });
          groupAccountId = accountData?._id;
        }

        //for advance amount recieved.
        newPostData.push({
          branchId: mongoose.Types.ObjectId(branchId),
          glAccountId: mongoose.Types.ObjectId(groupAccountId),
          voucherNo: voucherNoUnique,
          transactionType: "dr",
          paymentType: paymentMethod[i],
          payAmount: paidAmount,
          referenceType: "reciept",
          description,
          referenceNo: recieptNo,
          referenceNo2: vinNo,
          buyerNo: buyerNo,
          sellerNo: sellerNo,
          createdBy: createdBy[i],
          transDate: transDate[i],
          transactionOf: "buyer",
        });

        /*get recieviable account id base of payment type */
        const accountRecievableData = await accountModal.Accountmaster.findOne(
          { markAccountId: "receivable" },
          {
            markAccountId: 1,
          }
        ).sort({ createdAt: -1 });
        let recievableAccountId = accountRecievableData?._id;

        newPostData.push({
          branchId: mongoose.Types.ObjectId(branchId),
          glAccountId: mongoose.Types.ObjectId(recievableAccountId),
          voucherNo: voucherNoUnique,
          transactionType: "cr",
          paymentType: paymentMethod[i],
          payAmount: paidAmount,
          referenceType: "reciept",
          description,
          referenceNo: recieptNo,
          referenceNo2: vinNo,
          buyerNo: buyerNo,
          sellerNo: sellerNo,
          createdBy: createdBy[i],
          transDate: transDate[i],
          transactionOf: "buyer",
        });

        // * check storage data if applicable
        let storageAmountData = await cmethod.getStoargeRemainingPay(
          receiptIds[i]
        );

        if (storageAmountData?.storageAmount > 0) {
          const storageCharge = storageAmountData?.storageAmount;
          const vatStorage = storageAmountData?.storageVat;

          const accountRecievableData =
            await accountModal.Accountmaster.findOne(
              { markAccountId: "receivable" },
              {
                markAccountId: 1,
              }
            ).sort({ createdAt: -1 });
          let recievableAccountId = accountRecievableData?._id;
          //* for recievable amount or due amount.
          newPostData.push({
            branchId: mongoose.Types.ObjectId(branchId),
            glAccountId: mongoose.Types.ObjectId(recievableAccountId),
            voucherNo: voucherNoUnique,
            transactionType: "dr",
            paymentType: "",
            payAmount: Number(storageCharge) + Number(vatStorage),
            referenceType: "reciept",
            description,
            referenceNo: recieptNo,
            referenceNo2: vinNo,
            buyerNo: buyerNo,
            sellerNo: sellerNo,
            createdBy: createdBy[i],
            transDate: transDate[i],
            transactionOf: "buyer",
          });

          const accountStorageData = await accountModal.Accountmaster.findOne(
            { markAccountId: "storage" },
            {
              markAccountId: 1,
            }
          ).sort({ createdAt: -1 });
          let storageAccountId = accountStorageData?._id;
          //for recievable amount or due amount.
          newPostData.push({
            branchId: mongoose.Types.ObjectId(branchId),
            glAccountId: mongoose.Types.ObjectId(storageAccountId),
            voucherNo: voucherNoUnique,
            transactionType: "cr",
            paymentType: "",
            payAmount: Number(storageCharge),
            referenceType: "reciept",
            description,
            referenceNo: recieptNo,
            referenceNo2: vinNo,
            buyerNo: buyerNo,
            sellerNo: sellerNo,
            createdBy: createdBy[i],
            transDate: transDate[i],
            transactionOf: "buyer",
          });

          //for vat entry.
          let groupAcoountId;
          let groupAcoountType = "storage-vat";
          const accountGroupData = await accountModal.Accountmaster.findOne(
            { markAccountId: groupAcoountType },
            {
              markAccountId: 1,
            }
          ).sort({ createdAt: -1 });
          groupAcoountId = accountGroupData?._id;

          newPostData.push({
            branchId: mongoose.Types.ObjectId(branchId),
            glAccountId: mongoose.Types.ObjectId(groupAcoountId),
            voucherNo: voucherNoUnique,
            transactionType: "cr",
            paymentType: "",
            payAmount: Number(vatStorage),
            referenceType: "reciept",
            description,
            referenceNo: recieptNo,
            referenceNo2: vinNo,
            buyerNo: buyerNo,
            sellerNo: sellerNo,
            createdBy: createdBy[i],
            transDate: transDate[i],
            transactionOf: "buyer",
          });
        }

        if (dueAmount == 0) {
          updateRecieptData.push({
            recieptId: mongoose.Types.ObjectId(receiptIds[i]),
            buyerId,
            newPaidAmount: paidAmount,
            saleAmount,
            dueAmount,
            isCreditApplied,
            paidAmount: Number(body.paidAmount[i]),
            totalStoragePaid: Number(body?.payStorageAmount[i]),
            payStatus: 1,
            createdBy: createdBy[i],
          });
        } else {
          updateRecieptData.push({
            recieptId: mongoose.Types.ObjectId(receiptIds[i]),
            buyerId,
            newPaidAmount: paidAmount,
            saleAmount,
            dueAmount,
            isCreditApplied,
            paidAmount: Number(body.paidAmount[i]),
            totalStoragePaid: Number(body?.payStorageAmount[i]),
            payStatus: 0,
            createdBy: createdBy[i],
          });
        }
      }
    }

    if (newPostData.length > 0) {
      await accountModal.Accountledger.insertMany(newPostData)
        .then(async (data) => {
          if (updateRecieptData.length > 0) {
            await addCustomerPayment(updateRecieptData);
            cmethod.returnSuccess(
              res,
              data,
              false,
              "payment added successfully."
            );
          }
        })
        .catch((error) => {
          console.error("Error inserting products:", error);
        });
    } else {
      cmethod.returnSreverError(res, "amount can not be empty.", "");
    }
  }
);

// * security-amount-list
router.post("/security-amount-list", async (req, res) => {
  const {
    body,
    body: { page, pageLimit },
    headers: { lang = config.lang },
  } = req;

  const pipeline = [];

  try {
    const filter = { taxType: "security", securityClaim: 0, payStatus: 1 };
    Match(pipeline, filter);

    if (body.buyerId) {
      IDMatch(pipeline, "buyerId", body.buyerId);
    }

    if (body.search) {
      const searchFields = ["recieptNo", "exportCountry"];
      RegexSearch(pipeline, searchFields, body.search);
    }

    // * users
    Lookup(pipeline, "users", "buyerId", "_id", "buyerUser");
    Unwind(pipeline, "$buyerUser");

    // * inventories
    Lookup(pipeline, "inventorys", "inventoryId", "_id", "inventories");
    Unwind(pipeline, "$inventories");

    // * outgoingCash
    const _let = {
      referenceId: "$_id",
      referenceNo: "$recieptNo",
      referenceType: "$taxType",
      status: "rejected",
    };
    const _pipeline = [
      {
        $match: {
          $expr: {
            $and: [
              {
                $eq: ["$referenceId", "$$referenceId"],
              },
              {
                $eq: ["$referenceNo", "$$referenceNo"],
              },
              {
                $eq: ["$referenecType", "$$referenceType"],
              },
              {
                $ne: ["$status", "$$status"],
              },
            ],
          },
        },
      },
    ];

    LookupWithPipeline(
      pipeline,
      "outgoingcashs",
      _let,
      _pipeline,
      "outgoingCash"
    );

    if (body.vinNo) {
      RegexMatch(pipeline, "inventories.vin", body.vinNo);
    }

    // * project
    const projection = {
      _id: 1,
      recieptNo: 1,
      branchId: 1,
      transDate: 1,
      securityAmount: 1,
      exportCountry: {
        $cond: {
          if: {
            $eq: ["$exportCountry", ""],
          },
          then: "$zeroRatedExportCountry",
          else: "$exportCountry",
        },
      },
      securityClaim: 1,
      taxType: 1,
      createdAt: 1,
      isZeroRated: 1,
      daysPassed: {
        $floor: {
          $divide: [
            { $subtract: [new Date(), "$transDate"] },
            1000 * 60 * 60 * 24,
          ],
        },
      },
      reclaimValidity: { $literal: config.securityClaimValidityDays },
      buyer: {
        name: "$buyerUser.name",
        phone: "$buyerUser.phone",
        userType: "$buyerUser.userType",
        EID: "$buyerUser.eid",
        uniqueIdentifier: "$buyerUser.uniqueIdentifier",
        countryCode: "$buyerUser.countryCode",
        companyDetails: "$buyerUser.companyDetails",
      },
      inventory: {
        lotNo: "$inventories.lotNo",
        vinNo: "$inventories.vin",
        year: "$inventories.year",
      },
      isOCAdded: {
        $cond: {
          if: {
            $eq: ["$outgoingCash", []],
          },
          then: false,
          else: true,
        },
      },
    };

    Project(pipeline, projection);

    if (body.daysPassed) {
      ExactMatch(pipeline, "daysPassed", Number(body.daysPassed));
    }

    // * sort
    Sort(pipeline, config.defaultSort);

    // * count
    const sQuery = [...pipeline];
    sQuery.push({ $count: "totalCount" });

    // * pagination
    if (page) {
      pipeline.push({
        $skip: cmethod.pageOffset(page, pageLimit),
      });
      pipeline.push({ $limit: cmethod.pageLimit(pageLimit) });
    }

    // * results
    const [result, [{ totalCount } = {}] = []] = await Promise.all([
      recieptModal.Reciept.aggregate(pipeline),
      recieptModal.Reciept.aggregate(sQuery),
    ]);

    res.status(200).json({
      status: true,
      result,
      message: "",
      hasMore: cmethod.hasMoreCount(totalCount, page, pageLimit),
      totalCount,
    });
  } catch (error) {
    logger.error(error);
    cmethod.returnSreverError(res, message[lang].technicalError, error);
  }
});

// * type-tax
router
  .route("/type-tax")
  .post(
    [
      midleware.validateFieldValue(
        ["receiptId", "exportCountry", "createdBy"],
        ["receiptId", "exportCountry", "createdBy"]
      ),
    ],
    createTaxReceipt
  )
  .get(getTaxReceipts);

router.patch("/update/:id", updateReceipt);

module.exports = router;

/**
 * @swagger
 * /api/reciept/add:
 *   post:
 *     tags: [Reciept]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: branchId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: recieptType
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: inventoryId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: buyerId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: saleAmount
 *         in: formData
 *         type: number
 *         required: true
 *         description:
 *       - name: paidAmount
 *         in: formData
 *         type: number
 *         required: true
 *         description:
 *       - name: dueBalance
 *         in: formData
 *         type: number
 *         required: true
 *         description:
 *       - name: securityAmount
 *         in: formData
 *         type: number
 *         required: true
 *         description:
 *       - name: totalAmount
 *         in: formData
 *         type: number
 *         required: true
 *         description:
 *       - name: createdBy
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: Reciepts.
 *
 */

/**
 * @swagger
 * /api/reciept/delete:
 *   delete:
 *     tags: [Reciept]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: recieptId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: Reciepts.
 *
 */

/**
 * @swagger
 * /api/reciept/list:
 *   post:
 *     tags: [Reciept]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: taxType
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: recieptType
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: branchId[]
 *         in: formData
 *         type: array
 *         items:
 *           type: string
 *         required: false
 *         description:
 *       - name: search
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *              ex - buyername,mobile,vin,eid
 *       - name: recieptId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: paymentStatus
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: sellerUserId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: buyerUserId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: notCancelled
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: ledgerData
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: gatePass
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: documentIssue
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: securityClaim
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *               ex- 1,0
 *       - name: apiType
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *           ex- 1- web, 2- default
 *       - name: pageLimit
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: page
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *     responses:
 *       200:
 *         description: Reciepts.
 *
 */

/**
 * @swagger
 * /api/reciept/addLedger:
 *   post:
 *     tags: [Reciept]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: recieptId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: payAmount
 *         in: formData
 *         type: number
 *         required: true
 *         description:
 *       - name: paymentMethod
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: createdBy
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: Reciepts.
 *
 */

/**
 * @swagger
 * /api/reciept/bankTransfer:
 *   post:
 *     tags: [Reciept]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: bank
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: amount
 *         in: formData
 *         type: number
 *         required: true
 *         description:
 *       - name: createdBy
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: Reciepts.
 *
 */

/**
 * @swagger
 * /api/reciept/updateDiscount:
 *   patch:
 *     tags: [Reciept]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: recieptId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: discount
 *         in: formData
 *         type: number
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: Reciepts.
 *
 */

/**
 * @swagger
 * /api/reciept/updateRecieptStatus:
 *   patch:
 *     tags: [Reciept]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: recieptId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: statusType
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: status
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: Reciepts.
 *
 */

/**
 * @swagger
 * /api/reciept/checkStorageUpdate:
 *   get:
 *     tags: [Reciept]
 *     produces:
 *       - application/json
 *     parameters:
 *     responses:
 *       200:
 *         description: cron job for automatic check gatepass expired or not.
 *
 */

/**
 * @swagger
 * /api/reciept/cashinhand:
 *   post:
 *     tags: [Reciept]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: branchId[]
 *         in: formData
 *         type: array
 *         items:
 *           type: string
 *         required: true
 *         description:
 *       - name: fromData
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: toData
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: recieptType
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: entryType
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *          ledger value default
 *       - name: paymentType
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *          payment type- cash,card
 *       - name: pageLimit
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: page
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: Reciepts.
 *
 */

/**
 * @swagger
 * /api/reciept/cashSummary:
 *   post:
 *     tags: [Reciept]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: fromData
 *         in: formData
 *         type: string
 *         required: true
 *         description: from date
 *       - name: toData
 *         in: formData
 *         type: string
 *         required: true
 *         description: to date
 *       - name: entryType
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: pageLimit
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: page
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: Reciepts.
 *
 */

/**
 * @swagger
 * /api/reciept/addSalesReturn:
 *   post:
 *     tags: [Reciept]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: branchId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: recieptId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: transDate
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: status
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: Reciepts.
 *
 */

/**
 * @swagger
 * /api/reciept/salesReturnlist:
 *   post:
 *     tags: [Reciept]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: branchId[]
 *         in: formData
 *         type: array
 *         items:
 *           type: string
 *         required: false
 *         description:
 *       - name: salesReturnId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: search
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: vin
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: sellerUserId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: buyerUserId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: fromDate
 *         in: formData
 *         type: string
 *         required: false
 *         description: transaction date
 *       - name: toDate
 *         in: formData
 *         type: string
 *         required: false
 *         description: transaction date
 *       - name: pageLimit
 *         in: formData
 *         type: number
 *         required: true
 *         description:
 *       - name: page
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: Reciepts.
 *
 */

/**
 * @swagger
 * /api/reciept/updateSalesReturn:
 *   patch:
 *     tags: [Reciept]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: id
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: status
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: Reciepts.
 *
 */
/**
 * @swagger
 * /api/reciept/incomingcashadd:
 *   post:
 *     tags: [Reciept]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: referenceNo
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: userName
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: paymentType
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *          cash,card,bank only value
 *       - name: transactionType
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *          dr,cr only value
 *       - name: amount
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: description
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: createdBy
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: status
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: IncomingCash.
 *
 */
/**
 * @swagger
 * /api/reciept/incomingcashlist:
 *   post:
 *     tags: [Reciept]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: search
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: pageLimit
 *         in: formData
 *         type: number
 *         required: true
 *         description:
 *       - name: page
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: incomingcashlist.
 *
 */
/**
 * @swagger
 * /api/reciept/convertReciept:
 *   post:
 *     tags: [Reciept]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: inventoryId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: auctionId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: recieptType
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: convertReciept.
 *
 */

/**
 * @swagger
 * /api/reciept/add-customer-payment:
 *   post:
 *     tags: [Reciept]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: recieptId[]
 *         in: formData
 *         type: array
 *         items:
 *           type: string
 *         collectionFormat: multi
 *         required: true
 *         description:
 *       - name: payAmount[]
 *         in: formData
 *         type: array
 *         items:
 *           type: number
 *         collectionFormat: multi
 *         required: true
 *         description:
 *       - name: payStorageAmount[]
 *         in: formData
 *         type: array
 *         items:
 *           type: number
 *         collectionFormat: multi
 *         required: false
 *         description:
 *       - name: paidAmount[]
 *         in: formData
 *         type: array
 *         items:
 *           type: number
 *         collectionFormat: multi
 *         required: false
 *         description:
 *       - name: dueAmount[]
 *         in: formData
 *         type: array
 *         items:
 *           type: number
 *         collectionFormat: multi
 *         required: false
 *         description:
 *       - name: paymentMethod[]
 *         in: formData
 *         type: array
 *         items:
 *           type: string
 *         collectionFormat: multi
 *         required: false
 *         description:
 *       - name: createdBy[]
 *         in: formData
 *         type: array
 *         items:
 *           type: string
 *         collectionFormat: multi
 *         required: false
 *         description:
 *       - name: transDate[]
 *         in: formData
 *         type: array
 *         items:
 *           type: string
 *         collectionFormat: multi
 *         required: false
 *         description:
 *     responses:
 *       200:
 *         description: Reciept - Add Customer Payment (Wallet etc)
 *
 */

/**
 * @swagger
 * /api/reciept/security-amount-list:
 *   post:
 *     tags: [Reciept]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: buyerId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: vinNo
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: daysPassed
 *         in: formData
 *         type: number
 *         required: false
 *         description:
 *       - name: search
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: pageLimit
 *         in: formData
 *         type: number
 *         required: true
 *         description:
 *       - name: page
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: Receipt - Security Amount List
 *
 */

/**
 * @swagger
 * /api/reciept/type-tax:
 *   post:
 *     tags: [Reciept]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: receiptId
 *         in: formData
 *         type: string
 *         required: true
 *       - name: createdBy
 *         in: formData
 *         type: string
 *         required: true
 *       - name: exportCountry
 *         in: formData
 *         type: string
 *         required: true
 *       - name: outgoingFile
 *         in: formData
 *         type: string
 *         required: false
 *     responses:
 *       200:
 *         description: Receipt - Tax Type Create
 *
 */

/**
 * @swagger
 * /api/reciept/type-tax:
 *   get:
 *     tags: [Reciept]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: search
 *         in: query
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: Receipt - Tax Type Receipts
 *
 */

/**
 * @swagger
 * /api/reciept/update/{id}:
 *   patch:
 *     tags: [Reciept]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: id
 *         in: path
 *         type: string
 *         required: true
 *       - name: sellerInvoice
 *         in: formData
 *         type: string
 *         required: false
 *     responses:
 *       200:
 *         description: Receipt - Update
 */
