const { number, string } = require("@hapi/joi");
const mongoose = require("mongoose");
const Schema = mongoose.Schema;
const { connWrite } = require("../../config/database");

const recieptSchema = new Schema(
  {
    branchId: {
      type: mongoose.Types.ObjectId,
      default: mongoose.Types.ObjectId(),
      index: true,
    },
    recieptNo: { type: String, index: true }, //{ type: Number, default: 0 },
    securityClaim: { type: Number, default: 0 },
    inventoryId: {
      type: mongoose.Types.ObjectId,
      default: mongoose.Types.ObjectId(),
      index: true,
    },
    buyerId: {
      type: mongoose.Types.ObjectId,
      default: mongoose.Types.ObjectId(),
      index: true,
    },
    export: { type: Boolean, default: false },
    exportCountry: String,
    saleAmount: Number,
    paidAmount: Number,
    dueBalance: Number,
    securityAmount: Number, //for vat and security amount
    storageAmount: { type: Number, default: 0 },
    storageVat: { type: Number, default: 0 },
    storageDisc: { type: Number, default: 0 },
    totalStoragePaid: { type: Number, default: 0 },
    totalStorage: { type: Number, default: 0 },
    discount: { type: Number, default: 0 }, //trading discount
    cashDiscount: { type: Number, default: 0 }, //cash discount
    totalAmount: Number,
    totalExcAmount: Number,
    totalInclAmount: Number,
    totalNetAmount: Number,
    paymentMethod: String,
    payStatus: { type: Number, default: 0, index: true },
    taxType: String, //tax,security
    transactionCharge: { type: Number, default: 0 },
    recieptType: { type: String, default: "draft", index: true },
    gatePassReady: { type: String, default: "pending" },
    documentReady: { type: String, default: "pending" },
    gatePass: { type: String, default: "pending" },
    documentIssue: { type: String, default: "pending" },
    gatePassExpired: { type: Date },
    invoiceDate: { type: Date },
    invoiceStatus: { type: String, default: "pending" }, //pending,invoiced,cancelled
    createdBy: String,
    transDate: { type: Date },
    auctionId: {
      type: mongoose.Types.ObjectId,
      default: mongoose.Types.ObjectId(),
      index: true,
    },
    isCreditApplied: { type: Boolean, default: false },
    sapId: { type: Number, default: 0, index: true },
    isZeroRated: { type: Boolean, default: false },
    zeroRatedExportCountry: String,
    sellerInvoice: String,
  },
  {
    timestamps: {
      createdAt: "createdAt",
      updatedAt: "updatedAt",
    },
  }
);

const Reciept = connWrite.model("reciepts", recieptSchema);
// Contact
const ledgerSchema = new Schema(
  {
    voucherNo: { type: Number, default: 0 },
    glAccountId: {
      type: mongoose.Types.ObjectId,
      default: null,
      index: true,
    },
    transactionType: { type: String, default: "cr" } /*like cr or dr*/,
    paymentType: { type: String, default: "cash" } /*like cash or online*/,
    payAmount: Number,
    description: String,
    referenceType: String /*reciept,inventory,sales etc. */,
    referenceId: {
      type: mongoose.Types.ObjectId,
      index: true,
    },
    balanceAmount: { type: Number, default: 0 },
    createdBy: {
      type: String,
    },

    recieptId: {
      type: mongoose.Types.ObjectId,
      index: true,
    },
    entryType: { type: String, default: "ledger" } /*like ledger or invoice*/,
    ledgerType: {
      type: String,
      default: "buyersale",
    } /*like buyersales or salersale or bankDeposit*/,
    type: String /*like sale,vat,totalamount,transactionFee ,bankTransfer*/,
  },
  {
    timestamps: {
      createdAt: "createdAt",
      updatedAt: "updatedAt",
    },
  }
);
const Ledger = connWrite.model("ledgers", ledgerSchema);

//saleReturn
const salesReturnSchema = new Schema(
  {
    salesReturnNo: { type: String, default: "", index: true },
    branchId: {
      type: mongoose.Types.ObjectId,
      default: null,
      index: true,
    },
    recieptId: {
      type: mongoose.Types.ObjectId,
      default: null,
      index: true,
    },
    returnAmount: Number,
    type: { type: String, default: "return" }, // * return|selfbid
    otherIncome: { type: Number, default: 0 },
    status: String, // * pending|approved
    refundStatus: String, //* yes|no
    returnDate: { type: Date },
    createdBy: String,
    transDate: { type: Date },
  },
  {
    timestamps: {
      createdAt: "createdAt",
      updatedAt: "updatedAt",
    },
  }
);
const Salesreturn = connWrite.model("salesreturns", salesReturnSchema);
//IncomngCash
//saleReturn
const IncomngCashSchema = new Schema(
  {
    referenceNo: String,
    userName: String,
    transactionType: String,
    paymentType: String,
    amount: { type: Number, default: 0 },
    description: String,
    createdBy: String,
    approvedBy: String,
    status: { type: Number, default: 0 },
  },
  {
    timestamps: {
      createdAt: "createdAt",
      updatedAt: "updatedAt",
    },
  }
);
const IncomingCash = connWrite.model("incomingcashs", IncomngCashSchema);

module.exports = {
  Reciept,
  Ledger,
  Salesreturn,
  IncomingCash,
};
