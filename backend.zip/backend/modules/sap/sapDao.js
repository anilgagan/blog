const uModal = require("../user/userModal");
const masterModal = require("../master/masterModal");
const masterDao = require("../master/masterDao");
const auctionDao = require("../auction/auctionDao");
const accountDao = require("../account/accountDao");
const userDao = require("../user/userDao");
const { Accountledger } = require("../account/accountModal")
const { Reciept } = require("../reciept/recieptModal")
const { Inventorytemps } = require("../inventory/inventoryModal")
const { existMaster } = require("../inventory/inventoryDao")
const message = require("../../config/message");
const jwt = require("jsonwebtoken");
const config = require("../../config");
const midleware = require("../../middleware/validation");
const Promise = require("bluebird");
const cmethod = require("../../middleware/common-fun");
const moment = require("moment");
var axios = require("axios");
var sapBaseUrl = process.env.SAP_BASE_URL;
const {
  storeHash,
  getHash,
  encrypt,
  deleteHash,
  customDelete,
  deleteUser,
} = require("../../middleware/redisConnection");
var mongoose = require("mongoose");
const { connWrite, connRead } = require("./../../config/database");
const { access } = require("fs-extra");

const getSapAccessToken = async function () {
  try {
    const response = await axios.post(sapBaseUrl + "/Auth/Authenticate/Login", {
      username: process.env.SAP_USERNAME,
      password: process.env.SAP_PASSWORD
    },
      {
        "Content-Type": "application/json",
      }
    );
    if (response.status == 200) {
      // console.log("washi_res",response.data);
      let accessToken = response?.data?.token;
      return accessToken;
    }

    // res.status(200).json(response);
  } catch (err) {
    console.log("accessToken error", err);
    // res.status(500).json({ message: err });
  }
}
const sapbusinessPartener = async function (businesspartnerid) {
  let query = [];
  query.push({
    $match: {
      $and: [{ status: 1 }],
    },
  });
  if (businesspartnerid) {
    query.push({
      $match: {
        $and: [{ _id: mongoose.Types.ObjectId(businesspartnerid) }],
      },
    });
  }
  const sQuery = [...query];
  query.push({
    $project: {
      _id: 1,
      //branchId: "$branchs._id",
      //branchs: 1,
      userroles: 1,
      accessToken: 1,
      uniqueIdentifier: 1,
      createdAt: 1,
      deviceId: 1,
      deviceType: 1,
      email: 1,
      loginStatus: 1,
      name: 1,
      password: 1,
      phone: 1,
      eid: 1,
      businessType: 1,
      address: 1,
      companyDetails: 1,
      refreshToken: 1,
      token: 1,
      updatedAt: 1,
      userType: 1,
      verifyStatus: 1,
      status: 1,
      eidExpiry: 1,
      tradeLicenceNo: 1,
      tlExpiry: 1,
      trnCertificate: 1,
      eidCertificate: 1,
      tradeLicense: 1,
      qwaitingDepart: 1,
      qwaitingMappCounterId: 1,
      createdAt: 1,
    },
  });
  query.push({ $sort: { createdAt: -1 } });

  return new Promise(async function (resolve, reject) {
    let sellerdata = await userDao.findUserAggregation(query);
    if (sellerdata.length > 0) {
      let series;
      let cardTpe;
      let groupCode;
      let vatGroup;
      if (sellerdata[0]?.userType == 2 || sellerdata[0]?.userType == 3) {
        series = '71';
        cardTpe = 'S';
        groupCode = '101';
        vatGroup = "V1";
      } else {
        series = '70';
        cardTpe = 'C';
        groupCode = '100';
        vatGroup = "A1";
      }
      series = '70';
      cardTpe = 'C';
      groupCode = '100';
      vatGroup = "A1";
      sellerdata = sellerdata[0];
      let jsondata = {
        series: series,
        cardCode: String(sellerdata?.uniqueIdentifier),
        cardName: sellerdata?.name,
        cardType: cardTpe,
        groupCode: groupCode,
        BPAddresses: [
          {
            AddressName: sellerdata?.address,
            Street: null,
            Block: null,
            ZipCode: null,
            City: null,
            County: null,
            Country: null,
            State: null,
            FederalTaxID: null,
            TaxCode: null,
            BuildingFloorRoom: null,
            AddressType: "bo_BillTo",
            AddressName2: null,
            AddressName3: null,
            TypeOfAddress: null,
            StreetNo: null,
            RowNum: 0
          }
        ],
        contactEmployees: [
          {
            name: sellerdata?.name,
            phone1: String(sellerdata?.phone),
            active: 'tYES',
            firstName: sellerdata?.name,
            middleName: '',
            lastName: '',
          }
        ],
        zipCode: null,
        emailAddress: sellerdata?.email ? sellerdata?.email : '',
        mailZipCode: "",
        phone1: String(sellerdata?.phone),
        phone2: "",
        fax: "",
        notes: "",
        payTermsGrpCode: -1,
        vatLiable: "vLiable",
        freeText: "free_Text",
        salesPersonCode: "-1",
        currency: "USD",
        createDate: "2023-05-08",
        updateDate: "2023-05-08",
        validFrom: "2023-05-08",
        validTo: "2023-10-08",
        frozenFrom: "2023-05-08",
        frozenTo: "2023-05-08",
        valid: "tYES",
        frozen: "tNO",
        vatGroup: vatGroup,
        U_Branch_Name: "Branch 1",
        U_Email: String(sellerdata.email ? sellerdata?.email : "email"),
        U_Phone: String(sellerdata?.phone ? sellerdata?.phone : "phone"),
        U_Name: String(sellerdata?.name ? sellerdata?.name : "name"),
        U_Seller_Buyer_Type: String(sellerdata?.sellerBuyerType ? sellerdata?.sellerBuyerType : "type"),
        U_Business_Type: String(sellerdata?.businessType ? sellerdata?.businessType : "type1"),
        U_Unique_Identifier: String(sellerdata?.uniqueIdentifier ? sellerdata?.uniqueIdentifier : "123"),
        U_Eid: String(sellerdata?.eid ? sellerdata?.eid : "123"),
        U_Eid_Expiry: String(sellerdata?.eidExpiry ? sellerdata?.eidExpiry : "2023-05-15"),
        U_Address: String(sellerdata?.address ? sellerdata?.address : "123"),
        U_Cname: String(sellerdata?.name ? sellerdata?.name : "123"),
        U_C_Primary_Name: String(sellerdata?.companyDetails?.primaryName ? sellerdata?.companyDetails?.primaryName : "123"),
        U_C_Primary_Contact: String(sellerdata?.companyDetails?.primaryContact ? sellerdata?.companyDetails?.primaryContact : "123"),
        U_Trn: String(sellerdata?.companyDetails?.trn ? sellerdata?.companyDetails?.trn : "123"),
        U_Trade_Licence_No: String(sellerdata?.tradeLicenceNo ? sellerdata?.tradeLicenceNo : "123"),
        U_Tl_Expiry: String(sellerdata?.tlExpiry ? sellerdata?.tlExpiry : "2023-05-15"),
        U_Trn_Certificate: String(sellerdata?.trnCertificate ? sellerdata?.trnCertificate : "1123"),
        U_Eid_Certificate: String(sellerdata?.eidCertificate ? sellerdata?.eidCertificate : "123"),
        U_Trade_License: String(sellerdata?.tradeLicense ? sellerdata?.tradeLicense : "122"),
        U_Status: String(sellerdata?.trnCertificate ? sellerdata?.trnCertificate : "123"),
        U_Created_At: String("2023-05-15"),
      }
      let accessToken = await getSapAccessToken();
      let result;
      try {
        let response = await axios({
          method: "post",
          url: sapBaseUrl + "/BusinessPartners?CompanyCode=TEST_ACA",
          headers: {
            "Content-Type": "application/json",
            "Authorization": 'Bearer ' + accessToken
          },
          data: jsondata,
        });
        if (response.status == 200) {
          result = response?.data;
          // console.log("rppp====",result)
          await uModal.User.updateOne(
            { _id: mongoose.Types.ObjectId(businesspartnerid) },
            { $set: { sapId: result?.data?.cardCode } }
          );
        } else {
          result = response?.data;
        }
      } catch (err) {
        result = err?.response?.data;
        // console.log("accessToken error", err?.response?.data);

      }
      resolve(result)
    } else {
      resolve(result)
    }
  })

}
const sapincomingPaymnent = async function (voucherNos) {
  console.log("anilgagan--------------", voucherNos);
  let query = [];
  query.push({
    $lookup: {
      from: "accountmasters",
      localField: "glAccountId",
      foreignField: "_id",
      as: "accountmasters",
    },
  });
  query.push({
    $unwind: { path: "$accountmasters", preserveNullAndEmptyArrays: true },
  });

  query.push({
    $lookup: {
      from: "users",
      localField: "buyerNo",
      foreignField: "uniqueIdentifier",
      as: "buyers",
    },
  });
  query.push({
    $unwind: { path: "$buyers", preserveNullAndEmptyArrays: true },
  });

  query.push({
    $match: {
      $and: [
        {
          "accountmasters.markAccountId": { $in: ['cash-in-hand', 'cash-in-bank', 'cash-in-bank-sajja', 'cash-in-bank-ind'] }
        },
        {
          voucherNo: voucherNos,
          transactionType: "dr"
        }
      ],
    },
  });


  const sQuery = [...query];
  query.push({
    $project: {
      sapId: "$buyers.sapId",//"C00009",
      transDate: 1,
      referenceNo: 1,
      paymentType: 1,
      payAmount: 1,
      voucherNo: 1,
      buyers: 1

    },
  });
  query.push({ $sort: { createdAt: 1 } });

  return new Promise(async function (resolve, reject) {
    let sapdata = await accountDao.findAccountledgerAggregation(query);

    console.log("@@@@@----->", sapdata);
    // var date = new Date();
    // var formattedDate = moment(date).format('YYYYMMDD');
    if (sapdata) {
      sapdata = sapdata[0];
      let jsondata = {
        // docEntry: "",
        // buyerCode: "C00009",
        // cashAccount: "10201140",
        // tokenNo: "AQ_300",
        // amount: 10,
        // onAccount: true,
        // docDate: "2023-08-05"

        docEntry: "",
        onAccount: true,
        buyerCode: String(sapdata?.sapId ? sapdata?.sapId : "C00009"),
        cashAccount: "10201140",
        tokenNo: String(sapdata?.voucherNo),
        amount: sapdata?.payAmount ? sapdata?.payAmount : 0,
        docDate: "2023-08-05"
      }
      console.log("washisap", jsondata);
      let accessToken = await getSapAccessToken();
      let result;
      try {
        let response = await axios({
          method: "post",
          url: sapBaseUrl + "/Bids/IncomingPayment?CompanyCode=TEST_ACA",
          headers: {
            "Content-Type": "application/json",
            "Authorization": 'Bearer ' + accessToken
          },
          data: jsondata,
        });
        console.log("akg------------------->", response)
        if (response.status == 200) {
          result = response.data;
          await Reciept.updateOne(
            { recieptNo: sapdata?.referenceNo },
            { $set: { sapId: result?.data?.incomingPaymentDocEntry } }
          );
          await Accountledger.updateOne(
            { _id: mongoose.Types.ObjectId(sapdata?._id) },
            { $set: { sapId: result?.data?.incomingPaymentDocNum } }
          );
        } else {
          result = response.data;
        }
      } catch (err) {
        result = err?.response?.data;

      }
      console.log("result------------------->", result)
      resolve(result)
    } else {
      resolve(result)
    }
  })
};
const sapsyncInventory = async function () {
  let syncdataList = {
    "data": [
      {
        "ItemCode": "AlQaryah_CAR_1",
        "ItemName": "AlQaryah CAR 1",
        "U_Inventory_Status": "ok",
        "U_Cost_Price": 300,
        "U_Make": "123",
        "U_Year": "2023",
        "U_Interior_Color": "123",
        "U_Exterior_Color": "123",
        "U_Body": "Thi is a new item",
        "U_Drive_Type": "123",
        "U_Fuel_Type": "123",
        "U_Series": "123",
        "U_Vcc_Doc": "123",
        "U_Key": "123",
        "U_Images": "123",
        "U_Created_At": "2023-05-05T00:00:00",
        "U_Milage": 123,
        "U_Starting_Bid": 300,
        "U_Branch_Name": "123",
        "U_Warehouse_Name": "123",
        "U_Model": "123",
        "U_Reserve_Price": 320,
        "U_Plan_Price": 350,
        "U_Purchase_Doc": "123",
        "U_Owner_Code": "Owner code",
        "U_Owner_Name": "Owner Name"
      },
      {
        "ItemCode": "AlQaryah_CAR_2",
        "ItemName": "AlQaryah CAR 2",
        "U_Inventory_Status": "ok",
        "U_Cost_Price": 300,
        "U_Make": "123",
        "U_Year": "2023",
        "U_Interior_Color": "123",
        "U_Exterior_Color": "123",
        "U_Body": "Thi is a new item",
        "U_Drive_Type": "123",
        "U_Fuel_Type": "123",
        "U_Series": "123",
        "U_Vcc_Doc": "123",
        "U_Key": "123",
        "U_Images": "123",
        "U_Created_At": "2023-05-22T00:00:00",
        "U_Milage": 123,
        "U_Starting_Bid": 300,
        "U_Branch_Name": "123",
        "U_Warehouse_Name": "123",
        "U_Model": "123",
        "U_Reserve_Price": 320,
        "U_Plan_Price": 350,
        "U_Purchase_Doc": "123",
        "U_Owner_Code": "Owner code",
        "U_Owner_Name": "Owner Name"
      },
      {
        "ItemCode": "ITM0001",
        "ItemName": "Item Name 1",
        "U_Inventory_Status": {},
        "U_Cost_Price": {},
        "U_Make": "HONDA",
        "U_Year": "2001",
        "U_Interior_Color": "Black",
        "U_Exterior_Color": "White",
        "U_Body": "SEDAN",
        "U_Drive_Type": "4 WHEEL",
        "U_Fuel_Type": "DIESEL",
        "U_Series": "Series 1",
        "U_Vcc_Doc": {},
        "U_Key": "Yes",
        "U_Images": {},
        "U_Created_At": {},
        "U_Milage": 10000,
        "U_Starting_Bid": {},
        "U_Branch_Name": {},
        "U_Warehouse_Name": {},
        "U_Model": "CIVIC",
        "U_Reserve_Price": {},
        "U_Plan_Price": {},
        "U_Purchase_Doc": {},
        "U_Owner_Code": "NAJ",//NAS diff user assign
        "U_Owner_Name": "Noor Al Jabal"
      }
    ]
  }

  return new Promise(async function (resolve, reject) {
    let syncdata = syncdataList.data;
    //console.log("11--------", syncdata);
    //return false;
    let syncDataArr = [];
    let keyData = [];
    let result;
    if (syncdata.length > 0) {
      for (let i = 0; i < syncdata.length; i++) {

        syncDataArr.push({
          ItemCode: syncdata[i]?.ItemCode,
          ItemName: syncdata[i]?.ItemName,
          U_Inventory_Status: syncdata[i]?.U_Inventory_Status,
          U_Cost_Price: syncdata[i]?.U_Cost_Price,
          U_Make: syncdata[i]?.U_Make,
          U_Year: syncdata[i]?.U_Year,
          U_Interior_Color: syncdata[i]?.U_Interior_Color,
          U_Exterior_Color: syncdata[i]?.U_Exterior_Color,
          U_Body: syncdata[i]?.U_Body,
          U_Drive_Type: syncdata[i]?.U_Drive_Type,
          U_Fuel_Type: syncdata[i]?.U_Fuel_Type,
          U_Series: syncdata[i]?.U_Series,
          U_Vcc_Doc: syncdata[i]?.U_Vcc_Doc,
          U_Key: syncdata[i]?.U_Key,
          U_Images: syncdata[i]?.U_Images,
          U_Created_At: syncdata[i]?.U_Created_At,
          U_Milage: syncdata[i]?.U_Milage,
          U_Starting_Bid: syncdata[i]?.U_Starting_Bid,
          U_Branch_Name: syncdata[i]?.U_Branch_Name,
          U_Warehouse_Name: syncdata[i]?.U_Warehouse_Name,
          U_Model: syncdata[i]?.U_Model,
          U_Reserve_Price: syncdata[i]?._Reserve_Price,
          U_Plan_Price: syncdata[i]?.U_Plan_Price,
          U_Purchase_Doc: syncdata[i]?.U_Purchase_Doc,
          U_Owner_Code: syncdata[i]?.U_Owner_Code,
          U_Owner_Name: syncdata[i]?.U_Owner_Name,
        })
        keyData.push({
          ItemCode: syncdata[i]?.ItemCode,
        });
      }

      result = {
        status: "success",
        data: keyData,
        message: "Save no of items is " + keyData.length
      }
    }
    //console.log("22--------", result);
    resolve(result)
  })
};
const bids = async function (voucherNos) {
  //let newvoucherNos = await voucherNos;
  //voucherNo = recieptNo?.voucherNo;
  //console.log("sapincomingPaymnent----------", voucherNos);
  let query = [];
  query.push({
    $lookup: {
      from: "accountmasters",
      localField: "glAccountId",
      foreignField: "_id",
      as: "accountmasters",
    },
  });
  query.push({
    $unwind: { path: "$accountmasters", preserveNullAndEmptyArrays: true },
  });
  query.push({
    $lookup: {
      from: "reciepts",
      localField: "referenceNo",
      foreignField: "recieptNo",
      as: "reciepts",
    },
  });
  query.push({
    $unwind: { path: "$reciepts", preserveNullAndEmptyArrays: true },
  });
  // query.push({
  //   $lookup: {
  //     from: "users",
  //     localField: "buyerNo",
  //     foreignField: "uniqueIdentifier",
  //     as: "buyers",
  //   },
  // });
  // query.push({
  //   $unwind: { path: "$buyers", preserveNullAndEmptyArrays: true },
  // });
  // query.push({
  //   $lookup: {
  //     from: "users",
  //     localField: "sellerNo",
  //     foreignField: "uniqueIdentifier",
  //     as: "sellers",
  //   },
  // });
  // query.push({
  //   $unwind: { path: "$sellers", preserveNullAndEmptyArrays: true },
  // });

  query.push({
    $match: {
      $and: [
        {
          "accountmasters.markAccountId": { $in: ['cash-in-hand', 'cash-in-bank', 'cash-in-bank-sajja', 'cash-in-bank-ind'] }
        },
        {
          voucherNo: voucherNos
        },
        // {
        //   "sellers.userType": { $in: [2,3,4,5] }
        // }
      ],
    },
  });


  const sQuery = [...query];
  query.push({
    $project: {
      voucherNo: 1,
      markAccountId: "$accountmasters.markAccountId",
      //sellerCode: "C00009",
      //buyerCode: "C00009",
      //sellerCode: "$sellers.sapId",
      //buyerCode: "$buyers.sapId",
      //sellers: 1,
      //buyers: 1,
      //sellerNo: "C00009",
      saleAmount: "$reciepts.saleAmount",
      paidAmount: "$reciepts.paidAmount",
      dueBalance: "$reciepts.dueBalance",
      securityAmount: "$reciepts.securityAmount",
      sellerNo: 1,
      buyerNo: 1,
      tokenNo: "$reciepts.recie",
      transDate: 1,
      referenceNo: 1,
      paymentType: 1,
      payAmount: 1,
      itemCode: "ITM0012s",
      carCode: "ITM0012s"
    },
  });
  query.push({ $sort: { createdAt: 1 } });

  return new Promise(async function (resolve, reject) {
    let sapdatas = await accountDao.findAccountledgerAggregation(query);
    //console.log("well========>>>>>", sapdatas); //return false;
    let sapdata = sapdatas[0];

    //seller data
    let sellerUnique = {
      $and: [{ uniqueIdentifier: sapdata?.sellerNo }, { sellerNo: { $gt: 0 } }],
    };
    const sellerData = await uModal.User.findOne(sellerUnique, {
      sapId: 1,
    }).sort({ createdAt: -1 });

    if (sellerData) {
      sapdata.sellerCode = sellerData.sapId;
    }

    //buyer data
    let buyerUnique = {
      $and: [{ uniqueIdentifier: sapdata?.buyerNo }, { buyerNo: { $gt: 0 } }],
    };
    const buyerData = await uModal.User.findOne(buyerUnique, {
      sapId: 1,
    }).sort({ createdAt: -1 });

    if (buyerData) {
      sapdata.buyerCode = buyerData.sapId;
    }

    if (sapdatas.length > 0) {
      //console.log("Inner data========>>>>>", sapdata);
      jsondata = {
        tokenNo: sapdata?.referenceNo ? sapdata?.referenceNo : '',
        //tokenNo: String(sapdata?.voucherNo),
        itemCode: sapdata?.itemCode ? sapdata?.itemCode : '',
        carCode: sapdata?.carCode ? sapdata?.carCode : 'ITM0013s',
        itemOwnerCode: "",
        acaCode: "ACA", //sapdata?.sellerCode ? sapdata?.sellerCode : 'C00043',        
        sellerCode: sapdata?.sellerCode ? sapdata?.sellerCode : 'C00043',
        sellerCurrency: "AED",
        sellerVatGroup: "A1",
        sellerWarehouseCode: "01",
        buyerCode: sapdata?.buyerCode ? sapdata?.buyerCode : 'C00043',
        buyerCurrency: "AED",
        buyerVatGroup: "A1",
        buyerWarehouseCode: "01",
        minBid: 450,//salemaout
        bidValue: sapdata?.saleAmount ? sapdata?.saleAmount : 20000, //salemaout
        downPayment: sapdata?.payAmount ? sapdata?.payAmount : 20000, //salemaout,
        paymentType: "Cash",
        auctionCharges: 450,
        vat: 5,
        time: "02:30:00",
        date: "2023-08-02",
        cashAccount: "10201140",
        depositAccount: "11201150",
        export: false
      }

    } else {
      //console.log("Outer data========>>>>>", sapdata);
      jsondata = {
        tokenNo: "AQ_300",
        itemCode: "ITM0012s",
        carCode: "ITM0012s",
        itemOwnerCode: "",
        acaCode: "V00018",
        sellerCode: "C00009",
        sellerCurrency: "AED",
        sellerVatGroup: "A1",
        sellerWarehouseCode: "01",
        buyerCode: "C00009",
        buyerCurrency: "AED",
        buyerVatGroup: "A1",
        buyerWarehouseCode: "01",
        minBid: 450,
        bidValue: 20000,
        downPayment: 2000,
        paymentType: "Cash",
        auctionCharges: 450,
        vat: 5,
        time: "02:30:00",
        date: "2023-08-02",
        cashAccount: "10201140",
        depositAccount: "11201150",
        export: false

      }
    }
    //console.log("jsondata========>>>>>", jsondata);
    // return false;
    let result;
    let pushbidsdata = [];
    let accessToken = await getSapAccessToken();
    try {
      let response = await axios({
        method: "post",
        url: sapBaseUrl + "/Bids?CompanyCode=TEST_ACA",
        headers: {
          "Content-Type": "application/json",
          "Authorization": 'Bearer ' + accessToken
        },
        data: jsondata,
      });
      //console.log("response========>>>>>", response.data);
      if (response.status == 200) {
        result = response.data;
        //console.log("AAAAAAAAAAAAA========>>>>>", jsondata.itemCode);
        pushbidsdata.push({
          vin: jsondata.itemCode,
        });
        //console.log("anil_res100", response.data);
      } else {
        result = response.data;        
        console.log("anil_err200", response?.data);
        
      }
      //console.log("anil_err300", pushbidsdata);
    } catch (err) {
      console.log("accessToken error200", err?.response?.data);

    }
    resolve(pushbidsdata)

  })
};
const InventoryStatus = async function (userId) {
  return new Promise(async function (resolve, reject) {
    let accessToken = await getSapAccessToken();
    let result;
    try {
      let response = await axios({
        method: "post",
        url: sapBaseUrl + "/Outbound/InventoryStatus?CompanyCode=TEST_ACA",
        headers: {
          "Content-Type": "application/json",
          "Authorization": 'Bearer ' + accessToken
        }
      });
      if (response.status == 200) {
        let allVehicles = response?.data?.data;
        let pullData = [];
        if (allVehicles.length > 0) {
          for (let i = 0; i < allVehicles.length; i++) {
            if (allVehicles[i]?.ItemCode == 'SERV_AC') {
              continue;
            }
            pullData.push({
              userId: userId,
              sellerId: sellerId,
              // branchId: mongoose.Types.ObjectId(branchId),
              // warehosId: mongoose.Types.ObjectId(warehosId),
              vin: allVehicles[i]?.ItemCode,
              make: allVehicles[i]?.U_Make,
              model: allVehicles[i]?.U_Model,
              year: allVehicles[i]?.U_Year,
              // color: allVehicles[i]?.color,
              milage: allVehicles[i]?.U_Milage,
              reservePrice: allVehicles[i]?.U_Reserve_Price,
              interiorcolorId: allVehicles[i]?.U_Interior_Color,
              exteriorcolorId: allVehicles[i]?.U_Exterior_Color,
              bodyId: allVehicles[i]?.U_Body,
              drivetypeId: allVehicles[i]?.U_Drive_Type,
              // engineId: allVehicles[i]?.engine,
              seriesId: allVehicles[i]?.U_Series,
              fueltypeId: allVehicles[i]?.U_Fuel_Type,
              startingBid: allVehicles[i]?.U_Starting_Bid,
              // containerNo: allVehicles[i]?.container_no,
              costPrice: allVehicles[i]?.U_Cost_Price,
            });
          }
        }
        // console.log("washi===========",pullData);
        await syncInventory(pullData);
        result = {
          status: "success",
          data: pullData,
          message: "Total Items found " + allVehicles.length
        }
      } else {
        result = response.data;
      }
    } catch (err) {
      result = err?.response?.data
      // console.log("accessToken error", err?.response?.data);

    }
    resolve(result)
  });
}
const tempdataList = async function (userId, responseList) {
  return new Promise(async function (resolve, reject) {
    let result;
    try {
      // let responseList = {
      //   "data": [
      //     {
      //       "ItemCode": "AlQaryah_CAR_1",
      //       "ItemName": "AlQaryah CAR 1",
      //       "U_Inventory_Status": "ok",
      //       "U_Cost_Price": 300,
      //       "U_Make": "MAZDA",
      //       "U_Year": "2023",
      //       "U_Interior_Color": "123",
      //       "U_Exterior_Color": "123",
      //       "U_Body": "Thi is a new item",
      //       "U_Drive_Type": "123",
      //       "U_Fuel_Type": "123",
      //       "U_Series": "1.5",
      //       "U_Vcc_Doc": "123",
      //       "U_Key": "123",
      //       "U_Images": "123",
      //       "U_Created_At": "2023-05-05T00:00:00",
      //       "U_Milage": 123,
      //       "U_Starting_Bid": 300,
      //       "U_Branch_Name": "123",
      //       "U_Warehouse_Name": "123",
      //       "U_Model": "SPORTAGE",
      //       "U_Reserve_Price": 320,
      //       "U_Plan_Price": 350,
      //       "U_Purchase_Doc": "123",
      //       "U_Owner_Code": "Owner code",
      //       "U_Owner_Name": "Owner Name"
      //     },
      //     {
      //       "ItemCode": "ITM0001",
      //       "ItemName": "Item Name 1",
      //       "U_Inventory_Status": "okk",
      //       "U_Cost_Price": 300,
      //       "U_Make": "DODGE",
      //       "U_Year": "2023",
      //       "U_Interior_Color": "123",
      //       "U_Exterior_Color": "123",
      //       "U_Body": "Thi is a new item",
      //       "U_Drive_Type": "123",
      //       "U_Fuel_Type": "123",
      //       "U_Series": "C0",
      //       "U_Vcc_Doc": "123",
      //       "U_Key": "123",
      //       "U_Images": "123",
      //       "U_Created_At": "2023-05-05T00:00:00",
      //       "U_Milage": 123,
      //       "U_Starting_Bid": 300,
      //       "U_Branch_Name": "123",
      //       "U_Warehouse_Name": "123",
      //       "U_Model": "DISCOVERY",
      //       "U_Reserve_Price": 320,
      //       "U_Plan_Price": 350,
      //       "U_Purchase_Doc": "123",
      //       "U_Owner_Code": "Owner code",
      //       "U_Owner_Name": "Owner Name"
      //     }
      //   ]
      // }

      //-----------------------------------get branchId and warehousename------------------
      if (userId) {
        console.log('---debug-01');
        userId = userId;
      } else {
        console.log('---debug-02');
        userId = mongoose.Types.ObjectId("644bb2165b522f97549c00a6");
      }
      let warehosId;
      let queryUnique = {
        $and: [{ branchName: { $exists: true } }, { branchName: { $gt: 0 } }],
      };
      const masterData = await masterModal.Branch.findOne(queryUnique, {
        branchName: 1,
      }).sort({ createdAt: 1 }).limit(1);
      const branchId = mongoose.Types.ObjectId(masterData._id);
      if (masterData) {
        let queryUniquewarehouse = {
          $and: [{ warehouseName: { $exists: true } }, { warehouseName: { $gt: 0 } }, { branchId: branchId }],
        };
        const warehouseData = await masterModal.Warehouse.findOne(queryUniquewarehouse, {
          warehouseName: 1, branchId: 1,
        }).sort({ createdAt: 1 });
        warehosId = mongoose.Types.ObjectId(warehouseData._id);
      }
      //-----------------------------------get engineName------------------
      let engineUnique = {
        $and: [{ engineName: { $exists: true } }, { engineName: { $gt: 0 } }],
      };
      const engineData = await masterModal.Engines.findOne(engineUnique, {
        engineName: 1,
      }).sort({ createdAt: 1 }).limit(1);
      const engineId = mongoose.Types.ObjectId(engineData._id);



      let allVehicles = responseList?.data;
      let pullData = [];
      if (allVehicles.length > 0) {
        for (let i = 0; i < allVehicles.length; i++) {
          if (allVehicles[i]?.ItemCode == 'SERV_AC') {
            continue;
          }
          if (allVehicles[i]?.U_Owner_Name == 'NAS') {
            sellerId = mongoose.Types.ObjectId("645a106e71fd6a79b9291065");
          } else {
            sellerId = mongoose.Types.ObjectId("645a100e71fd6a79b9291055");
          }
          pullData.push({
            userId: userId,
            sellerId: sellerId,
            branchId: branchId,
            warehosId: warehosId,
            engineId: engineId,
            vin: allVehicles[i]?.ItemCode,
            make: allVehicles[i]?.U_Make,
            model: allVehicles[i]?.U_Model,
            year: allVehicles[i]?.U_Year,
            milage: allVehicles[i]?.U_Milage,
            reservePrice: allVehicles[i]?.U_Reserve_Price,
            interiorcolorId: allVehicles[i]?.U_Interior_Color,
            exteriorcolorId: allVehicles[i]?.U_Exterior_Color,
            bodyId: allVehicles[i]?.U_Body,
            drivetypeId: allVehicles[i]?.U_Drive_Type,
            seriesId: allVehicles[i]?.U_Series,
            fueltypeId: allVehicles[i]?.U_Fuel_Type,
            startingBid: allVehicles[i]?.U_Starting_Bid,
            costPrice: allVehicles[i]?.U_Cost_Price,
            status: allVehicles[i]?.U_Inventory_Status,
            containerNo: allVehicles[i]?.container_no,
          });
        }
      }


      //console.log("anil===========", pullData); return false;
      let insertData= await syncInventory(pullData);
      let successVin=[];
      for (let i = 0; i < insertData.length; i++) {
        successVin.push(insertData[i]?.vin);
      }
      result = {
        status: "success",
        data: successVin,
        message: "Total Items found " + successVin.length
      }
      // } else {
      //   result = response.data;
      // }
    } catch (err) {
      result = err?.response?.data
      // console.log("accessToken error", err?.response?.data);

    }
    resolve(result)
  });
}
const syncInventory = async function (results) {
  let insertData = [];
  if (results.length > 0) {
    let userId;
    let sellerId;
    let branchId;
    let warehosId;
    for (let i = 0; i < results.length; i++) {
      userId = results[i]?.userId;
      sellerId = results[i]?.sellerId;
      branchId = results[i]?.branchId;
      warehosId = results[i]?.warehosId;
      // console.log("washi============",userId); return false;
      results[i] = await existMaster(results[i]);
      const getParams = results[i][0]?.getParams;
      const remarksArrs = results[i][0]?.remarksArr;
      const rArrayy = remarksArrs.join(" ,");
      //  console.log("cheetah==========",getParams);

      insertData.push({
        userId: mongoose.Types.ObjectId(userId),
        sellerId: mongoose.Types.ObjectId(sellerId),
        branchId: mongoose.Types.ObjectId(branchId),
        warehosId: mongoose.Types.ObjectId(warehosId),
        vin: getParams?.vin,
        make: getParams?.make,
        model: getParams?.model,
        year: getParams?.year,
        // color: getParams.color,
        milage: getParams?.milage,
        // reservePrice: getParams?.reserve_price,
        // interiorcolorId: getParams?.interior_color,
        // exteriorcolorId: getParams?.exterior_color,
        // bodyId: getParams?.body,
        // drivetypeId: getParams?.drive_type,
        // engineId: getParams?.engine,
        // seriesId: getParams?.series,
        // fueltypeId: getParams?.fuel_type,
        remarks: rArrayy,
        // duplicatetemp: getParams.duplicatetemp,
        // startingBid: getParams?.starting_bid,
        // containerNo: getParams.container_no,
        // costPrice: getParams?.costPrice,
      });
    }
    //console.log("kkkk==============", insertData); return false;
    if (insertData.length > 0) {
      await Inventorytemps.deleteMany({
        userId: mongoose.Types.ObjectId(userId),
      });
      await Inventorytemps.insertMany(insertData);
      // , (err, data) => {
      //   if (err) {
      //     cmethod.returnSreverError(res, "dsaasa", err);
      //   } else {
      //     cmethod.returnSuccess(
      //       res,
      //       data,
      //       false,
      //       "Data has been imported successfully!"
      //     );
      //   }
      // }
    }

  }

  return insertData;

}

const getReserveInvoiceData = async function (res, postData) {
  let query = [];
  query.push({
    $lookup: {
      from: "accountmasters",
      localField: "glAccountId",
      foreignField: "_id",
      as: "accountmasters",
    },
  });
  query.push({
    $unwind: { path: "$accountmasters", preserveNullAndEmptyArrays: true },
  });
  query.push({
    $lookup: {
      from: "reciepts",
      localField: "referenceNo",
      foreignField: "recieptNo",
      as: "reciepts",
    },
  });
  query.push({
    $unwind: { path: "$reciepts", preserveNullAndEmptyArrays: true },
  });
  query.push({
    $lookup: {
      from: "users",
      localField: "buyerNo",
      foreignField: "uniqueIdentifier",
      as: "buyers",
    },
  });
  query.push({
    $unwind: { path: "$buyers", preserveNullAndEmptyArrays: true },
  });
  query.push({
    $lookup: {
      from: "users",
      localField: "sellerNo",
      foreignField: "uniqueIdentifier",
      as: "sellerUsers",
    },
  });

  query.push({
    $unwind: { path: "$sellerUsers", preserveNullAndEmptyArrays: true },
  });
  query.push({
    $match: {
      $and: [
        {
          "accountmasters.markAccountId": "sales"
        },
        {
          voucherNo: postData?.voucherNo
        }
      ],
    },
  });


  const sQuery = [...query];
  query.push({
    $project: {
      buyerCode: "$buyers.uniqueIdentifier",
      buyerName: "$buyers.name",
      transDate: 1,
      referenceNo: 1,
      referenceNo2: 1,
      paymentType: 1,
      payAmount: 1,
      sellerCode: "$sellerUsers.uniqueIdentifier",
      sellerName: "$sellerUsers.name",
      taxType: "$reciepts.taxType",
      exportCountry: "$reciepts.exportCountry",
      securityAmount: "$reciepts.securityAmount"

    },
  });
  query.push({ $sort: { createdAt: 1 } });
  let sapdata = await accountDao.findAccountledgerAggregation(query);
  return sapdata;
};
const createBuyerReserveInvoice = async function (res, postData) {
  return new Promise(async function (resolve, reject) {
    let sapdata = await getReserveInvoiceData(res, postData);
    if (sapdata) {
      sapdata = sapdata[0];
      let vat = 0;
      let exportCar = "No";
      let exportCountry;
      if (sapdata?.taxType == 'tax') {
        vat = sapdata?.securityAmount;
      }
      if (sapdata?.taxType == 'security') {
        exportCar = "Yes";
        exportCountry = sapdata?.exportCountry;
      }
      console.log('=================>>>>>', sapdata);
      let jsondata = {
        /*Card: { cardCode: sapdata?.buyerCode, CardName: sapdata?.buyerName },
        recieptNo: sapdata?.referenceNo,
        DocDate: sapdata?.transDate,
        ItemCode: sapdata?.referenceNo2,
        UnitPrice: sapdata?.payAmount,
        JournalRemarks: sapdata?.referenceNo,
        sellerCode: sapdata?.buyerCode,
        vatAmount: vat,
        export: exportCar,
        exportCountry: exportCountry*/
        bid: "111",
        tokenNo: String("123"),
        itemCode: String(sapdata?.referenceNo2 ? sapdata?.referenceNo2 : "J100464"),
        sellerCode: String(sapdata?.sellerCode ? sapdata?.sellerCode : "V00003"),
        sellerCurrency: String("a"),
        sellerVatGroup: String("a"),
        sellerWarehouseCode: String("V00003"),
        buyerCode: String(sapdata?.buyerCode),
        buyerCurrency: String("12"),
        buyerVatGroup: String("23"),
        buyerWarehouseCode: String("V00003"),
        minBid: 2000,
        bidValue: 5000,
        downPayment: 1000,
        paymentType: String(sapdata?.paymentType),
        auctionCharges: 12345,
        vat: String(vat),
        time: String("02:30:00"),
        date: String("2023-05-29")
      }
      console.log('jsondata------->', jsondata);
      let accessToken = await getSapAccessToken();
      try {
        let response = await axios({
          method: "post",
          url: sapBaseUrl + "/Bids?CompanyCode=TEST_ACA",
          headers: {
            "Content-Type": "application/json",
            "Authorization": 'Bearer ' + accessToken
          },
          data: jsondata,
        });
        if (response.status == 200) {
          console.log("anil_res1", response.data);
        } else {
          console.log("anil_err2", response?.data);
        }
      } catch (err) {
        console.log("accessToken error", err?.response?.data);

      }
      resolve(jsondata)
    } else {
      resolve(sapdata)
    }
  });
}
const createSellerReserveInvoice = async function (res, postData) {
  return new Promise(async function (resolve, reject) {
    let sapdata = await getReserveInvoiceData(res, postData);
    if (sapdata) {
      sapdata = sapdata[0];
      let vat = 0;
      let exportCar = "No";
      let exportCountry;
      if (sapdata?.taxType == 'tax') {
        vat = sapdata?.securityAmount;
      }
      if (sapdata?.taxType == 'security') {
        exportCar = "Yes";
        exportCountry = sapdata?.exportCountry;
      }
      let jsondata = {
        /*sellerCard: { cardCode: sapdata?.sellerCode, CardName: sapdata?.sellerName },
        buyerCard: { buyerCode: sapdata?.buyerCode, buyerName: sapdata?.buyerName },
        recieptNo: sapdata?.referenceNo,
        JournalRemarks: sapdata?.referenceNo,
        DocDate: sapdata?.transDate,
        UnitPrice: sapdata?.payAmount,
        ItemCode: sapdata?.referenceNo2,
        Description: sapdata?.referenceNo + ' ' + sapdata?.referenceNo2,
        Comments: sapdata?.referenceNo + ' ' + sapdata?.referenceNo2,*/

        /* {
           "tokenNo": "AlQaryah_107",
           "itemCode": "AlQaryah_CAR_4",
           "sellerCode": "V00010",
           "sellerCurrency": "USD",
           "sellerVatGroup": "V1",
           "sellerWarehouseCode": "01",
           "buyerCode": "C00002",
           "buyerCurrency": "USD",
           "buyerVatGroup": "A1",
           "buyerWarehouseCode": "01",
           "minBid": 450,
           "bidValue": 20000,
           "downPayment": 2000,
           "paymentType": "Cash",
           "auctionCharges": 450,
           "vat": 5,
           "time": "02:30:00",
           "date": "2023-06-07",
          "cashAccount": "7010102"
          }*/
        cardCode: String("V00010"),
        tokenNo: String("AlQaryah_107"),
        itemCode: String("AlQaryah_CAR_4"),
        sellerCode: String("V00010"),
        sellerCurrency: String("USD"),
        sellerVatGroup: String("V1"),
        sellerWarehouseCode: String("01"),
        buyerCode: String("C00002"),
        buyerCurrency: String("USD"),
        buyerVatGroup: String("A1"),
        buyerWarehouseCode: String("01"),
        minBid: 450,
        bidValue: 20000,
        downPayment: 2000,
        paymentType: String("Cash"),
        auctionCharges: 450,
        vat: 5,
        time: "02:30:00",
        date: "2023-06-07",
        cashAccount: "7010102"
      }
      console.log('jsondata------->', jsondata);
      let accessToken = await getSapAccessToken();
      try {
        let response = await axios({
          method: "post",
          url: sapBaseUrl + "/Bids?CompanyCode=TEST_ACA",
          headers: {
            "Content-Type": "application/json",
            "Authorization": 'Bearer ' + accessToken
          },
          data: jsondata,
        });
        if (response.status == 200) {
          console.log("anil_res1", response.data);
        } else {
          console.log("anil_err2", response?.data);
        }
      } catch (err) {
        console.log("accessToken error", err?.response?.data);

      }
      resolve(jsondata)
    } else {
      resolve(sapdata)
    }
  });
}
const sapItems = async function (res, postData) {
  let query = [];
  query.push({
    $lookup: {
      from: "users",
      localField: "sellerId",
      foreignField: "_id",
      as: "users",
    },
  });
  query.push({
    $unwind: { path: "$users", preserveNullAndEmptyArrays: true },
  });

  query.push({
    $lookup: {
      from: "interiorcolors",
      localField: "interiorcolorId",
      foreignField: "_id",
      as: "interiorcolors",
    },
  });
  query.push({
    $unwind: { path: "$interiorcolors", preserveNullAndEmptyArrays: true },
  });
  query.push({
    $lookup: {
      from: "exteriorcolors",
      localField: "exteriorcolorId",
      foreignField: "_id",
      as: "exteriorcolors",
    },
  });
  query.push({
    $unwind: { path: "$exteriorcolors", preserveNullAndEmptyArrays: true },
  });
  query.push({
    $lookup: {
      from: "makes",
      localField: "make",
      foreignField: "_id",
      as: "makes",
    },
  });
  query.push({
    $unwind: { path: "$makes", preserveNullAndEmptyArrays: true },
  });
  query.push({
    $lookup: {
      from: "models",
      localField: "model",
      foreignField: "_id",
      as: "models",
    },
  });

  query.push({
    $unwind: { path: "$models", preserveNullAndEmptyArrays: true },
  });
  query.push({
    $lookup: {
      from: "bodys",
      localField: "bodyId",
      foreignField: "_id",
      as: "bodys",
    },
  });
  query.push({
    $unwind: { path: "$bodys", preserveNullAndEmptyArrays: true },
  });
  query.push({
    $lookup: {
      from: "series",
      localField: "seriesId",
      foreignField: "_id",
      as: "series",
    },
  });
  query.push({
    $unwind: { path: "$series", preserveNullAndEmptyArrays: true },
  });
  query.push({
    $lookup: {
      from: "fueltypes",
      localField: "fueltypeId",
      foreignField: "_id",
      as: "fueltypes",
    },
  });
  query.push({
    $unwind: { path: "$fueltypes", preserveNullAndEmptyArrays: true },
  });
  query.push({
    $lookup: {
      from: "drivetypes",
      localField: "drivetypeId",
      foreignField: "_id",
      as: "drivetypes",
    },
  });
  query.push({
    $unwind: { path: "$drivetypes", preserveNullAndEmptyArrays: true },
  });
  query.push({
    $lookup: {
      from: "engines",
      localField: "engineId",
      foreignField: "_id",
      as: "engines",
    },
  });
  query.push({
    $unwind: { path: "$engines", preserveNullAndEmptyArrays: true },
  });
  query.push({
    $lookup: {
      from: "branchs",
      localField: "branchId",
      foreignField: "_id",
      as: "branchs",
    },
  });
  query.push({
    $unwind: { path: "$branchs", preserveNullAndEmptyArrays: true },
  });
  query.push({
    $lookup: {
      from: "warehouses",
      localField: "warehosId",
      foreignField: "_id",
      as: "warehouses",
    },
  });
  query.push({
    $unwind: { path: "$warehouses", preserveNullAndEmptyArrays: true },
  });
  query.push({
    $lookup: {
      from: "vinimages",
      // localField: "salesUserId",
      // foreignField: "_id",
      let: {
        inventoryId: "$_id",
        imageType: "inventory",
      },
      pipeline: [
        {
          $match: {
            $expr: {
              $and: [
                { $eq: ["$imageType", "$$imageType"] },
                { $eq: ["$referenceId", "$$inventoryId"] },
              ],
            },
          },
        },
      ],
      as: "vinimages",
    },
  });

  query.push({
    $lookup: {
      from: "vinimages",
      // localField: "salesUserId",
      // foreignField: "_id",
      let: {
        inventoryId: "$_id",
        imageType: "inventory",
        type: "carimage",
      },
      pipeline: [
        {
          $match: {
            $expr: {
              $and: [
                { $eq: ["$imageType", "$$imageType"] },
                { $eq: ["$type", "$$type"] },
                { $eq: ["$referenceId", "$$inventoryId"] },
              ],
            },
          },
        },
      ],
      as: "singlevinimages",
    },
  });
  if (postData.sapitemid) {
    query.push({
      $match: {
        $and: [{ _id: mongoose.Types.ObjectId(postData.sapitemid) }],
      },
    });
  }
  const sQuery = [...query];
  query.push({
    $project: {
      companyCode: 'TEST_ACA',
      ownerCode: '$users.uniqueIdentifier',
      ownerName: '$users.name',
      lotNo: 1,
      vin: 1,
      branchs: "$branchs.branchName",
      bodys: "$bodys.bodyName",
      drivetypes: "$drivetypes.drivetypeName",
      fueltypes: "$fueltypes.fueltypeName",
      series: "$series.seriesName",
      engines: "$engines.engineName",
      year: 1,
      exteriorcolors: "$exteriorcolors.colorName",
      interiorcolors: "$exteriorcolors.colorName",
      make: "$makes.makeName",
      model: "$models.modelName",
      warehouses: "$warehouses.warehouseName",
      specification: 1,
      branchId: "$branchs._id",
      //branchName: "$branchs.branchName",
      warehosId: "$warehouses._id",
      milage: 1,
      costPrice: 1,
      startingBid: 1,
      reservePrice: 1,
      sellerReservePrice: 1,
      sellerPriceAccept: 1,
      lastAuctionDate: 1,
      lastBid: 1,
      inventoryStatus: 1,
      planPrice: 1,
      rejectedMsg: 1,
      vccDoc: 1,
      purchaseDoc: 1,
      status: 1,
      createdAt: 1,
      vinimages: 1,
      sellerId: {
        $cond: {
          if: { $eq: ["$users", {}] },
          then: "",
          else: "$users._id",
        },
      },
      sellerDbId: {
        $cond: {
          if: { $eq: ["$users", {}] },
          then: "",
          else: "$users._id",
        },
      },
    },
  });


  query.push({ $sort: { createdAt: -1 } });

  return new Promise(async function (resolve, reject) {
    let invdata = await intventoryDao.findInventoryAggregation(query);
    if (invdata) {
      invdata = invdata[0];
      //console.log('sapdata=====================>', invdata);
      let jsondata = {
        companyCode: invdata?.companyCode,
        ownerCode: invdata?.ownerCode,
        ownerName: invdata?.ownerName,
        Series: "3",
        ItemCode: String(invdata?.lotNo ? invdata?.lotNo : 'NA'),
        ItemType: 'itItems',
        ItemName: invdata?.vin ? invdata?.vin : '',
        ForeignName: 'Foreign Name',
        ItemsGroupCode: '100',
        U_Owner_Code: String(invdata?.ownerCode),
        U_Owner_Name: String(invdata?.ownerName),
        U_Branch_Name: String(invdata?.branchs),
        U_Warehouse_Name: String(invdata?.warehouses),
        U_Make: String(invdata?.make),
        U_Model: String(invdata?.model),
        U_Year: String(invdata?.year),
        U_Interior_Color: String(invdata?.interiorcolors),
        U_Exterior_Color: String(invdata?.exteriorcolors),
        U_Body: String(invdata?.bodys),
        U_Drive_Type: String(invdata?.drivetypes),
        U_Engine: String(invdata?.engines),
        U_Series: String(invdata?.series ? invdata?.series : '3'),
        U_Fuel_Type: String(invdata?.fueltypes),
        U_Milage: invdata?.milage,
        U_Cost_Price: invdata?.costPrice ? invdata?.costPrice : 1,
        U_Starting_Bid: invdata?.startingBid ? invdata?.startingBid : 1,
        U_Reserve_Price: invdata?.reservePrice ? invdata?.reservePrice : 1,
        U_Inventory_Status: String(invdata?.inventoryStatus),
        U_Plan_Price: invdata?.planPrice ? invdata?.planPrice : 1,
        U_Vcc_Doc: String(invdata?.vccDoc ? invdata?.vccDoc : ''),
        U_Purchase_Doc: String(invdata?.purchaseDoc ? invdata?.purchaseDoc : ''),
        U_Key: String(invdata?.key ? invdata?.key : 'N'),
        U_Images: 'images',
        U_Created_At: invdata?.createdAt,
      }
      //console.log('sapdata=====================>',sapdata);
      //call sap API
      let accessToken = await getSapAccessToken();
      try {
        let response = await axios({
          method: "post",
          url: sapBaseUrl + "/Items?CompanyCode=TEST_ACA",
          headers: {
            "Content-Type": "application/json",
            "Authorization": 'Bearer ' + accessToken
          },
          data: jsondata,
        });
        if (response.status == 200) {
          console.log("washi_res1", response.data);
        } else {
          console.log("washi_err", response?.data);
        }
      } catch (err) {
        console.log("accessToken error", err?.response?.data);

      }

      resolve(jsondata)
    } else {
      resolve(sapdata)
    }
  })
}

const inventoryTransfer = async function (res, postData) {
  let query = [];
  let stockTransferLines = [];
  if (postData.auctionNo) {
    query.push({
      $match: {
        $and: [{ auctionNo: postData.auctionNo }],
      },
    });
    query.push({
      $lookup: {
        from: "auctionvehicles",
        localField: "_id",
        foreignField: "auctionId",
        as: "auctionvehicles",
      },
    });
    query.push({
      $unwind: { path: "$auctionvehicles", preserveNullAndEmptyArrays: true },
    });
    query.push({
      $lookup: {
        from: "inventorys",
        localField: "auctionvehicles.inventoryId",
        foreignField: "_id",
        as: "inventorys",
      },
    });
    query.push({
      $unwind: { path: "$inventorys", preserveNullAndEmptyArrays: true },
    });
  }
  query.push({
    $lookup: {
      from: "warehouses",
      localField: "inventorys.warehosId",
      foreignField: "_id",
      as: "fromwarehouses",
    },
  });
  query.push({
    $unwind: { path: "$fromwarehouses", preserveNullAndEmptyArrays: true },
  });
  query.push({
    $project: {
      //comapnyCode: "ALQ001",
      //lotNo: "$inventorys.lotNo",
      //status: "Y",
      fromwarehouses: "$fromwarehouses.warehouseName",
      //ToWhseCode: "virtual",
      //Quantity: 1,
      auctionNo: 1
    },
  });
  query.push({ $sort: { createdAt: -1 } });
  return new Promise(async function (resolve, reject) {
    let transferdata = await auctionDao.findAuctionAggregation(query);
    if (transferdata) {

      for (var i = 0; i < transferdata.length; i++) {
        let jsondata = {
          itemCode: String("AlQaryah_CAR_4"),
          quantity: 15,
          fromWarehouseCode: String("01"),
          warehouseCode: String("ALQARYAH")

        }
        stockTransferLines.push(jsondata)
      }
      let newdata = {
        docEntry: "10",
        docNum: "3",

      }
      newdata.stockTransferLines = stockTransferLines;
      console.log("InventoryTransfers============>>", newdata); //return false;
      let accessToken = await getSapAccessToken();
      try {
        let response = await axios({
          method: "post",
          url: sapBaseUrl + "/InventoryTransfers?CompanyCode=TEST_ACA",
          headers: {
            "Content-Type": "application/json",
            "Authorization": 'Bearer ' + accessToken
          },
          data: newdata,
        });
        if (response.status == 200) {
          console.log("anil_res3", response.data);
        } else {
          console.log("anil_res3", response?.data);
        }
      } catch (err) {
        console.log("accessToken error", err?.response?.data);

      }
      resolve(newdata)
    } else {
      resolve(newdata)
    }
  })

}
const goodsReciept = async function (res, postData) {
  let query = [];
  let documentLines = [];
  if (postData.auctionNo) {
    query.push({
      $match: {
        $and: [{ auctionNo: postData.auctionNo }],
      },
    });
    query.push({
      $lookup: {
        from: "auctionvehicles",
        localField: "_id",
        foreignField: "auctionId",
        as: "auctionvehicles",
      },
    });
    query.push({
      $unwind: { path: "$auctionvehicles", preserveNullAndEmptyArrays: true },
    });
    query.push({
      $lookup: {
        from: "inventorys",
        localField: "auctionvehicles.inventoryId",
        foreignField: "_id",
        as: "inventorys",
      },
    });
    query.push({
      $unwind: { path: "$inventorys", preserveNullAndEmptyArrays: true },
    });
  }
  query.push({
    $lookup: {
      from: "warehouses",
      localField: "inventorys.warehosId",
      foreignField: "_id",
      as: "fromwarehouses",
    },
  });
  query.push({
    $unwind: { path: "$fromwarehouses", preserveNullAndEmptyArrays: true },
  });
  query.push({
    $project: {
      //comapnyCode: "ALQ001",
      lotNo: "$inventorys.lotNo",
      //status: "Y",
      fromwarehouses: "$fromwarehouses.warehouseName",
      //ToWhseCode: "virtual",
      //Quantity: 1,
      //inventorys: 1
    },
  });
  query.push({ $sort: { createdAt: -1 } });
  return new Promise(async function (resolve, reject) {
    let transferdata = await auctionDao.findAuctionAggregation(query);
    if (transferdata) {

      /*for (var i = 0; i < transferdata.length; i++) {
        let jsondata = {
          comapnyCode: String("ALQ001"),
          LotNo: String(transferdata[i].lotNo ? transferdata[i].lotNo : ""),
          status: String("Y"),
          filler: String(transferdata[i].fromwarehouses ? transferdata[i].fromwarehouses : ""),
          ToWhseCode: String("virtual"),
          Quantity: 1,
        }
        transferdataArr.push(jsondata)
      }
      console.log(transferdataArr); return false;*/
      for (var i = 0; i < transferdata.length; i++) {
        let jsondata = {
          itemCode: String(transferdata[i].auctionNo ? transferdata[i].auctionNo : "AlQaryah_CAR_4"),
          quantity: 1,
          fromWarehouseCode: String(transferdata[i].fromwarehouses ? transferdata[i].fromwarehouses : ""),
          warehouseCode: "01",
          unitPrice: "20000"
        }
        documentLines.push(jsondata)
      }
      let goodrecieptData = {
        docEntry: "10",
        docNum: "3",

      }
      goodrecieptData.documentLines = documentLines;
      console.log("goodsReciept============>>", goodrecieptData); //return false;
      let accessToken = await getSapAccessToken();
      try {
        let response = await axios({
          method: "post",
          url: sapBaseUrl + "/GoodsReceipts?CompanyCode=TEST_ACA",
          headers: {
            "Content-Type": "application/json",
            "Authorization": 'Bearer ' + accessToken
          },
          data: goodrecieptData,
        });
        if (response.status == 200) {
          console.log("anil_res3", response.data);
        } else {
          console.log("anil_res3", response?.data);
        }
      } catch (err) {
        console.log("accessToken error", err?.response?.data);

      }
      resolve(goodrecieptData)
    } else {
      resolve(goodrecieptData)
    }
  })

}
const createBuyerStorageInvoice = async function (res, postData) {
  return new Promise(async function (resolve, reject) {
    let sapdata = await getReserveInvoiceData(res, postData);
    if (sapdata) {
      sapdata = sapdata[0];
      let vat = 0;
      let exportCar = "No";
      let exportCountry;
      if (sapdata?.taxType == 'tax') {
        vat = sapdata?.securityAmount;
      }
      if (sapdata?.taxType == 'security') {
        exportCar = "Yes";
        exportCountry = sapdata?.exportCountry;
      }
      console.log('=================>>>>>', sapdata);
      let jsondata = {
        /*Card: { cardCode: sapdata?.buyerCode, CardName: sapdata?.buyerName },
        recieptNo: sapdata?.referenceNo,
        DocDate: sapdata?.transDate,
        ItemCode: sapdata?.referenceNo2,
        UnitPrice: sapdata?.payAmount,
        JournalRemarks: sapdata?.referenceNo,
        sellerCode: sapdata?.buyerCode,
        vatAmount: vat,
        export: exportCar,
        exportCountry: exportCountry*/
        bid: "111",
        tokenNo: String("123"),
        itemCode: String(sapdata?.referenceNo2 ? sapdata?.referenceNo2 : "J100464"),
        sellerCode: String(sapdata?.sellerCode ? sapdata?.sellerCode : "V00003"),
        sellerCurrency: String("a"),
        sellerVatGroup: String("a"),
        sellerWarehouseCode: String("V00003"),
        buyerCode: String(sapdata?.buyerCode),
        buyerCurrency: String("12"),
        buyerVatGroup: String("23"),
        buyerWarehouseCode: String("V00003"),
        minBid: 2000,
        bidValue: 5000,
        downPayment: 1000,
        paymentType: String(sapdata?.paymentType),
        auctionCharges: 12345,
        vat: String(vat),
        time: String("02:30:00"),
        date: String("2023-05-29")
      }
      console.log('jsondata------->', jsondata);
      let accessToken = await getSapAccessToken();
      try {
        let response = await axios({
          method: "post",
          url: sapBaseUrl + "/Bids?CompanyCode=TEST_ACA",
          headers: {
            "Content-Type": "application/json",
            "Authorization": 'Bearer ' + accessToken
          },
          data: jsondata,
        });
        if (response.status == 200) {
          console.log("anil_res1", response.data);
        } else {
          console.log("anil_err2", response?.data);
        }
      } catch (err) {
        console.log("accessToken error", err?.response?.data);

      }
      resolve(jsondata)
    } else {
      resolve(sapdata)
    }
  });
}
const carInventoryStatusReport = async function (res, postData) {
  return new Promise(async function (resolve, reject) {
    let jsondata = {
      companyCode: String("C001"),
      ItemCode: mongoose.Types.ObjectId("640ee9162e6dbb9991b20e91"),
      warehouse: String(""),
      cost: "5000",
      stock: 1
    }
    console.log('jsondata------->', jsondata);
    resolve(jsondata)
  });
}
const delivery = async function (res, postData) {
  return new Promise(async function (resolve, reject) {

    let jsondata = {
      cardCode: String("C00003"),
      docEntry: "5",
      docNum: "1",
      documentLines: [
        {
          itemCode: String("ITM0001"),//AlQaryah_CAR_4
          quantity: String("1"),
          taxCode: String("A1"),
          unitPrice: String("20000"),
          baseType: 13,
          baseEntry: String("33"),
          baseLine: 0
        }
      ]
    }

    console.log('delivery------->', jsondata);
    let accessToken = await getSapAccessToken();
    try {
      let response = await axios({
        method: "post",
        url: sapBaseUrl + "/Delivery?CompanyCode=TEST_ACA",
        headers: {
          "Content-Type": "application/json",
          "Authorization": 'Bearer ' + accessToken
        },
        data: jsondata,
      });
      if (response.status == 200) {
        console.log("anil_res3", response.data);
      } else {
        console.log("anil_res3", response?.data);
      }
    } catch (err) {
      console.log("accessToken error", err?.response?.data);

    }
    resolve(jsondata)
  });
}
const ApInvoice = async function(req) {
  return new Promise(async (resolve, reject) => {
    try {
      // return resolve("ApInvoice");
      const accessToken = await getSapAccessToken();
     
      let keyData=[];
      for (let i = 0; i < req.length; i++) {
        keyData.push({
          DocNum: req[i]?.DocNum,
      });
      
    }
      resolve({data:keyData,status:"success",message:"success"});
    } catch (error) {
      console.log("############# Error: ApInvoice #############", error);
      reject("Error: ApInvoice");
    }
  });
};
const ArInvoice = async function(req) {
  return new Promise(async (resolve, reject) => {
    try {
      // return resolve("ArInvoice");
      const accessToken = await getSapAccessToken();
      let keyData=[];
      for (let i = 0; i < req.length; i++) {
        keyData.push({
          DocNum: req[i]?.DocNum,
      });
      
    }
    resolve({data:keyData,status:"success",message:"success"});
    } catch (error) {
      console.log("############# Error: ArInvoice #############", error);
      reject("Error: ArInvoice");
    }
  });
};

module.exports = {
  createBuyerReserveInvoice,
  createSellerReserveInvoice,
  sapincomingPaymnent,
  bids,
  InventoryStatus,
  sapItems,
  sapbusinessPartener,
  inventoryTransfer,
  goodsReciept,
  createBuyerStorageInvoice,
  carInventoryStatusReport,
  delivery,
  sapsyncInventory,
  syncInventory,
  tempdataList,
  ApInvoice,
  ArInvoice
};
