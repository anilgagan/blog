const express = require("express");
const router = express.Router();
const masterModal = require("../master/masterModal");
const message = require("../../config/message");
const jwt = require("jsonwebtoken");
const config = require("../../config");
const midleware = require("../../middleware/validation");
const Promise = require("bluebird");
const cmethod = require("../../middleware/common-fun");
const moment = require("moment");
const sapDao = require("../sap/sapDao");
const axios = require("axios");
var mongoose = require("mongoose");
const { update } = require("lodash");
const XLSX = require("xlsx");
const json2xls = require("json2xls");
const fs = require("fs");
const http = require("http");
const { dirname } = require("path");
const path = require("path");
const excel = require("exceljs");
const recieptDao = require("../reciept/recieptDao");
const accountModal = require("../account/accountModal");
const accountDao = require("../account/accountDao");
const { object } = require("@hapi/joi");
var CryptoJS = require("crypto-js");
var $apiKey = config.getresponse.apiKey;
var $apiUrl = config.getresponse.apiUrl;
var $api = require("getresponse-nodejs-api/lib/getResponse");
const { UserRead } = require("../user/userModal");
var $api = new $api($apiKey, $apiUrl);

router.post(
  "/saplogin",
  [
    midleware.validateFieldValue(
      config.signinReqfields,
      config.signinReqfieldsVal
    ),
  ],
  async (req, res) => {
    // 
    let postData = req.body;
    
    let queryCond = { email: postData.email };
    let lang = req.headers["lang"] || config.lang;

    if (postData.email == "test@test.com") {
      cmethod.returrnErrorMessage(res, message[lang].usernotExist);
    } else {
      
      //queryCond = { $and: [{ email: postData.email }] };
      UserRead.findOne(queryCond, async function (err, data) {
        if (err) {
          
          cmethod.returnSreverError(res, message[lang].technicalError, err);
        } else {
          
          if (data != null) {
            if (data.validPassword(postData.password)) {
              const jwttoken = jwt.sign({ email: postData.email, deviceId: postData.deviceId },
                config.secret, { expiresIn: config.tokenLife });
              UserRead.findOneAndUpdate(queryCond, { $set: { deviceId: postData.deviceId, token: jwttoken, }, }, { new: true },
                async function (err, uptData) {
                  if (err) {
                    
                    cmethod.returnSreverError(
                      res,
                      message[lang].technicalError,
                      err
                    );
                  } else {
                    
                    if (uptData.status == 1) {
                      postData.loginType = 'admin';
                      if (([2, 3, 4, 5].includes(Number(data?.userType)) && postData.loginType == 'web')
                        || (![2, 3, 4, 5].includes(Number(data?.userType)) && postData.loginType == 'admin')) {
                        cmethod.returnSuccess(
                          res,
                          uptData.token,
                          false,
                          message[lang].loginSucess,
                        );
                      } else {
                        cmethod.returrnErrorMessage(res, message[lang].unathorized);
                      }

                    } else {
                      cmethod.returrnErrorMessage(res, message[lang].blocked);
                    }
                  }
                }
              );
            } else {
              await UserRead.findOneAndUpdate(queryCond, {
                $set: {
                  logAtt: parseInt(data.logAtt) + 1,
                },
              });

              cmethod.returrnErrorMessage(res, message[lang].usernameExist);
            }
          } else {
            cmethod.returrnErrorMessage(res, message[lang].usernotExist);
          }
        }
      });
    }
  }
);

router.post(
  "/businesspartener",
  async (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let data = await sapDao.sapbusinessPartener(postData?.businesspartnerid);
    // 
    if (data.status == 'Success') {
      cmethod.returnSuccess(
        res,
        data,
        false,
        data?.message,
      );
    } else {
      cmethod.returrnErrorMessage(res, data?.message);
    }
  }
);

router.post(
  "/incomingpaymnent",
  async (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let voucNo = postData.voucherNo;
    // let data = await sapDao.sapincomingPaymnent(voucNo);
    
    if (data.status == 'Success') {
      cmethod.returnSuccess(
        res,
        data,
        false,
        data?.message,
      );
    } else {
      cmethod.returrnErrorMessage(res, data?.message);
    }

  }
);
router.post(
  "/syncinventory",
  async (req, res) => {
    //let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let data = await sapDao.sapsyncInventory();
    if (data.status == 'success') {
      cmethod.returnSuccess(
        res,
        data?.data,
        false,
        data?.message,
      );
    } else {
      cmethod.returrnErrorMessage(res, data?.message);
    }

  }
);
router.post(
  "/bids",
  async (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let newvoucherNo = postData.voucherNo;
     //return false;
    let data = await sapDao.bids(newvoucherNo);
    if (data) {
      cmethod.returnSuccess(
        res,
        data,
        false,
        message[lang].loginSucess,
      );
    } else {
      cmethod.returrnErrorMessage(res, message[lang].usernameExist);
    }

  }
);
router.post(
  "/inventoryStatus",
  async (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let data = await sapDao.InventoryStatus(postData?.user_id, postData?.sellerId);
    if (data?.status == "success") {
      cmethod.returnSuccess(
        res,
        data?.data,
        false,
        data?.message,
      );
    } else {
      cmethod.returrnErrorMessage(res, data?.message);
    }

  }
);
router.post(
  "/outgoingPayment",
  async (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang; console.log("washi");
    let data = await sapDao.ApInvoice(postData?.data);
    if (data?.status == "success") {
      cmethod.returnSuccess(
        res,
        data?.data,
        false,
        data?.message,
      );
    } else {
      cmethod.returrnErrorMessage(res, data?.message);
    }

  }
);
router.post(
  "/incomingPayment",
  async (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let data = await sapDao.ArInvoice(postData?.data);
    if (data?.status == "success") {
      cmethod.returnSuccess(
        res,
        data?.data,
        false,
        data?.message,
      );
    } else {
      cmethod.returrnErrorMessage(res, data?.message);
    }

  }
);
router.post(
  "/tempdatalist",
  async (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let data = await sapDao.tempdataList(postData?.user_id,postData);
    if (data?.status == "success") {
      cmethod.returnSuccess(
        res,
        data?.data,
        false,
        data?.message,
      );
    } else {
      cmethod.returrnErrorMessage(res, data?.message);
    }

  }
)

router.post(
  "/createBuyerReserveInvoice",
  async (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let data = await sapDao.createBuyerReserveInvoice(res, postData);
    if (data) {
      cmethod.returnSuccess(
        res,
        data,
        false,
        message[lang].loginSucess,
      );
    } else {
      cmethod.returrnErrorMessage(res, message[lang].usernameExist);
    }

  }
);
router.post(
  "/createSellerReserveInvoice",
  async (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let data = await sapDao.createSellerReserveInvoice(res, postData);
    if (data) {
      cmethod.returnSuccess(
        res,
        data,
        false,
        message[lang].loginSucess,
      );
    } else {
      cmethod.returrnErrorMessage(res, message[lang].usernameExist);
    }

  }
);

router.post(
  "/sapitems",
  async (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let getdata = await sapDao.sapItems(res, postData);
    

  }
);

router.post(
  "/inventorytransfer",
  async (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let data = await sapDao.inventoryTransfer(res, postData);
    if (data) {
      cmethod.returnSuccess(
        res,
        data,
        false,
        message[lang].loginSucess,
      );
    } else {
      cmethod.returrnErrorMessage(res, message[lang].usernameExist);
    }

  }
);
router.post(
  "/goodsreciept",
  async (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let data = await sapDao.goodsReciept(res, postData);
    if (data) {
      cmethod.returnSuccess(
        res,
        data,
        false,
        message[lang].loginSucess,
      );
    } else {
      cmethod.returrnErrorMessage(res, message[lang].usernameExist);
    }

  }
);
router.post(
  "/createBuyerStorageInvoice",
  async (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let data = await sapDao.createBuyerStorageInvoice(res, postData);
    if (data) {
      cmethod.returnSuccess(
        res,
        data,
        false,
        message[lang].loginSucess,
      );
    } else {
      cmethod.returrnErrorMessage(res, message[lang].usernameExist);
    }

  }
);
router.post(
  "/carInventoryStatusReport",
  async (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let data = await sapDao.carInventoryStatusReport(res, postData);
    if (data) {
      cmethod.returnSuccess(
        res,
        data,
        false,
        message[lang].loginSucess,
      );
    } else {
      cmethod.returrnErrorMessage(res, message[lang].usernameExist);
    }

  }
);
router.post(
  "/delivery",
  async (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let data = await sapDao.delivery(res, postData);
    if (data) {
      cmethod.returnSuccess(
        res,
        data,
        false,
        message[lang].loginSucess,
      );
    } else {
      cmethod.returrnErrorMessage(res, message[lang].usernameExist);
    }

  }
);

module.exports = router;
/**
 * @swagger
 * /api/sap/saplogin:
 *   post:
 *     tags: [SAP]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: email
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: password
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: User Role List.
 *
 */
/**
 * @swagger
 * /api/sap/businesspartener:
 *   post:
 *     tags: [SAP]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: x-access-token
 *         in: header
 *         type: string
 *         required: true
 *         description: Authorization Token
 *       - name: businesspartnerid
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: businesspartnerid.
 *
 */
/**
 * @swagger
 * /api/sap/incomingpaymnent:
 *   post:
 *     tags: [SAP]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: x-access-token
 *         in: header
 *         type: string
 *         required: true
 *         description: Authorization Token
 *       - name: voucherNo
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *           ex - GL voucer No- J104031
 *     responses:
 *       200:
 *         description: incomingpaymnent.
 *
 */
/**
 * @swagger
 * /api/sap/syncinventory:
 *   post:
 *     tags: [SAP]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: x-access-token
 *         in: header
 *         type: string
 *         required: true
 *         description: Authorization Token
 *     responses:
 *       200:
 *         description: syncinventory.
 *
 */
/**
 * @swagger
 * /api/sap/bids:
 *   post:
 *     tags: [SAP]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: x-access-token
 *         in: header
 *         type: string
 *         required: true
 *         description: Authorization Token
 *       - name: voucherNo
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *           ex - GL voucer No- J104257
 *     responses:
 *       200:
 *         description: bids.
 *
 */

/**
 * @swagger
 * /api/sap/inventoryStatus:
 *   post:
 *     tags: [SAP]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: user_id
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: sellerId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: x-access-token
 *         in: header
 *         type: string
 *         required: true
 *         description: Authorization Token
 *     responses:
 *       200:
 *         description: inventoryStatus.
 *
 */


/**
 * @swagger
 * /api/sap/createBuyerReserveInvoice:
 *   post:
 *     tags: [SAP]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: x-access-token
 *         in: header
 *         type: string
 *         required: true
 *         description: Authorization Token
 *       - name: voucherNo
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *           ex - GL voucer No- J100434
 *     responses:
 *       200:
 *         description: incomingpaymnent.
 *
 */

/**
 * @swagger
 * /api/sap/createSellerReserveInvoice:
 *   post:
 *     tags: [SAP]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: x-access-token
 *         in: header
 *         type: string
 *         required: true
 *         description: Authorization Token
 *       - name: voucherNo
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *           ex - GL voucer No- J100434
 *     responses:
 *       200:
 *         description: incomingpaymnent.
 *
 */


/**
 * @swagger
 * /api/sap/sapitems:
 *   post:
 *     tags: [SAP]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: x-access-token
 *         in: header
 *         type: string
 *         required: true
 *         description: Authorization Token
 *       - name: sapitemid
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: sapitemid.
 *
 */

/**
 * @swagger
 * /api/sap/inventorytransfer:
 *   post:
 *     tags: [SAP]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: x-access-token
 *         in: header
 *         type: string
 *         required: true
 *         description: Authorization Token
 *       - name: auctionNo
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *     responses:
 *       200:
 *         description: inventorytransfer.
 *
 */
/**
 * @swagger
 * /api/sap/goodsreciept:
 *   post:
 *     tags: [SAP]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: x-access-token
 *         in: header
 *         type: string
 *         required: true
 *         description: Authorization Token
 *       - name: auctionNo
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *          ex - A100010
 *     responses:
 *       200:
 *         description: goodsreciept.
 *
 */
/**
 * @swagger
 * /api/sap/createBuyerStorageInvoice:
 *   post:
 *     tags: [SAP]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: x-access-token
 *         in: header
 *         type: string
 *         required: true
 *         description: Authorization Token
 *       - name: voucherNo
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *           ex - GL voucer No- J100434
 *     responses:
 *       200:
 *         description: incomingpaymnent.
 *
 */
/**
 * @swagger
 * /api/sap/carInventoryStatusReport:
 *   post:
 *     tags: [SAP]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: x-access-token
 *         in: header
 *         type: string
 *         required: true
 *         description: Authorization Token
 *     responses:
 *       200:
 *         description: carInventoryStatusReport.
 *
 */
/**
 * @swagger
 * /api/sap/delivery:
 *   post:
 *     tags: [SAP]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: x-access-token
 *         in: header
 *         type: string
 *         required: true
 *         description: Authorization Token
 *     responses:
 *       200:
 *         description: Delivery.
 *
 */
/**
 * @swagger
 * /api/sap/tempdatalist:
 *   post:
 *     tags: [SAP]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: user_id
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: sellerId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: x-access-token
 *         in: header
 *         type: string
 *         required: true
 *         description: Authorization Token
 *     responses:
 *       200:
 *         description: inventoryStatus.
 *
 */

/**
 * @swagger
 * /api/sap/outgoingPayment:
 *   post:
 *     tags: [SAP]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: user_id
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: sellerId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: x-access-token
 *         in: header
 *         type: string
 *         required: true
 *         description: Authorization Token
 *     responses:
 *       200:
 *         description: inventoryStatus.
 *
 */
/**
 * @swagger
 * /api/sap/incomingPayment:
 *   post:
 *     tags: [SAP]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: user_id
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: sellerId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: x-access-token
 *         in: header
 *         type: string
 *         required: true
 *         description: Authorization Token
 *     responses:
 *       200:
 *         description: inventoryStatus.
 *
 */