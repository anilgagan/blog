const express = require("express");
const router = express.Router();
const auctionDao = require("./../auction/auctionDao");
const bidDao = require("../bid/bidDao");
const inventoryModal = require("../inventory/inventoryModal");
const message = require("../../config/message");
const config = require("../../config");
const midleware = require("../../middleware/validation");
const cmethod = require("../../middleware/common-fun");
var mongoose = require("mongoose");
const http = require("http");
const { dirname } = require("path");
const path = require("path");
const { middleware } = require("json2xls");
const bidModal = require("./bidModal");
const bid = require(".");
const auctionModal = require("../auction/auctionModal");
const {
  createNewMongoDoc,
  makeObjectId,
  checkBoolean,
  regexSearch,
} = require("../../functions/global.functions");
const { User } = require("../user/userModal");
const { creditCalHistory } = require("../order/orderModel");
const { handleRejectedBid } = require("../../services/bid.service");
const logger = require("../../config/logger");
const { UpdateOne, FindByIdWithKey } = require("../../models/factory");
const { createComment } = require("../../services/comment.service");
//update auction
router.patch(
  "/update-reserve-price",
  [
    midleware.validateFieldValue(
      ["auctionId", "inventoryId", "reservePrice"],
      ["auctionId", "inventoryId", "reservePrice"]
    ),
  ],
  async (req, res) => {
    const postData = req.body;
    await inventoryModal.Inventory.updateOne(
      { _id: mongoose.Types.ObjectId(postData.inventoryId) },
      { $set: { reservePrice: postData.reservePrice }, upsert: true }
    );
    let currentBidData = await bidModal.Bid.findOne({
      auctionId: mongoose.Types.ObjectId(postData.auctionId),
      //status: "Open",
    })
      .sort({ createdAt: -1 })
      .limit(1);
    if (currentBidData) {
      await bidModal.Bid.updateOne(
        { _id: mongoose.Types.ObjectId(currentBidData._id) },
        { $set: { reservePrice: postData.reservePrice } }
      );
    }
    cmethod.returnSuccess(
      res,
      { reservePrice: postData.reservePrice },
      false,
      message["eng"].Updated
    );
  }
);

// * update-bid
router.post(
  "/update-bid",
  [
    midleware.validateFieldValue(
      ["userId", "userName", "inventoryId", "bidStatus", "bidType"],
      ["userId", "userName", "inventoryId", "bidStatus", "bidType"]
    ),
  ],
  async (req, res) => {
    const postData = req.body;
    const { bidStatus, bidType } = postData;

    try {
      if (bidStatus === "Open" && bidType === "Pre") {
        const {
          auctionId,
          inventoryId,
          currAmount,
          calcAmount,
          userId,
          userName,
        } = postData;

        if (auctionId) {
          const isAuctionStarted = await FindByIdWithKey(
            auctionModal.Auction,
            auctionId,
            "auctionStart"
          );

          if (isAuctionStarted) {
            return cmethod.returrnErrorMessage(
              res,
              "Sorry, Auction is already started!"
            );
          }
        }

        const inventoryData = await inventoryModal.Inventory.findOne({
          _id: mongoose.Types.ObjectId(inventoryId),
        });

        const auctionDetail = await auctionModal.Auctionvehicle.findOne({
          inventoryId: mongoose.Types.ObjectId(inventoryId),
          status: "pending",
        });

        const startBidVal = inventoryData.startingBid
          ? inventoryData.startingBid
          : 0;

        const data = {
          currAmount: parseInt(currAmount),
          calcAmount,
          userId,
          userName,
          auctionId: auctionDetail?.auctionId,
          inventoryId,
          status: bidStatus,
          reservePrice: inventoryData?.reservePrice,
          startPrice: inventoryData?.startingBid,
          bidType,
        };

        if (parseInt(calcAmount) > startBidVal) {
          bidModal.Bid.create(data).then(async (result) => {
            cmethod.returnSuccess(res, result, false, message["eng"].Updated);
          });
        } else {
          cmethod.returrnErrorMessage(
            res,
            "Sorry Amount is less than Starting Bid value"
          );
        }
      } else if (bidStatus === "UnderApproval" && bidType === "Current") {
        const { inventoryId, userId } = postData;

        const auctionDetail =
          await auctionModal.Auctionvehicle.findOneAndUpdate(
            {
              inventoryId: mongoose.Types.ObjectId(inventoryId),
              status: "unsold",
            },
            { $set: { status: bidStatus } }
          );

        const filter = {
          status: "UnSold",
          userId: mongoose.Types.ObjectId(userId),
          auctionId: mongoose.Types.ObjectId(auctionDetail.auctionId),
          inventoryId: mongoose.Types.ObjectId(inventoryId),
        };
        const getUnSoldBid = await bidModal.bidHistoryLog
          .findOne(filter)
          .sort({ createdAt: -1 })
          .limit(1);

        let newUnderApprovalDoc = createNewMongoDoc(getUnSoldBid);
        newUnderApprovalDoc = {
          ...newUnderApprovalDoc,
          status: bidStatus,
          bidType,
        };

        bidModal.Bid.create(newUnderApprovalDoc).then(async (result) => {
          cmethod.returnSuccess(res, result, false, message["eng"].Updated);
        });
      } else if (bidStatus === "CounterOffer" && bidType === "Current") {
        const { inventoryId, userId, counterOfferAmount } = postData;

        const auctionDetail = await auctionModal.Auctionvehicle.findOne({
          inventoryId: mongoose.Types.ObjectId(inventoryId),
          status: "UnderApproval",
        });

        const filter = {
          status: "UnderApproval",
          bidType,
          userId: mongoose.Types.ObjectId(userId),
          auctionId: mongoose.Types.ObjectId(auctionDetail.auctionId),
          inventoryId: mongoose.Types.ObjectId(inventoryId),
        };

        const update = {
          $set: { counterOfferAmount, isCounterOfferGiven: true },
        };

        const getUnderApprovalBid =
          await bidModal.bidHistoryLog.findOneAndUpdate(filter, update);

        cmethod.returnSuccess(
          res,
          getUnderApprovalBid,
          false,
          message["eng"].Updated
        );
      } else if (bidStatus === "Sold" && bidType === "Current") {
        const { bidId, auctionId, inventoryId, userId, calcAmount } = postData;
        const update = {
          $set: { status: bidStatus, calcAmount },
        };

        // * mark auction vehicle sold
        await auctionModal.Auctionvehicle.findOneAndUpdate(
          {
            inventoryId: mongoose.Types.ObjectId(inventoryId),
            auctionId: mongoose.Types.ObjectId(auctionId),
            status: "UnderApproval",
          },
          { $set: { status: "sold", bidAmount: calcAmount } }
        );

        // * mark bid Sold
        const getSoldBid = await bidModal.bidHistoryLog.findByIdAndUpdate(
          bidId,
          update
        );

        const user = await User.findOne(
          { _id: mongoose.Types.ObjectId(userId) },
          { userType: 1 }
        );

        // * don't create/update credit limit for admin
        if (user.userType !== 1) {
          // * deduct credit limit
          await User.updateOne(
            { _id: mongoose.Types.ObjectId(userId) },
            {
              $inc: {
                creditLimit: -calcAmount,
              },
            }
          );

          // * make credit history
          let creditCalData = await creditCalHistory.create({
            userId: userId,
            deposit: 0,
            creditLimit: calcAmount,
            creditType: "DR",
          });

          // * update credit history
          await creditCalHistory.updateOne(
            { _id: mongoose.Types.ObjectId(creditCalData._id) },
            { $inc: { balance: -calcAmount } }
          );
        }

        cmethod.returnSuccess(res, getSoldBid, false, message["eng"].Updated);
      } else if (bidStatus === "UnSold" && bidType === "Current") {
        const { bidId } = postData;
        const update = {
          $set: { status: bidStatus },
        };

        // * mark bid UnSold
        const bidID = makeObjectId(bidId);
        const getUnSoldBid = await bidModal.bidHistoryLog.findByIdAndUpdate(
          bidID,
          update
        );

        cmethod.returnSuccess(res, getUnSoldBid, false, message["eng"].Updated);
      } else {
        cmethod.returrnErrorMessage(res, "Auction is not Initiated Yet");
      }
    } catch (error) {
      cmethod.returnSreverError(res, "Fail to create or update bid!", error);
    }
  }
);

// Mark as sold if not bid happend in  20 sencond

// mark sold
router.get(
  "/mark-sold",
  [midleware.validateFieldValue([], [])],
  async (req, res) => {
    let bidData = await bidModal.Bid.findOne({
      auctionId: mongoose.Types.ObjectId(data.auctionId),
      inventoryId: mongoose.Types.ObjectId(data.inventoryId),
      auctionType: "online",
    })
      .sort({ createdAt: -1 })
      .limit(1);
    let bidDateTime = new Date(bidData.createdAt).getTime();
    let currentTime = new Date().getTime();
    if (currentTime - bidDateTime > 50000) {
      await bidModal.Bid.updateOne(
        {
          auctionId: mongoose.Types.ObjectId(data.auctionId),
          inventoryId: mongoose.Types.ObjectId(data.inventoryId),
          auctionType: "online",
        },
        { $set: { status: "Sold" } }
      );
      cmethod.returnSuccess(res, {}, false, "Updated");
    } else {
      cmethod.returnSuccess(res, {}, false, "Note updated");
    }
  }
);
// Get Pre Bids
router.post(
  "/get-bid",
  [midleware.validateFieldValue(["page", "pageLimit"], ["page", "pageLimit"])],
  async (req, res) => {
    const postData = req.body;
    let query = [];

    // * auctions
    query.push({
      $lookup: {
        from: "auctions",
        localField: "auctionId",
        foreignField: "_id",
        as: "auctions",
      },
    });
    query.push({
      $unwind: { path: "$auctions", preserveNullAndEmptyArrays: true },
    });

    // * inventorys
    query.push({
      $lookup: {
        from: "inventorys",
        localField: "inventoryId",
        foreignField: "_id",
        as: "inventorys",
      },
    });
    query.push({
      $unwind: { path: "$inventorys", preserveNullAndEmptyArrays: true },
    });

    // * seller
    query.push({
      $lookup: {
        from: "users",
        localField: "inventorys.sellerId",
        foreignField: "_id",
        as: "sellerUsers",
      },
    });
    query.push({
      $unwind: { path: "$sellerUsers", preserveNullAndEmptyArrays: true },
    });

    // * buyer
    query.push({
      $lookup: {
        from: "users",
        localField: "userId",
        foreignField: "_id",
        as: "buyerUsers",
      },
    });
    query.push({
      $unwind: { path: "$buyerUsers", preserveNullAndEmptyArrays: true },
    });

    // * makes
    query.push({
      $lookup: {
        from: "makes",
        localField: "inventorys.make",
        foreignField: "_id",
        as: "makes",
      },
    });
    query.push({
      $unwind: { path: "$makes", preserveNullAndEmptyArrays: true },
    });

    // * models
    query.push({
      $lookup: {
        from: "models",
        localField: "inventorys.model",
        foreignField: "_id",
        as: "models",
      },
    });
    query.push({
      $unwind: { path: "$models", preserveNullAndEmptyArrays: true },
    });

    // * engines
    query.push({
      $lookup: {
        from: "engines",
        localField: "inventorys.engineId",
        foreignField: "_id",
        as: "engines",
      },
    });
    query.push({
      $unwind: { path: "$engines", preserveNullAndEmptyArrays: true },
    });

    // * drivetypes
    query.push({
      $lookup: {
        from: "drivetypes",
        localField: "inventorys.drivetypeId",
        foreignField: "_id",
        as: "drivetypes",
      },
    });
    query.push({
      $unwind: { path: "$drivetypes", preserveNullAndEmptyArrays: true },
    });

    // * fueltypes
    query.push({
      $lookup: {
        from: "fueltypes",
        localField: "inventorys.fueltypeId",
        foreignField: "_id",
        as: "fueltypes",
      },
    });
    query.push({
      $unwind: { path: "$fueltypes", preserveNullAndEmptyArrays: true },
    });

    // * vinimages
    query.push({
      $lookup: {
        from: "vinimages",
        let: {
          inventoryId: "$_id",
          imageType: "inventory",
          type: "carimage",
        },
        pipeline: [
          {
            $match: {
              $expr: {
                $and: [
                  { $eq: ["$imageType", "$$imageType"] },
                  { $eq: ["$type", "$$type"] },
                  { $eq: ["$referenceId", "$$inventoryId"] },
                ],
              },
            },
          },
        ],
        as: "singlevinimages",
      },
    });

    query.push({
      $match: {
        $and: [{ status: postData.bidStatus }, { bidType: postData.bidType }],
      },
    });

    if (postData.userId) {
      query.push({
        $match: {
          $and: [{ userId: mongoose.Types.ObjectId(postData.userId) }],
        },
      });
    }

    if (postData.auctionId) {
      query.push({
        $match: {
          $and: [{ auctionId: mongoose.Types.ObjectId(postData.auctionId) }],
        },
      });
    }

    if (postData.vin) {
      query.push({
        $match: {
          $and: [{ "inventorys.vin": regexSearch(postData.vin) }],
        },
      });
    }

    query.push({ $sort: { createdAt: -1 } });

    // * project
    query.push({
      $project: {
        sellerId: "$sellerUsers._id",
        sellerName: "$sellerUsers.name",
        sellerUniqueIdentifier: "$sellerUsers.uniqueIdentifier",
        sellerCompanyDetails: "$sellerUsers.companyDetails",
        sellerUserType: "$sellerUsers.userType",
        buyerUniqueIdentifier: "$buyerUsers.uniqueIdentifier",
        userId: "$userId",
        buyerCompanyDetails: "$buyerUsers.companyDetails",
        buyerUserType: "$buyerUsers.userType",
        auctionId: "$auctionId",
        inventoryId: "$inventoryId",
        userName: "$userName",
        bidStatus: "$status",
        bidType: "$bidType",
        createdAt: "$createdAt",
        counterOfferAmount: "$counterOfferAmount",
        inventoryDetails: {
          carName: {
            $concat: [
              "$inventorys.year",
              " ",
              "$makes.makeName",
              " ",
              "$models.modelName",
            ],
          },
          lotNo: "$inventorys.lotNo",
          vinNo: "$inventorys.vin",
          engineName: "$engines.engineName",
          milage: "$inventorys.milage",
          fuelType: "$fueltypes.fueltypeName",
          transmissionType: "$transmissions.transName",
          driveType: "$drivetypes.drivetypeName",
          singleImage: {
            $cond: {
              if: { $eq: ["$singlevinimages", []] },
              then: config.defaultInventoryImage,
              else: { $arrayElemAt: ["$singlevinimages.image", 0] },
            },
          },
        },
        bidDetails: {
          userBidAmount: "$currAmount",
          latestBidAmount: "$calcAmount",
        },
      },
    });

    const sQuery = [...query];
    sQuery.push({ $count: "recordCount" });

    if (postData.page) {
      query.push({
        $skip: cmethod.pageOffset(postData.page, postData.pageLimit),
      });
      query.push({ $limit: cmethod.pageLimit(postData.pageLimit) });
    }

    bidDao
      .findBidHistoryAggregation(query)
      .then(function (data) {
        bidDao
          .findBidHistoryAggregation(sQuery)
          .then(async function (dcount) {
            let tptCnt = 0;
            if (dcount.length > 0) {
              tptCnt = dcount[0].recordCount;
            }

            res.status(200).json({
              status: true,
              result: data,
              message: "",
              hasMore: cmethod.hasMoreCount(
                tptCnt,
                postData.page,
                postData.pageLimit
              ),
              totalCount: tptCnt,
            });
          })
          .catch((err) => {
            cmethod.returnSreverError(res, "Some technical issue", err);
          });
      })
      .catch((err) => {
        cmethod.returnSreverError(res, "Some technical issue", err);
      });
  }
);

// * Pre-Bids
router.post(
  "/get-pre-bid",
  [midleware.validateFieldValue(["page", "pageLimit"], ["page", "pageLimit"])],
  async (req, res) => {
    const postData = req.body;
    let query = [];
    let Model = bidModal.Bid;
    let ModelAggregation = bidDao.findBidAggregation;

    const isAuctionEnded = await bidDao.checkAuctionEnded(postData);

    if (isAuctionEnded) {
      Model = bidModal.bidHistoryLog;
      ModelAggregation = bidDao.findBidHistoryAggregation;
    }

    // * auctions
    query.push({
      $lookup: {
        from: "auctions",
        localField: "auctionId",
        foreignField: "_id",
        as: "auctions",
      },
    });
    query.push({
      $unwind: { path: "$auctions", preserveNullAndEmptyArrays: true },
    });

    // * inventorys
    query.push({
      $lookup: {
        from: "inventorys",
        localField: "inventoryId",
        foreignField: "_id",
        as: "inventorys",
      },
    });
    query.push({
      $unwind: { path: "$inventorys", preserveNullAndEmptyArrays: true },
    });

    // * bids
    query.push({
      $lookup: {
        from: Model.modelName,
        let: {
          status: "$status",
          bidType: "$bidType",
          userId: makeObjectId(postData.userId),
          // auctionId: "$auctionId",
          inventoryId: "$inventoryId",
        },
        pipeline: [
          {
            $match: {
              $expr: {
                $and: [
                  { $eq: ["$status", "$$status"] },
                  { $eq: ["$bidType", "$$bidType"] },
                  { $eq: ["$userId", "$$userId"] },
                  // { $eq: ["$auctionId", "$$auctionId"] },
                  { $eq: ["$inventoryId", "$$inventoryId"] },
                ],
              },
            },
          },
        ],
        as: "bids",
      },
    });

    // * seller
    query.push({
      $lookup: {
        from: "users",
        localField: "inventorys.sellerId",
        foreignField: "_id",
        as: "sellerUsers",
      },
    });
    query.push({
      $unwind: { path: "$sellerUsers", preserveNullAndEmptyArrays: true },
    });

    // * buyer
    query.push({
      $lookup: {
        from: "users",
        localField: "userId",
        foreignField: "_id",
        as: "buyerUsers",
      },
    });
    query.push({
      $unwind: { path: "$buyerUsers", preserveNullAndEmptyArrays: true },
    });

    // * makes
    query.push({
      $lookup: {
        from: "makes",
        localField: "inventorys.make",
        foreignField: "_id",
        as: "makes",
      },
    });
    query.push({
      $unwind: { path: "$makes", preserveNullAndEmptyArrays: true },
    });

    // * models
    query.push({
      $lookup: {
        from: "models",
        localField: "inventorys.model",
        foreignField: "_id",
        as: "models",
      },
    });
    query.push({
      $unwind: { path: "$models", preserveNullAndEmptyArrays: true },
    });

    // * engines
    query.push({
      $lookup: {
        from: "engines",
        localField: "inventorys.engineId",
        foreignField: "_id",
        as: "engines",
      },
    });
    query.push({
      $unwind: { path: "$engines", preserveNullAndEmptyArrays: true },
    });

    // * drivetypes
    query.push({
      $lookup: {
        from: "drivetypes",
        localField: "inventorys.drivetypeId",
        foreignField: "_id",
        as: "drivetypes",
      },
    });
    query.push({
      $unwind: { path: "$drivetypes", preserveNullAndEmptyArrays: true },
    });

    // * fueltypes
    query.push({
      $lookup: {
        from: "fueltypes",
        localField: "inventorys.fueltypeId",
        foreignField: "_id",
        as: "fueltypes",
      },
    });
    query.push({
      $unwind: { path: "$fueltypes", preserveNullAndEmptyArrays: true },
    });

    // * vinimages
    query.push({
      $lookup: {
        from: "vinimages",
        let: {
          inventoryId: "$_id",
          imageType: "inventory",
          type: "carimage",
        },
        pipeline: [
          {
            $match: {
              $expr: {
                $and: [
                  { $eq: ["$imageType", "$$imageType"] },
                  { $eq: ["$type", "$$type"] },
                  { $eq: ["$referenceId", "$$inventoryId"] },
                ],
              },
            },
          },
        ],
        as: "singlevinimages",
      },
    });

    query.push({
      $match: {
        $and: [{ status: postData.bidStatus }, { bidType: postData.bidType }],
      },
    });

    if (checkBoolean(postData.isMyBids) && postData.userId) {
      query.push({
        $match: {
          $and: [{ userId: mongoose.Types.ObjectId(postData.userId) }],
        },
      });
    }

    if (postData.auctionId) {
      query.push({
        $match: {
          $and: [{ auctionId: mongoose.Types.ObjectId(postData.auctionId) }],
        },
      });
    }

    if (postData.vin) {
      query.push({
        $match: {
          $and: [{ "inventorys.vin": regexSearch(postData.vin) }],
        },
      });
    }

    if (postData?.isMyBids) {
      query.push({
        $project: {
          sellerId: "$sellerUsers._id",
          sellerName: "$sellerUsers.name",
          sellerUniqueIdentifier: "$sellerUsers.uniqueIdentifier",
          buyerUniqueIdentifier: "$buyerUsers.uniqueIdentifier",
          userId: "$userId",
          auctionId: "$auctionId",
          inventoryId: "$inventoryId",
          userName: "$userName",
          bidStatus: "$status",
          bidType: "$bidType",
          createdAt: "$createdAt",
          counterOfferAmount: "$counterOfferAmount",
          inventoryDetails: {
            carName: {
              $concat: [
                "$inventorys.year",
                " ",
                "$makes.makeName",
                " ",
                "$models.modelName",
              ],
            },
            lotNo: "$inventorys.lotNo",
            vinNo: "$inventorys.vin",
            engineName: "$engines.engineName",
            milage: "$inventorys.milage",
            fuelType: "$fueltypes.fueltypeName",
            transmissionType: "$transmissions.transName",
            driveType: "$drivetypes.drivetypeName",
            singleImage: {
              $cond: {
                if: { $eq: ["$singlevinimages", []] },
                then: config.defaultInventoryImage,
                else: { $arrayElemAt: ["$singlevinimages.image", 0] },
              },
            },
          },
          bidDetails: {
            userBidAmount: "$currAmount",
            latestBidAmount: "$calcAmount",
          },
        },
      });
    } else {
      query.push({
        $project: {
          sellerId: "$sellerUsers._id",
          sellerName: "$sellerUsers.name",
          sellerUniqueIdentifier: "$sellerUsers.uniqueIdentifier",
          buyerUniqueIdentifier: "$buyerUsers.uniqueIdentifier",
          userId: "$userId",
          auctionId: "$auctionId",
          inventoryId: "$inventoryId",
          userName: "$userName",
          bidStatus: "$status",
          bidType: "$bidType",
          createdAt: "$createdAt",
          counterOfferAmount: "$counterOfferAmount",
          inventoryDetails: {
            carName: {
              $concat: [
                "$inventorys.year",
                " ",
                "$makes.makeName",
                " ",
                "$models.modelName",
              ],
            },
            lotNo: "$inventorys.lotNo",
            vinNo: "$inventorys.vin",
            engineName: "$engines.engineName",
            milage: "$inventorys.milage",
            fuelType: "$fueltypes.fueltypeName",
            transmissionType: "$transmissions.transName",
            driveType: "$drivetypes.drivetypeName",
            singleImage: {
              $cond: {
                if: { $eq: ["$singlevinimages", []] },
                then: config.defaultInventoryImage,
                else: { $arrayElemAt: ["$singlevinimages.image", 0] },
              },
            },
          },
          bidDetails: {
            userBidAmount: { $arrayElemAt: ["$bids.calcAmount", -1] },
            latestBidAmount: "$calcAmount",
          },
        },
      });
    }

    query.push({ $sort: { createdAt: -1 } });

    const sQuery = [...query];
    sQuery.push({ $count: "recordCount" });

    if (postData.page) {
      query.push({
        $skip: cmethod.pageOffset(postData.page, postData.pageLimit),
      });
      query.push({ $limit: cmethod.pageLimit(postData.pageLimit) });
    }

    ModelAggregation(query)
      .then(function (data) {
        ModelAggregation(sQuery)
          .then(async function (dcount) {
            let tptCnt = 0;
            if (dcount.length > 0) {
              tptCnt = dcount[0].recordCount;
            }

            res.status(200).json({
              status: true,
              result: data,
              message: "",
              hasMore: cmethod.hasMoreCount(
                tptCnt,
                postData.page,
                postData.pageLimit
              ),
              totalCount: tptCnt,
            });
          })
          .catch((err) => {
            cmethod.returnSreverError(res, "Some technical issue", err);
          });
      })
      .catch((err) => {
        cmethod.returnSreverError(res, "Some technical issue", err);
      });
  }
);

// Get Pre Bids

// router.get(
//   "/create-bid-log",
//   [midleware.validateFieldValue([], [])],
//   async (req, res) => {
//     let BidData = await bidModal.Bid.findOne().sort({ createdAt: 1 });
//     if (BidData) {
//       let data = await bidModal.Bid.find({
//         auctionId: mongoose.Types.ObjectId(BidData.auctionId),
//         inventoryId: mongoose.Types.ObjectId(BidData.inventoryId),
//       }).sort({ createdAt: 1 });

//       bidModal.bidHistoryLog.insertMany(data).then(async (result) => {
//         let ids = data.map((ele) => {
//           return mongoose.Types.ObjectId(ele._id);
//         });
//         const auctionIds = data.map((ele) => {
//           return mongoose.Types.ObjectId(ele.auctionId);
//         });
//         bidModal.Bid.remove({ _id: { $in: ids } }).then(async (result) => {
//           await auctionModal.Auction.updateMany(
//             { _id: { $in: auctionIds } },
//             { $set: { isAuctionEnded: true } }
//           );
//           cmethod.returnSuccess(res, result, false, message["eng"].Updated);
//         });
//       });
//       // cmethod.returnSuccess(res, ids, false, message["eng"].Updated);
//     } else {
//       cmethod.returrnErrorMessage(res, "Not Available");
//     }
//   }
// );

router.post(
  "/bid-history",
  [midleware.validateFieldValue(["page", "pageLimit"], ["page", "pageLimit"])],
  async (req, res) => {
    const postData = req.body;
    let query = [];

    // * auctions
    query.push({
      $lookup: {
        from: "auctions",
        localField: "auctionId",
        foreignField: "_id",
        as: "auctions",
      },
    });
    query.push({
      $unwind: { path: "$auctions", preserveNullAndEmptyArrays: true },
    });

    // * inventorys
    query.push({
      $lookup: {
        from: "inventorys",
        localField: "inventoryId",
        foreignField: "_id",
        as: "inventorys",
      },
    });
    query.push({
      $unwind: { path: "$inventorys", preserveNullAndEmptyArrays: true },
    });

    // * makes
    query.push({
      $lookup: {
        from: "makes",
        localField: "inventorys.make",
        foreignField: "_id",
        as: "makes",
      },
    });
    query.push({
      $unwind: { path: "$makes", preserveNullAndEmptyArrays: true },
    });

    // * models
    query.push({
      $lookup: {
        from: "models",
        localField: "inventorys.model",
        foreignField: "_id",
        as: "models",
      },
    });
    query.push({
      $unwind: { path: "$models", preserveNullAndEmptyArrays: true },
    });

    // * engines
    query.push({
      $lookup: {
        from: "engines",
        localField: "inventorys.engineId",
        foreignField: "_id",
        as: "engines",
      },
    });
    query.push({
      $unwind: { path: "$engines", preserveNullAndEmptyArrays: true },
    });

    // * drivetypes
    query.push({
      $lookup: {
        from: "drivetypes",
        localField: "inventorys.drivetypeId",
        foreignField: "_id",
        as: "drivetypes",
      },
    });
    query.push({
      $unwind: { path: "$drivetypes", preserveNullAndEmptyArrays: true },
    });

    // * fueltypes
    query.push({
      $lookup: {
        from: "fueltypes",
        localField: "inventorys.fueltypeId",
        foreignField: "_id",
        as: "fueltypes",
      },
    });
    query.push({
      $unwind: { path: "$fueltypes", preserveNullAndEmptyArrays: true },
    });

    // * vinimages
    query.push({
      $lookup: {
        from: "vinimages",
        let: {
          inventoryId: "$_id",
          imageType: "inventory",
          type: "carimage",
        },
        pipeline: [
          {
            $match: {
              $expr: {
                $and: [
                  { $eq: ["$imageType", "$$imageType"] },
                  { $eq: ["$type", "$$type"] },
                  { $eq: ["$referenceId", "$$inventoryId"] },
                ],
              },
            },
          },
        ],
        as: "singlevinimages",
      },
    });

    // * bids
    query.push({
      $lookup: {
        from: "bidhistorylogs",
        let: {
          userId: "$userId",
          auctionId: "$auctionId",
          inventoryId: "$inventoryId",
        },
        pipeline: [
          {
            $match: {
              $expr: {
                $and: [
                  { $eq: ["$userId", "$$userId"] },
                  { $eq: ["$auctionId", "$$auctionId"] },
                  { $eq: ["$inventoryId", "$$inventoryId"] },
                ],
              },
            },
          },
        ],
        as: "bids",
      },
    });

    if (postData?.userId) {
      query.push({
        $match: {
          userId: mongoose.Types.ObjectId(postData.userId),
        },
      });
    }

    if (postData?.bidStatus) {
      query.push({
        $match: {
          status: postData.bidStatus,
        },
      });
    }

    if (postData?.bidType) {
      query.push({
        $match: {
          bidType: postData.bidType,
        },
      });
    }

    if (postData?.inventoryId) {
      query.push({
        $match: {
          inventoryId: mongoose.Types.ObjectId(postData.inventoryId),
        },
      });
    }

    query.push({
      $group: {
        _id: "$inventoryId",
        currAmount: { $last: "$currAmount" },
        calcAmount: { $last: "$calcAmount" },
        userName: { $last: "$userName" },
        auctionId: { $last: "$auctionId" },
        inventoryId: { $last: "$inventoryId" },
        makes: { $last: "$makes" },
        models: { $last: "$models" },
        inventorys: { $last: "$inventorys" },
        engines: { $last: "$engines" },
        fueltypes: { $last: "$fueltypes" },
        transmissions: { $last: "$transmissions" },
        drivetypes: { $last: "$drivetypes" },
        singlevinimages: { $last: "$singlevinimages" },
        createdAt: { $last: "$createdAt" },
        history: { $last: "$bids" },
      },
    });

    if (checkBoolean(postData.history)) {
      query.push({
        $unwind: { path: "$history", preserveNullAndEmptyArrays: true },
      });

      query.push({
        $project: {
          userName: "$history.userName",
          auctionId: "$history.auctionId",
          inventoryId: "$history.inventoryId",
          carDescription: {
            $concat: [
              "$inventorys.year",
              " ",
              "$makes.makeName",
              " ",
              "$models.modelName",
            ],
          },
          lotNo: "$inventorys.lotNo",
          vinNo: "$inventorys.vin",
          engineName: "$engines.engineName",
          milage: "$inventorys.milage",
          fuelType: "$fueltypes.fueltypeName",
          transmissionType: "$transmissions.transName",
          driveType: "$drivetypes.drivetypeName",
          createdAt: "$history.createdAt",
          singleImage: {
            $cond: {
              if: { $eq: ["$singlevinimages", []] },
              then: config.defaultInventoryImage,
              else: { $arrayElemAt: ["$singlevinimages.image", 0] },
            },
          },
          bidDetails: {
            userBidAmount: "$history.currAmount",
            latestBidAmount: "$history.calcAmount",
          },
        },
      });
    } else {
      query.push({
        $project: {
          userName: 1,
          auctionId: "$auctionId",
          inventoryId: "$inventoryId",
          carDescription: {
            $concat: [
              "$inventorys.year",
              " ",
              "$makes.makeName",
              " ",
              "$models.modelName",
            ],
          },
          lotNo: "$inventorys.lotNo",
          vinNo: "$inventorys.vin",
          engineName: "$engines.engineName",
          milage: "$inventorys.milage",
          fuelType: "$fueltypes.fueltypeName",
          transmissionType: "$transmissions.transName",
          driveType: "$drivetypes.drivetypeName",
          createdAt: "$createdAt",
          singleImage: {
            $cond: {
              if: { $eq: ["$singlevinimages", []] },
              then: config.defaultInventoryImage,
              else: { $arrayElemAt: ["$singlevinimages.image", 0] },
            },
          },
          bidDetails: {
            userBidAmount: "$currAmount",
            latestBidAmount: "$calcAmount",
          },
        },
      });
    }

    query.push({ $sort: { createdAt: -1 } });

    const sQuery = [...query];
    sQuery.push({ $count: "recordCount" });

    if (postData.page) {
      query.push({
        $skip: cmethod.pageOffset(postData.page, postData.pageLimit),
      });
      query.push({ $limit: cmethod.pageLimit(postData.pageLimit) });
    }

    bidDao
      .findBidHistoryAggregation(query)
      .then(function (data) {
        bidDao
          .findBidHistoryAggregation(sQuery)
          .then(async function (dcount) {
            let tptCnt = 0;

            if (dcount.length > 0) tptCnt = dcount[0].recordCount;

            res.status(200).json({
              status: true,
              result: data,
              message: "",
              hasMore: cmethod.hasMoreCount(
                tptCnt,
                postData.page,
                postData.pageLimit
              ),
              totalCount: tptCnt,
            });
          })
          .catch((err) => {
            cmethod.returnSreverError(res, "Some technical issue", err);
          });
      })
      .catch((err) => {
        cmethod.returnSreverError(res, "Some technical issue", err);
      });
  }
);

/* Get Reverse Bid value */
router.post(
  "/reverse-bid-val",
  [midleware.validateFieldValue([], [])],
  async (req, res) => {
    let ltCount = req.body.reserveCount || 1;
    //console.log(req.body.auctionId);
    let BidData = await bidModal.Bid.find(
      {
        auctionId: mongoose.Types.ObjectId(req.body.auctionId),
        inventoryId: mongoose.Types.ObjectId(req.body.inventoryId),
      },
      { currAmount: 1, calcAmount: 1 }
    )
      .sort({ createdAt: -1 })
      .skip(0)
      .limit(ltCount);
    let sumAmt = 0;
    if (BidData.length > 0) {
      for (let i = 0; i < BidData.length; i++) {
        sumAmt = sumAmt + BidData[i].currAmount;
      }
    }
    cmethod.returnSuccess(res, sumAmt, false, "");
  }
);

// * Update Bid History Log By ID
router.patch(
  "/update-bid-history",
  [midleware.validateFieldValue([], [])],
  async (req, res) => {
    const {
      body,
      query: { id },
      headers: { lang = config.lang },
    } = req;

    try {
      if (!id) {
        return cmethod.returrnErrorMessage(res, "bidId (id) is required!");
      }

      const previousBidAmount = await FindByIdWithKey(
        bidModal.bidHistoryLog,
        id,
        "calcAmount"
      );

      const { isBidAmountChanged, createdBy, receiptId, ...rest } = body;

      const filter = { _id: makeObjectId(id) };
      const nDoc = { new: true };
      const updateBidHistory = await bidModal.bidHistoryLog.findOneAndUpdate(
        filter,
        rest,
        nDoc
      );

      if (!updateBidHistory) {
        return cmethod.returrnErrorMessage(res, "doc not found!");
      }

      if (isBidAmountChanged) {
        // * auction-vehicle-update
        const { auctionId, inventoryId, calcAmount } = updateBidHistory;
        const filter = { auctionId, inventoryId, status: "sold" };
        const update = { bidAmount: calcAmount };
        await UpdateOne(auctionModal.Auctionvehicle, filter, update);

        // * add-comment-log
        const message = `Screening - changed last bid amount from ${previousBidAmount} to ${calcAmount}`;
        const log = {
          referenceType: "reciept",
          referenceId: receiptId,
          message: message,
          commentBy: createdBy,
        };

        await createComment(log);
      }

      cmethod.returnSuccess(
        res,
        updateBidHistory,
        false,
        message[lang]?.Updated
      );
    } catch (error) {
      logger.error(error);
      cmethod.returnSreverError(res, message[lang].technicalError, error);
    }
  }
);

// * Reject Bid
router.patch("/reject-bid", async (req, res) => {
  const {
    body,
    query: { id },
  } = req;

  if (!id) return cmethod.returrnErrorMessage(res, "bidId (id) is required!");

  try {
    const rejectedBid = await handleRejectedBid(id, body);
    cmethod.returnSuccess(res, rejectedBid, false, message["eng"].Updated);
  } catch (error) {
    logger.error(error);
    return cmethod.returrnErrorMessage(res, error.message);
  }
});

module.exports = router;

/**
 * @swagger
 * /api/bid/update-bid:
 *   post:
 *     tags: [Bid]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: currAmount
 *         in: formData
 *         type: number
 *         required: false
 *         description:
 *       - name: counterOfferAmount
 *         in: formData
 *         type: number
 *         required: false
 *         description:
 *       - name: userId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: userName
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: inventoryId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: bidStatus
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: bidType
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: counterOfferAdminId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: counterOfferAdminName
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *     responses:
 *       200:
 *         description: Reciepts.
 *
 */

/**
 * @swagger
 * /api/bid/get-bid:
 *   post:
 *     tags: [Bid]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: userId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: bidStatus
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: bidType
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: auctionId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: vin
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: pageLimit
 *         in: formData
 *         type: number
 *         required: true
 *         description:
 *       - name: page
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: Get User Bids.
 *
 */

/**
 * @swagger
 * /api/bid/get-pre-bid:
 *   post:
 *     tags: [Bid]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: userId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: bidStatus
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: bidType
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: inventoryId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: auctionId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: vin
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: pageLimit
 *         in: formData
 *         type: number
 *         required: true
 *         description:
 *       - name: page
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: Get User Pre Bids.
 *
 */

/**
 * @swagger
 * /api/bid/create-bid-log:
 *   get:
 *     tags: [Bid]
 *     produces:
 *       - application/json
 *     responses:
 *       200:
 *         description: Reciepts.
 *
 */

/**
 * @swagger
 * /api/bid/bid-history:
 *   post:
 *     tags: [Bid]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: userId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: bidStatus
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: bidType
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: history
 *         in: formData
 *         type: boolean
 *         required: false
 *         description:
 *       - name: pageLimit
 *         in: formData
 *         type: number
 *         required: true
 *         description:
 *       - name: page
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: Reciepts.
 *
 */

/**
 * @swagger
 * /api/bid/update-bid-history:
 *   patch:
 *     tags: [Bid]
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: query
 *         name: id
 *         schema:
 *           type: string
 *         description:
 *       - in: query
 *         name: auctionId
 *         schema:
 *           type: string
 *         description:
 *       - in: formData
 *         name: userId
 *         type: string
 *         required: false
 *         description:
 *       - in: formData
 *         name: receiptId
 *         type: string
 *         required: false
 *         description:
 *       - in: formData
 *         name: calcAmount
 *         type: number
 *         required: false
 *         description:
 *       - in: formData
 *         name: createdBy
 *         type: string
 *         required: false
 *         description:
 *       - in: formData
 *         name: comment
 *         type: string
 *         required: false
 *         description:
 *       - in: formData
 *         name: isBidAmountChanged
 *         type: boolean
 *         required: false
 *         description:
 *       - in: formData
 *         name: wasAdminBid
 *         type: boolean
 *         required: false
 *         description:
 *     responses:
 *       200:
 *         description: Bid | Bid-History - Update
 *
 */
/**
 * @swagger
 * /api/bid/reject-bid:
 *   patch:
 *     tags: [Bid]
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: query
 *         name: id
 *         schema:
 *           type: string
 *           required: true
 *         description:
 *       - in: formData
 *         name: comments
 *         type: string
 *         required: false
 *         description:
 *     responses:
 *       200:
 *         description: Bid-History - Reject
 *
 */
