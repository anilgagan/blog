const bidModal = require("./bidModal");
const auctionModal = require("./../auction/auctionModal");
const inventoryModal = require("../inventory/inventoryModal");
const userModel = require("../user/userModal");
const orderModel = require("./../order/orderModel");
const mongoose = require("mongoose");
const {
  createBidHistoryLog,
  removeInventoriesFromWatchList,
  checkReserveStatus,
} = require("../../services/bid.service");
const bidDao = require("../bid/bidDao");
const common = require("../../middleware/common-fun");
const { FindById, Count } = require("../../models/factory");

// Car Sold Function
async function CarSold(data, currentBidData, userData) {
  await auctionModal.Auctionvehicle.updateOne(
    {
      auctionId: mongoose.Types.ObjectId(data.auctionId),
      inventoryId: mongoose.Types.ObjectId(data.inventoryId),
    },
    { $set: { status: "sold", bidAmount: currentBidData?.calcAmount } } // an error came here so applied optional chaining ?.
  );
  // update Close Staus of last acution
  await bidModal.Bid.updateOne(
    { _id: mongoose.Types.ObjectId(currentBidData._id) },
    { $set: { status: "Sold", isProcessed: true } }
  );

  // * don't create/update for admin
  if (userData.userType !== 1) {
    await userModel.User.updateOne(
      { _id: mongoose.Types.ObjectId(currentBidData.userId) },
      {
        $inc: {
          creditLimit: -currentBidData.calcAmount,
        },
      }
    );

    let creditCalData = await orderModel.creditCalHistory.create({
      userId: currentBidData.userId,
      deposit: 0,
      creditLimit: currentBidData.calcAmount,
      creditType: "DR",
    });

    await orderModel.creditCalHistory.updateOne(
      { _id: mongoose.Types.ObjectId(creditCalData._id) },
      { $inc: { balance: -currentBidData.calcAmount } }
    );
  }

  // update auction status close in auctionModal
  await auctionModal.Auction.updateOne(
    { _id: mongoose.Types.ObjectId(data.auctionId) },
    { $set: { isAuctionEnded: true } }
  );
}

// Mark Care Under Approvel function

async function CarUnderApproval(data, currentBidData, userData) {
  await auctionModal.Auctionvehicle.updateOne(
    {
      auctionId: mongoose.Types.ObjectId(data.auctionId),
      inventoryId: mongoose.Types.ObjectId(data.inventoryId),
    },
    {
      $set: {
        status: "UnderApproval",
        bidAmount: currentBidData.calcAmount,
      },
    }
  );
  // update Close Staus of last acution
  await bidModal.Bid.updateOne(
    { _id: mongoose.Types.ObjectId(currentBidData._id) },
    { $set: { status: "UnderApproval", isProcessed: true } }
  );
}

// Function To return  Last five Bids  after each event
async function getLastFiveBids(io, data, currentBidData, userData) {
  let bidData = await bidModal.Bid.find({
    auctionId: mongoose.Types.ObjectId(data.auctionId),
    inventoryId: mongoose.Types.ObjectId(data.inventoryId),
  })
    .sort({ createdAt: -1 })
    .limit(5);
  io.to(data.auctionId + data.inventoryId).emit("getData", bidData);
  if (userData) {
    io.to(data.auctionId + data.inventoryId).emit(
      "bidMessage",
      "You win the Auction=" + data.userId + "=" + userData
        ? userData.creditLimit
        : 0
    );
  } else {
    io.to(data.auctionId + data.inventoryId).emit(
      "bidMessage",
      "You win the Auction=" + data.userId + "=" + 0
    );
  }
}

module.exports = function (io) {
  var numClients = {};
  var onlimeTimeSecond = 10000;
  var setTimeObject = {};

  io.on("connection", (socket) => {
    //
    // Add the socket to the room for the specific auction ID
    socket.on("joinAuction", (joinData) => {
      //
      socket.join(joinData.auctionId + joinData.inventoryId);
      socket.room = joinData.auctionId + joinData.inventoryId;
      //
      if (numClients[joinData.auctionId + joinData.inventoryId] == undefined) {
        numClients[joinData.auctionId + joinData.inventoryId] = 1;
      } else {
        numClients[joinData.auctionId + joinData.inventoryId]++;
      }
    });

    /* To Find bid data to calulate  current Biding value */

    socket.on("bidData", async (data) => {
      const auctionData = await auctionModal.Auction.findOne({
        _id: mongoose.Types.ObjectId(data.auctionId),
      });

      //

      if (auctionData.auctionStart) {
        let auctionStartDataTime = new Date(auctionData.auctionDate).getTime();
        let currentDate = new Date().getTime();
        //capare Date and Time
        console.log(
          auctionData.auctionDate,
          "==",
          currentDate + ">" + auctionStartDataTime
        );
        if (currentDate > auctionStartDataTime) {
          // flash Duration if auction is oline for counetr

          if (auctionData.auctionType == "online") {
            io.to(data.auctionId + data.inventoryId).emit(
              "onlieTimerDuration",
              auctionData.duration
            );
          }

          //To Check user Credit
          let userCredit = await userModel.User.findOne(
            { _id: mongoose.Types.ObjectId(data.userId) },
            { creditLimit: 1, userType: 1, curBalance: 1 }
          );
          let bidData = await bidModal.Bid.findOne({
            auctionId: mongoose.Types.ObjectId(data.auctionId),
            inventoryId: mongoose.Types.ObjectId(data.inventoryId),
            // status: "Open",
          })
            .sort({ createdAt: -1 })
            .limit(1);

          // * return when already processed
          const isBidProcessed = await Count(bidModal.Bid, {
            auctionId: mongoose.Types.ObjectId(data.auctionId),
            inventoryId: mongoose.Types.ObjectId(data.inventoryId),
            isProcessed: true,
          });

          if (isBidProcessed) {
            await getLastFiveBids(io, data, bidData, userCredit);
            return;
          }

          if (bidData) {
            //
            data.calcAmount =
              parseInt(bidData.calcAmount) + parseInt(data.currAmount);
          } else {
            data.calcAmount =
              parseInt(data.startPrice) + parseInt(data.currAmount);
          }

          // Check Condtion for ReservePrice Update
          if (bidData && data.reservePrice > bidData.reservePrice) {
            data.reservePrice = bidData.reservePrice;
          }

          if (bidData) {
            data.biderCount = bidData.biderCount + 1;
            data.auctionType = auctionData.auctionType
              ? auctionData.auctionType
              : "online";
          }
          //
          if (
            parseInt(userCredit.creditLimit) < parseInt(data.calcAmount) &&
            userCredit.userType != 1
          ) {
            io.to(data.auctionId + data.inventoryId).emit(
              "bidMessage",
              "Your Credit is Low. Please Purchage new Plan.=" + data.userId
            );
          } else if (
            (bidData &&
              bidData.status == "Open" &&
              bidData.status != "Sold" &&
              bidData.status != "UnderApproval") ||
            !bidData
          ) {
            try {
              let isApproved;
              let result = await bidModal.Bid.create(data);

              const inventory = await inventoryModal.Inventory.findOne(
                {
                  _id: mongoose.Types.ObjectId(data.inventoryId),
                },
                { reservePrice: 1, startingBid: 1 }
              );

              if (result.calcAmount >= inventory.reservePrice) {
                isApproved = true;
              } else if (inventory.startingBid >= inventory.reservePrice) {
                isApproved = true;
              } else {
                isApproved = false;
              }

              // Return the current Auction
              io.to(data.auctionId + data.inventoryId).emit(
                "bidResponse",
                result
              );
              io.to(data.auctionId + data.inventoryId).emit(
                "isProcessDone",
                isApproved
              );
              // Return last 5 bid of that auction
              let bidData = await bidModal.Bid.find({
                auctionId: mongoose.Types.ObjectId(data.auctionId),
                inventoryId: mongoose.Types.ObjectId(data.inventoryId),
                isApproved,
                // status: "Open",
              })
                .sort({ createdAt: -1 })
                .limit(5);
              //
              io.to(data.auctionId + data.inventoryId).emit(
                "userCount",
                numClients[socket.room]
              );
              io.to(data.auctionId + data.inventoryId).emit("getData", bidData);
            } catch (err) {
              // send Error
              io.to(data.auctionId + data.inventoryId).emit(
                "bidError",
                "Please try again. =3"
              );
            }
          } else {
            //
            io.to(data.auctionId + data.inventoryId).emit(
              "bidMessage",
              "Auction has been Closed. =4"
            );
          }

          /* Mark as sold if onlin online acution cross the time*/
          if (auctionData.auctionType == "online") {
            // if bidData if null in case of firts bid
            if (!bidData) {
              bidData = await bidModal.Bid.findOne({
                auctionId: mongoose.Types.ObjectId(data.auctionId),
                inventoryId: mongoose.Types.ObjectId(data.inventoryId),
                // status: "Open",
              });
            }
            if (bidData) {
              clearTimeout(setTimeObject[data.auctionId + data.inventoryId]);
              setTimeObject[data.auctionId + data.inventoryId] = setTimeout(
                async function () {
                  let lastBidTime = new Date(bidData.createdAt).getTime();
                  let cTime = new Date().getTime();
                  if (cTime - lastBidTime >= auctionData.duration * 1000) {
                    if (bidData.calcAmount > bidData.reservePrice) {
                      await bidDao.markSold(bidData);
                      let userData = await userModel.User.findOne(
                        { _id: mongoose.Types.ObjectId(bidData.userId) },
                        { creditLimit: 1 }
                      );
                      io.to(data.auctionId + data.inventoryId).emit(
                        "bidMessage",
                        "You win the Auction=" + data.userId + "=" + userData
                          ? userData.creditLimit
                          : 0
                      );
                    } else {
                      await auctionModal.Auctionvehicle.updateOne(
                        {
                          auctionId: mongoose.Types.ObjectId(data.auctionId),
                          inventoryId: mongoose.Types.ObjectId(
                            data.inventoryId
                          ),
                        },
                        {
                          $set: {
                            status: "UnderApproval",
                            bidAmount: bidData.calcAmount,
                          },
                        }
                      );
                      // update Close Staus of last acution
                      await bidModal.Bid.updateOne(
                        { _id: mongoose.Types.ObjectId(bidData._id) },
                        { $set: { status: "UnderApproval" } }
                      );
                    }

                    let bidDataUpdated = await bidModal.Bid.find({
                      auctionId: mongoose.Types.ObjectId(data.auctionId),
                      inventoryId: mongoose.Types.ObjectId(data.inventoryId),
                    })
                      .sort({ createdAt: -1 })
                      .limit(5);
                    io.to(data.auctionId + data.inventoryId).emit(
                      "getData",
                      bidDataUpdated
                    );
                  }
                },
                auctionData.duration * 1000
              );
            }
          }
          /* end code  */
        } else {
          io.to(data.auctionId + data.inventoryId).emit(
            "bidMessage",
            "Auction has not started Yet.=6"
          );
        }
      } else {
        //
        io.to(data.auctionId + data.inventoryId).emit(
          "bidMessage",
          "Auction has not started Yet.=6"
        );
        io.to(data.auctionId + data.inventoryId).emit(
          "bidAdminMessage",
          "Auction has not started Yet.=6"
        );
      }
    });

    /* To Find bid data to calulate  current Biding value */
    socket.on("getBidData", async (data) => {
      // To Check Auction Status
      let inventryAuctionInfo = {};
      const auctionData = await auctionModal.Auction.findOne(
        {
          _id: mongoose.Types.ObjectId(data.auctionId),
        },
        {
          duration: 1,
          auctionClose: 1,
          auctionDate: 1,
          auctionType: 1,
          auctionStart: 1,
          auctionHighlight: 1,
        }
      );

      const inventoryData = await inventoryModal.Inventory.findOne(
        {
          _id: mongoose.Types.ObjectId(data.inventoryId),
        },
        { reservePrice: 1, startingBid: 1 }
      );

      if (inventoryData && auctionData) {
        const isApprovedOrUnderApproval = await checkReserveStatus(
          data.auctionId,
          data.inventoryId,
          inventoryData.startingBid,
          inventoryData.reservePrice
        );

        io.to(data.auctionId + data.inventoryId).emit(
          "isProcessDone",
          isApprovedOrUnderApproval
        );
        inventryAuctionInfo = Object.assign({}, inventoryData._doc);
        let auctionInfo = Object.assign({}, auctionData._doc);
        inventryAuctionInfo.auctionStart = auctionInfo.auctionStart;
        inventryAuctionInfo.auctionHighlight = auctionInfo.auctionHighlight;
      }
      let bidData = await bidModal.Bid.find({
        auctionId: mongoose.Types.ObjectId(data.auctionId),
        inventoryId: mongoose.Types.ObjectId(data.inventoryId),
        // status: "Open",
      })
        .sort({ createdAt: -1 })
        .limit(5);

      if (auctionData.auctionType == "online") {
        let defaultDuration = auctionData.duration;
        let latestBidData = bidData[0];
        if (bidData && bidData.length > 0) {
          let lastBidTime = new Date(latestBidData.createdAt).getTime();
          let currentDate = new Date().getTime();
          let difTime = Math.ceil((currentDate - lastBidTime) / 1000);
          if (difTime < 0) {
            difTime = 0;
          } else if (difTime >= defaultDuration) {
            difTime = defaultDuration;
          }

          io.to(data.auctionId + data.inventoryId).emit(
            "onlineBidSartTime",
            difTime
          );
        } else {
          let lastBidTime = new Date(auctionData.auctionDate).getTime();
          let currentDate = new Date().getTime();
          let difTime = Math.ceil((currentDate - lastBidTime) / 1000);
          if (difTime > auctionData.duration) {
            difTime = 0;
          }
          io.to(data.auctionId + data.inventoryId).emit(
            "onlineBidSartTime",
            difTime
          );
        }
      }

      io.to(data.auctionId + data.inventoryId).emit(
        "userCount",
        numClients[socket.room]
      );

      io.to(data.auctionId + data.inventoryId).emit(
        "inventryData",
        inventryAuctionInfo
      );

      io.to(data.auctionId + data.inventoryId).emit("getData", bidData);
    });

    // Close the Auction
    // * Sold - sold
    socket.on("closeAuction", async (data) => {
      // Get Current Bid details
      let currentBidData = await bidModal.Bid.findOne({
        auctionId: mongoose.Types.ObjectId(data.auctionId),
        inventoryId: mongoose.Types.ObjectId(data.inventoryId),
        //status: "Open",
      })
        .sort({ createdAt: -1 })
        .limit(1);

      let userData = await userModel.User.findOne(
        { _id: mongoose.Types.ObjectId(currentBidData.userId) },
        { creditLimit: 1, userType: 1 }
      );

      if (currentBidData.calcAmount >= currentBidData.reservePrice) {
        if (currentBidData.status != "Sold") {
          await CarSold(data, currentBidData, userData);
        }
      } else {
        await CarUnderApproval(data, currentBidData, userData);
      }

      await getLastFiveBids(io, data, currentBidData, userData);
      await createBidHistoryLog(data.auctionId, data.inventoryId);
      await removeInventoriesFromWatchList(data.auctionId, data.inventoryId);
    });

    // Puase Auction
    // * Cancel - unsold
    socket.on("puaseAuction", async (data) => {
      // Get Current Bid details
      let currentBidData = await bidModal.Bid.findOne({
        auctionId: mongoose.Types.ObjectId(data.auctionId),
        inventoryId: mongoose.Types.ObjectId(data.inventoryId),
        //status: "Open",
      })
        .sort({ createdAt: -1 })
        .limit(1);

      let statVal = "Open";
      if (data.status == "Pause" || data.status == "UnSold") {
        statVal = data.status;
      }
      if (data.status == "UnSold") {
        let bidAmountVal = 0;
        if (currentBidData) {
          bidAmountVal = currentBidData.calcAmount;
        }
        await auctionModal.Auctionvehicle.updateOne(
          {
            auctionId: mongoose.Types.ObjectId(data.auctionId),
            inventoryId: mongoose.Types.ObjectId(data.inventoryId),
          },
          { $set: { status: "unsold", bidAmount: bidAmountVal } }
        );
      }
      if (
        (data.status == "UnSold" ||
          data.status == "Pause" ||
          data.status == "Open") &&
        currentBidData
      ) {
        // update Close Staus of last acution
        await bidModal.Bid.updateOne(
          { _id: mongoose.Types.ObjectId(currentBidData._id) },
          { $set: { status: statVal } }
        );
      } else if (!currentBidData) {
        // Create Entry in Bid Collection
        let obj = {
          currAmount: 0,
          userId: mongoose.Types.ObjectId(),
          userName: "None",
          auctionId: data.auctionId,
          status: "UnSold",
          inventoryId: data.inventoryId,
          reservePrice: 0,
          startPrice: 0,
        };
        let result = await bidModal.Bid.create(obj);
      }
      let bidData = await bidModal.Bid.find({
        auctionId: mongoose.Types.ObjectId(data.auctionId),
        inventoryId: mongoose.Types.ObjectId(data.inventoryId),
      })
        .sort({ createdAt: -1 })
        .limit(5);
      io.to(data.auctionId + data.inventoryId).emit("getData", bidData);
      io.to(data.auctionId + data.inventoryId).emit(
        "bidMessage",
        "Auction is in Pause Mode"
      );

      if (data.status === "UnSold") {
        await createBidHistoryLog(data.auctionId, data.inventoryId);
        await removeInventoriesFromWatchList(data.auctionId, data.inventoryId);
        await common.checkVehicleUnsold(data.auctionId, [data.inventoryId]);
      }
    });

    // Approve Auction
    // * Approve - approve
    socket.on("approveBids", async (data) => {
      // Get Current Bid details
      let currentBidData = await bidModal.Bid.findOne({
        auctionId: mongoose.Types.ObjectId(data.auctionId),
        inventoryId: mongoose.Types.ObjectId(data.inventoryId),
        //status: "Open",
      })
        .sort({ createdAt: -1 })
        .limit(1);
      //
      if (currentBidData.calcAmount == currentBidData.reservePrice) {
        let userData = await userModel.User.findOne(
          { _id: mongoose.Types.ObjectId(currentBidData.userId) },
          { creditLimit: 1, userType: 1 }
        );
        await CarSold(data, currentBidData, userData);
        await getLastFiveBids(io, data, currentBidData, userData);
        await createBidHistoryLog(data.auctionId, data.inventoryId);
        await removeInventoriesFromWatchList(data.auctionId, data.inventoryId);
      } else {
        await inventoryModal.Inventory.updateOne(
          { _id: mongoose.Types.ObjectId(data.inventoryId) },
          { $set: { reservePrice: currentBidData.calcAmount }, upsert: true }
        );
        // update Close Staus of last acution
        await bidModal.Bid.updateOne(
          { _id: mongoose.Types.ObjectId(currentBidData._id) },
          { $set: { reservePrice: currentBidData.calcAmount } }
        );

        let UptCurrentBidData = await bidModal.Bid.findOne({
          auctionId: mongoose.Types.ObjectId(data.auctionId),
          inventoryId: mongoose.Types.ObjectId(data.inventoryId),
          //status: "Open",
        })
          .sort({ createdAt: -1 })
          .limit(1);

        let userData = await userModel.User.findOne(
          { _id: mongoose.Types.ObjectId(UptCurrentBidData.userId) },
          { creditLimit: 1, userType: 1 }
        );
        await CarSold(data, UptCurrentBidData, userData);
        await getLastFiveBids(io, data, UptCurrentBidData, userData);
        await createBidHistoryLog(data.auctionId, data.inventoryId);
        await removeInventoriesFromWatchList(data.auctionId, data.inventoryId);
      }
    });

    // remove Bid

    socket.on("removeBids", async (data) => {
      let ltm = data.count ? data.count : 1;
      // Get Current Bid details
      let ids = await bidModal.Bid.find(
        {
          auctionId: mongoose.Types.ObjectId(data.auctionId),
          inventoryId: mongoose.Types.ObjectId(data.inventoryId),
          //status: "Open",
        },
        { _id: 1 }
      )
        .sort({ createdAt: -1 })
        .limit(parseInt(ltm));
      await bidModal.Bid.deleteMany({ _id: { $in: ids } });
      let bidData = await bidModal.Bid.find({
        auctionId: mongoose.Types.ObjectId(data.auctionId),
        inventoryId: mongoose.Types.ObjectId(data.inventoryId),
      })
        .sort({ createdAt: -1 })
        .limit(5);
      io.to(data.auctionId + data.inventoryId).emit("getData", bidData);
      io.to(data.auctionId + data.inventoryId).emit("isProcessDone", true); // * to know if bid process is done
    });

    // under approval

    // Close the Auction
    socket.on("unApprove", async (data) => {
      // Get Current Bid details
      let currentBidData = await bidModal.Bid.findOne({
        auctionId: mongoose.Types.ObjectId(data.auctionId),
        inventoryId: mongoose.Types.ObjectId(data.inventoryId),
        //status: "Open",
      })
        .sort({ createdAt: -1 })
        .limit(1);
      // updat auction for sold of Vehicle reapctive of auction Id
      if (currentBidData.calcAmount < currentBidData.reservePrice) {
        await auctionModal.Auctionvehicle.updateOne(
          {
            auctionId: mongoose.Types.ObjectId(data.auctionId),
            inventoryId: mongoose.Types.ObjectId(data.inventoryId),
          },
          {
            $set: {
              status: "UnderApproval",
              bidAmount: currentBidData.calcAmount,
            },
          }
        );
        // update Close Staus of last acution
        await bidModal.Bid.updateOne(
          { _id: mongoose.Types.ObjectId(currentBidData._id) },
          { $set: { status: "UnderApproval" } }
        );

        let bidData = await bidModal.Bid.find({
          auctionId: mongoose.Types.ObjectId(data.auctionId),
          inventoryId: mongoose.Types.ObjectId(data.inventoryId),
        })
          .sort({ createdAt: -1 })
          .limit(5);
        io.to(data.auctionId + data.inventoryId).emit("getData", bidData);

        await createBidHistoryLog(data.auctionId, data.inventoryId);
        await removeInventoriesFromWatchList(data.auctionId, data.inventoryId);
      } else {
        /*    */
        io.to(data.auctionId + data.inventoryId).emit(
          "bidAdminMessage",
          "You can't make this under approval. Reverve Bid amount has been crossed. ="
        );
      }
    });

    // Close the Auction
    socket.on("OnlineUnsold", async (data) => {
      // Get Current Bid details
      let auctionData = await auctionModal.Auction.findOne({
        _id: mongoose.Types.ObjectId(data.auctionId),
      });
      let auctionStartDataTime = new Date(auctionData.auctionDate).getTime();
      let currentDate = new Date().getTime();
      //capare Date and Time
      if ((currentDate - auctionStartDataTime) / 1000 >= auctionData.duration) {
        let currentBidData = await bidModal.Bid.findOne({
          auctionId: mongoose.Types.ObjectId(data.auctionId),
          inventoryId: mongoose.Types.ObjectId(data.inventoryId),
          //status: "Open",
        })
          .sort({ createdAt: -1 })
          .limit(1);
        if (!currentBidData) {
          if (data.status == "UnSold") {
            let bidAmountVal = 0;
            if (currentBidData) {
              bidAmountVal = currentBidData.calcAmount;
            }
            await auctionModal.Auctionvehicle.updateOne(
              {
                auctionId: mongoose.Types.ObjectId(data.auctionId),
                inventoryId: mongoose.Types.ObjectId(data.inventoryId),
              },
              { $set: { status: "unsold", bidAmount: 0 } }
            );
          }
          // Create Entry in Bid Collection
          let obj = {
            currAmount: 0,
            userId: mongoose.Types.ObjectId(),
            userName: "None",
            auctionId: data.auctionId,
            status: data.status,
            inventoryId: data.inventoryId,
            reservePrice: 0,
            startPrice: 0,
          };
          let result = await bidModal.Bid.create(obj);
          // Return the current Auction
          io.to(data.auctionId + data.inventoryId).emit("bidResponse", result);
        }

        let bidData = await bidModal.Bid.find({
          auctionId: mongoose.Types.ObjectId(data.auctionId),
          inventoryId: mongoose.Types.ObjectId(data.inventoryId),
        })
          .sort({ createdAt: -1 })
          .limit(5);
        io.to(data.auctionId + data.inventoryId).emit("getData", bidData);
        await createBidHistoryLog(data.auctionId, data.inventoryId);
        await common.checkVehicleUnsold(data.auctionId, [data.inventoryId]);
      }

      // Create Entry in Bid Collection
      let obj = {
        currAmount: 0,
        userId: mongoose.Types.ObjectId(),
        userName: "None",
        auctionId: data.auctionId,
        status: data.status,
        inventoryId: data.inventoryId,
        reservePrice: 0,
        startPrice: 0,
      };

      let result = await bidModal.Bid.create(obj);
      // Return the current Auction
      io.to(data.auctionId + data.inventoryId).emit("bidResponse", result);

      let bidData = await bidModal.Bid.find({
        auctionId: mongoose.Types.ObjectId(data.auctionId),
        inventoryId: mongoose.Types.ObjectId(data.inventoryId),
      })
        .sort({ createdAt: -1 })
        .limit(5);
      io.to(data.auctionId + data.inventoryId).emit("getData", bidData);
      await createBidHistoryLog(data.auctionId, data.inventoryId);
      await common.checkVehicleUnsold(data.auctionId, [data.inventoryId]);
    });

    // Show HightLight
    socket.on("showHighlight", async (data) => {
      let hStatus = false;
      if (data.flag) {
        hStatus = true;
      }
      let auctionData = await auctionModal.Auction.updateOne(
        {
          _id: mongoose.Types.ObjectId(data.auctionId),
        },
        { $set: { auctionHighlight: hStatus } }
      );
      if (data.flag) {
        io.to(data.auctionId + data.inventoryId).emit("highlightEvent", "show");
      } else {
        io.to(data.auctionId + data.inventoryId).emit("highlightEvent", "");
      }
    });

    // Auction Start

    socket.on("auctionStart", async (data) => {
      let auctionData = await auctionModal.Auction.updateOne(
        {
          _id: mongoose.Types.ObjectId(data.auctionId),
        },
        { $set: { auctionStart: data.status } }
      );
    });

    // skipAuction

    socket.on("skipAuction", async (data) => {
      await auctionModal.Auctionvehicle.updateOne(
        {
          auctionId: mongoose.Types.ObjectId(data.auctionId),
          inventoryId: mongoose.Types.ObjectId(data.inventoryId),
        },
        { $set: { status: "skip" } } // an error came here so applied optional chaining ?.
      );
      io.to(data.auctionId + data.inventoryId).emit("skipStatus", true);
    });

    // update Reserve Price

    socket.on("updatReservePrice", async (data) => {
      let inventoryData = await inventoryModal.Inventory.findOne(
        {
          _id: mongoose.Types.ObjectId(data.inventoryId),
        },
        { reservePrice: 1, startingBid: 1 }
      );

      const auction = await FindById(auctionModal.Auction, data.auctionId, {
        auctionStart: 1,
        auctionHighlight: 1,
      });

      const isApprovedOrUnderApproval = await checkReserveStatus(
        data.auctionId,
        data.inventoryId,
        inventoryData.startingBid,
        inventoryData.reservePrice
      );

      const reserveData = {
        startingBid: inventoryData.startingBid,
        reservePrice: inventoryData.reservePrice,
        isApproved: isApprovedOrUnderApproval,
        auctionStart: auction.auctionStart,
        auctionHighlight: auction.auctionHighlight,
      };

      io.to(data.auctionId + data.inventoryId).emit(
        "isProcessDone",
        isApprovedOrUnderApproval
      );
      io.to(data.auctionId + data.inventoryId).emit(
        "inventryData",
        reserveData
      );
    });

    // Disconnect the socket Connection
    socket.on("disconnect", () => {
      numClients[socket.room]--;
    });
  });
};
