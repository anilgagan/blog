const { number } = require("@hapi/joi");
const mongoose = require("mongoose");
const Schema = mongoose.Schema;
const { connWrite } = require("../../config/database");

const bidSchema = new Schema(
  {
    currAmount: { type: Number, default: 0, index: true },
    counterOfferAmount: { type: Number, default: 0, index: true },
    reservePrice: { type: Number, default: 0, index: true },
    startPrice: { type: Number, default: 0, index: true },
    calcAmount: { type: Number, default: 0, index: true },
    currBidCount: { type: Number, default: 0, index: true },
    biderCount: { type: Number, default: 1, index: true },
    wasAdminBid: { type: Boolean, default: false, index: true },
    counterOfferAdminId: {
      type: mongoose.Types.ObjectId,
      default: null,
      index: true,
    },
    counterOfferAdminName: {
      type: String,
      default: "",
      index: true,
    },
    userId: {
      type: mongoose.Types.ObjectId,
      default: mongoose.Types.ObjectId(),
      index: true,
    },
    userName: {
      type: String,
      default: "",
      index: true,
    },
    auctionId: {
      type: mongoose.Types.ObjectId,
      default: mongoose.Types.ObjectId(),
      index: true,
    },
    inventoryId: {
      type: mongoose.Types.ObjectId,
      default: mongoose.Types.ObjectId(),
      index: true,
    },
    puaseSecond: { type: Number, default: 0, index: true },
    status: { type: String, default: "Open", index: true }, // Pre, Open, Close, Pause, Sold, UnderApproval, CounterOffer
    bidType: {
      type: String,
      default: "Current",
      index: true,
    }, // Current //Pre //After
    auctionType: {
      type: String,
      default: "online",
      index: true,
    }, // online, offline
    comments: { type: String, default: "", index: true },
    isProcessed: { type: Boolean, default: false, index: true },
  },
  {
    timestamps: {
      createdAt: "createdAt",
      updatedAt: "updatedAt",
    },
  }
);

const bidHistoryLogSchema = new Schema(
  {
    currAmount: { type: Number, default: 0, index: true },
    counterOfferAmount: { type: Number, default: 0, index: true },
    reservePrice: { type: Number, default: 0, index: true },
    startPrice: { type: Number, default: 0, index: true },
    calcAmount: { type: Number, default: 0, index: true },
    currBidCount: { type: Number, default: 0, index: true },
    biderCount: { type: Number, default: 1, index: true },
    wasAdminBid: { type: Boolean, default: false, index: true },
    counterOfferAdminId: {
      type: mongoose.Types.ObjectId,
      default: null,
      index: true,
    },
    counterOfferAdminName: {
      type: String,
      default: "",
      index: true,
    },
    userId: {
      type: mongoose.Types.ObjectId,
      default: mongoose.Types.ObjectId(),
      index: true,
    },
    userName: {
      type: String,
      default: "",
      index: true,
    },
    auctionId: {
      type: mongoose.Types.ObjectId,
      default: mongoose.Types.ObjectId(),
      index: true,
    },
    inventoryId: {
      type: mongoose.Types.ObjectId,
      default: mongoose.Types.ObjectId(),
      index: true,
    },
    puaseSecond: { type: Number, default: 0, index: true },
    status: { type: String, default: "Open", index: true }, // Open, Close, Pause, Sold,
    bidType: {
      type: String,
      default: "Current",
      index: true,
    }, // Current //Pre
    isMarkedUnSoldByCron: { type: Boolean, default: false, index: true },
    isCounterOfferGiven: { type: Boolean, default: false, index: true },
    comments: { type: String, default: "", index: true },
  },
  {
    timestamps: {
      createdAt: "createdAt",
      updatedAt: "updatedAt",
    },
  }
);

bidHistoryLogSchema.index({ createdAt: 1 });

const Bid = connWrite.model("bids", bidSchema);
const bidHistoryLog = connWrite.model("bidhistorylog", bidHistoryLogSchema);
module.exports = {
  Bid,
  bidHistoryLog,
};
