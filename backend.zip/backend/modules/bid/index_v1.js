const bidModal = require("./bidModal");
const auctionModal = require("./../auction/auctionModal");
const inventoryModal = require("../inventory/inventoryModal");
const userModel = require("../user/userModal");
const orderModel = require("./../order/orderModel");
const mongoose = require("mongoose");
const {
  createBidHistoryLog,
  removeInventoryFromWatchList,
} = require("../../services/bid.service");
const bidDao = require("../bid/bidDao");
const common = require("../../middleware/common-fun");

module.exports = function (io) {
  var numClients = {};
  var onlimeTimeSecond = 10000;
  var setTimeObject = {};

  io.on("connection", (socket) => {
    //console.log("Connection Estbalish",joinData)
    // Add the socket to the room for the specific auction ID
    socket.on("joinAuction", (joinData) => {
      // console.log("User Join=>",joinData.auctionId+joinData.inventoryId)
      socket.join(joinData.auctionId + joinData.inventoryId);
      socket.room = joinData.auctionId + joinData.inventoryId;
      //console.log("==========",numClients[joinData.auctionId + joinData.inventoryId])
      if (numClients[joinData.auctionId + joinData.inventoryId] == undefined) {
        numClients[joinData.auctionId + joinData.inventoryId] = 1;
      } else {
        numClients[joinData.auctionId + joinData.inventoryId]++;
      }
      console.log("A user connected in Auction Room");
    });

    /* To Find bid data to calulate  current Biding value */

    socket.on("bidData", async (data) => {
      // To Check Auction Status
      let auctionData = await auctionModal.Auction.findOne({
        _id: mongoose.Types.ObjectId(data.auctionId),
      });
      let auctionStartDataTime = new Date(auctionData.auctionDate).getTime();
      let currentDate = new Date().getTime();
      //capare Date and Time
      if (currentDate > auctionStartDataTime) {
        // flash Duration if auction is oline for counetr

        if (auctionData.auctionType == "online") {
          io.to(data.auctionId + data.inventoryId).emit(
            "onlieTimerDuration",
            auctionData.duration
          );
        }

        //To Check user Credit
        let userCredit = await userModel.User.findOne(
          { _id: mongoose.Types.ObjectId(data.userId) },
          { creditLimit: 1, userType: 1, curBalance: 1 }
        );
        let bidData = await bidModal.Bid.findOne({
          auctionId: mongoose.Types.ObjectId(data.auctionId),
          inventoryId: mongoose.Types.ObjectId(data.inventoryId),
          // status: "Open",
        })
          .sort({ createdAt: -1 })
          .limit(1);
        if (bidData) {
          // console.log(parseInt(bidData.calcAmount) +"<"+ parseInt(data.currAmount))
          data.calcAmount =
            parseInt(bidData.calcAmount) + parseInt(data.currAmount);
        } else {
          data.calcAmount =
            parseInt(data.startPrice) + parseInt(data.currAmount);
        }
        if (bidData) {
          data.biderCount = bidData.biderCount + 1;
          data.auctionType = auctionData.auctionType
            ? auctionData.auctionType
            : "online";
        }

        if (
          parseInt(userCredit.creditLimit) < parseInt(data.calcAmount) &&
          userCredit.userType != 1
        ) {
          io.to(data.auctionId + data.inventoryId).emit(
            "bidMessage",
            "Your Credit is Low. Please Purchage new Plan.=" + data.userId
          );
        } else if ((bidData && bidData.status == "Open") || !bidData) {
          try {
            let result = await bidModal.Bid.create(data);
            // Return the current Auction
            io.to(data.auctionId + data.inventoryId).emit(
              "bidResponse",
              result
            );
            // Return last 5 bid of that auction
            let bidData = await bidModal.Bid.find({
              auctionId: mongoose.Types.ObjectId(data.auctionId),
              inventoryId: mongoose.Types.ObjectId(data.inventoryId),
              // status: "Open",
            })
              .sort({ createdAt: -1 })
              .limit(5);
            console.log("User Count: " + numClients[socket.room]);
            io.to(data.auctionId + data.inventoryId).emit(
              "userCount",
              numClients[socket.room]
            );
            io.to(data.auctionId + data.inventoryId).emit("getData", bidData);
          } catch (err) {
            // send Error
            io.to(data.auctionId + data.inventoryId).emit(
              "bidError",
              "Please try again. =3"
            );
          }
        } else {
          //console.log("===============>check")
          io.to(data.auctionId + data.inventoryId).emit(
            "bidMessage",
            "Auction has been Closed. =4"
          );
        }

        /* Mark as sold if onlin online acution cross the time*/
        // if (auctionData.auctionType == "online") {
        //   // if bidData if null in case of firts bid
        //   if (!bidData) {
        //     console.log("bidData=1", bidData);
        //     bidData = await bidModal.Bid.findOne({
        //       auctionId: mongoose.Types.ObjectId(data.auctionId),
        //       inventoryId: mongoose.Types.ObjectId(data.inventoryId),
        //       // status: "Open",
        //     });
        //   }
        //   if (bidData) {
        //     console.log("bidData=2", bidData);
        //     clearTimeout(setTimeObject[data.auctionId + data.inventoryId]);
        //     setTimeObject[data.auctionId + data.inventoryId] = setTimeout(
        //       async function () {
        //         let lastBidTime = new Date(bidData.createdAt).getTime();
        //         let cTime = new Date().getTime();
        //         if (cTime - lastBidTime >= auctionData.duration * 1000) {
        //           await bidDao.markSold(bidData);
        //           let userData = await userModel.User.findOne(
        //             { _id: mongoose.Types.ObjectId(bidData.userId) },
        //             { creditLimit: 1 }
        //           );
        //           let bidDataUpdated = await bidModal.Bid.find({
        //             auctionId: mongoose.Types.ObjectId(data.auctionId),
        //             inventoryId: mongoose.Types.ObjectId(data.inventoryId),
        //           })
        //             .sort({ createdAt: -1 })
        //             .limit(5);
        //           io.to(data.auctionId + data.inventoryId).emit(
        //             "getData",
        //             bidDataUpdated
        //           );
        //           io.to(data.auctionId + data.inventoryId).emit(
        //             "bidMessage",
        //             "You win the Auction=" + data.userId + "=" + userData
        //               ? userData.creditLimit
        //               : 0
        //           );
        //         }
        //       },
        //       auctionData.duration * 1000
        //     );
        //   }
        // }
        /* end code  */
      } else {
        io.to(data.auctionId + data.inventoryId).emit(
          "bidMessage",
          "Auction has not started Yet. =5"
        );
      }
    });

    /* To Find bid data to calulate  current Biding value */
    socket.on("getBidData", async (data) => {
      let bidData = await bidModal.Bid.find({
        auctionId: mongoose.Types.ObjectId(data.auctionId),
        inventoryId: mongoose.Types.ObjectId(data.inventoryId),
        // status: "Open",
      })
        .sort({ createdAt: -1 })
        .limit(5);
      io.to(data.auctionId + data.inventoryId).emit(
        "userCount",
        numClients[socket.room]
      );
      io.to(data.auctionId + data.inventoryId).emit("getData", bidData);
    });

    // Close the Auction
    socket.on("closeAuction", async (data) => {
      // Get Current Bid details
      let currentBidData = await bidModal.Bid.findOne({
        auctionId: mongoose.Types.ObjectId(data.auctionId),
        inventoryId: mongoose.Types.ObjectId(data.inventoryId),
        //status: "Open",
      })
        .sort({ createdAt: -1 })
        .limit(1);
      //console.log(currentBidData);
      // updat auction for sold of Vehicle reapctive of auction Id

      await auctionModal.Auctionvehicle.updateOne(
        {
          auctionId: mongoose.Types.ObjectId(data.auctionId),
          inventoryId: mongoose.Types.ObjectId(data.inventoryId),
        },
        { $set: { status: "sold", bidAmount: currentBidData?.calcAmount } } // an error came here so applied optional chaining ?.
      );
      // update Close Staus of last acution
      await bidModal.Bid.updateOne(
        { _id: mongoose.Types.ObjectId(currentBidData._id) },
        { $set: { status: "Sold" } }
      );

      const user = await userModel.User.findOne(
        { _id: mongoose.Types.ObjectId(currentBidData.userId) },
        { userType: 1 }
      );

      // * don't create/update for admin
      if (user.userType !== 1) {
        await userModel.User.updateOne(
          { _id: mongoose.Types.ObjectId(currentBidData.userId) },
          {
            $inc: {
              creditLimit: -currentBidData.calcAmount,
            },
          }
        );

        let creditCalData = await orderModel.creditCalHistory.create({
          userId: currentBidData.userId,
          deposit: 0,
          creditLimit: currentBidData.calcAmount,
          creditType: "DR",
        });

        await orderModel.creditCalHistory.updateOne(
          { _id: mongoose.Types.ObjectId(creditCalData._id) },
          { $inc: { balance: -currentBidData.calcAmount } }
        );
      }

      let userData = await userModel.User.findOne(
        { _id: mongoose.Types.ObjectId(currentBidData.userId) },
        { creditLimit: 1 }
      );

      // update auction status close in auctionModal
      await auctionModal.Auction.updateOne(
        { _id: mongoose.Types.ObjectId(data.auctionId) },
        { $set: { isAuctionEnded: true } }
      );

      let bidData = await bidModal.Bid.find({
        auctionId: mongoose.Types.ObjectId(data.auctionId),
        inventoryId: mongoose.Types.ObjectId(data.inventoryId),
      })
        .sort({ createdAt: -1 })
        .limit(5);
      io.to(data.auctionId + data.inventoryId).emit("getData", bidData);
      io.to(data.auctionId + data.inventoryId).emit(
        "bidMessage",
        "You win the Auction=" + data.userId + "=" + userData
          ? userData.creditLimit
          : 0
      );

      await createBidHistoryLog(data.auctionId, data.inventoryId);
      await removeInventoryFromWatchList(
        currentBidData.userId,
        data.inventoryId
      );
    });

    // Puase Auction
    socket.on("puaseAuction", async (data) => {
      // Get Current Bid details
      let currentBidData = await bidModal.Bid.findOne({
        auctionId: mongoose.Types.ObjectId(data.auctionId),
        inventoryId: mongoose.Types.ObjectId(data.inventoryId),
        //status: "Open",
      })
        .sort({ createdAt: -1 })
        .limit(1);
      let statVal = "Open";
      if (data.status == "Pause" || data.status == "UnSold") {
        statVal = data.status;
      }
      if (data.status == "UnSold") {
        let bidAmountVal = 0;
        if (currentBidData) {
          bidAmountVal = currentBidData.calcAmount;
        }
        await auctionModal.Auctionvehicle.updateOne(
          {
            auctionId: mongoose.Types.ObjectId(data.auctionId),
            inventoryId: mongoose.Types.ObjectId(data.inventoryId),
          },
          { $set: { status: "unsold", bidAmount: bidAmountVal } }
        );
      }
      if (
        (data.status == "UnSold" ||
          data.status == "Pause" ||
          data.status == "Open") &&
        currentBidData
      ) {
        // update Close Staus of last acution
        await bidModal.Bid.updateOne(
          { _id: mongoose.Types.ObjectId(currentBidData._id) },
          { $set: { status: statVal } }
        );
      }
      let bidData = await bidModal.Bid.find({
        auctionId: mongoose.Types.ObjectId(data.auctionId),
        inventoryId: mongoose.Types.ObjectId(data.inventoryId),
      })
        .sort({ createdAt: -1 })
        .limit(5);
      io.to(data.auctionId + data.inventoryId).emit("getData", bidData);
      io.to(data.auctionId + data.inventoryId).emit(
        "bidMessage",
        "Auction is in Pause Mode"
      );

      if (data.status === "UnSold") {
        await createBidHistoryLog(data.auctionId, data.inventoryId);
        await common.checkVehicleUnsold(data.auctionId, [data.inventoryId]);
      }
    });

    // Approve Auction
    socket.on("approveBids", async (data) => {
      // Get Current Bid details
      let currentBidData = await bidModal.Bid.findOne({
        auctionId: mongoose.Types.ObjectId(data.auctionId),
        inventoryId: mongoose.Types.ObjectId(data.inventoryId),
        //status: "Open",
      })
        .sort({ createdAt: -1 })
        .limit(1);
      //console.log(currentBidData);
      await inventoryModal.Inventory.updateOne(
        { _id: mongoose.Types.ObjectId(data.inventoryId) },
        { $set: { reservePrice: currentBidData.calcAmount }, upsert: true }
      );
      // update Close Staus of last acution
      await bidModal.Bid.updateOne(
        { _id: mongoose.Types.ObjectId(currentBidData._id) },
        { $set: { reservePrice: currentBidData.calcAmount } }
      );

      let bidData = await bidModal.Bid.find({
        auctionId: mongoose.Types.ObjectId(data.auctionId),
        inventoryId: mongoose.Types.ObjectId(data.inventoryId),
      })
        .sort({ createdAt: -1 })
        .limit(5);
      io.to(data.auctionId + data.inventoryId).emit("getData", bidData);
    });

    // remove Bid

    socket.on("removeBids", async (data) => {
      let ltm = data.count ? data.count : 1;
      // Get Current Bid details
      let ids = await bidModal.Bid.find(
        {
          auctionId: mongoose.Types.ObjectId(data.auctionId),
          inventoryId: mongoose.Types.ObjectId(data.inventoryId),
          //status: "Open",
        },
        { _id: 1 }
      )
        .sort({ createdAt: -1 })
        .limit(parseInt(ltm));
      await bidModal.Bid.deleteMany({ _id: { $in: ids } });
      let bidData = await bidModal.Bid.find({
        auctionId: mongoose.Types.ObjectId(data.auctionId),
        inventoryId: mongoose.Types.ObjectId(data.inventoryId),
      })
        .sort({ createdAt: -1 })
        .limit(5);
      io.to(data.auctionId + data.inventoryId).emit("getData", bidData);
    });

    // under approval

    // Close the Auction
    socket.on("unApprove", async (data) => {
      // Get Current Bid details
      let currentBidData = await bidModal.Bid.findOne({
        auctionId: mongoose.Types.ObjectId(data.auctionId),
        inventoryId: mongoose.Types.ObjectId(data.inventoryId),
        //status: "Open",
      })
        .sort({ createdAt: -1 })
        .limit(1);
      // updat auction for sold of Vehicle reapctive of auction Id
      if (currentBidData.calcAmount < currentBidData.reservePrice) {
        await auctionModal.Auctionvehicle.updateOne(
          {
            auctionId: mongoose.Types.ObjectId(data.auctionId),
            inventoryId: mongoose.Types.ObjectId(data.inventoryId),
          },
          {
            $set: {
              status: "UnderApproval",
              bidAmount: currentBidData.calcAmount,
            },
          }
        );
        // update Close Staus of last acution
        await bidModal.Bid.updateOne(
          { _id: mongoose.Types.ObjectId(currentBidData._id) },
          { $set: { status: "UnderApproval" } }
        );

        let bidData = await bidModal.Bid.find({
          auctionId: mongoose.Types.ObjectId(data.auctionId),
          inventoryId: mongoose.Types.ObjectId(data.inventoryId),
        })
          .sort({ createdAt: -1 })
          .limit(5);
        io.to(data.auctionId + data.inventoryId).emit("getData", bidData);

        await createBidHistoryLog(data.auctionId, data.inventoryId);
        await removeInventoryFromWatchList(
          currentBidData.userId,
          data.inventoryId
        );
      } else {
        /*console.log("Test==>",currentBidData);    */
        io.to(data.auctionId + data.inventoryId).emit(
          "bidAdminMessage",
          "You can't make this under approval. Reverve Bid amount has been crossed. ="
        );
      }
    });

    // Disconnect the socket Connection
    socket.on("disconnect", () => {
      console.log("a user disconnected!");
      numClients[socket.room]--;
    });
  });
};
