const mongoose = require("mongoose");
const auctionModal = require("./../auction/auctionModal");
const inventory = require("../inventory/inventoryModal");
const userModel = require("../user/userModal");
const orderModel = require("./../order/orderModel");
const bid = require("./bidModal");
const { createBidHistoryLog } = require("../../services/bid.service");
const findBidHistoryAggregation = function (query) {
  return new Promise(function (resolve, reject) {
    bid.bidHistoryLog.aggregate(query, function (err, data) {
      if (err) {
        reject(err);
      } else {
        resolve(data);
      }
    });
  });
};

const findBidAggregation = function (query) {
  return new Promise(function (resolve, reject) {
    bid.Bid.aggregate(query, function (err, data) {
      if (err) {
        reject(err);
      } else {
        resolve(data);
      }
    });
  });
};

const checkAuctionEnded = async ({
  userId,
  inventoryId,
  auctionId,
  bidStatus,
  bidType,
}) => {
  try {
    let query = [];

    const filter = {
      $and: [
        { userId: mongoose.Types.ObjectId(userId) },
        { inventoryId: mongoose.Types.ObjectId(inventoryId) },
        { auctionId: mongoose.Types.ObjectId(auctionId) },
        { status: bidStatus },
        { bidType: bidType },
      ],
    };

    query.push({
      $match: filter,
    });

    query.push({
      $lookup: {
        from: "auctions",
        localField: "auctionId",
        foreignField: "_id",
        as: "auctions",
      },
    });

    query.push({
      $unwind: { path: "$auctions", preserveNullAndEmptyArrays: true },
    });

    query.push({
      $match: {
        $and: [{ "auctions.isAuctionEnded": { $eq: true } }],
      },
    });

    query.push({ $sort: { createdAt: -1 } });

    const bids = await findBidAggregation(query);

    return bids.length > 0;
  } catch (error) {
    console.log(error);
  }
};

const markSold = async (data) => {
  // Get Current Bid details
  let currentBidData = await bid.Bid.findOne({
    auctionId: mongoose.Types.ObjectId(data.auctionId),
    inventoryId: mongoose.Types.ObjectId(data.inventoryId),
    //status: "Open",
  })
    .sort({ createdAt: -1 })
    .limit(1);
  //console.log(currentBidData);
  // updat auction for sold of Vehicle reapctive of auction Id

  await auctionModal.Auctionvehicle.updateOne(
    {
      auctionId: mongoose.Types.ObjectId(data.auctionId),
      inventoryId: mongoose.Types.ObjectId(data.inventoryId),
    },
    { $set: { status: "sold", bidAmount: currentBidData?.calcAmount } } // an error came here so applied optional chaining ?.
  );
  // update Close Staus of last acution
  await bid.Bid.updateOne(
    { _id: mongoose.Types.ObjectId(currentBidData._id) },
    { $set: { status: "Sold" } }
  );

  const user = await userModel.User.findOne(
    { _id: mongoose.Types.ObjectId(currentBidData.userId) },
    { userType: 1 }
  );

  // * don't create/update for admin
  if (user.userType !== 1) {
    await userModel.User.updateOne(
      { _id: mongoose.Types.ObjectId(currentBidData.userId) },
      {
        $inc: {
          creditLimit: -currentBidData.calcAmount,
        },
      }
    );

    let creditCalData = await orderModel.creditCalHistory.create({
      userId: currentBidData.userId,
      deposit: 0,
      creditLimit: currentBidData.calcAmount,
      creditType: "DR",
    });

    await orderModel.creditCalHistory.updateOne(
      { _id: mongoose.Types.ObjectId(creditCalData._id) },
      { $inc: { balance: -currentBidData.calcAmount } }
    );
  }

  let userData = await userModel.User.findOne(
    { _id: mongoose.Types.ObjectId(currentBidData.userId) },
    { creditLimit: 1 }
  );

  // update auction status close in auctionModal
  await auctionModal.Auction.updateOne(
    { _id: mongoose.Types.ObjectId(data.auctionId) },
    { $set: { isAuctionEnded: true } }
  );

  await createBidHistoryLog(data.auctionId, data.inventoryId);
};

module.exports = {
  findBidHistoryAggregation,
  findBidAggregation,
  checkAuctionEnded,
  markSold,
};
