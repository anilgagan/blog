const masterModal = require("../master/masterModal");
const message = require("../../config/message");
const cmethod = require("../../middleware/common-fun");

const warehouseAdd = async function (res, postData) {
  const newWarehouse = new masterModal.Warehouse(postData);

  newWarehouse.save(postData, async function (err, data) {
    if (err) {
      cmethod.returnSreverError(res, message.technicalError, err);
    } else {
      cmethod.returnSuccess(res, data, false, message.signupsuccess);
    }
  });
};

const findWarehouseWithFiled = async function (query) {
  return new Promise(function (resolve, reject) {
    masterModal.Warehouse.find(
      { _id: { $exists: true } },
      { vin: 1 },
      function (err, data) {
        if (err) {
          reject(err);
        } else {
          resolve(data);
        }
      }
    );
  });
};
const findWarehouseAggregation = function (query) {
  return new Promise(function (resolve, reject) {
    masterModal.Warehouse.aggregate(query, function (err, data) {
      if (err) {
        reject(err);
      } else {
        resolve(data);
      }
    });
  });
};

module.exports = {
  warehouseAdd,
  findWarehouseWithFiled,
  findWarehouseAggregation,
};
