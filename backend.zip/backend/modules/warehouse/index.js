const express = require("express");
const router = express.Router();
const masterWarehouse = require("../master/masterModal");
const message = require("../../config/message");
const config = require("../../config");
const midleware = require("../../middleware/validation");
const cmethod = require("../../middleware/common-fun");
const warehouseDao = require("./warehouseDao");
var mongoose = require("mongoose");

router.post(
  "/warehouseadd",
  [
    midleware.validateFieldValue(
      ["warehouseName", "status"],
      ["warehouseName", "status"]
    ),
  ],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    masterDao.warehouseAdd(res, postData);
  }
);

// update User

router.patch(
  "/warehouseupdate",
  [midleware.validateFieldValue(["warehosId"], ["warehosId"])],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let xtoken = req.headers["x-access-token"];
    //{ token: xtoken },
    let queryCond = {
      $and: [{ _id: mongoose.Types.ObjectId(postData.warehosId) }],
    };
    delete postData.warehosId;
    //console.log("=======================>", req.body);
    masterModal.Warehouse.findOneAndUpdate(
      queryCond,
      { $set: postData },
      { new: true },
      async function (err, data) {
        console.log("user->", data);
        if (err) {
          cmethod.returnSreverError(res, message[lang].technicalError, err);
        } else {
          cmethod.returnSuccess(res, data, false, message[lang].profileUpdate);
        }
      }
    );
  }
);
router.post(
  "/warehouselist",
  [midleware.validateFieldValue(["pageLimit", "page"], ["page"])],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let query = [];

    query.push({
      $project: {
        warehouseName: 1,
        status: 1,
        branchId: 1,
      },
    });
    const sQuery = [...query];
    query.push({ $sort: { createdAt: -1 } });
    sQuery.push({ $count: "recordCount" });

    if (postData.page) {
      query.push({
        $skip: cmethod.pageOffset(postData.page, postData.pageLimit),
      });
      query.push({ $limit: cmethod.pageLimit(postData.pageLimit) });
    }

    masterDao
      .findWarehouseAggregation(query)
      .then(function (data) {
        masterDao
          .findWarehouseAggregation(sQuery)
          .then(async function (dcount) {
            let tptCnt = 0;
            if (dcount.length > 0) {
              tptCnt = dcount[0].recordCount;
            }
            res.status(200).json({
              status: true,
              result: data,
              message: "",
              hasMore: cmethod.hasMoreCount(
                tptCnt,
                postData.page,
                postData.pageLimit
              ),
              totalCount: tptCnt,
            });
          })
          .catch((err) => {
            cmethod.returnSreverError(res, message[lang].technicalError, err);
          });
      })
      .catch((err) => {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      });
  }
);
module.exports = router;
