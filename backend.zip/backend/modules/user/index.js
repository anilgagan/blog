const express = require("express");
const router = express.Router();
const uModal = require("../user/userModal");
const masterModal = require("../master/masterModal");
const vinModal = require("../vin/vinModal");
const message = require("../../config/message");
const jwt = require("jsonwebtoken");
const config = require("../../config");
const midleware = require("../../middleware/validation");
const Promise = require("bluebird");
const cmethod = require("../../middleware/common-fun");
const moment = require("moment");
const userDao = require("./userDao");
const axios = require("axios");
var mongoose = require("mongoose");
const { update } = require("lodash");
const XLSX = require("xlsx");
const json2xls = require("json2xls");
const fs = require("fs");
const http = require("http");
const { dirname } = require("path");
const path = require("path");
const excel = require("exceljs");
const { object } = require("@hapi/joi");
const { sapbusinessPartener } = require("../sap/sapDao");
var $apiKey = config.getresponse.apiKey;
var $apiUrl = config.getresponse.apiUrl;
var $api = require("getresponse-nodejs-api/lib/getResponse");
const {
  isArrayWithLength,
  removeSpaces,
  removeSpecialCharacters,
} = require("../../functions/global.functions");
const {
  checkUniqueEmail,
  checkUserWithPhoneAndRole,
  sendOTP,
  checkEmailOrPhoneChange,
  checkUserVerification,
  checkUserProfileCompletion,
  sendEmailOTP,
  sendSmsOTP,
  matchPassword,
  checkEmailOrPhoneValidation,
} = require("../../services/user.service");
const logger = require("../../config/logger");
const { sendEmail } = require("../../services/email.service");
const {
  FindOne,
  FindByIdAndUpdate,
  FindById,
  FindOneAndUpdate,
} = require("../../models/factory");
const { makeSmsNumber } = require("../../services/sms.service");
const { getOTP } = require("../../services/otp.service");

var $api = new $api($apiKey, $apiUrl);
// console.log($api);
//end testing api for getresponse
router.get("/getresponse", (req, res) => {
  $ping = $api.ping(function (r) {
    console.log(r);
  });
  // $details = $api.getAccountInfo(function(r){console.log(r);});
  // $api.addContact({
  //   name: "Random Test",
  //   email: "random-test-123@gmail.com",
  //   token: "yyy",
  //   dayOfCycle: 0,
  //   ip: "10.20.30.40",
  //   customFields: [{
  //       id: "abcd",
  //       value: ["Test"]
  //   },{
  //       id: "efgh",
  //       value: ["CA"]
  //   }]
  // }).then(ok => {
  //   if(ok) console.log("Contact added!")
  // }).catch(err => {
  //   console.log(err)
  // });
  cmethod.returnSuccess(res, [], false, "jjjj");
});
router.post(
  "/ticketMaxLogin",
  [midleware.validateFieldValue(["userId"], ["userId"])],
  async (req, res) => {
    const postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let query = { $and: [{ _id: mongoose.Types.ObjectId(postData.userId) }] };
    userDao
      .findUser(query)
      .then(async (data) => {
        // let loginUlr = "https://api.ticketmx.com/login";
        let loginUlr = config.ticketMaxApiURL + "/login";

        let tmaxEmail = data[0].ticketMaxEmail;
        let tmaxPass = data[0].ticketMaxPass;
        reqData = {
          email: tmaxEmail,
          password: tmaxPass,
        };
        if (!data[0].ticketMax) {
          //  loginUlr = "https://api.ticketmx.com/register";
          loginUlr = config.ticketMaxApiURL + "/register";

          let splitEmail = data[0].email.split("@");
          tmaxEmail = splitEmail[0] + "-riyadh2021.@" + splitEmail[1];
          tmaxPass = cmethod.makerandomString(6);
          // console.log(data[0]);
          reqData = {
            email: tmaxEmail,
            password: tmaxPass,
            fullname:
              data[0].name && data[0].name != "" ? data[0].name : "User",
            mobile:
              data[0].phone &&
              data[0].phone != "" &&
              data[0].phone != null &&
              typeof data[0].phone != null
                ? data[0].phone
                : 1111111111,
          };
        }
        let tdata = await axios({
          method: "post",
          url: loginUlr,
          headers: {
            "Content-Type": "application/json",
            Language: lang == "eng" ? "en" : "ar",
            "x-api-key": config.ticketMax["x-api-key"],
            clientId: config.ticketMax.clientId,
            clientToken: config.ticketMax.clientSecret,
          },
          data: reqData,
        });

        ////console.log("tdata.data",tdata.data)
        if (tdata.data == "Failed") {
          loginUlr = config.ticketMaxApiURL + "/register";

          let splitEmail = data[0].email.split("@");
          tmaxEmail = splitEmail[0] + "-alt" + "-riyadh2021.@" + splitEmail[1];
          tmaxPass = cmethod.makerandomString(6);
          // console.log(data[0]);
          reqData = {
            email: tmaxEmail,
            password: tmaxPass,
            fullname:
              data[0].name && data[0].name != "" ? data[0].name : "User",
            mobile:
              data[0].phone &&
              data[0].phone != "" &&
              data[0].phone != null &&
              typeof data[0].phone != null
                ? data[0].phone
                : 1111111111,
          };
          tdata = await axios({
            method: "post",
            url: loginUlr,
            headers: {
              "Content-Type": "application/json",
              Language: lang == "eng" ? "en" : "ar",
              "x-api-key": config.ticketMax["x-api-key"],
              clientId: config.ticketMax.clientId,
              clientToken: config.ticketMax.clientSecret,
            },
            data: reqData,
          });
          //console.log(tdata);
        }
        //console.log(tdata);
        if (tdata) {
          let updateData = {
            ticketMax: true,
            ticketMaxEmail: tmaxEmail,
            ticketMaxPass: tmaxPass,
            accessToken: tdata.data.accessToken,
            refreshToken: tdata.data.refreshToken,
          };
          let queryCond = { _id: mongoose.Types.ObjectId(postData.userId) };
          uModal.User.findOneAndUpdate(
            queryCond,
            { $set: updateData },
            { new: true },
            async function (err, data) {
              // cmethod.returnSuccess(res, tdata.data);
              await eventModal.BookingLog.create({
                userId: postData.userId,
                eventId: postData.eventId,
                cpasId: postData.cpasId,
                twEventId: postData.tmxEventId,
                twLink: postData.tiketmaxURL,
              });
              res.status(200).json({
                status: true,
                result: tdata.data,
                clientId: config.ticketMax.clientId,
                clientToken: config.ticketMax.clientSecret,
              });
            }
          );
        } else {
          cmethod.returrnErrorMessage(res, message[lang].emailNotExist);
        }
      })
      .catch((err) => {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      });
  }
);

router.post(
  "/validate",
  [midleware.validateFieldValue(["email"], ["email"])],
  async (req, res) => {
    const postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    var regex = new RegExp(["^", postData.email.trim(), "$"].join(""), "i");

    let query = { $and: [{ email: postData.email.trim() }] }; //{ $and: [{ email: regex }] };
    userDao
      .findUser(query)
      .then((resp) => {
        if (resp.length > 0) {
          cmethod.returrnErrorMessage(res, message[lang].emailExist);
        } else {
          cmethod.returnSuccess(res, [], false, message[lang].emailNotExist);
        }
      })
      .catch((err) => {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      });
  }
);

//Checking user verification status
router.post(
  "/getUserDetailsOnVerification",
  [midleware.validateFieldValue(["userId"], ["userId"])],
  async (req, res) => {
    let lang = req.headers["lang"] || config.lang;
    let userId = req.body.userId;
    let user = await uModal.UserRead.findById(
      mongoose.Types.ObjectId(userId)
    ).exec();
    if (user) {
      if (user.userVerify == true) {
        cmethod.returnSuccess(res, user, false, "");
      } else {
        cmethod.returrnErrorMessage(res, message[lang].userVerify);
      }
    } else {
      cmethod.returrnErrorMessage(res, message[lang].userVerify);
    }
  }
);

//gert all message by refernce Type and refenceId

// CHecking user Email verification
router.post(
  "/verify-email",
  [midleware.validateFieldValue(["email", "userId"], ["email", "userId"])],
  async (req, res) => {
    let postData = req.body;
    //console.log(req,"==>",postData);
    let queryCond = {
      $and: [
        { _id: mongoose.Types.ObjectId(postData.userId) },
        { email: postData.email },
        { userType: 2 },
      ],
    };
    let lang = req.headers["lang"] || config.lang;
    uModal.UserRead.findOne(queryCond, async function (err, data) {
      if (err) {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      } else {
        if (data != null) {
          if (data.loginType == 1) {
            const jwttoken = jwt.sign(
              { email: postData.email, deviceId: postData.deviceId },
              config.secret,
              { expiresIn: config.tokenLife }
            );
            uModal.User.findOneAndUpdate(
              queryCond,
              {
                $set: {
                  token: jwttoken,
                  logAtt: 0,
                  userVerify: true,
                },
              },
              { new: true },
              function (err, uptData) {
                if (err) {
                  cmethod.returnSreverError(
                    res,
                    message[lang].technicalError,
                    err
                  );
                } else {
                  if (uptData.status == 1) {
                    cmethod.returnSuccess(
                      res,
                      uptData,
                      false,
                      message[lang].signupsuccess
                    );
                  } else {
                    cmethod.returrnErrorMessage(res, message[lang].blocked);
                  }
                }
              }
            );
          } else {
            cmethod.returrnErrorMessage(res, message[lang].socialUserExist);
          }
        } else {
          cmethod.returrnErrorMessage(res, message[lang].usernotExist);
        }
      }
    });
  }
);

// * register
router.post(
  "/register",
  [midleware.validateFieldValue(config.regReqfields, config.regReqfieldsVal)],
  async (req, res) => {
    const postData = req.body;
    let lang = req.headers["lang"] || config.lang;

    try {
      if ([0, 1, 2].includes(postData.status)) {
        postData.status = Number(postData.status);
      } else if (postData?.forApproval) {
        postData.status = 0;
      } else {
        postData.status = 1;
      }

      postData.email = postData.email.trim().toLowerCase();
      postData.phone = removeSpaces(postData.phone);

      let query;
      postData.userType = Number(postData.userType);

      if ([2, 3, 4, 5].includes(postData.userType)) {
        if (postData.userType == 2 || postData.userType == 3) {
          let uniqueIdentifier = await cmethod.getSellerNo();
          postData.uniqueIdentifier = uniqueIdentifier;
          if (postData?.secondaryPhone) {
            postData.secondaryPhone = postData.secondaryPhone.trim();
          }
        }
        if (postData.userType == 4 || postData.userType == 5) {
          let uniqueIdentifier = await cmethod.getBuyerNo();
          postData.uniqueIdentifier = uniqueIdentifier;
        }
        query = {
          $or: postData?.secondaryPhone
            ? [
                { phone: postData.phone },
                { secondaryPhone: postData.secondaryPhone },
              ]
            : [{ phone: postData.phone }],
        };
      } else {
        query = {
          $and: [{ email: postData.email }, { userType: postData.userType }],
        };
      }

      const checkEmail = await checkUniqueEmail(postData.email);

      if (!checkEmail.status) {
        return cmethod.returrnErrorMessage(res, checkEmail.message);
      }

      const userCheckResult = await checkUserWithPhoneAndRole(
        postData.phone,
        postData.userType
      );

      if (!userCheckResult.status) {
        return cmethod.returrnErrorMessage(res, userCheckResult.message);
      }

      userDao.userRegiter(res, postData, lang);
    } catch (error) {
      logger.error(error.message);
      cmethod.returnSreverError(
        res,
        message[lang].technicalError,
        error.message
      );
    }
  }
);

router.post("/checkmobile", async (req, res) => {
  const postData = req.body;
  // console.log("postData==>", postData);
  let lang = req.headers["lang"] || config.lang;
  let phonequery = {
    $and: [{ phone: postData.phone }],
  };
  userDao.checkmobile(phonequery).then(function (doc) {
    if (doc == "exist") {
      /* userDao.findUser(query)
           .then(async (result) => {
             if (result == null || result.length == 0) {             
             } else {
               cmethod.returrnErrorMessage(res, message[lang].userexist);
             }
           })
           .catch((err) => {
             cmethod.returnSreverError(res, message[lang].phoneVerify);
           });*/
      cmethod.returnSreverError(res, message[lang].phoneExit);
    } else {
      cmethod.returnSreverError(res, message[lang].phoneVerify);
    }
  });
});
router.post("/verifyotp", async (req, res) => {
  const postData = req.body;
  // console.log("postData==>", postData);
  let lang = req.headers["lang"] || config.lang;
  let phonequery = {
    $and: [{ phone: postData.phone }],
  };
  let verifyotp = postData.otp;
  userDao.checkmobile(phonequery).then(function (doc) {
    //phoneSchema
    if (doc == "exist") {
      var otp = 1234;
      if (1234 == otp) {
        cmethod.returnSuccess(res, message[lang].otpverify);
      }
    } else {
      cmethod.returnSreverError(res, message[lang].notpverify);
    }
  });
});
router.post(
  "/importUser",
  [midleware.validateFieldValue(config.regReqfields, config.regReqfieldsVal)],
  async (req, res) => {
    const postData = req.body;
    // console.log("postData==>", postData);
    let lang = req.headers["lang"] || config.lang;
    postData.status = 1;
    postData.email = postData.email.trim().toLowerCase();
    postData.phone = postData.phone.trim();

    if ([2, 3, 4, 5].includes(postData.userType)) {
      let queryUnique = {
        // $and: [{ userType: postData.userType }],
        userType: { $in: [2, 3, 4, 5] },
      };
      let uniqueIdentifier = 0;
      const userData = await uModal.User.findOne(queryUnique, {
        uniqueIdentifier: 1,
      }).sort({ createdAt: -1 });

      if (userData) {
        if (userData.uniqueIdentifier == 0) {
          uniqueIdentifier = 100101;
        } else {
          uniqueIdentifier = userData.uniqueIdentifier + 1;
        }
        postData.uniqueIdentifier = uniqueIdentifier;
      }
      // if([2,3].includes(postData.userType)){
      //   if(userData.uniqueIdentifier==0){
      //     uniqueIdentifier=100101;
      //   } else {
      //     uniqueIdentifier=userData.uniqueIdentifier+1;
      //   }
      // } else if([3,4].includes(postData.userType)){
      //   if(userData.uniqueIdentifier==0){
      //     uniqueIdentifier=100101;
      //   } else {
      //     uniqueIdentifier=userData.uniqueIdentifier+1;
      //   }
      // }
    }

    let query = {
      $and: [{ email: postData.email }, { userType: postData.userType }],
    };
    // { phone: postData.phone }
    // query = {
    //   $and: [{ userType: postData.userType }],
    // };

    // query = {
    //   $and: [{ email: postData.email }, { userType: postData.userType }],
    // };

    // if (!postData.zoneId) {
    //   postData.zoneId = mongoose.Types.ObjectId();
    // }

    // if (postData.loginType == 1) {
    //   if (postData.userType == 3) {
    //     query = {
    //       $and: [
    //         { deviceId: postData.deviceId },
    //         { userType: postData.userType },
    //       ],
    //     };
    //   } else {
    //     query = {
    //       $and: [{ email: postData.email }, { userType: postData.userType }],
    //     };
    //   }
    // } else {
    //   query = {
    //     $and: [

    //       { userType: postData.userType },
    //     ],
    //   };
    // }

    userDao
      .findUser(query)
      .then(async (result) => {
        if (result == null || result.length == 0) {
          userDao.userImport(res, postData, lang);
        } else {
          cmethod.returrnErrorMessage(res, message[lang].userexist);
        }
      })
      .catch((err) => {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      });
  }
);
router.post(
  "/reg-admin",
  [midleware.validateFieldValue(config.regReqfields, config.regReqfieldsVal)],
  async (req, res) => {
    const postData = req.body;
    //console.log("postData==>", postData);
    let lang = req.headers["lang"] || config.lang;
    postData.status = 1;
    postData.userType = Number(postData.userType);

    if (postData.fcmToken != "") {
      await uModal.User.updateMany(
        { fcmToken: postData.fcmToken },
        { $set: { fcmToken: "" } }
      );
    }
    //// 1 - Email/Phone Login 2- Google Login 3-  Apple login
    postData.email = postData.email.trim().toLowerCase();
    let query = {
      $and: [{ email: postData.email }],
    };

    userDao
      .findUser(query)
      .then(async (result) => {
        if (result == null || result.length == 0) {
          userDao.userRegiter(res, postData, lang);
        } else {
          cmethod.returrnErrorMessage(res, message[lang].emailidexist);
        }
      })
      .catch((err) => {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      });
  }
);
router.post(
  "/reg-admin1",
  [midleware.validateFieldValue(config.regReqfields, config.regReqfieldsVal)],
  async (req, res) => {
    const postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    postData.status = 1;

    await uModal.User.updateMany(
      { fcmToken: postData.fcmToken },
      { $set: { fcmToken: "" } }
    );
    if (postData.userType == 4) {
      let scode = await uModal.ConstantRead.find({});
      let newCode = scode.length > 0 ? scode[0].sCode + 1 : 10001;
      postData.serialNumber = newCode;
      await uModal.Constant.findOneAndUpdate(
        {
          sCode: scode.length > 0 ? scode[0].sCode : 0,
        },
        { $set: { sCode: newCode } },
        { upsert: true }
      );
    }
    //// 1 - Email/Phone Login 2- Google Login 3-  Apple login
    postData.email = postData.email.trim().toLowerCase();
    let query = {
      $and: [{ email: postData.email }, { userType: postData.userType }],
    };

    if (!postData.zoneId) {
      postData.zoneId = mongoose.Types.ObjectId();
    }

    if (postData.loginType == 1) {
      if (postData.userType == 3) {
        query = {
          $and: [
            { deviceId: postData.deviceId },
            { userType: postData.userType },
          ],
        };
      } else {
        query = {
          $and: [{ email: postData.email }, { userType: postData.userType }],
        };
      }
    } else {
      query = {
        $and: [
          { socialId: postData.socialId },
          { userType: postData.userType },
        ],
      };
    }

    userDao
      .findUser(query)
      .then(async (result) => {
        if (result == null || result.length == 0) {
          if (postData.userType == 4 || postData.userType == 5) {
            var emailData = {
              to: postData.email,
              from: "info@riyadhseason.com",
              subject:
                lang == "eng"
                  ? "Welcome to Jeddah Season"
                  : "مرحبًا بكم في موسم الرياض",
              body:
                lang == "eng"
                  ? "Glad to see you here!  Discover our best events and get your tickets immediately!<br><br>Credentials:<br><br>Username:" +
                    postData.email +
                    "<br>Password:" +
                    postData.password
                  : "سعيد لرؤيتك هنا! اكتشف أفضل الأحداث لدينا واحصل على التذاكر الخاصة بك على الفور!<br><br>Credentials:<br><br>Username:" +
                    postData.email +
                    "<br>Password:" +
                    postData.password,
            };
            //Send Email
            sendEmail(emailData);
          }
          // await deleteHash(req);
          console.log(postData);
          userDao.userRegiter(res, postData, lang);
          console.log("washi");
        } else {
          if (postData.loginType != 1) {
            // await deleteHash(req);
            cmethod.returnSuccess(
              res,
              result,
              false,
              message[lang].signupsuccess
            );
          } else if (postData.loginType == 1 && postData.userType == 3) {
            const jwttoken = jwt.sign(
              { email: postData.email, deviceId: postData.deviceId },
              config.secret,
              { expiresIn: config.tokenLife }
            );

            uModal.User.findOneAndUpdate(
              query,
              {
                $set: {
                  fcmToken: postData.fcmToken,
                  token: jwttoken,
                },
              },
              { new: true },
              async function (err, uptData) {
                if (err) {
                  cmethod.returnSreverError(
                    res,
                    message[lang].technicalError,
                    err
                  );
                } else {
                  // await deleteHash(req);
                  cmethod.returnSuccess(
                    res,
                    uptData,
                    false,
                    message[lang].loginSucess
                  );
                }
              }
            );
          } else {
            cmethod.returrnErrorMessage(res, message[lang].userexist);
          }
        }
      })
      .catch((err) => {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      });
  }
);

// Social User Login/ Registartion  Router
router.post(
  "/social-login",
  [
    midleware.validateFieldValue(
      config.socialReqfields,
      config.socialReqfieldsVal
    ),
  ],
  async (req, res) => {
    const postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    postData.status = 1;
    await uModal.User.updateMany(
      { fcmToken: postData.fcmToken },
      { $set: { fcmToken: "" } }
    );
    //// 1 - Email/Phone Login 2- Google Login 3-  Apple login
    let query = {
      $and: [
        { socialId: postData.socialId },
        { userType: 2 },
        { loginType: postData.loginType },
      ],
    };

    userDao
      .findUser(query)
      .then((result) => {
        if (result == null || result.length == 0) {
          if (postData.phone != result.phone) {
            userDao.userRegiter(res, postData, lang);
          } else {
            cmethod.returrnErrorMessage(res, message[lang].phoneExit);
          }
        } else {
          const jwttoken = jwt.sign(
            { email: postData.email, deviceId: postData.deviceId },
            config.secret,
            { expiresIn: config.tokenLife }
          );
          //console.log(result);
          uModal.User.findOneAndUpdate(
            query,
            {
              $set: {
                fcmToken: postData.fcmToken,
                deviceId: postData.deviceId,
                token: jwttoken,
                phone: postData.phone ? postData.phone : result[0].phone,
                cCode: postData.cCode ? postData.cCode : result[0].cCode,
                name: postData.name ? postData.gender : result[0].name,
                age: postData.age ? postData.age : result[0].age,
                email: postData.email ? postData.email : result[0].email,
                areasInterest:
                  result[0].areasInterest.length > 0
                    ? result[0].areasInterest
                    : postData.areasInterest
                    ? postData.areasInterest
                    : [],
              },
            },
            { new: true },
            function (err, uptData) {
              if (err) {
                cmethod.returnSreverError(
                  res,
                  message[lang].technicalError,
                  err
                );
              } else {
                if (uptData.status == 1) {
                  cmethod.returnSuccess(
                    res,
                    uptData,
                    false,
                    message[lang].loginSucess
                  );
                } else {
                  cmethod.returrnErrorMessage(res, message[lang].blocked);
                }
              }
            }
          );

          /* cmethod.returnSuccess(
            res,
            result,
            false,
            message[lang].signupsuccess
          );*/
        }
      })
      .catch((err) => {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      });
  }
);

// * login
router.post(
  "/login",
  [
    midleware.validateFieldValue(
      config.signinReqfields,
      config.signinReqfieldsVal
    ),
  ],
  async (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    const { email, phone, role, password, loginType } = postData;

    if (loginType === config.platform.WEB) {
      // * restrict buyer login on prod
      if (config.isProd()) {
        if (role === "buyer") {
          return cmethod.returrnErrorMessage(
            res,
            "Buyer access is currently undergoing optimization. Please check back soon!"
          );
        }
      }

      // * password validation
      const checkPassword = await matchPassword(email, phone, role, password);
      if (!checkPassword.status) {
        return cmethod.returrnErrorMessage(res, checkPassword.message);
      }

      // * email verification
      const checkVerified = await checkUserVerification(email, phone, role);
      if (!checkVerified.status) {
        return res.status(200).json({
          status: false,
          step: checkVerified.step,
          message: checkVerified.message,
          user: checkVerified.user,
        });
      }

      // * profile completed verification
      const profileCompleted = await checkUserProfileCompletion(
        email,
        phone,
        role
      );
      if (!profileCompleted.status) {
        return res.status(200).json({
          status: false,
          step: profileCompleted.step,
          message: profileCompleted.message,
          user: profileCompleted.user,
        });
      }
    }

    const queryCond = {};

    if (email) {
      queryCond.email = email;
    }

    if (phone && role) {
      const userType = config.userTypeStatus[role];

      queryCond.$and = [{ phone }, { userType: { $in: userType } }];
    }

    if (postData.email == "test@test.com") {
      cmethod.returrnErrorMessage(res, message[lang].usernotExist);
    } else {
      uModal.UserRead.findOne(queryCond, async function (err, data) {
        if (err) {
          cmethod.returnSreverError(res, message[lang].technicalError, err);
        } else {
          if (data != null) {
            if (data.validPassword(postData.password)) {
              jwttoken = jwt.sign(
                {
                  $or: [
                    { email: postData.email, deviceId: postData.deviceId },
                    { phone: postData.email, deviceId: postData.deviceId },
                  ],
                },
                config.secret,
                { expiresIn: config.tokenLife }
              );
              uModal.User.findOneAndUpdate(
                queryCond,
                { $set: { deviceId: postData.deviceId, token: jwttoken } },
                { new: true },
                async function (err, uptData) {
                  if (err) {
                    cmethod.returnSreverError(
                      res,
                      message[lang].technicalError,
                      err
                    );
                  } else {
                    if (uptData.status == 1) {
                      if (uptData?.roleId != null) {
                        const userRoleData = await masterModal.Userrole.findOne(
                          { _id: mongoose.Types.ObjectId(uptData.roleId) },
                          { userRole: 1 }
                        ).sort({ createdAt: -1 });
                        const userBranch =
                          await masterModal.Branchusermapping.find(
                            { userId: mongoose.Types.ObjectId(uptData._id) },
                            {
                              branchId: 1,
                              warehosId: 1,
                            }
                          ).sort({ createdAt: -1 });
                        if (userRoleData) {
                          uptData = JSON.parse(JSON.stringify(uptData));
                          uptData["roleName"] = userRoleData.userRole;
                          uptData["branchIds"] = userBranch;
                        }
                      }
                      if (
                        ([2, 3, 4, 5].includes(Number(data?.userType)) &&
                          postData.loginType == "web") ||
                        (![2, 3, 4, 5].includes(Number(data?.userType)) &&
                          postData.loginType == "admin")
                      ) {
                        cmethod.returnSuccess(
                          res,
                          uptData,
                          false,
                          message[lang].loginSucess
                        );
                      } else {
                        cmethod.returrnErrorMessage(
                          res,
                          message[lang].unathorized
                        );
                      }
                    } else if (uptData.status === 3) {
                      cmethod.returrnErrorMessage(res, message[lang].suspended);
                    } else {
                      cmethod.returrnErrorMessage(res, message[lang].blocked);
                    }
                  }
                }
              );
            } else {
              await uModal.User.findOneAndUpdate(queryCond, {
                $set: {
                  logAtt: parseInt(data.logAtt) + 1,
                },
              });

              cmethod.returrnErrorMessage(res, message[lang].usernameExist);
            }
          } else {
            cmethod.returrnErrorMessage(res, message[lang].usernotExist);
          }
        }
      });
    }
  }
);

// * update
router.patch(
  "/update",
  [midleware.validateFieldValue(["userId"], ["userId"])],
  async (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;

    const checkUniqueUser = await checkEmailOrPhoneValidation(postData);

    if (!checkUniqueUser?.status) {
      return cmethod.returrnErrorMessage(res, checkUniqueUser.errors);
    }

    let queryCond = {
      $and: [{ _id: mongoose.Types.ObjectId(postData.userId) }],
    };
    delete postData.userId;
    //console.log("=======================>",req.body)
    uModal.User.findOneAndUpdate(
      queryCond,
      { $set: postData },
      { new: true },
      async function (err, data) {
        if (err) {
          cmethod.returnSreverError(res, message[lang].technicalError, err);
        } else {
          if (data?.trnCertificate) {
            let trnCertificateImage = {
              imageType: "saller",
              referenceId: mongoose.Types.ObjectId(data._id),
              image: data?.trnCertificate,
              type: "trn",
            };
            await vinModal.Vinimage.insertMany(trnCertificateImage);
          }
          if (data?.tradeLicense) {
            let tradeLicenseImage = {
              imageType: "saller",
              referenceId: mongoose.Types.ObjectId(data._id),
              image: data?.tradeLicense,
              type: "trade",
            };
            await vinModal.Vinimage.insertMany(tradeLicenseImage);
          }
          if (data?.eidCertificate) {
            let eidCertificateImage = {
              imageType: "saller",
              referenceId: mongoose.Types.ObjectId(data._id),
              image: data?.eidCertificate,
              type: "eid",
            };
            await vinModal.Vinimage.insertMany(eidCertificateImage);
          }
          if (data?.commercialAgreement) {
            const commercialAgreement = {
              imageType: "saller",
              referenceId: mongoose.Types.ObjectId(data._id),
              image: data?.commercialAgreement,
              type: "agreement",
            };
            await vinModal.Vinimage.insertMany(commercialAgreement);
          }

          await masterModal.Branchusermapping.deleteMany({
            userId: mongoose.Types.ObjectId(data?._id),
          });
          let userBranchMapp = [];
          if (postData?.branchIds?.length > 0) {
            let allBranch = postData?.branchIds;
            for (var i = 0; i < allBranch.length; i++) {
              userBranchMapp.push({
                userId: mongoose.Types.ObjectId(data?._id),
                branchId: mongoose.Types.ObjectId(allBranch[i]),
              });
            }
          }
          if (postData?.warehosId) {
            userBranchMapp.push({
              userId: mongoose.Types.ObjectId(data?._id),
              warehosId: mongoose.Types.ObjectId(postData?.warehosId),
            });
          }
          if (userBranchMapp.length > 0) {
            masterModal.Branchusermapping.insertMany(userBranchMapp);
          }
          //------------------comments log for add seller------------------//
          if (data?.status == 2) {
            let updatesellerCommentLog = {
              referenceType: "seller",
              referenceId: mongoose.Types.ObjectId(data?._id),
              message:
                postData?.rejectedRemarks +
                " seller rejected by " +
                postData?.commentBy,
              commentBy: postData?.commentBy,
            };
            cmethod.addcommentsLog(updatesellerCommentLog);
          } else if (data?.status == 1) {
            let updatesellerCommentLog = {
              referenceType: "seller",
              referenceId: mongoose.Types.ObjectId(data?._id),
              message:
                "Due to " +
                postData?.rejectedRemarks +
                " seller approved by " +
                postData?.commentBy,
              commentBy: postData?.commentBy,
            };
            cmethod.addcommentsLog(updatesellerCommentLog);
          } else if (data?.status == 0) {
            let updatesellerCommentLog = {
              referenceType: "seller",
              referenceId: mongoose.Types.ObjectId(data?._id),
              message: " re-apply by " + postData?.commentBy,
              commentBy: postData?.commentBy,
            };
            cmethod.addcommentsLog(updatesellerCommentLog);
          }

          //add sap data here
          if (
            (!data?.sapId || data?.sapId == "") &&
            data.status == 1 &&
            [2, 3, 4, 5].includes(data?.userType)
          ) {
            // await sapbusinessPartener(data?._id);
          }
          cmethod.returnSuccess(res, data, false, message[lang].profileUpdate);
        }
      }
    );
  }
);

router.post(
  "/list121",
  [midleware.validateFieldValue(["pageLimit", "page"], ["page"])],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let query = [];

    query.push({
      $project: {
        _id: 1,
        branchId: 1,
        roleId: 1,
        accessToken: 1,
        uniqueIdentifier: 1,
        createdAt: 1,
        deviceId: 1,
        deviceType: 1,
        email: 1,
        loginStatus: 1,
        name: 1,
        password: 1,
        phone: 1,
        eid: 1,
        businessType: 1,
        address: 1,
        companyDetails: 1,
        refreshToken: 1,
        token: 1,
        updatedAt: 1,
        userType: 1,
        verifyStatus: 1,
        status: 1,
        eidExpiry: 1,
        tradeLicenceNo: 1,
        tlExpiry: 1,
        trnCertificate: 1,
        eidCertificate: 1,
        tradeLicense: 1,
        createdAt: 1,
      },
    });
    const sQuery = [...query];
    query.push({ $sort: { createdAt: -1 } });
    sQuery.push({ $count: "recordCount" });

    if (postData.page) {
      query.push({
        $skip: cmethod.pageOffset(postData.page, postData.pageLimit),
      });
      query.push({ $limit: cmethod.pageLimit(postData.pageLimit) });
    }

    userDao
      .findUserAggregation(query)
      .then(function (data) {
        userDao
          .findUserAggregation(sQuery)
          .then(async function (dcount) {
            let tptCnt = 0;
            if (dcount.length > 0) {
              tptCnt = dcount[0].recordCount;
            }
            res.status(200).json({
              status: true,
              result: data,
              message: "",
              hasMore: cmethod.hasMoreCount(
                tptCnt,
                postData.page,
                postData.pageLimit
              ),
              totalCount: tptCnt,
            });
          })
          .catch((err) => {
            cmethod.returnSreverError(res, message[lang].technicalError, err);
          });
      })
      .catch((err) => {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      });
  }
);

// * list
router.post("/list", (req, res) => {
  let postData = req.body;
  let lang = req.headers["lang"] || config.lang;
  let query = [];

  if (postData.userType) {
    postData.userType = Number(postData.userType);
  }

  if (
    postData.searchUserType == "seller" ||
    postData.searchUserType == "buyer" ||
    postData.searchUserType == "admin"
  ) {
    if (postData.fromDate && postData.toDate) {
      query.push({
        $match: {
          $and: [
            {
              createdAt: {
                $gte: new Date(
                  cmethod.startTimeString(new Date(postData.fromDate))
                ),
              },
            },
            {
              createdAt: {
                $lte: new Date(
                  cmethod.endTimeString(new Date(postData.toDate))
                ),
              },
            },
          ],
        },
      });
    }
    if (postData.addedFrom) {
      query.push({
        $match: {
          $and: [{ addedFrom: postData.addedFrom }],
        },
      });
    }
  }

  if (postData.searchUserType == "seller") {
    var today = new Date();
    var _month = today.getMonth();
    var _year = today.getFullYear();
    var _day1 = today.getDate();
    var __month1 = _month + 1;    
    var _toDate = _year + "-" + __month1 + "-" + _day1;
    var tdate = new Date(_toDate);
    tdate.setDate(tdate.getDate());
    tdate.setUTCHours(23, 59, 59, 0);   
    if (postData.eidExpiredStatus == "valid") {
      query.push({
        $match: {
          $and: [{ eidExpiry: { $gte: tdate } }],
        },
      });
    } else if (postData.eidExpiredStatus == "invalid") {
      query.push({
        $match: {
          $and: [{ eidExpiry: { $lte: tdate } }],
        },
      });
    }

    if (postData.status || postData.status == 0) {
      query.push({
        $match: {
          $and: [{ status: postData.status }],
        },
      });
    }

    if ([2, 3].includes(postData.userType)) {
      query.push({
        $match: {
          $and: [{ userType: postData.userType }],
        },
      });
    } else {
      query.push({
        $match: {
          $and: [{ userType: { $in: [2, 3] } }],
        },
      });
    }
  } else if (postData.searchUserType == "buyer") {
    if (postData.status || postData.status == 0) {
      query.push({
        $match: {
          $and: [{ status: postData.status }],
        },
      });
    }

    if ([4, 5].includes(postData.userType)) {
      query.push({
        $match: {
          $and: [{ userType: postData.userType }],
        },
      });
    } else {
      query.push({
        $match: {
          $and: [{ userType: { $in: [4, 5] } }],
        },
      });
    }
  } else if (postData.searchUserType == "admin") {
    // * userroles
    query.push({
      $lookup: {
        from: "userroles",
        localField: "roleId",
        foreignField: "_id",
        as: "userroles",
      },
    });
    query.push({
      $unwind: { path: "$userroles", preserveNullAndEmptyArrays: true },
    });

    // * branchusermappings
    query.push({
      $lookup: {
        from: "branchusermappings",
        localField: "_id",
        foreignField: "userId",
        as: "branchusermappings",
      },
    });

    // * branchs
    query.push({
      $lookup: {
        from: "branchs",
        localField: "branchusermappings.branchId",
        foreignField: "_id",
        as: "branchs",
      },
    });

    // * warehouses
    query.push({
      $lookup: {
        from: "warehouses",
        localField: "warehosIds",
        foreignField: "_id",
        as: "warehouses",
      },
    });

    // * match
    query.push({
      $match: {
        $and: [{ userType: { $nin: [2, 3, 4, 5] } }],
      },
    });

    if (postData.status) {
      query.push({
        $match: {
          $and: [{ status: Number(postData.status) }],
        },
      });
    }
    if (postData.roleName) {
      query.push({
        $match: {
          $and: [{ "userroles.userRole": postData.roleName }],
        },
      });
    }
  } else {
    if (postData.roleId) {
      query.push({
        $match: {
          $and: [{ roleId: mongoose.Types.ObjectId(postData.roleId) }],
        },
      });
    }
  }

  if (postData.uniqueIdentifier) {
    query.push({
      $match: {
        $and: [{ uniqueIdentifier: postData.uniqueIdentifier }],
      },
    });
  }

  if (postData.branchId) {
    query.push({
      $match: {
        $and: [{ branchId: mongoose.Types.ObjectId(postData.branchId) }],
      },
    });
  } else if (postData.roleId) {
    query.push({
      $match: {
        $and: [{ roleId: mongoose.Types.ObjectId(postData.roleId) }],
      },
    });
  } else if (postData.userId) {
    query.push({
      $match: {
        $and: [{ _id: mongoose.Types.ObjectId(postData.userId) }],
      },
    });
  } else if (postData.search) {
    query.push({
      $match: {
        $and: [
          {
            $or: [
              { email: { $regex: postData.search, $options: "i" } },
              { name: { $regex: postData.search, $options: "i" } },
              { phone: { $regex: postData.search, $options: "i" } },
              { eid: { $regex: postData.search, $options: "i" } },
              {
                "companyDetails.primaryName": {
                  $regex: postData.search,
                  $options: "i",
                },
              },
            ],
          },
        ],
      },
    });
  }

  const sQuery = [...query];

  if (isArrayWithLength(postData.searchUserTypes)) {
    const userStatus = postData.searchUserTypes.flatMap(
      (userType) => config.userTypeStatus[userType]
    );

    query.push({
      $match: {
        $and: [{ userType: { $in: userStatus } }],
      },
    });
  }

  query.push({
    $project: {
      _id: 1,
      branchId: "$branchs._id",
      branchs: 1,
      warehosId: "$warehouses._id",
      warehosIds: 1,
      warehouses: 1,
      userroles: 1,
      accessToken: 1,
      uniqueIdentifier: 1,
      createdAt: 1,
      deviceId: 1,
      deviceType: 1,
      addedFrom: 1,
      email: 1,
      loginStatus: 1,
      name: 1,
      password: 1,
      phone: 1,
      eid: 1,
      businessType: 1,
      address: 1,
      companyDetails: 1,
      refreshToken: 1,
      token: 1,
      updatedAt: 1,
      userType: 1,
      verifyStatus: 1,
      status: 1,
      eidExpiry: 1,
      tradeLicenceNo: 1,
      tlExpiry: 1,
      trnCertificate: 1,
      eidCertificate: 1,
      tradeLicense: 1,
      qwaitingDepart: 1,
      qwaitingMappCounterId: 1,
      createdAt: 1,
      countryCode: 1,
      countryIso: 1,
      createdBy: 1,
      planId: 1,
      roleId: 1,
      sellerNo: 1,
      buyerNo: 1,
      sapId: 1,
      creditLimit: 1,
      depositAmt: 1,
      unpaidAmt: 1,
      overdueAmt: 1,
      curBalance: 1,
      walletAmount: 1,
      secondaryPhone: 1,
      secondaryCountryCode: 1,
      secondaryCountryIso: 1,
      commercialAgreement: 1,
      isEmailVerified: 1,
      isPhoneVerified: 1,
      isVerificationCompleted: 1,
      isProfileCompleted: 1,
      bank: 1,
      isApproved: {
        $cond: {
          if: { $eq: ["$status", 1] },
          then: true,
          else: false,
        },
      },
      // planId: "$sellerplans._id",
      // planName: "$sellerplans.planName"
    },
  });

  query.push({ $sort: { createdAt: -1 } });
  sQuery.push({ $count: "recordCount" });

  if (postData.page) {
    query.push({
      $skip: cmethod.pageOffset(postData.page, postData.pageLimit),
    });
    query.push({ $limit: cmethod.pageLimit(postData.pageLimit) });
  }

  userDao
    .findUserAggregation(query)
    .then(async function (data) {
      try {
        const dCount = await userDao.findUserAggregation(sQuery);
        let tptCnt = 0;
        if (dCount.length > 0) {
          tptCnt = dCount[0].recordCount;
        }

        res.status(200).json({
          status: true,
          result: data,
          message: "",
          hasMore: cmethod.hasMoreCount(
            tptCnt,
            postData.page,
            postData.pageLimit
          ),
          totalCount: tptCnt,
        });
      } catch (err) {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      }
    })
    .catch((err) => {
      cmethod.returnSreverError(res, message[lang].technicalError, err);
    });
});

//qwaiting user access

router.post(
  "/qwaitingUserAccesslist",
  // RedisMiddleware.getDataFromRedis,
  [
    midleware.validateFieldValue(
      ////userId","searchUserType", ,"userType", "search"
      ["pageLimit", "page"],
      ["page", "pageLimit"]
    ),
  ],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;

    let query = [];
    query.push({
      $lookup: {
        from: "departcountermapps",
        localField: "qwaitingMappCounterId",
        foreignField: "_id",
        as: "departcountermapps",
      },
    });
    query.push({
      $unwind: {
        path: "$departcountermapps",
        preserveNullAndEmptyArrays: true,
      },
    });
    query.push({
      $lookup: {
        from: "counters",
        localField: "departcountermapps.counterId",
        foreignField: "_id",
        as: "counters",
      },
    });
    query.push({
      $unwind: { path: "$counters", preserveNullAndEmptyArrays: true },
    });
    query.push({
      $lookup: {
        from: "departments",
        localField: "qwaitingDepart",
        foreignField: "_id",
        as: "departments",
      },
    });
    query.push({
      $unwind: { path: "$departments", preserveNullAndEmptyArrays: true },
    });
    query.push({
      $lookup: {
        from: "userroles",
        localField: "roleId",
        foreignField: "_id",
        as: "userroles",
      },
    });
    query.push({
      $unwind: { path: "$userroles", preserveNullAndEmptyArrays: true },
    });
    query.push({
      $match: {
        $and: [{ qwaitingMappCounterId: { $ne: null } }],
      },
    });
    query.push({
      $match: {
        $and: [{ "userroles.userRole": "qwaiting" }],
      },
    });

    const sQuery = [...query];

    // Join with zone

    query.push({
      $project: {
        _id: 1,
        name: 1,
        phone: 1,
        email: 1,
        counter: 1,
        department: "$departments.department",
        counter: "$counters.counterName",
        createdAt: 1,
      },
    });

    // Set the order of the query result
    query.push({ $sort: { createdAt: -1 } });
    // Clone to query before preparing to pagination
    sQuery.push({ $count: "recordCount" });
    // set Pagination if required
    if (postData.page) {
      query.push({
        $skip: cmethod.pageOffset(postData.page, postData.pageLimit),
      });
      query.push({ $limit: cmethod.pageLimit(postData.pageLimit) });
    }
    userDao
      .findUserAggregation(query)
      .then(function (data) {
        userDao
          .findUserAggregation(sQuery)
          .then(async function (dCount) {
            let tptCnt = 0;
            if (dCount.length > 0) {
              tptCnt = dCount[0].recordCount;
            }
            res.status(200).json({
              status: true,
              result: data,
              message: "",
              hasMore: cmethod.hasMoreCount(
                tptCnt,
                postData.page,
                postData.pageLimit
              ),
              totalCount: tptCnt,
              //pkey:privateKey
            });
          })
          .catch((err) => {
            cmethod.returnSreverError(res, message[lang].technicalError, err);
          });
      })
      .catch((err) => {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      });
  }
);
// User Logout
router.patch(
  "/logout",
  [midleware.validateFieldValue(["userId"], ["userId"])],
  (req, res) => {
    let postData = req.body;
    let queryCond = { _id: mongoose.Types.ObjectId(postData.userId) };
    let lang = req.headers["lang"] || config.lang;

    uModal.User.findOneAndUpdate(
      queryCond,
      { $set: { token: "" } },
      { new: true },
      function (err, data) {
        if (err) {
          cmethod.returnSreverError(res, message[lang].technicalError, err);
        } else {
          cmethod.returnSuccess(res, data, false, message[lang].logout);
        }
      }
    );
  }
);

router.patch(
  "/change-password",
  [
    midleware.validateFieldValue(
      ["userId", "oldPass", "newPass"],
      ["userId", "oldPass", "newPass"]
    ),
  ],
  async (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;

    const userData = await uModal.UserRead.findOne({
      $and: [{ _id: mongoose.Types.ObjectId(postData.userId) }],
    });
    if (userData) {
      // let passFlag = await userData.validPassword(postData.oldPass);
      // console.log(userData.password + "==" + oldhash);
      if (postData.source == "external") {
        let expireTime = userData.resetSession;
        let currentTime = new Date().getTime();
        let differenceTime = Math.floor((currentTime - expireTime) / 1000);
        if (differenceTime > 900) {
          cmethod.returrnErrorMessage(res, message[lang].resetPassTimeErr);
        } else {
          let myquery = { _id: userData._id };
          let hash = await uModal.hashPassword(postData.newPass);
          let newvalues = { $set: { password: hash } };
          uModal.User.updateOne(myquery, newvalues, async function (err, data) {
            if (err) {
              cmethod.returnSreverError(res, message[lang].technicalError, err);
            } else {
              // await deleteHash(req);
              cmethod.returnSuccess(
                res,
                [],
                false,
                message[lang].changePassword
              );
            }
          });
        }
      } else if (userData.validPassword(postData.oldPass)) {
        let myquery = { _id: userData._id };
        let hash = await uModal.hashPassword(postData.newPass);
        let newvalues = { $set: { password: hash } };
        uModal.User.updateOne(myquery, newvalues, async function (err, data) {
          if (err) {
            cmethod.returnSreverError(res, message[lang].technicalError, err);
          } else {
            // await deleteHash(req);
            cmethod.returnSuccess(res, [], false, message[lang].changePassword);
          }
        });
      } else {
        cmethod.returrnErrorMessage(res, message[lang].passNotMatch);
      }
    } else {
      cmethod.returrnErrorMessage(res, message[lang].userexist);
    }
  }
);
router.patch(
  "/changePasswordByAdmin",
  [midleware.validateFieldValue(["userId", "newPass"], ["userId", "newPass"])],
  async (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;

    const userData = await uModal.UserRead.findOne({
      $and: [{ _id: mongoose.Types.ObjectId(postData.userId) }],
    });
    if (userData) {
      let myquery = { _id: userData._id };
      let hash = await uModal.hashPassword(postData.newPass);
      let newvalues = { $set: { password: hash } };
      uModal.User.updateOne(myquery, newvalues, async function (err, data) {
        if (err) {
          cmethod.returnSreverError(res, message[lang].technicalError, err);
        } else {
          cmethod.returnSuccess(res, [], false, message[lang].changePassword);
        }
      });
    } else {
      cmethod.returrnErrorMessage(res, message[lang].userexist);
    }
  }
);
router.delete("/remove/:id", (req, res) => {
  let userId = req.params.id;
  let lang = req.headers["lang"] || config.lang;

  if (!("id" in req.params) || req.params.id == "") {
    cmethod.returnSreverError(res, message[lang].userIdReqired, err);
  }

  let queryCond = { _id: mongoose.Types.ObjectId(userId) };
  uModal.User.deleteOne(queryCond, async function (err, data) {
    if (err) {
      cmethod.returnSreverError(res, message[lang].technicalError, err);
    } else {
      // await deleteHash(req);
      cmethod.returnSuccess(res, [], false, message[lang].delUser);
    }
  });
});

// Create contact
router.post(
  "/contact",
  [
    midleware.validateFieldValue(
      ["userId", "email", "title", "message"],
      ["userId", "email", "title", "message"]
    ),
  ],
  (req, res) => {
    let lang = req.headers["lang"] || config.lang;
    let postData = req.body;
    if (lang == "ara") {
      postData.titleAra = postData.title;
      postData.messageAra = postData.message;
      delete postData.title;
      delete postData.message;
    }
    userDao.saveContact(res, postData);
  }
);

// send Verification Code

router.post(
  "/reqVerify",
  [midleware.validateFieldValue(["cCode", "phone"], ["cCode", "phone"])],
  (req, res) => {
    let lang = req.headers["lang"] || config.lang;
    let postData = req.body;
    userDao.saveVrificationCode(res, postData);
  }
);

router.post(
  "/phoneVerify",
  [
    midleware.validateFieldValue(
      ["cCode", "phone", "vCode"],
      ["cCode", "phone", "vCode"]
    ),
  ],
  (req, res) => {
    let lang = req.headers["lang"] || config.lang;
    let postData = req.body;
    postData.phone = parseInt(postData.phone);
    postData.vCode = parseInt(postData.vCode);
    let query = {
      $and: [
        { cCode: postData.cCode },
        { phoneNumber: postData.phone },
        { vCode: postData.vCode },
      ],
    };
    userDao
      .findPhone(query)
      .then((data) => {
        // console.log(data);
        if (data.length == 0) {
          cmethod.returrnErrorMessage(res, message[lang].notVerify);
        } else {
          userDao
            .deletePhone(query)
            .then((succ) => {
              uModal.User.updateMany(
                { phone: parseInt(postData.phone) },
                { $set: { verifyStatus: 1 } },
                function (err, data) {
                  //console.log(err, data);
                  cmethod.returnSuccess(
                    res,
                    [],
                    false,
                    message[lang].phoneVerify
                  );
                }
              );
            })
            .catch((err) => {
              cmethod.returnSreverError(res, message[lang].technicalError, err);
            });
        }
      })
      .catch((err) => {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      });
  }
);

// Delete  Conatct

router.delete(
  "/contact/delete",
  [midleware.validateFieldValue(["fId"], ["fId"])],
  (req, res) => {
    let lang = req.headers["lang"] || config.lang;
    let postData = req.body;
    let queryCond = { _id: mongoose.Types.ObjectId(postData.fId) };
    uModal.Contact.deleteOne(queryCond, function (err, data) {
      if (err) {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      } else {
        cmethod.returnSuccess(res, [], false, message[lang].Deleteed);
      }
    });
  }
);

// Delete  User

router.delete(
  "/delete",
  [midleware.validateFieldValue(["userId"], ["userId"])],
  (req, res) => {
    let lang = req.headers["lang"] || config.lang;
    let postData = req.body;
    let queryCond = { _id: mongoose.Types.ObjectId(postData.userId) };
    uModal.User.deleteOne(queryCond, function (err, data) {
      if (err) {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      } else {
        cmethod.returnSuccess(res, [], false, message[lang].Deleteed);
      }
    });
  }
);

// contact List

router.post(
  "/contact/list",
  [
    midleware.validateFieldValue(
      ["cId", "pageLimit", "page", "search"],
      ["page"]
    ),
  ],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let query = [];
    if (postData.fId) {
      query.push({ $match: { _id: mongoose.Types.ObjectId(postData.cId) } });
    } else if (postData.search) {
      query.push({
        $match: {
          $and: [{ $text: { $search: postData.search } }],
        },
      });
    } else {
      query.push({ $match: { status: 1 } });
    }
    // Set the order of the query result
    query.push({ $sort: { createdAt: -1 } });
    // Clone to query before preparing to pagination
    const sQuery = [...query];
    sQuery.push({ $count: "recordCount" });
    // set Pagination if required
    if (postData.page) {
      query.push({
        $skip: cmethod.pageOffset(postData.page, postData.pageLimit),
      });
      query.push({ $limit: cmethod.pageLimit(postData.pageLimit) });
    }

    userDao
      .findContactAggregation(query)
      .then(function (data) {
        userDao
          .findContactAggregation(sQuery)
          .then(function (dCount) {
            let tptCnt = 0;
            if (dCount.length > 0) {
              tptCnt = dCount[0].recordCount;
            }

            data.map((ele) => {
              ele.title =
                lang == "ara"
                  ? ele.titleAra
                    ? ele.titleAra
                    : ele.title
                  : ele.title;
              ele.message =
                lang == "ara"
                  ? ele.messageAra
                    ? ele.messageAra
                    : ele.message
                  : ele.message;
            });
            cmethod.returnSuccess(
              res,
              data,
              cmethod.hasMoreCount(tptCnt, postData.page, postData.pageLimit),
              "",
              tptCnt
            );
          })
          .catch((err) => {
            cmethod.returnSreverError(res, message[lang].technicalError, err);
          });
      })
      .catch((err) => {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      });
  }
);

// Request Call List

router.post(
  "/callrequest",
  [midleware.validateFieldValue(["pageLimit", "page", "search"], ["page"])],
  async (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let query = [];

    query.push({
      $lookup: {
        from: "users",
        localField: "userId",
        foreignField: "_id",
        as: "userData",
      },
    });

    query.push({
      $lookup: {
        from: "events",
        localField: "typeId",
        foreignField: "_id",
        as: "eventData",
      },
    });

    query.push({
      $lookup: {
        from: "zones",
        localField: "typeId",
        foreignField: "_id",
        as: "zoneData",
      },
    });

    query.push({
      $lookup: {
        from: "restaurants",
        localField: "typeId",
        foreignField: "_id",
        as: "returantData",
      },
    });

    query.push({
      $project: {
        _id: 1,
        requestNumber: 1,
        userId: 1,
        type: 1,
        name: { $arrayElemAt: ["$userData.name", 0] },
        phone: { $arrayElemAt: ["$userData.phone", 0] },
        cCode: { $arrayElemAt: ["$userData.cCode", 0] },
        userData: {
          $ifNull: ["$userData", {}],
        },
        eventData: {
          $ifNull: ["$eventData", {}],
        },
        zoneData: {
          $ifNull: ["$zoneData", {}],
        },
        returantData: {
          $ifNull: ["$returantData", {}],
        },
        status: 1,
        createdAt: 1,
        updatedAt: 1,
      },
    });

    // Set the order of the query result
    query.push({ $sort: { createdAt: -1 } });
    // Clone to query before preparing to pagination
    const sQuery = [...query];
    sQuery.push({ $count: "recordCount" });
    // set Pagination if required
    if (postData.page) {
      query.push({
        $skip: cmethod.pageOffset(postData.page, postData.pageLimit),
      });
      query.push({ $limit: cmethod.pageLimit(postData.pageLimit) });
    }

    categroyModel.RequestCall.aggregate(query)
      .then(function (data) {
        categroyModel.RequestCall.aggregate(sQuery)
          .then(function (dCount) {
            let tptCnt = 0;
            if (dCount.length > 0) {
              tptCnt = dCount[0].recordCount;
            }

            cmethod.returnSuccess(
              res,
              data,
              cmethod.hasMoreCount(tptCnt, data, postData.pageLimit),
              "",
              tptCnt
            );
          })
          .catch((err) => {
            cmethod.returnSreverError(res, message[lang].technicalError, err);
          });
      })
      .catch((err) => {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      });
  }
);

router.get("/exportUsers", async (req, res) => {
  let lang = req.headers["lang"] || config.lang;
  try {
    let data = await userDao.getUsersExport();
    let workbook = new excel.Workbook();
    let worksheet = workbook.addWorksheet("User Data");
    if (!data.length > 0) {
      cmethod.returnSuccess(res, [], false, "No record found!");
    }
    let keys = Object.keys(data[0]).map((value) => {
      return {
        header: value.replace(/^./, value[0].toUpperCase()),
        key: "id",
        width: 25,
      };
    });
    worksheet.columns = keys;
    data.forEach((val) => {
      worksheet.addRow(Object.values(val)).commit();
    });
    res.setHeader(
      "Content-Type",
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    );
    res.setHeader(
      "Content-Disposition",
      "attachment; filename=" + "Report.xlsx"
    );
    return workbook.xlsx.write(res).then(function () {
      res.status(200).end();
    });
    // let xls = json2xls(data);
    // let filePath = __basedir+'/userData.xlsx';
    // fs.writeFileSync(filePath , xls, 'binary')
    // res.download(filePath, 'userData.xlsx', (err) => {
    //     if (err) {
    //         cmethod.returnSreverError(res, message[lang].technicalError, err);
    //     }
    // });
    // cmethod.returnSuccess(res, [], false, 'export done successfully');
  } catch (err) {
    cmethod.returnSreverError(res, message[lang].technicalError, err);
  }
});

router.get("/supports", async (req, res) => {
  let response = [{ number: "920014177" }, { number: "920014177" }];
  cmethod.returnSuccess(res, response);
});

// APi to adjust  data to Ticket max platform
router.post(
  "/adjust",
  [
    midleware.validateFieldValue(
      ["gps_adid", "event_token", "app_token", "s2s"],
      ["gps_adid", "event_token", "app_token", "s2s"]
    ),
  ],
  async (req, res) => {
    let lang = req.headers["lang"] || config.lang;
    let postData = req.body;
    let counteventTrack = await userDao.getCountEventTrack();
    postData.serialNo = counteventTrack + 1;
    userDao.saveEventTrack(res, postData);
  }
);
// update event track status by third party
router.post(
  "/s2s/update",
  [
    midleware.validateFieldValue(
      [
        "serialNo",
        "gps_adid",
        "eventId",
        "evtStatus",
        "revenue",
        "currency",
        "noOfTickets",
      ],
      ["serialNo", "gps_adid", "eventId", "evtStatus"]
    ),
  ],
  async (req, res) => {
    let lang = req.headers["lang"] || config.lang;
    let postData = req.body;
    userDao.updateEventTrack(res, postData);
  }
);

//--------------------comment log scheam---------------------------
//update branch API
router.post(
  "/commentlogadd",
  [midleware.validateFieldValue(["message"], ["message"])],
  async (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    await cmethod.addcommentsLog(postData);
    //userDao.commentlogadd(res, postData);
  }
);

router.post(
  "/getAllMessage",
  [midleware.validateFieldValue(["referenceType"], ["referenceType"])],
  async (req, res) => {
    let lang = req.headers["lang"] || config.lang;

    let postData = req.body;
    let referenceTypes = postData.referenceType;
    let referenceIds = postData.referenceId;
    // let queryCond = {
    //   referenceType: referenceTypes,
    //   referenceId: mongoose.Types.ObjectId(referenceIds),
    // };
    // let getalldata = await uModal.Commentlog.find(queryCond).exec();

    let getalldata = await cmethod.commentsLog(referenceTypes, referenceIds);
    if (getalldata) {
      cmethod.returnSuccess(
        res,
        getalldata,
        false,
        message[lang].profileUpdate
      );
    } else {
      cmethod.returrnErrorMessage(res, message[lang].userVerify);
    }
  }
);

// update User

router.patch(
  "/commentlogupdate",
  [midleware.validateFieldValue(["commentId"], ["commentId"])],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let xtoken = req.headers["x-access-token"];
    //{ token: xtoken },
    let queryCond = {
      $and: [{ _id: mongoose.Types.ObjectId(postData.commentId) }],
    };
    delete postData.commentId;
    //console.log("=======================>", req.body);
    uModal.Commentlog.findOneAndUpdate(
      queryCond,
      { $set: postData },
      { new: true },
      async function (err, data) {
        //console.log("user->", data);
        if (err) {
          cmethod.returnSreverError(res, message[lang].technicalError, err);
        } else {
          cmethod.returnSuccess(res, data, false, message[lang].profileUpdate);
        }
      }
    );
  }
);

// * update-password
router.patch("/update-password", async (req, res) => {
  const {
    body: { email, phone, role, password },
  } = req;

  const lang = req.headers["lang"] || config.lang;

  const filter = {};

  if (email) {
    filter.email = email;
  }

  if (phone && role) {
    const userType = config.userTypeStatus[role];

    filter.$and = [{ phone }, { userType: { $in: userType } }];
  }

  const newPassword = await uModal.hashPassword(password);

  uModal.User.findOneAndUpdate(
    filter,
    { $set: { password: newPassword } },
    { new: true },
    async function (err, data) {
      if (err) {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      } else {
        cmethod.returnSuccess(res, data, false, message[lang].passwordUpdated);
      }
    }
  );
});

// * reset-password
router.patch("/reset-password", async (req, res) => {
  const { body, headers } = req;
  const { email, phone, countryCode, role } = body;
  const lang = headers.lang || config.lang;

  try {
    const filter = {};

    if (email) {
      filter.email = email;
    }

    if (phone && countryCode && role) {
      const userType = config.userTypeStatus[role];

      filter.$and = [
        { phone },
        { countryCode },
        { userType: { $in: userType } },
      ];
    }

    const user = await FindOne(uModal.User, filter);

    if (!user) {
      return cmethod.returrnErrorMessage(res, message[lang]?.usernotExist);
    }

    const { _id } = user;
    const update = {
      $set: {
        logAtt: 0,
        resetSession: new Date().getTime(),
      },
    };

    const updatedUser = await FindByIdAndUpdate(uModal.User, _id, update);

    if (!updatedUser) {
      return cmethod.returrnErrorMessage(
        res,
        "Failed to update the user with reset session!"
      );
    }

    const {
      email: userEmail,
      phone: userPhone,
      countryCode: userCountryCode,
    } = updatedUser;
    const phoneNo = `${userCountryCode}${userPhone}`;
    const userPhoneNo = removeSpecialCharacters(phoneNo);

    await sendOTP(userEmail, userPhoneNo, "reset");

    cmethod.returnSuccess(res, true, false, message[lang].resetPassword);
  } catch (error) {
    logger.error(error.message);
    cmethod.returnSreverError(res, message[lang]?.technicalError, error);
  }
});

// * verify-otp
router.post(
  "/verify-otp",
  [midleware.validateFieldValue(["otp"], ["otp"])],
  async (req, res) => {
    const {
      body,
      headers: { lang = config.lang },
    } = req;

    try {
      const {
        email,
        phone,
        countryCode,
        userType,
        otp: Otp,
        update: shouldUpdate,
      } = body;

      const filter = {};

      if (email && Otp) {
        filter.$and = [{ email }, { otp: Otp }];
      }

      if (phone && countryCode && Otp) {
        const phoneNo = makeSmsNumber(countryCode, phone);
        filter.$and = [{ phone: phoneNo }, { otp: Otp }];
      }

      const otp = await getOTP(filter);

      if (!otp) {
        return cmethod.returrnErrorMessage(
          res,
          "Kindly enter the correct OTP!"
        );
      }

      if (email && userType && shouldUpdate) {
        const filter = { email, userType };
        const update = { isEmailVerified: true };
        await FindOneAndUpdate(uModal.User, filter, update);
      }

      if (phone && countryCode && userType && shouldUpdate) {
        const filter = { phone, countryCode, userType };
        const update = { isPhoneVerified: true };
        await FindOneAndUpdate(uModal.User, filter, update);
      }

      const message = "OTP verified successfully!";
      cmethod.returnSuccess(res, true, false, message);
    } catch (error) {
      logger.error(error.message);
      cmethod.returnSreverError(res, message[lang]?.technicalError, error);
    }
  }
);

// * resend-otp
router.post(
  "/resend-otp",
  [midleware.validateFieldValue(["mode"], ["mode"])],
  async (req, res) => {
    const { body, headers } = req;
    const lang = headers.lang || config.lang;

    const {
      email,
      phone,
      countryCode,
      role,
      mode,
      isEmailVerified,
      isPhoneVerified,
    } = body;

    try {
      const filter = {};

      if (email) {
        filter.email = email;
      }

      if (phone && countryCode && role) {
        const userType = config.userTypeStatus[role];

        filter.$and = [
          { phone },
          { countryCode },
          { userType: { $in: userType } },
        ];
      }

      const user = await FindOne(uModal.User, filter);

      if (!user) {
        return cmethod.returrnErrorMessage(res, message[lang]?.usernotExist);
      }

      if (email && !isEmailVerified) {
        await sendEmailOTP(email, mode);
      }

      if (phone && countryCode && !isPhoneVerified) {
        const phoneNo = `${countryCode}${phone}`;
        const userPhoneNo = removeSpecialCharacters(phoneNo);
        await sendSmsOTP(userPhoneNo, mode);
      }

      cmethod.returnSuccess(res, true, false, message[lang]?.resetPassword);
    } catch (error) {
      logger.error(error.message);
      cmethod.returnSreverError(res, message[lang]?.technicalError, error);
    }
  }
);

// * update-profile-otp
router.post(
  "/update-profile-otp",
  [midleware.validateFieldValue(["userId", "mode"], ["userId", "mode"])],
  async (req, res) => {
    const { body, headers } = req;
    const lang = headers.lang || config.lang;

    const {
      userId,
      email: newEmail,
      countryCode: newCountryCode,
      phone: newPhone,
      mode,
    } = body;

    try {
      const user = await FindById(uModal.User, userId);

      if (!user) {
        return cmethod.returrnErrorMessage(res, message[lang]?.usernotExist);
      }

      const previousUser = user;
      const newUser = { newEmail, newCountryCode, newPhone };

      await checkEmailOrPhoneChange(previousUser, newUser, mode);

      cmethod.returnSuccess(res, true, false, message[lang]?.resetPassword);
    } catch (error) {
      logger.error(error.message);
      cmethod.returnSreverError(res, message[lang]?.technicalError, error);
    }
  }
);

// * check-valid
router.post("/check-valid", async (req, res) => {
  const { body, headers } = req;
  const lang = headers.lang || config.lang;
  const { email, phone, userType } = body;
  const errors = {};

  try {
    if (email) {
      const checkEmail = await checkUniqueEmail(email);
      if (!checkEmail.status) errors.email = checkEmail.message;
    }

    if (phone && userType) {
      const userPhoneWithType = await checkUserWithPhoneAndRole(
        phone,
        userType
      );
      if (!userPhoneWithType.status) errors.phone = userPhoneWithType.message;
    }

    if (Object.keys(errors).length > 0) {
      return cmethod.returrnErrorMessage(res, errors);
    }

    cmethod.returnSuccess(res, true, false);
  } catch (error) {
    logger.error(error.message);
    cmethod.returnSreverError(res, message[lang]?.technicalError, error);
  }
});

// * resend-otp
router.post("/send-otp", async (req, res) => {
  const { body, headers } = req;
  const lang = headers.lang || config.lang;

  const { email, phone, role, mode = "verify" } = body;

  try {
    const filter = {};

    if (email && role) {
      const userType = config.userTypeStatus[role];

      filter.$and = [{ email }, { userType: { $in: userType } }];
    }

    if (phone && role) {
      const userType = config.userTypeStatus[role];

      filter.$and = [{ phone }, { userType: { $in: userType } }];
    }

    const user = await FindOne(uModal.User, filter);

    if (!user) {
      return cmethod.returrnErrorMessage(res, message[lang]?.usernotExist);
    }

    const {
      email: userEmail,
      phone: userPhone,
      countryCode: userCountryCode,
    } = user;

    if (userEmail && userPhone && userCountryCode) {
      const phoneNo = `${userCountryCode}${userPhone}`;
      const userPhoneNo = removeSpecialCharacters(phoneNo);
      await sendOTP(userEmail, userPhoneNo, mode);
    }

    cmethod.returnSuccess(res, user, false, message[lang]?.resetPassword);
  } catch (error) {
    logger.error(error.message);
    cmethod.returnSreverError(res, message[lang]?.technicalError, error);
  }
});

module.exports = router;

// * user/register - comment
// { phone: postData.phone }
// query = {
//   $and: [{ userType: postData.userType }],
// };

// query = {
//   $and: [{ email: postData.email }, { userType: postData.userType }],
// };

// if (!postData.zoneId) {
//   postData.zoneId = mongoose.Types.ObjectId();
// }

// if (postData.loginType == 1) {
//   if (postData.userType == 3) {
//     query = {
//       $and: [
//         { deviceId: postData.deviceId },
//         { userType: postData.userType },
//       ],
//     };
//   } else {
//     query = {
//       $and: [{ email: postData.email }, { userType: postData.userType }],
//     };
//   }
// } else {
//   query = {
//     $and: [

//       { userType: postData.userType },
//     ],
//   };
// }

/* let uniqueIdentifier = 0;
       const userData = await uModal.User.findOne(queryUnique, {
         uniqueIdentifier: 1,
       }).sort({ createdAt: -1 });

       if (userData) {
         if (userData.uniqueIdentifier == 0) {
           uniqueIdentifier = 100101;
         } else {
           uniqueIdentifier = userData.uniqueIdentifier + 1;
         }
         postData.uniqueIdentifier = uniqueIdentifier;
       }*/

// if([2,3].includes(postData.userType)){
//   if(userData.uniqueIdentifier==0){
//     uniqueIdentifier=100101;
//   } else {
//     uniqueIdentifier=userData.uniqueIdentifier+1;
//   }
// } else if([3,4].includes(postData.userType)){
//   if(userData.uniqueIdentifier==0){
//     uniqueIdentifier=100101;
//   } else {
//     uniqueIdentifier=userData.uniqueIdentifier+1;
//   }
// }

/**
 * @swagger
 * /api/user/login:
 *   post:
 *     tags: [User]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: email
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: password
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: loginType
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *                exp - web, admin
 *     responses:
 *       200:
 *         description: User Role List.
 *
 */
/**
 * @swagger
 * /api/user/logout:
 *   post:
 *     tags: [User]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: userId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: token
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *     responses:
 *       200:
 *         description: User Role List.
 *
 */
/**
 * @swagger
 * /api/user/register:
 *   post:
 *     tags: [User]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: forApproval
 *         in: formData
 *         type: boolean
 *         required: true
 *       - name: businessType
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *            ex- external
 *       - name: email
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: phone
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: password
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: name
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: userType
 *         in: formData
 *         type: number
 *         required: true
 *         description:
 *            ex- 2 for seller individual | 3 for corporate indiviadual | 4 for buyer individual | 5 for buyer corporate
 *       - name: eid
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: address
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: companyDetails
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: eidExpiry
 *         in: formData
 *         type: Date
 *         required: false
 *         description:
 *       - name: tradeLicenceNo
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: tlExpiry
 *         in: formData
 *         type: Date
 *         required: false
 *         description:
 *       - name: trnCertificate
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: eidCertificate
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: tradeLicense
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: deviceId
 *         in: formData
 *         type: srting
 *         required: false
 *         description:
 *       - name: status
 *         in: formData
 *         type: number
 *         required: false
 *         description:
 *       - name: planId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: addedFrom
 *         in: formData
 *         type: srting
 *         required: false
 *         description:
 *              ex- web app admin
 *     responses:
 *       200:
 *         description: Add user role.
 *
 */
/**
 * @swagger
 * /api/user/reg-admin:
 *   post:
 *     tags: [User]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: roleId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: branchIds
 *         in: formData
 *         type: array
 *         items:
 *           type: string
 *         required: true
 *         description:
 *       - name: email
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: password
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: phone
 *         in: formData
 *         type: Number
 *         required: false
 *         description:
 *       - name: name
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: userType
 *         in: formData
 *         type: number
 *         required: true
 *         description:
 *            ex - 1
 *       - name: deviceId
 *         in: formData
 *         type: srting
 *         required: false
 *         description:
 *     responses:
 *       200:
 *         description: Add user role.
 *
 */
/**
 * @swagger
 * /api/user/list:
 *   post:
 *     tags: [User]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: searchUserType
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *          searchUserType like seller,buyer,admin
 *       - name: userType
 *         in: formData
 *         type: Number
 *         required: false
 *         description:
 *       - name: branchId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: roleId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: roleName
 *         in: formData
 *         type: string
 *         required: false
 *       - name: userId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: search
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: buyerNo
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: sellerNo
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: status
 *         in: formData
 *         type: Number
 *         required: false
 *         description:
 *       - name: searchUserTypes
 *         in: formData
 *         type: array
 *         items:
 *           type: string
 *         collectionFormat: multi
 *         required: false
 *         description:
 *       - name: uniqueIdentifier
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: addedFrom
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: fromDate
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: toDate
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: eidExpiredStatus
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *          ex- valid | invalid
 *       - name: pageLimit
 *         in: formData
 *         type: number
 *         required: false
 *         description:
 *       - name: page
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *     responses:
 *       200:
 *         description: User Role List.
 *
 */
/**
 * @swagger
 * /api/user/verifyotp:
 *   post:
 *     tags: [User]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: phone
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *     responses:
 *       200:
 *         description: checkmobile.
 *
 */
/**
 * @swagger
 * /api/user/getAllMessage:
 *   post:
 *     tags: [User]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: referenceType
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *              ex - seller , inventory ,reciept
 *       - name: referenceId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: pageLimit
 *         in: formData
 *         type: number
 *         required: true
 *         description:
 *       - name: page
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description:getAllMessage.
 *
 */
/**
 * @swagger
 * /api/user/commentlogadd:
 *   post:
 *     tags: [User]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: referenceType
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: referenceId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: message
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: commentBy
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description:comment log add.
 *
 */
/**
 * @swagger
 * /api/user/commentlogupdate:
 *   patch:
 *     tags: [User]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: commentId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: referenceType
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: referenceId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: message
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: commentBy
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: User update List.
 *
 */
/**
 * @swagger
 * /api/user/reset-password:
 *   patch:
 *     tags: [User]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: email
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: phone
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: countryCode
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: role
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *     responses:
 *       200:
 *         description: User - Reset Password
 *
 */
/**
 * @swagger
 * /api/user/checkmobile:
 *   post:
 *     tags: [User]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: phone
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *     responses:
 *       200:
 *         description: checkmobile.
 *
 */
/**
 * @swagger
 * /api/user/changePasswordByAdmin:
 *   patch:
 *     tags: [User]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: userId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: newPass
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *     responses:
 *       200:
 *         description: changePasswordByAdmin List.
 *
 */
/**
 * @swagger
 * /api/user/change-password:
 *   patch:
 *     tags: [User]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: x-access-token
 *         in: header
 *         type: string
 *         required: true
 *         description: Authorization Token
 *       - name: userId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: oldPass
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: newPass
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *     responses:
 *       200:
 *         description: User Role List.
 *
 */
/**
 * @swagger
 * /api/user/qwaitingUserAccesslist:
 *   post:
 *     tags: [User]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: pageLimit
 *         in: formData
 *         type: number
 *         required: true
 *         description:
 *       - name: page
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: User Role List.
 *
 */
/**
 * @swagger
 * /api/user/update-password:
 *   patch:
 *     tags: [User]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: email
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: phone
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: role
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: password
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: User - Update Password.
 *
 */
/**
 * @swagger
 * /api/user/verify-otp:
 *   post:
 *     tags: [User]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: email
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: phone
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: otp
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: User - Verify OTP
 *
 */
/**
 * @swagger
 * /api/user/resend-otp:
 *   post:
 *     tags: [User]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: email
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: phone
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: countryCode
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: userType
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: mode
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: User - Resend OTP
 *
 */
/**
 * @swagger
 * /api/user/update-profile-otp:
 *   post:
 *     tags: [User]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: userId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: email
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: phone
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: countryCode
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: mode
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: User - Update Profile OTP
 *
 */
/**
 * @swagger
 * /api/user/check-valid:
 *   post:
 *     tags: [User]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: email
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: phone
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: userType
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *     responses:
 *       200:
 *         description: User - Check Valid
 *
 */
