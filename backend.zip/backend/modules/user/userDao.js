const uModal = require("../user/userModal");
const masterModal = require("../master/masterModal");
const iModal = require("../inventory/inventoryModal");
const vinModal = require("../vin/vinModal");
const message = require("../../config/message");
const jwt = require("jsonwebtoken");
const config = require("../../config");
const midleware = require("../../middleware/validation");
const Promise = require("bluebird");
const cmethod = require("../../middleware/common-fun");
var axios = require("axios");

var mongoose = require("mongoose");
const { sendEmailOTP, sendSmsOTP } = require("../../services/user.service");
const { removeSpecialCharacters } = require("../../functions/global.functions");

// User Registartion  function
const userRegiter = async function (res, postData, lang) {
  //console.log('first======================>>>>>', postData);
  const jwttoken = jwt.sign(
    { email: postData.email, deviceId: postData.deviceId },
    config.secret,
    { expiresIn: config.tokenLife }
  );
  postData.password = await uModal.hashPassword(postData.password);
  postData.token = jwttoken;
  postData.resetSession = new Date().getTime();
  const newUser = new uModal.User(postData);
  if (postData.userType == 2 && postData.loginType != 1) {
    postData.userVerify = true;
  }
  if (postData?.warehosIds?.length > 0) {
    let insertData = [];
    for (var i = 0; i < postData?.warehosIds.length; i++) {
      insertData.push(mongoose.Types.ObjectId(postData?.warehosIds[i]));
    }
    postData.warehosIds = insertData;
  }

  newUser.save(postData, async function (err, data) {
    if (err) {
      cmethod.returnSreverError(res, err, err);
    } else {
      let sellerplanData = [];
      if (data?.id && [2, 3].includes(data?.userType)) {
        const planData = await masterModal.Sellerplan.find(
          { defaultbranchplan: 1 },
          { branchId: 1 }
        ).sort({ createdAt: -1 });
        let pId;
        if (planData) {
          for (var i = 0; i < planData.length; i++) {
            pId = planData[i]._id;
            sellerplanData.push({
              sellerId: mongoose.Types.ObjectId(data?._id),
              branchId: mongoose.Types.ObjectId(planData[i].branchId),
              planId: mongoose.Types.ObjectId(planData[i]._id),
            });
          }
        }
        if (sellerplanData.length > 0) {
          await iModal.Sellermappingbranch.insertMany(sellerplanData);
          await uModal.User.updateOne(
            { _id: mongoose.Types.ObjectId(data?._id) },
            { $set: { planId: mongoose.Types.ObjectId(pId) } }
          );
        }
      }

      //-----------------------save multiple image---------------
      if (data?.trnCertificate) {
        let trnCertificateImage = {
          imageType: "saller",
          referenceId: mongoose.Types.ObjectId(data._id),
          image: data?.trnCertificate,
          type: "trn",
        };
        await vinModal.Vinimage.insertMany(trnCertificateImage);
      }
      if (data?.tradeLicense) {
        let tradeLicenseImage = {
          imageType: "saller",
          referenceId: mongoose.Types.ObjectId(data._id),
          image: data?.tradeLicense,
          type: "trade",
        };
        await vinModal.Vinimage.insertMany(tradeLicenseImage);
      }
      if (data?.eidCertificate) {
        let eidCertificateImage = {
          imageType: "saller",
          referenceId: mongoose.Types.ObjectId(data._id),
          image: data?.eidCertificate,
          type: "eid",
        };
        await vinModal.Vinimage.insertMany(eidCertificateImage);
      }
      if (data?.commercialAgreement) {
        const commercialAgreement = {
          imageType: "saller",
          referenceId: mongoose.Types.ObjectId(data._id),
          image: data?.commercialAgreement,
          type: "agreement",
        };
        await vinModal.Vinimage.insertMany(commercialAgreement);
      }

      let userBranchMapp = [];
      if (postData?.branchIds?.length > 0) {
        let allBranch = postData?.branchIds;
        for (var i = 0; i < allBranch.length; i++) {
          userBranchMapp.push({
            userId: mongoose.Types.ObjectId(data?._id),
            branchId: mongoose.Types.ObjectId(allBranch[i]),
          });
        }
      }
      // if (postData?.warehosIds?.length > 0) {
      //   let allWares = postData?.warehosIds;
      //   for (var i = 0; i < allWares.length; i++) {
      //     userBranchMapp.push({
      //       userId: mongoose.Types.ObjectId(data?._id),
      //       warehosId: mongoose.Types.ObjectId(allWares[i]),
      //     });
      //   }
      // }
      // if (postData?.warehosId) {
      //   userBranchMapp.push({
      //     userId: mongoose.Types.ObjectId(data?._id),
      //     warehosId: mongoose.Types.ObjectId(postData?.warehosId),
      //   });
      // }
      if (userBranchMapp.length > 0) {
        masterModal.Branchusermapping.insertMany(userBranchMapp);
      }
      //------------------comments log for add seller------------------//
      let savesellerCommentLog = {
        referenceType: "seller",
        referenceId: mongoose.Types.ObjectId(data?._id),
        message: "New seller has been create created by " + postData?.createdBy,
        commentBy: postData?.createdBy,
      };

      if (!data.status) {
        const phoneNo = `${data.countryCode}${data.phone}`;
        const phone = removeSpecialCharacters(phoneNo);
        await sendEmailOTP(data.email, "register");
        await sendSmsOTP(phone, "register");
      }
      cmethod.addcommentsLog(savesellerCommentLog);
      cmethod.returnSuccess(res, data, true, message.signupsuccess);
    }
  });
};
const commentlogadd = async function (res, postData) {
  const newCommentlog = new uModal.Commentlog(postData);
  //console.log("postData=>1", postData);

  newCommentlog.save(postData, async function (err, data) {
    if (err) {
      cmethod.returnSreverError(res, message.technicalError, err);
    } else {
      cmethod.returnSuccess(res, data, false, message.signupsuccess);
    }
  });
};
const findCommentLogAggregation = function (query) {
  return new Promise(function (resolve, reject) {
    uModal.Commentlog.aggregate(query, function (err, data) {
      if (err) {
        reject(err);
      } else {
        resolve(data);
      }
    });
  });
};
const findCommentLogWithFiled = async function (query, fields) {
  return new Promise(function (resolve, reject) {
    uModal.Commentlog.find(query, fields, function (err, data) {
      if (err) {
        reject(err);
      } else {
        resolve(data);
      }
    });
  });
};
const userImport = async function (res, postData, lang) {
  let resp;
  const jwttoken = jwt.sign(
    { email: postData.email, deviceId: postData.deviceId },
    config.secret,
    { expiresIn: config.tokenLife }
  );
  postData.password = await uModal.hashPassword(postData.password);
  //postData.dob = new Date(postData.dob);
  postData.token = jwttoken;
  postData.resetSession = new Date().getTime();
  const newUser = new uModal.User(postData);

  newUser.save(postData, async function (err, data) {
    if (err) {
      // cmethod.returnSreverError(res, message.technicalError, err);
      resp = err;
    } else {
      /* let index = await uModal.User.find({"_id": { "$lte" : mongoose.Types.ObjectId(data._id)}}).count()
        await deleteUser(index) */
      resp = message.signupsuccess;

      cmethod.returnSuccess(res, data, false, message.signupsuccess);
    }
  });
  return resp;
};

// Create Contact
const saveContact = async function (res, postData) {
  const newfeedBack = new uModal.Contact(postData);
  newfeedBack.save(postData, function (err, data) {
    if (err) {
      cmethod.returnSreverError(res, message.technicalError, err);
    } else {
      cmethod.returnSuccess(res, data, false, message.addFeedback);
    }
  });
};

const saveVrificationCode = function (res, postData) {
  postData.vCode = Math.floor(1000 + Math.random() * 9000);
  postData.phoneNumber = postData.phone;
  const verifyCode = new uModal.Phone(postData);
  verifyCode.save(postData, async function (err, data) {
    if (err) {
      cmethod.returnSreverError(res, message.technicalError, err);
    } else {
      let cCode = postData.cCode != "" ? postData.cCode : "966";
      let number = cCode + "" + postData.phone;
      let message =
        "OTP is " +
        postData.vCode +
        " for mobile number verification on your Riyadh Season application. Do not share this OTP with anyone for security reasons";
      let ack = await sendThirdPartyOtp(number, message);
      // console.log(ack)
      cmethod.returnSuccess(res, [], false, message.addFeedback);
    }
  });
};

const findUserAggregation = function (query) {
  return new Promise(function (resolve, reject) {
    uModal.UserRead.aggregate(query, function (err, data) {
      if (err) {
        reject(err);
      } else {
        resolve(data);
      }
    });
  });
};

const findContactAggregation = function (query) {
  return new Promise(function (resolve, reject) {
    uModal.ContactRead.aggregate(query, function (err, data) {
      if (err) {
        reject(err);
      } else {
        resolve(data);
      }
    });
  });
};

const findUserWithFiled = async function (query, fields) {
  return new Promise(function (resolve, reject) {
    uModal.UserRead.find(query, fields, function (err, data) {
      if (err) {
        reject(err);
      } else {
        resolve(data);
      }
    });
  });
};

const findUser = async function (query) {
  return new Promise(function (resolve, reject) {
    uModal.UserRead.find(query, function (err, data) {
      if (err) {
        reject(err);
      } else {
        resolve(data);
      }
    });
  });
};

const findPhone = async function (query) {
  return new Promise(function (resolve, reject) {
    uModal.PhoneRead.find(query, function (err, data) {
      if (err) {
        reject(err);
      } else {
        resolve(data);
      }
    });
  });
};
const checkmobile = async function (query) {
  return new Promise(function (resolve, reject) {
    uModal.User.find(query, function (err, data) {
      if (data.length > 0) {
        resolve("exist");
      } else {
        resolve("notexist");
      }
    });
  });
};
const deletePhone = function (query) {
  return new Promise(function (resolve, reject) {
    uModal.Phone.deleteOne(query, function (err, data) {
      if (err) {
        reject(err);
      } else {
        resolve(data);
      }
    });
  });
};
const getUsersExport = async function (query) {
  return await uModal.UserRead.find(
    { userType: 4 },
    {
      email: 1,
      cCode: 1,
      phone: 1,
      name: 1,
      gender: 1,
      age: 1,
      profileImg: 1,
      loginType: 1,
      deviceType: 1,
      deviceId: 1,
      userType: 1,
    }
  ).lean();
};

const getCountEventTrack = async function () {
  return await uModal.eventTrackRead.count({});
};

// Create Save Event
const saveEventTrack = async function (res, postData) {
  const eventTrack = new uModal.eventTrack(postData);
  eventTrack.save(postData, function (err, data) {
    if (err) {
      cmethod.returnSreverError(res, message.technicalError, err);
    } else {
      cmethod.returnSuccess(res, data, false, "Cretaed");
    }
  });
};

// Update Save Event
const updateEventTrack = async function (res, postData) {
  uModal.eventTrack.findOneAndUpdate(
    {
      $and: [{ serialNo: postData.serialNo }, { gps_adid: postData.gps_adid }],
    },
    {
      $set: {
        status: postData.evtStatus,
        revenue: postData.revenue,
        currency: postData.currency,
        noOfTickets: postData.noOfTickets,
      },
    },
    { returnNewDocument: true },
    function (err, data) {
      if (err) {
        cmethod.returnSreverError(res, message.technicalError, err);
      } else {
        if (data) {
          axios({
            method: "post",
            url: "https://s2s.adjust.com/event",
            headers: {
              "Content-Type": "application/x-www-form-urlencoded",
            },
            data: {
              s2s: data.s2s,
              event_token: data.event_token,
              app_token: data.app_token,
              revenue: data.revenue,
              currency: data.currency,
              noOfTickets: data.noOfTickets,
              created_at: data.createdAt,
            },
          });
        } else {
          data = {};
        }

        cmethod.returnSuccess(res, data, false, "send to S2S");
      }
    }
  );
};

module.exports = {
  userRegiter,
  commentlogadd,
  findCommentLogAggregation,
  findCommentLogWithFiled,
  findUserAggregation,
  saveContact,
  findContactAggregation,
  findUserWithFiled,
  findUser,
  saveVrificationCode,
  findPhone,
  deletePhone,
  getUsersExport,
  getCountEventTrack,
  saveEventTrack,
  updateEventTrack,
  checkmobile,
};
