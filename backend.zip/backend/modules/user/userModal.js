const mongoose = require("mongoose");
const Schema = mongoose.Schema;
const { connWrite, connRead } = require("./../../config/database");
const bcrypt = require("bcryptjs");
const { date } = require("@hapi/joi");
const userSchema = new Schema(
  {
    planId: {
      type: mongoose.Types.ObjectId,
      default: null,
      index: true,
    },
    roleId: {
      type: mongoose.Types.ObjectId,
      default: null,
      index: true,
    },
    branchId: {
      type: mongoose.Types.ObjectId,
      default: null,
      index: true,
    },
    warehosIds: [
      {
        type: mongoose.Types.ObjectId,
        default: [],
        index: true,
      },
    ],
    email: { type: String, index: true, unique: true },
    password: String,
    phone: { type: String, index: true },
    name: {
      type: String,
      // index: true,
    },
    userType: { type: Number, default: 2, index: true },
    sellerBuyerType: String,
    businessType: { type: String, default: "external" },
    uniqueIdentifier: { type: String, index: true, default: "" },
    eid: String,
    address: String,
    addedFrom: String,
    companyDetails: {
      primaryName: String,
      primaryContact: String,
      trn: String,
    },
    // eid: String,
    eidExpiry: { type: Date },
    tradeLicenceNo: String,
    tlExpiry: { type: Date },
    trnCertificate: String,
    eidCertificate: String,
    tradeLicense: String,
    commercialAgreement: String,
    token: { type: String, default: "", index: true },
    accessToken: { type: String, default: "" },
    refreshToken: { type: String, default: "" },
    status: { type: Number, default: 1 }, //0=not approved,1=aproved,2=rejected, 3 = suspended
    whyRejected: String,
    rejectedRemarks: String,
    verifyStatus: { type: Number, default: 0 },
    loginStatus: { type: Number, default: 0 },
    resetSession: { type: String, default: "" }, //index:true
    userVerify: { type: Boolean, default: false }, //index:true
    deviceId: { type: String, default: "" },
    countryCode: String,
    countryIso: String,
    createdBy: String,
    qwaitingDepart: {
      type: mongoose.Types.ObjectId,
      default: null,
      index: true,
    },
    qwaitingMappCounterId: {
      type: mongoose.Types.ObjectId,
      default: null,
      index: true,
    },
    creditLimit: { type: Number, default: 0 },
    depositAmt: { type: Number, default: 0 },
    unpaidAmt: { type: Number, default: 0 },
    overdueAmt: { type: Number, default: 0 },
    curBalance: { type: Number, default: 0 },
    walletAmount: { type: Number, default: 0 },
    sapId: { type: String, default: "" },
    secondaryPhone: { type: String, index: true },
    secondaryCountryCode: { type: String, index: true },
    secondaryCountryIso: { type: String, index: true },
    isEmailVerified: { type: Boolean, default: false },
    isPhoneVerified: { type: Boolean, default: false },
    isVerificationCompleted: { type: Boolean, default: false },
    isProfileCompleted: { type: Boolean, default: false },
    tnm: { type: Boolean, default: false },
    bank: {
      bankName: { type: String, default: "" },
      accountName: { type: String, default: "" },
      accountNumber: { type: String, default: "" },
      ibanNumber: { type: String, default: "" },
    },
  },
  {
    timestamps: {
      createdAt: "createdAt",
      updatedAt: "updatedAt",
    },
  }
  // //verifyCode: Number,
  // age: { type: Number, default: 1 }, // 1- Below 15 years, 2- Between 15 and 25 years, 3- Bewtween 26-40 years 4- between 41-55 years, 5-Above 55 years
  // //profileImg: { type: String, default: "" },
  // //socialId: { type: String, default: "0000-0000-0000-0000" }, //,index: true
  // loginType: { type: Number,index: true }, // 1 - Email/Phone Login 2- Google Login 3-  Apple login
  // deviceType: {
  //   type: Number,
  //   default: 1,
  // }, // 1 -Ios, 2=Android, 3- Web
  // deviceId: { type: String, default: "" }, //,index: true

  // userType: { type: Number, default: 2,index: true }, // 1.) Admin , 2.) Email App login,  3.) Guest User, 4.) protocal Users, 5.) Agent User
  // notifyStatus: { type: Boolean }, //, default: true
  //terms: { type: Boolean }, //, default: false
  //fcmToken: String,
  // areasInterest: {
  //   type: [mongoose.Types.ObjectId],
  //   default: [mongoose.Types.ObjectId()],
  //     index: true
  // },
  //   userScale: { type: Number, default: 1 }, //1 =Free , 2--paid
  //   validFrom: { type: Date, default: "1971-01-01" },
  //   validTo: { type: Date, default: "1971-01-01" },
  //   serialNumber: { type: String, default: "" },
  //   ticketMax: { type: Boolean, default: false },
  //   ticketMaxEmail: { type: String, default: "" }, //, index: true
  //   ticketMaxPass: { type: String, default: "" },

  //   lang: { type: String, default: "eng" },

  //   logAtt: { type: Number, default: 0 },

  //   zoneId: {
  //     type: mongoose.Types.ObjectId,
  //     default: [mongoose.Types.ObjectId()],
  //       index: true
  //   },
  // },
  // {
  //   timestamps: {
  //     createdAt: "createdAt",
  //     updatedAt: "updatedAt",
  //   },
);

userSchema.methods.hashPassword = async function (password) {
  try {
    const salt = await bcrypt.genSalt(10);
    return await bcrypt.hash(password, salt);
  } catch (error) {
    throw new Error("Hashing failed", error);
  }
};

userSchema.methods.generateHash = function (password) {
  return bcrypt.hash(password, bcrypt.genSalt(10));
};

userSchema.methods.validPassword = function (password) {
  console.log("checking" + bcrypt.compareSync(password, this.password));
  ///console.log(this.hashPassword(password));
  return bcrypt.compareSync(password, this.password);
  //return this.hashPassword(password)
};
// for users comments logs
const commentLogsSchema = new Schema(
  {
    referenceName: { type: String, index: true }, // * name of grouped reference (hierarchy)
    referenceType: { type: String, index: true }, //* seller|inventory|reciept|bid|advance
    referenceId: {
      type: mongoose.Types.ObjectId,
      default: null,
      index: true,
    },
    message: String,
    commentBy: String,
    hierarchy: [
      {
        _id: false,
        message: String,
        by: String,
      },
    ],
  },
  {
    timestamps: {
      createdAt: "createdAt",
      updatedAt: "updatedAt",
    },
  }
);

// Contact
const contactSchema = new Schema(
  {
    userId: {
      type: mongoose.Types.ObjectId,
      index: true,
    },
    email: {
      type: String,
      index: true,
    },
    title: {
      type: String,
    },
    titleAra: {
      type: String,
    },
    message: {
      type: String,
    },
    messageAra: {
      type: String,
    },
    status: { type: Number, default: 1 },
  },
  {
    timestamps: {
      createdAt: "createdAt",
      updatedAt: "updatedAt",
    },
  }
);

// phone

const phoneSchema = new Schema(
  {
    cCode: {
      type: String,
      default: "",
    },
    phoneNumber: {
      type: Number,
      createIndexes: true,
    },
    vCode: {
      type: Number,
      createIndexes: true,
    },
    status: { type: Number, default: 1 },
  },
  {
    timestamps: {
      createdAt: "createdAt",
      updatedAt: "updatedAt",
    },
  }
);

//constatnts

const constantSchema = new Schema(
  {
    sCode: {
      type: Number,
      default: 10001,
      index: true,
    },
    requestNumber: {
      type: Number,
      default: 10001,
      index: true,
    },
  },
  {
    timestamps: {
      createdAt: "createdAt",
      updatedAt: "updatedAt",
    },
  }
);

const eventTrackingSchema = new Schema(
  {
    eventId: {
      type: mongoose.Types.ObjectId,
      default: mongoose.Types.ObjectId(),
      index: true,
    },
    serialNo: {
      type: Number,
      default: 1,
      index: true,
    },
    gps_adid: {
      type: String,
      default: "",
      index: true,
    },
    event_token: {
      type: String,
      default: "",
      index: true,
    },
    app_token: {
      type: String,
      default: "",
      index: true,
    },
    s2s: {
      type: String,
      default: "",
      index: true,
    },
    revenue: {
      type: String,
      default: "",
      index: true,
    },
    currency: {
      type: String,
      default: "",
      index: true,
    },
    noOfTickets: {
      type: Number,
      default: 0,
      index: true,
    },
    status: {
      type: Boolean,
      default: false,
      index: true,
    },
  },
  {
    timestamps: {
      createdAt: "createdAt",
      updatedAt: "updatedAt",
    },
  }
);

const userTnmSchema = new Schema(
  {
    title_eng: {
      type: String,
      index: true,
    },
    title_arbic: {
      type: String,
    },
    description_eng: {
      type: String,
    },
    decription_arbic: {
      type: String,
    },
    status: { type: Number, default: 1 },
  },
  {
    timestamps: {
      createdAt: "createdAt",
      updatedAt: "updatedAt",
    },
  }
);
const tnmAcceptLogsSchema = new Schema(
  {
    userId: {
      type: mongoose.Types.ObjectId,
      index: true,
    },
    tnmId: {
      type: mongoose.Types.ObjectId,
      index: true,
    },
    status: { type: Number, default: 1 },
  },
  {
    timestamps: {
      createdAt: "createdAt",
      updatedAt: "updatedAt",
    },
  }
);

// const User = mongoose.model("users", userSchema);
// const Contact = mongoose.model("contact", contactSchema);
// const Phone = mongoose.model("phone", phoneSchema);
// const Constant = mongoose.model("constant", constantSchema);
// const eventTrack = mongoose.model("eventtrack",eventTrackingSchema)
const UserTnm = connWrite.model("usertnms", userTnmSchema);
const TnmAcceptLog = connWrite.model("tnmacceptlogs", tnmAcceptLogsSchema);
const User = connWrite.model("users", userSchema);
const Commentlog = connWrite.model("commentlogs", commentLogsSchema);

const Contact = connWrite.model("contact", contactSchema);
const Phone = connWrite.model("phone", phoneSchema);
const Constant = connWrite.model("constant", constantSchema);
const eventTrack = connWrite.model("eventtrack", eventTrackingSchema);

const UserRead = connRead.model("users", userSchema);
//const CommentlogRead = connRead.model("commentlogs", commentLogsSchema);

const ContactRead = connRead.model("contact", contactSchema);
const PhoneRead = connRead.model("phone", phoneSchema);
const ConstantRead = connRead.model("constant", constantSchema);
const eventTrackRead = connRead.model("eventtrack", eventTrackingSchema);

module.exports = {
  User,
  Commentlog,
  Contact,
  Phone,
  Constant,
  eventTrack,
  UserRead,
  //CommentlogRead,
  ContactRead,
  PhoneRead,
  ConstantRead,
  eventTrackRead,
  UserTnm,
  TnmAcceptLog,
};
module.exports.hashPassword = async (password) => {
  try {
    const salt = await bcrypt.genSalt(10);
    return await bcrypt.hash(password, salt);
  } catch (error) {
    throw new Error("Hashing failed", error);
  }
};
