const express = require("express");
const router = express.Router();
const { log: info, error: _error } = console;
const fs = require("fs");
const db = require("../../config/database");
const message = require("../../config/message");
const config = require("../../config");
const midleware = require("../../middleware/validation");
const Promise = require("bluebird");
const path = require("path");
const mt = require("media-thumbnail");
const multer = require("multer");
const moment = require("moment");
const DIR = "./public/temp";
const unlink = Promise.promisify(fs.unlink, fs);
var fse = require("fs-extra");
var ffmpeg = require("fluent-ffmpeg");
var spawn = require("child_process").spawn;
var AWS = require("aws-sdk");
var pdf = require("pdf-creator-node");
const cmethod = require("../../middleware/common-fun");
const auctionModel = require("../../modules/auction/auctionModal");
const auctionDao = require("../../modules/auction/auctionDao");
var mongoose = require("mongoose");
const {
  removeFileByPath,
  resizeImage,
} = require("../../functions/global.functions");
const { fileUpload } = require("../../utils/fileUpload");
const generateStickerPDF = require("../../pdf/sticker");
const { Lookup, Unwind } = require("../../functions/mongoose.functions");
// var s3 = new AWS.S3({
//   accessKeyId: "AKIAVZRLDQ4TV7U64C4M",
//   secretAccessKey: "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",
// });
// var s3 = new AWS.S3({
//   accessKeyId: "AKIAVZRLDQ4TVD64C2W2",
//   secretAccessKey: "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",
// });

var s3 = new AWS.S3({
  accessKeyId: process.env.AWS_ACCESSKEYID,
  secretAccessKey: process.env.AWS_SECRETACCESSKEY,
});
var aws_bucket = process.env.AWS_BUCKET;
let storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, DIR);
  },
  filename: (req, file, cb) => {
    cb(
      null,
      file.fieldname + "-" + Date.now() + path.extname(file.originalname)
    );
  },
  onError: function (err, next) {
    //console.log('error', err);
    //next(err);
    res.send({ status: false, message: message.filenotUpdate });
  },
});
let uploadsFile = multer({ storage: storage });
let uploads = {};

const fetchFilesFromReq = (req) => {
  if (req.file) {
    return [req.file];
  } else if (req.files) {
    return req.files;
  }
};

const uplaodfilesAWS = async (fileName, filePath, uploadPath, cType) => {
  let seq = new Date().getTime();
  let currentDate = new Date();
  return new Promise(function (resolve, reject) {
    if (
      uploadPath == "assets" ||
      uploadPath == "videos" ||
      uploadPath == "pdf"
    ) {
      uploadPath =
        uploadPath +
        "/" +
        currentDate.getFullYear() +
        "/" +
        (parseInt(currentDate.getMonth()) + 1) +
        "/" +
        currentDate.getDate();
    }
    const params = {
      Bucket: aws_bucket + "/" + uploadPath,
      Key: seq + "-" + String(fileName),
      Body: fs.createReadStream(filePath),
      ACL: "public-read",
      ContentType: cType,
    };
    s3.upload(params, function (s3Err, data) {
      if (s3Err) {
        reject(s3Err);
      } else {
        resolve(data);
      }
    });
  });
};

const uploadBase64ImageToS3 = (imageData, imageName) => {
  //const body = Buffer.from(imageData.split("base64")[1], "base64");
  var body = Buffer.from(
    imageData.replace(/^data:image\/\w+;base64,/, ""),
    "base64"
  );

  const ts = new Date().getTime();

  let seq = new Date().getTime();
  let currentDate = new Date();
  let cType = imageData.substring(
    imageData.indexOf(":") + 1,
    imageData.indexOf(";")
  ); // => image/png
  return new Promise(function (resolve, reject) {
    const params = {
      Bucket:
        aws_bucket +
        "/thumbnails/" +
        currentDate.getFullYear() +
        "/" +
        (parseInt(currentDate.getMonth()) + 1) +
        "/" +
        currentDate.getDate(),
      Key: seq + "-" + String("qrCode") + ".jpeg",
      //Body: Buffer.from(body, "base64"),
      Body: body,
      // ContentEncoding: "base64",
      ACL: "public-read",
      ContentType: "image/jpeg",
    };

    s3.upload(params, function (s3Err, data) {
      if (s3Err) {
        reject(s3Err);
      } else {
        resolve(data);
      }
    });
  });
};
const listObjectsInBucket = (bucketName) => {
  // Create the parameters for calling listObjects
  var bucketParams = {
    Bucket: bucketName,
  };
  return new Promise(function (resolve, reject) {
    // Call S3 to obtain a list of the objects in the bucket
    s3.listObjects(bucketParams, function (err, data) {
      if (err) {
        // console.log("Error", err);
        reject(err);
      } else {
        // console.log("Success", data);
        resolve(data);
      }
    });
  });
};
router.post("/folderList", [], (req, res) => {
  let lang = req.headers["lang"] || config.lang;
  listObjectsInBucket(aws_bucket)
    .then(function (data) {
      res.status(200).json({
        status: true,
        message: message[lang].imgUpload,
        result: data,
      });
    })
    .catch(function (error) {
      res
        .status(500)
        .json({ status: false, message: message[lang].technicalError });
    });
});
router.post("/image", uploadsFile.single("myFile"), function (req, res) {
  let lang = req.headers["lang"] || config.lang;
  if (req.file.mimetype.indexOf("image/") != -1) {
    let files = fetchFilesFromReq(req);
    let uploadPath = req.body?.folderPath;
    if (uploadPath == undefined) {
      uploadPath = "assets";
    }
    uplaodfilesAWS(
      files[0].filename,
      files[0].path,
      uploadPath,
      files[0].mimetype
    )
      .then(function (data) {
        fs.unlink(req.file.path, function (err) {});
        let object = { imgPath: data.Location };
        res.status(200).json({
          status: true,
          message: message[lang].imgUpload,
          result: object,
        });
      })
      .catch(function (error) {
        console.log(error);
        res
          .status(500)
          .json({ status: false, message: message[lang].technicalError });
      });
  } else {
    res.status(500).json({ status: false, message: message[lang].imgOnly });
  }
});
router.post("/file", uploadsFile.single("myFile"), function (req, res) {
  let lang = req.headers["lang"] || config.lang;
  let files = fetchFilesFromReq(req);
  let uploadPath = req.body?.folderPath;
  if (uploadPath == undefined) {
    uploadPath = "assets";
  }
  uplaodfilesAWS(
    files[0].filename,
    files[0].path,
    uploadPath,
    files[0].mimetype
  )
    .then(function (data) {
      fs.unlink(req.file.path, function (err) {});
      let object = { imgPath: data.Location };
      res.status(200).json({
        status: true,
        message: message[lang].imgUpload,
        result: object,
      });
    })
    .catch(function (error) {
      console.log(error);
      res
        .status(500)
        .json({ status: false, message: message[lang].technicalError });
    });
});

router.post("/video", uploadsFile.single("myFile"), function (req, res) {
  let lang = req.headers["lang"] || config.lang;
  if (req.file.mimetype.indexOf("video") != -1) {
    let files = fetchFilesFromReq(req);
    uplaodfilesAWS(
      files[0].filename,
      files[0].path,
      "videos",
      req.file.mimetype
    )
      .then(function (data) {
        fs.unlink(req.file.path, function (err) {});
        let object = { imgPath: data.Location };
        res.status(200).json({
          status: true,
          message: message[lang].imgUpload,
          result: object,
        });
      })
      .catch(function (error) {
        // console.log(error);
        res
          .status(500)
          .json({ status: false, message: message[lang].technicalError });
      });
  } else {
    res.status(500).json({ status: false, message: message[lang].imgOnly });
  }
});

router.post("/pdf", uploadsFile.single("myFile"), function (req, res) {
  let lang = req.headers["lang"] || config.lang;
  if (req.file.mimetype.indexOf("pdf") != -1) {
    let files = fetchFilesFromReq(req);
    uplaodfilesAWS(files[0].filename, files[0].path, "pdf", req.file.mimetype)
      .then(function (data) {
        fs.unlink(req.file.path, function (err) {});
        let object = { imgPath: data.Location };
        res.status(200).json({
          status: true,
          message: message[lang].imgUpload,
          result: object,
        });
      })
      .catch(function (error) {
        // console.log(error);
        res
          .status(500)
          .json({ status: false, message: message[lang].technicalError });
      });
  } else {
    res.status(500).json({ status: false, message: message[lang].imgOnly });
  }
});

router.post("/editor-image", uploadsFile.single("upload"), function (req, res) {
  let lang = req.headers["lang"] || config.lang;

  let files = fetchFilesFromReq(req);
  uplaodfilesAWS(
    files[0].filename,
    files[0].path,
    "thumbnails",
    req.file.mimetype
  )
    .then(function (data) {
      fs.unlink(req.file.path, function (err) {});
      let object = { imgPath: data.Location };
      let error = {};
      error.number = 201;
      error.message =
        "A file with the same name already exists. The uploaded file was renamed to \u0022print(1).png\u0022.";
      res.json({
        url: data.Location,
        fileName: files[0].filename,
        uploaded: 1,
      });
    })
    .catch(function (error) {
      // console.log(error);
      res
        .status(500)
        .json({ status: false, message: message[lang].technicalError });
    });
});

const createPdfUpload = async (data, filename) => {
  const filePath = process.cwd() + `/public/temp/${filename}.pdf`;

  const pdfPath = await generateStickerPDF(data, filePath);
  const uploadedFilePath = await uplaodfilesAWS(
    "mypdf.pdf",
    pdfPath,
    "pdf",
    "application/pdf"
  );

  return { imagePath: uploadedFilePath.Location };
};

router.post(
  "/create-pdf",
  [midleware.validateFieldValue([], [])],
  async (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let arrdata = [];
    let query = [];

    if (postData.auctionId) {
      query.push({
        $match: {
          $and: [{ auctionId: mongoose.Types.ObjectId(postData?.auctionId) }],
        },
      });
    }

    // * inventorys
    query.push({
      $lookup: {
        from: "inventorys",
        localField: "inventoryId",
        foreignField: "_id",
        as: "inventorys",
      },
    });
    query.push({
      $unwind: { path: "$inventorys", preserveNullAndEmptyArrays: true },
    });

    // * makes
    Lookup(query, "makes", "inventorys.make", "_id", "makes");
    Unwind(query, "$makes");

    // * models
    query.push({
      $lookup: {
        from: "models",
        localField: "inventorys.model",
        foreignField: "_id",
        as: "models",
      },
    });
    query.push({
      $unwind: { path: "$models", preserveNullAndEmptyArrays: true },
    });

    // * project
    query.push({
      $project: {
        auctionId: 1,
        inventoryId: 1,
        runNumber: 1,
        displayNo: 1,
        vin: "$inventorys.vin",
        make: "$makes.makeName",
        model: "$models.modelName",
        seriesId: "$inventorys.seriesId",
        engineId: "$inventorys.engineId",
        lotNo: "$inventorys.lotNo",
        year: "$inventorys.year",
        milage: "$inventorys.milage",
        startingBid: "$inventorys.startingBid",
      },
    });
    const sQuery = [...query];
    query.push({ $sort: { displayNo: 1 } });
    sQuery.push({ $count: "recordCount" });

    auctionDao.findAuctionvehicleAggregation(query).then(async function (data) {
      await createPdfUpload(data, "mypdf").then(async function (datas) {
        await auctionModel.Auction.updateOne(
          {
            _id: mongoose.Types.ObjectId(data[0]?.auctionId),
          },
          { $set: { pdfimgPath: datas?.imagePath } }
        );
        cmethod.returnSuccess(res, datas, false, "Created Successfully");
      });
    });
    // var auctionData = await auctionModel.Auctionvehicle.find(query, {
    //   auctionId: 1, inventoryId: 1, runNumber: 1
    // }).sort({ createdAt: -1 });
    // //

    //console.log("---------->", auctionData);
    return false;

    if (auctionData.length > 0) {
      for (var i = 0; i < auctionData.length; i++) {
        arrdata.push({ name: auctionData[i].title });
      }
    }
    //}

    //console.log("---------->", arrdata); //return false;
    // var users = [
    //   {
    //     name: "Shyam",
    //     age: "26",
    //   },
    //   {
    //     name: "Navjot",
    //     age: "26",
    //   },
    //   {
    //     name: "Vitthal",
    //     age: "26",
    //   },
    //   {
    //     name: "Vitthal1",
    //     age: "26",
    //   },
    //   {
    //     name: "Vitthal2",
    //     age: "26",
    //   },
    //   {
    //     name: "Vitthal3",
    //     age: "26",
    //   },
    //   {
    //     name: "Vitthal4",
    //     age: "26",
    //   },
    //   {
    //     name: "Vitthal5",
    //     age: "26",
    //   },
    //   {
    //     name: "Vitthal6",
    //     age: "26",
    //   },
    // ];
    //let url = createPdfUpload(arrdata, 'mypdf')
    //cmethod.returnSuccess(res, url, false, "Created Successfully");
  }
);

router.post("/image_resizing", fileUpload.single("file"), async (req, res) => {
  try {
    const {
      file,
      body: { folderPath },
      headers: { lang = config.lang },
    } = req;

    const uploadPath = folderPath || "assets";

    const { path: imagePath, originalname: imageName, mimetype } = file;
    const { resizedImagesOutputDirectory: outputDir } = config;

    const resizedImagePaths = await resizeImage(imagePath, outputDir);

    const imagePaths = await uploadFilesToAWS(
      imageName,
      resizedImagePaths,
      uploadPath,
      mimetype
    );

    res.status(200).json({
      status: true,
      message: message[lang].imgUpload,
      result: imagePaths,
    });
  } catch (error) {
    _error("Error processing the image:", error);

    const {
      headers: { lang = config.lang },
    } = req;

    res
      .status(500)
      .json({ status: false, message: message[lang].technicalError });
  }
});

const uploadFileToAWS = async (
  image,
  time,
  imageName,
  uploadPath,
  contentType
) => {
  return new Promise((resolve, reject) => {
    const { path: imagePath, size } = image;

    const { name, ext } = path.parse(imageName);
    const fileName = `${name}-${time}-${size}${ext}`;
    const fileStream = fs.createReadStream(imagePath);

    const params = {
      Bucket: aws_bucket + `/${uploadPath}`,
      Key: String(fileName),
      Body: fileStream,
      ACL: "public-read",
      ContentType: contentType,
    };

    s3.upload(params, (err, data) => {
      if (err) {
        _error("Error uploading image to S3:", err);
        reject(err);
      } else {
        info("Image uploaded to S3:", data.Location);
        removeFileByPath(imagePath);
        resolve(data.Location);
      }
    });
  });
};

const uploadFilesToAWS = async (imageName, images, uploadPath, contentType) => {
  const awsImagePaths = [];
  const today = moment().format("YYYY/MM/DD");
  const time = moment().valueOf();
  uploadPath = `${uploadPath}/${today}`;

  for (const image of images) {
    try {
      const awsImagePath = await uploadFileToAWS(
        image,
        time,
        imageName,
        uploadPath,
        contentType
      );

      awsImagePaths.push(awsImagePath);
    } catch (error) {
      _error("Error uploading file:", error);
    }
  }

  return awsImagePaths;
};

module.exports = router;
module.exports.uploadBase64ImageToS3 = uploadBase64ImageToS3;

/**
 * @swagger
 * /api/upload/file:
 *   post:
 *     tags: [Uploads]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: folderPath
 *         in: formData
 *         type: String
 *         required: false
 *         description:
 *            ex- assets/vehicle/1111
 *       - name: myFile
 *         in: formData
 *         type: file
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: Reciepts.
 *
 */

/**
 * @swagger
 * /api/upload/folderList:
 *   post:
 *     tags: [Uploads]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: folderName
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *     responses:
 *       200:
 *         description: Reciepts.
 *
 */
/**
 * @swagger
 * /api/upload/create-pdf:
 *   post:
 *     tags: [Uploads]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: auctionId
 *         in: formData
 *         type: String
 *         required: false
 *         description:
 *       - name: folderPath
 *         in: formData
 *         type: String
 *         required: false
 *         description:
 *     responses:
 *       200:
 *         description: create-pdf.
 *
 */

/**
 * @swagger
 * /api/upload/image_resizing:
 *   post:
 *     tags: [Uploads]
 *     consumes:
 *       - multipart/form-data
 *     parameters:
 *       - name: file
 *         in: formData
 *         type: file
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: Uploads - Image Resizing
 *
 */
