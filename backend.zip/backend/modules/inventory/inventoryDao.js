const inventory = require("../inventory/inventoryModal");
const masterModal = require("../master/masterModal");
const userModal = require("../user/userModal");
const vinModal = require("../vin/vinModal");
const message = require("../../config/message");
const jwt = require("jsonwebtoken");
const config = require("../../config");
const midleware = require("../../middleware/validation");
// const Promise = require("bluebird");
const cmethod = require("../../middleware/common-fun");
// const moment = require("moment");
// var axios = require('axios');
// const { sendThirdPartyOtp } = require("../import/thirdParty");
// const {
//   storeHash,
//   getHash,
//   encrypt,
//   deleteHash,
//   customDelete,
//   deleteUser,
// } = require("../../middleware/redisConnection");
var mongoose = require("mongoose");
const { connWrite } = require("./../../config/database");
const {
  todayDate,
  makeObjectId,
  isArrayWithLength,
} = require("../../functions/global.functions");
const { createInspection } = require("../../services/inspection.service");

const existMaster = async function (getParams) {
  let remarksArr = [];

  if (typeof getParams.make !== "undefined") {
    let makeval = getParams.make;
    makeval = makeval.trim();
    let chkmakeName = {
      makeName: { $regex: new RegExp(`^${makeval}$`), $options: "i" },
    };

    let makeData = await masterModal.Make.findOne(chkmakeName, { makeName: 1 });

    if (makeData) {
      getParams.make = makeData._id;
    } else {
      remarksArr.push(getParams.make + " make Not available in master");
      getParams.make = null;
    }
  } else {
    remarksArr.push(" Make field required");
  }

  if (typeof getParams.model !== "undefined") {
    let chkmodelName = {
      modelName: { $regex: new RegExp(`^${getParams.model}$`), $options: "i" },
    };

    let modelData = await masterModal.Model.findOne(chkmodelName, {
      modelName: 1,
    });
    if (modelData) {
      getParams.model = modelData._id;
    } else {
      remarksArr.push(getParams.model + " model Not available in master");
      getParams.model = null;
    }
  } else {
    remarksArr.push(" Model field required");
  }

  if (typeof getParams.series !== "undefined") {
    let seriesNameval = getParams.series;
    seriesNameval = seriesNameval.trim();
    let chkseriesName = {
      $and: [
        {
          seriesName: {
            $regex: new RegExp(`^${seriesNameval}$`),
            $options: "i",
          },
        },
      ],
    };

    let seriesData = await masterModal.Series.findOne(chkseriesName, {
      seriesName: 1,
    });
    if (seriesData) {
      getParams.series = seriesData._id;
    } else {
      getParams.series = null;
    }
  } else {
    remarksArr.push(" series field required");
  }

  if (typeof getParams.engine !== "undefined") {
    let engineData = await masterModal.Engines.findOne(
      { engineName: getParams.engine },
      { engineName: 1 }
    );
    if (engineData) {
      getParams.engine = engineData._id;
    } else {
      getParams.engine = null;
    }
  } else {
  }

  if (typeof getParams.year !== "undefined") {
    if (Number(getParams.year)) {
      getParams.year = Number(getParams.year);
    } else {
      remarksArr.push(getParams.year + " year is not valid");
    }
  } else {
    remarksArr.push("  year field required");
  }
  if (typeof getParams.reserve_price !== "undefined") {
    getParams.reserve_price = getParams.reserve_price;
  } else {
    remarksArr.push(" reserve_price field required");
  }

  if (getParams.interior_color) {
    let colorNameval = getParams.interior_color;
    colorNameval = colorNameval.trim();
    let chkinteriorcolorName = {
      $or: [
        {
          colorName: { $regex: new RegExp(`^${colorNameval}$`), $options: "i" },
        },
      ],
    };
    let interiorcolorData = await masterModal.interiorColor.findOne(
      chkinteriorcolorName,
      { colorName: 1 }
    );
    if (interiorcolorData) {
      getParams.interior_color = interiorcolorData._id;
    } else {
      getParams.interior_color = null;
    }
  }

  if (getParams.exterior_color) {
    let colorNameval = getParams.exterior_color;
    colorNameval = colorNameval.trim();
    let chkexteriorcolorName = {
      $or: [
        {
          colorName: { $regex: new RegExp(`^${colorNameval}$`), $options: "i" },
        },
      ],
    };
    let exteriorcolorData = await masterModal.exteriorColor.findOne(
      chkexteriorcolorName,
      { colorName: 1 }
    );
    if (exteriorcolorData) {
      getParams.exterior_color = exteriorcolorData._id;
    } else {
      getParams.exterior_color = null;
    }
  }

  if (getParams.body) {
    let bodyNameval = getParams.body;
    bodyNameval = bodyNameval.trim();
    let chkbodyIdName = {
      $or: [
        { bodyName: { $regex: new RegExp(`^${bodyNameval}$`), $options: "i" } },
      ],
    };

    let bodyData = await masterModal.Bodys.findOne(chkbodyIdName, {
      bodyName: 1,
    });
    if (bodyData) {
      getParams.body = bodyData._id;
    } else {
      getParams.body = null;
    }
  }

  if (getParams.drive_type) {
    let drivetypeNameval = getParams.drive_type;
    drivetypeNameval = drivetypeNameval.trim();
    let chkdrivetypeName = {
      $or: [
        {
          drivetypeName: {
            $regex: new RegExp(`^${drivetypeNameval}$`),
            $options: "i",
          },
        },
      ],
    };

    let drivetypeData = await masterModal.Drivetype.findOne(chkdrivetypeName, {
      bodyName: 1,
    });
    if (drivetypeData) {
      getParams.drive_type = drivetypeData._id;
    } else {
      getParams.drive_type = null;
    }
  }

  if (getParams.fuel_type) {
    let fueltypeNameval = getParams.fuel_type;
    fueltypeNameval = fueltypeNameval.trim();
    let chkfueltypeIdName = {
      $or: [
        {
          fueltypeName: {
            $regex: new RegExp(`^${fueltypeNameval}$`),
            $options: "i",
          },
        },
      ],
    };
    let fueltypeData = await masterModal.Fueltypes.findOne(chkfueltypeIdName, {
      fueltypeName: 1,
    });
    if (fueltypeData) {
      getParams.fuel_type = fueltypeData._id;
    } else {
      getParams.fuel_type = null;
    }
  }

  if (getParams.vin) {
    let vinResponse = await cmethod.checkVinNoWithStatus(getParams.vin);
    if (vinResponse?.status) {
      getParams.duplicatetemp = 1;
      remarksArr.push(vinResponse?.message);
    }
  }
  if (getParams.vin) {
    let vinResponse = await cmethod.vinnosixDigit(getParams.vin);

    if (vinResponse) {
      getParams.vin = getParams.vin;
    } else {
      remarksArr.push("Vin no should be 17 digit@.");
    }
  }
  return [{ getParams: getParams, remarksArr: remarksArr }];
};

const inventorypassAdd = async function (res, postData) {
  let passNoUnique3 = await cmethod.getPassNo();
  const newInventory = new inventory.Getpass(postData);
  newInventory.referenceType = "inventory";
  newInventory.passNo = passNoUnique3;
  newInventory.save(postData, async function (err, data) {
    if (err) {
      cmethod.returnSreverError(res, message.technicalError, err);
    } else {
      //--------------------update branchid & warehouseid on basis of  inventorid
      //console.log('inventorypassAdd----------------',postData); return false;
      await inventory.Inventory.findOneAndUpdate(
        { _id: postData?.inventoryId },
        {
          $set: {
            branchId: mongoose.Types.ObjectId(postData?.branchId),
            warehosId: mongoose.Types.ObjectId(postData?.warehosId),
            getpassissue: 1,
          },
        }
      );
      cmethod.returnSuccess(res, data, false, message.signupsuccess);
    }
  });
};
const inventoryAdd = async function (res, postData) {
  //console.log('22=======>>>>>>>>>', postData.inventcopy); return false;
  // postData.vin = await cmethod.vinnosixDigit(postData?.vin);
  if (postData.status == "pending" || postData.status == "document verify") {
    postData.inventoryStatus = 0;
    postData.inventoryType = config.inventoryTypes.INDIRECT;
  }
  if (postData?.status == "approved") {
    postData.getpassissue = 1;
    postData.inventoryStatus = 0;
    postData.inventoryType = config.inventoryTypes.DIRECT;
  }
  //console.log('=========>', postData); return false;
  const newInventory = new inventory.Inventory(postData);

  newInventory.save(postData, async function (err, data) {
    if (err) {
      cmethod.returnSreverError(res, message.technicalError, err);
    } else {
      if (postData?.status == "approved") {
        let passNoUnique = await cmethod.getPassNo();
        let savegetPassData = {
          passNo: passNoUnique,
          direction: "in",
          //referenceId: "",
          referenceType: "inventory",
          referenceNo: postData.vin,
          inventoryId: mongoose.Types.ObjectId(data?._id),
          status: "pending",
          gatePassExpired: todayDate(),
          createdBy: "system",
        };
        //console.log("getpass============>>>>>",savegetPassData);
        await cmethod.addgetPass(savegetPassData);

        let docNoUnique = await cmethod.getDocumentpass();
        let savegetDocumentData = {
          passNo: docNoUnique,
          direction: "in",
          //referenceId: "",
          referenceType: "inventory",
          referenceNo: postData.vin,
          status: "pending",
          inventoryId: mongoose.Types.ObjectId(data?._id),
          branchId: mongoose.Types.ObjectId(data?.branchId),
          warehosId: mongoose.Types.ObjectId(data?.warehosId),
          createdBy: "system",
        };
        //console.log("getdoc============>>>>>",savegetDocumentData);
        await cmethod.addgetDocument(savegetDocumentData);
      }

      /* let index = await uModal.User.find({"_id": { "$lte" : mongoose.Types.ObjectId(data._id)}}).count()
          await deleteUser(index) */
      /*add inventory images */
      let allImages = postData?.images;
      if (
        (postData?.images && allImages.length > 0) ||
        isArrayWithLength(postData?.sellerInventoryImages)
      ) {
        let insertImages = [];
        if (isArrayWithLength(postData?.images)) {
          allImages.forEach((value, index) => {
            if (index == 0) {
              insertImages.push({
                imageType: "inventory",
                referenceId: mongoose.Types.ObjectId(data._id),
                image: value,
                type: "carimage",
                defaultimage: 1,
              });
            } else {
              insertImages.push({
                imageType: "inventory",
                referenceId: mongoose.Types.ObjectId(data._id),
                image: value,
                type: "carimage",
              });
            }
          });
        }

        if (isArrayWithLength(postData?.sellerInventoryImages)) {
          postData?.sellerInventoryImages.forEach((value, index) => {
            insertImages.push({
              imageType: "inventory",
              referenceId: data._id,
              image: value,
              type: "seller-car-image",
              ...(index === 0 && { defaultimage: 1 }),
            });
          });
        }
        //type : cardocumnet
        if (data?.vccDoc) {
          insertImages.push({
            imageType: "inventory",
            referenceId: mongoose.Types.ObjectId(data._id),
            image: data?.vccDoc,
            type: "cardocumnet",
          });
        }
        if (data?.purchaseDoc) {
          insertImages.push({
            imageType: "inventory",
            referenceId: mongoose.Types.ObjectId(data._id),
            image: data?.purchaseDoc,
            type: "cardocumnet",
          });
        }
        if (data?.mulkiya) {
          insertImages.push({
            imageType: "inventory",
            referenceId: mongoose.Types.ObjectId(data._id),
            image: data?.mulkiya,
            type: "cardocumnet",
          });
        }
        if (data?.hayaza) {
          insertImages.push({
            imageType: "inventory",
            referenceId: mongoose.Types.ObjectId(data._id),
            image: data?.hayaza,
            type: "cardocumnet",
          });
        }
        await vinModal.Vinimage.insertMany(insertImages);
      }
      /*add inventory images */
      let saveCommentLogData = {
        referenceType: "inventory",
        referenceId: mongoose.Types.ObjectId(data?._id),
        message: "Inventory created by " + postData?.createdBy,
        commentBy: postData?.createdBy,
      };
      cmethod.addcommentsLog(saveCommentLogData);
      //------------------add reserve price---------------------
      if (postData.status == "document verify") {
        let reservepricedata = {
          inventoryId: mongoose.Types.ObjectId(data?._id),
          acaOffer: 0,
          sellerOffer: postData?.reservePrice ? postData?.reservePrice : 0,
          acaStatus: 0,
          sellerStatus: 1,
          acaofferDate: new Date(),
          sellerofferDate: new Date(),
        };
        //const reseverInventory = new inventory.Reseverprice(reservepricedata);
        //reseverInventory.save(reservepricedata, async function (err, data) { })

        const reseverInventory = await new inventory.Reseverprice(
          reservepricedata
        );
        const reseverInventorys = await reseverInventory.save(reservepricedata);
      }
      if (data.inventoryStatus == 0) {
        await addcarPlan(data?._id);
      }

      if (postData.inventcopy == "inventcopy") {
        //console.log("inventcopy============>>>>>inventcopy");
        await inventory.Getpass.updateOne(
          { inventoryId: mongoose.Types.ObjectId(data?._id) },
          { $set: { status: "out of stock" } }
        );
        await inventory.Getdocument.updateOne(
          { inventoryId: mongoose.Types.ObjectId(data?._id) },
          { $set: { status: "given" } }
        );
      }

      const inspection = {
        inventoryId: makeObjectId(data?._id),
      };
      await createInspection(inspection);

      cmethod.returnSuccess(res, data, false, message.signupsuccess);
    }
  });
};

const findInventoryWithFiled = async function (query) {
  // const yyyy=inventory.Inventory.find(query);
  // console.log("jjj==========",yyyy);
  //return false;
  return new Promise(function (resolve, reject) {
    inventory.Inventory.find(
      { costPrice: { $exists: true } },
      { make: 1, model: 1 },
      function (err, data) {
        if (err) {
          reject(err);
        } else {
          resolve(data);
        }
      }
    );
  });
};
const findInventoryAggregation = function (query) {
  return new Promise(function (resolve, reject) {
    inventory.Inventory.aggregate(query, function (err, data) {
      if (err) {
        reject(err);
      } else {
        resolve(data);
      }
    });
  });
};
const findInventoryTempAggregation = function (query) {
  return new Promise(function (resolve, reject) {
    inventory.Inventorytemps.aggregate(query, function (err, data) {
      if (err) {
        reject(err);
      } else {
        resolve(data);
      }
    });
  });
};
const checkUniqueVin = async function (query) {
  return new Promise(function (resolve, reject) {
    inventory.Inventory.find(query, function (err, data) {
      if (data.length > 0) {
        resolve("exist");
      } else {
        resolve("notexist");
      }
    });
  });
};
const checkUniqueInventory = async function (query) {
  return new Promise(function (resolve, reject) {
    inventory.Carwisesellerplan.find(query, function (err, data) {
      if (data.length > 0) {
        resolve("exist");
      } else {
        resolve("notexist");
      }
    });
  });
};

const checkwatchlist = async function (query) {
  return new Promise(function (resolve, reject) {
    inventory.Watchlist.find(query, function (err, data) {
      if (data.length > 0) {
        resolve(true);
      } else {
        resolve(false);
      }
    });
  });
};
const findGetPassAggregation = function (query) {
  return new Promise(function (resolve, reject) {
    inventory.Getpass.aggregate(query, function (err, data) {
      if (err) {
        reject(err);
      } else {
        resolve(data);
      }
    });
  });
};
const findGetDocumentAggregation = function (query) {
  return new Promise(function (resolve, reject) {
    inventory.Getdocument.aggregate(query, function (err, data) {
      if (err) {
        reject(err);
      } else {
        resolve(data);
      }
    });
  });
};
const inventorytransferadd = async function (res, postData) {
  let errorData = [];
  let insertData = [];
  // if (postData.status) {
  //   postData.status = "transfer";
  // } else {
  //   postData.status = "Pending";
  // }

  //   postData = [
  //     {
  //         fromBranch: "640e235b00b462b7e05a006a",
  //         fromWarehouse: "640ee9222e6dbb9991b20e95",
  //         toBranch: "640ec8a8e979987820b80f7b",
  //         toWarehouse: "640ee9432e6dbb9991b20ea1",
  //         inventoryId: ["6421c16c12180c395a7d3134","641cbff3dd53762c1a6438fa"],
  //         recoveryNo: ["12345","6789"],
  //         filePath: ["abc.png","def.jpg"],
  //         createdBy: "washi",
  //         //status: postData.status
  //     }
  // ]

  //-------------------------------------------------------------
  if (postData[0].inventoryId.length) {
    for (var i = 0; i < postData[0].inventoryId.length; i++) {
      insertData.push({
        fromBranch: mongoose.Types.ObjectId(postData[0].fromBranch),
        fromWarehouse: mongoose.Types.ObjectId(postData[0].fromWarehouse),
        toBranch: mongoose.Types.ObjectId(postData[0].toBranch),
        toWarehouse: mongoose.Types.ObjectId(postData[0].toWarehouse),
        inventoryId: mongoose.Types.ObjectId(postData[0].inventoryId[i]),
        recoveryNo: postData[0].recoveryNo[i],
        filePath: postData[0].filePath[i],
        createdBy: postData[0].createdBy,
        status: postData[0].status, //"transfer"
      });
    }
  } else {
    let error = "row " + i + " inventoryId data not correct or invalid";
    errorData.push({
      error: error,
    });
  }
  let transvertype = postData[0].transverType;
  //console.log('inventorytransferadd------------->>>>',transvertype);
  //----------------------------------------------------------------------------
  if (insertData.length > 0) {
    inventory.Inventorytransfer.insertMany(insertData, async (err, data) => {
      if (err) {
        // console.log(err);
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      } else {
        for (var i = 0; i < data.length; i++) {
          await inventory.Inventory.findOneAndUpdate(
            { _id: data[i].inventoryId },
            {
              $set: {
                branchId: data[i].toBranch,
                warehosId: data[i].toWarehouse,
              },
            }
          );
          // if (transvertype == "fromgatepass") {
          //   // Add get pass
          //   let passNoUnique = await cmethod.getPassNo();
          //   let savegetPassData = {
          //     passNo: passNoUnique,
          //     direction: "internal Transfer",
          //     referenceType: "inventory",
          //     inventoryId: mongoose.Types.ObjectId(data[i]?.inventoryId),
          //     status: "pending",
          //     createdBy: data[i]?.createdBy,
          //   }
          //   await cmethod.addgetPass(savegetPassData);
          // }
        }

        //-----------------------------------------------------------

        cmethod.returnSuccess(res, data, false, message.signupsuccess);
      }
    });
  } else {
    cmethod.returnSreverError(res, "Inventory is blank");
  }
};
const documenttransferadd = async function (res, postData) {
  const documentTransfer = new inventory.DocumentTransfer(postData);
  documentTransfer.save(postData, async function (err, data) {
    if (err) {
      cmethod.returnSreverError(res, message.technicalError, err);
    } else {
      //add transfer id in getdocument page
      await inventory.Getdocument.findOneAndUpdate(
        { _id: postData?.documentId },
        {
          $set: {
            transferId: mongoose.Types.ObjectId(data._id),
            status: "inTransit",
          },
        }
      );
      cmethod.returnSuccess(res, data, false, message.signupsuccess);
    }
  });
};
const inventoryInternaltransferadd = async function (res, postData) {
  const internalTransfer = new inventory.Inventorytransfer(postData);
  internalTransfer.save(postData, async function (err, data) {
    if (err) {
      cmethod.returnSreverError(res, message.technicalError, err);
    } else {
      //--------------------save data in vin image-------------//
      if (postData?.filePath) {
        let inventtransImage = {
          imageType: "inventory",
          referenceId: mongoose.Types.ObjectId(data.inventoryId),
          image: postData?.filePath,
          type: "inventorytransfertype",
        };
        await vinModal.Vinimage.insertMany(inventtransImage);
      }

      await inventory.Inventory.findOneAndUpdate(
        { _id: mongoose.Types.ObjectId(data.inventoryId) },
        {
          $set: {
            transferId: mongoose.Types.ObjectId(data._id),
            ...(postData?.keyNo && { keyNo: postData?.keyNo }),
          },
        }
      );
      cmethod.returnSuccess(res, data, false, message.signupsuccess);
    }
  });
};
const findInventoryTransferAggregation = function (query) {
  return new Promise(function (resolve, reject) {
    inventory.Inventorytransfer.aggregate(query, function (err, data) {
      if (err) {
        reject(err);
      } else {
        resolve(data);
      }
    });
  });
};
const findDocumentTransferAggregation = function (query) {
  return new Promise(function (resolve, reject) {
    inventory.DocumentTransfer.aggregate(query, function (err, data) {
      if (err) {
        reject(err);
      } else {
        resolve(data);
      }
    });
  });
};
const watchlistAdd = async function (res, postData) {
  const newwatchlist = new inventory.Watchlist(postData);
  newwatchlist.save(postData, async function (err, data) {
    if (err) {
      cmethod.returnSreverError(res, message.technicalError, err);
    } else {
      cmethod.returnSuccess(res, data, false, message.signupsuccess);
    }
  });
};
const findWatchlistAggregation = function (query) {
  return new Promise(function (resolve, reject) {
    inventory.Watchlist.aggregate(query, function (err, data) {
      if (err) {
        reject(err);
      } else {
        resolve(data);
      }
    });
  });
};
const findAddreseverpriceAggregation = function (query) {
  return new Promise(function (resolve, reject) {
    inventory.Reseverprice.aggregate(query, function (err, data) {
      if (err) {
        reject(err);
      } else {
        resolve(data);
      }
    });
  });
};
const findCarwiseplanlistAggregation = function (query) {
  return new Promise(function (resolve, reject) {
    inventory.Carwisesellerplan.aggregate(query, function (err, data) {
      if (err) {
        reject(err);
      } else {
        resolve(data);
      }
    });
  });
};
const findSellermappingbranchAggregation = function (query) {
  return new Promise(function (resolve, reject) {
    inventory.Sellermappingbranch.aggregate(query, function (err, data) {
      if (err) {
        reject(err);
      } else {
        resolve(data);
      }
    });
  });
};
const addreseverPrice = async function (res, postData) {
  const reseverInventory = new inventory.Reseverprice(postData);
  reseverInventory.save(postData, async function (err, data) {
    if (err) {
      cmethod.returnSreverError(res, message.technicalError, err);
    } else {
      let setData = {};
      if (data?.acaOffer) {
        setData["reservePrice"] = data?.acaOffer;
      }
      if (data?.sellerOffer) {
        setData["reservePrice"] = data?.sellerOffer;
      }
      if (postData?.counterStatus) {
        setData["counterStatus"] = postData?.counterStatus;
      }
      await inventory.Inventory.updateOne(
        { _id: mongoose.Types.ObjectId(data?.inventoryId) },
        { $set: setData }
      );
      cmethod.returnSuccess(res, data, false, message.signupsuccess);
    }
  });
};

const addcarPlan = async function (inventryId) {
  //console.log('gupta1------------->>>>>>', inventryId);
  //inventryId = "648b4390a5dec05afb9d97a8";
  let inventdata = {
    _id: mongoose.Types.ObjectId(inventryId),
  };
  let chkinventryData = await inventory.Inventory.findOne(inventdata, {
    sellerId: 1,
    branchId: 1,
  });
  //console.log('gupta2------------->>>>>>', chkinventryData);
  if (chkinventryData) {
    let invenquery = {
      $and: [
        {
          inventoryId: mongoose.Types.ObjectId(inventryId),
          sellerId: mongoose.Types.ObjectId(chkinventryData.sellerId),
        },
      ],
    };

    let checkUniques = await checkUniqueInventory(invenquery);
    // console.log('gupta3------------->>>>>>', checkUniques);
    if (checkUniques == "exist") {
      console.log("dublicate data");
      return;
    } else {
      // let sellerdata1 = {
      //   _id: mongoose.Types.ObjectId(chkinventryData.sellerId)
      // };
      //let plandata2 = await userModal.User.findOne(sellerdata, { planId: 1 });

      let sellerdata = {
        $and: [
          {
            branchId: mongoose.Types.ObjectId(chkinventryData.branchId),
            sellerId: mongoose.Types.ObjectId(chkinventryData.sellerId),
          },
        ],
      };

      //let plandata2 = await findCarwiseplanlistAggregation(sellerdata);
      let plandata2 = await inventory.Sellermappingbranch.findOne(sellerdata, {
        planId: 1,
      });
      //------------------------sellermappingbranchs-------------------sellerId,branchId //sellerId,branchId

      //console.log('plandata2------------->', plandata2);

      if (plandata2) {
        let plandata = {
          _id: mongoose.Types.ObjectId(plandata2.planId),
        };
        let plandatas = await masterModal.Sellerplan.findOne(plandata);

        let insertData = {
          inventoryId: mongoose.Types.ObjectId(inventryId),
          sellerId: mongoose.Types.ObjectId(chkinventryData?.sellerId),
          branchId: mongoose.Types.ObjectId(plandatas?.branchId),
          planName: plandatas?.planName,
          listingFee: plandatas?.listingFee,
          runs: plandatas?.runs,
          auctionTypeFee: plandatas?.auctionTypeFee,
          increment: plandatas?.increment,
          amountValue: plandatas?.amountValue,
          status: plandatas?.status,
          parkingDays: plandatas?.parkingDays,
          storage: plandatas?.storage,
          initialfee: plandatas?.initialfee,
        };
        const insertcardata = await new inventory.Carwisesellerplan(insertData);
        const insertcarwisedata = await insertcardata.save(insertData);
        //----------------------------update inventoryPlanId------------------------------------------------
        if (insertcarwisedata) {
          let conplanid = {
            _id: mongoose.Types.ObjectId(chkinventryData.sellerId),
          };
          let plandatadata = await userModal.User.findOne(conplanid, {
            planId: 1,
          });
          //console.log('plandatadata------------->', plandatadata);
          await inventory.Inventory.findOneAndUpdate(
            { _id: insertcarwisedata?.inventoryId },
            {
              $set: {
                inventoryPlanId: mongoose.Types.ObjectId(plandatadata?.planId),
              },
            }
          );
        }

        console.log("insert data data");
      }
    }
  }
};
const sellermappingbranchAdd = async function (res, postData) {
  let branchIds = postData?.branchIds;
  let planIds = postData?.planIds;
  let sellerId = postData?.sellerId;
  if (branchIds.length > 0) {
    for (var i = 0; i < branchIds.length; i++) {
      let dbPlanData = await inventory.Sellermappingbranch.findOne(
        {
          sellerId: mongoose.Types.ObjectId(sellerId),
          branchId: mongoose.Types.ObjectId(branchIds[i]),
        },
        { planId: 1 }
      );
      if (dbPlanData) {
        await inventory.Sellermappingbranch.updateOne(
          { _id: mongoose.Types.ObjectId(dbPlanData?._id) },
          { $set: { planId: mongoose.Types.ObjectId(planIds[i]) } }
        );
      } else {
        let newPlanData = {
          sellerId: mongoose.Types.ObjectId(sellerId),
          planId: mongoose.Types.ObjectId(planIds[i]),
          branchId: mongoose.Types.ObjectId(branchIds[i]),
        };
        const newPlanDataLog = new inventory.Sellermappingbranch(newPlanData);
        const addCommentsData = await newPlanDataLog.save(newPlanData);

        //impement exixting car plan
        let queryCond2 = {
          $and: [
            { sellerId: mongoose.Types.ObjectId(sellerId), inventoryStatus: 1 },
          ],
        };
        let inventoryData2 = await inventory.Inventory.find(queryCond2, {
          inventoryStatus: 1,
        });
        for (var i = 0; i < inventoryData2.length; i++) {
          await addcarPlan(inventoryData2[i]._id); // common function used karana
        }
      }
      await userModal.User.findOneAndUpdate(
        { _id: mongoose.Types.ObjectId(sellerId) },
        { $set: { planId: mongoose.Types.ObjectId(planIds[i]) } }
      );
    }
  }
  cmethod.returnSuccess(res, [], false, message.signupsuccess);
};
module.exports = {
  existMaster,
  checkUniqueVin,
  inventoryAdd,
  findInventoryWithFiled,
  findInventoryAggregation,
  findInventoryTempAggregation,
  findGetPassAggregation,
  findGetDocumentAggregation,
  inventorytransferadd,
  inventoryInternaltransferadd,
  findInventoryTransferAggregation,
  checkwatchlist,
  watchlistAdd,
  findWatchlistAggregation,
  addreseverPrice,
  findAddreseverpriceAggregation,
  checkUniqueInventory,
  inventorypassAdd,
  addcarPlan,
  findCarwiseplanlistAggregation,
  sellermappingbranchAdd,
  findSellermappingbranchAggregation,
  documenttransferadd,
  findDocumentTransferAggregation,
};
