const express = require("express");
const router = express.Router();
const inventoryModal = require("../inventory/inventoryModal");
const masterModal = require("../master/masterModal");
const recieptModal = require("../reciept/recieptModal");
const saleRecieptModal = require("../saleReciept/saleRecieptModal");
const userModal = require("../user/userModal");
const vinModal = require("../vin/vinModal");
const account = require("../account/accountModal");
const message = require("../../config/message");
//const jwt = require("jsonwebtoken");
const config = require("../../config");
const midleware = require("../../middleware/validation");
//const Promise = require("bluebird");
const cmethod = require("../../middleware/common-fun");
//const moment = require("moment");
const intventoryDao = require("./inventoryDao");
//const axios = require("axios");
var mongoose = require("mongoose");
//const { update } = require("lodash");
//const categroyModel = require("../category/categoryModal");
//const eventModal = require("../event/eventModal");
//const XLSX = require("xlsx");
//const json2xls = require("json2xls");
//const fs = require("fs");
const http = require("http");
const { dirname } = require("path");
const path = require("path");
const { count, log } = require("console");
const QRCode = require("qrcode");
const { fileUpload } = require("../../utils/fileUpload");
const {
  parseCSVFile,
  fileCleaner,
  makeObjectId,
  checkBoolean,
  todayDate,
  makeObjectIds,
  isArrayWithLength,
} = require("../../functions/global.functions");
const {
  makeInventoryRelatedCopies,
  updateCarWisePlanWithInventoryId,
  withdrawInventory,
} = require("../../services/inventory.service");
const { deleteHash } = require("../../middleware/redisConnection");
const { Auctionvehicle } = require("../auction/auctionModal");
const logger = require("../../config/logger");
const {
  NotNullMatch,
  ExactMatch,
  LookupWithPipeline,
  Unwind,
  Lookup,
  InMatch,
  AddFields,
  RegexMatch,
} = require("../../functions/mongoose.functions");
const {
  DeleteOne,
  FindByIdWithKey,
  MultiAggregate,
  Count,
  DeleteById,
} = require("../../models/factory");
const {
  createInspection,
  updateInspection,
} = require("../../services/inspection.service");
const {
  createComment,
  getComment,
  updateComment,
} = require("../../services/comment.service");
//var singleBaseUrl = process.env.CARS_IMAGE_URL;
//const excel = require("exceljs");
// const {
//   storeHash,
//   getHash,
//   encrypt,
//   deleteHash,
//   customDelete,
//   deleteUser,
// } = require("../../middleware/redisConnection");
// const RedisMiddleware = require("../../middleware/redisMiddleware");
//const { object } = require("@hapi/joi");
//const NodeRSA = require('node-rsa');
//var CryptoJS = require("crypto-js");

router.post("/list", async (req, res) => {
  const {
    body: postData,
    headers: { lang = config.lang },
  } = req;

  const query = [];

  try {
    // * createdAt
    if (postData.fromDate && postData.toDate) {
      query.push({
        $match: {
          $and: [
            {
              createdAt: {
                $gte: new Date(
                  cmethod.startTimeString(new Date(postData.fromDate))
                ),
              },
            },
            {
              createdAt: {
                $lte: new Date(
                  cmethod.endTimeString(new Date(postData.toDate))
                ),
              },
            },
          ],
        },
      });
    }
    if (postData.addedFrom) {
      query.push({
        $match: {
          $and: [{ addedFrom: postData.addedFrom }],
        },
      });
    }
    // * users 
    query.push({
      $lookup: {
        from: "users",
        localField: "sellerId",
        foreignField: "_id",
        as: "users",
      },
    });
    query.push({
      $unwind: { path: "$users", preserveNullAndEmptyArrays: true },
    });   
     // * users 
     query.push({
      $lookup: {
        from: "users",
        localField: "salesUserId",
        foreignField: "_id",
        as: "salesusers",
      },
    });
    query.push({
      $unwind: { path: "$salesusers", preserveNullAndEmptyArrays: true },
    }); 
    // * interiorcolors
    query.push({
      $lookup: {
        from: "interiorcolors",
        localField: "interiorcolorId",
        foreignField: "_id",
        as: "interiorcolors",
      },
    });
    query.push({
      $unwind: { path: "$interiorcolors", preserveNullAndEmptyArrays: true },
    });

    // * exteriorcolors
    query.push({
      $lookup: {
        from: "exteriorcolors",
        localField: "exteriorcolorId",
        foreignField: "_id",
        as: "exteriorcolors",
      },
    });
    query.push({
      $unwind: { path: "$exteriorcolors", preserveNullAndEmptyArrays: true },
    });

    // * makes
    query.push({
      $lookup: {
        from: "makes",
        localField: "make",
        foreignField: "_id",
        as: "makes",
      },
    });
    query.push({
      $unwind: { path: "$makes", preserveNullAndEmptyArrays: true },
    });

    // * models
    query.push({
      $lookup: {
        from: "models",
        localField: "model",
        foreignField: "_id",
        as: "models",
      },
    });
    query.push({
      $unwind: { path: "$models", preserveNullAndEmptyArrays: true },
    });

    // * bodys
    query.push({
      $lookup: {
        from: "bodys",
        localField: "bodyId",
        foreignField: "_id",
        as: "bodys",
      },
    });
    query.push({
      $unwind: { path: "$bodys", preserveNullAndEmptyArrays: true },
    });

    // * series
    query.push({
      $lookup: {
        from: "series",
        localField: "seriesId",
        foreignField: "_id",
        as: "series",
      },
    });
    query.push({
      $unwind: { path: "$series", preserveNullAndEmptyArrays: true },
    });

    // * fueltypes
    query.push({
      $lookup: {
        from: "fueltypes",
        localField: "fueltypeId",
        foreignField: "_id",
        as: "fueltypes",
      },
    });
    query.push({
      $unwind: { path: "$fueltypes", preserveNullAndEmptyArrays: true },
    });

    // * drivetypes
    query.push({
      $lookup: {
        from: "drivetypes",
        localField: "drivetypeId",
        foreignField: "_id",
        as: "drivetypes",
      },
    });
    query.push({
      $unwind: { path: "$drivetypes", preserveNullAndEmptyArrays: true },
    });

    // * engines
    query.push({
      $lookup: {
        from: "engines",
        localField: "engineId",
        foreignField: "_id",
        as: "engines",
      },
    });
    query.push({
      $unwind: { path: "$engines", preserveNullAndEmptyArrays: true },
    });

    // * branchs
    query.push({
      $lookup: {
        from: "branchs",
        localField: "branchId",
        foreignField: "_id",
        as: "branchs",
      },
    });
    query.push({
      $unwind: { path: "$branchs", preserveNullAndEmptyArrays: true },
    });

    // * warehouses
    query.push({
      $lookup: {
        from: "warehouses",
        localField: "warehosId",
        foreignField: "_id",
        as: "warehouses",
      },
    });
    query.push({
      $unwind: { path: "$warehouses", preserveNullAndEmptyArrays: true },
    });

    // * inspection
    if (checkBoolean(postData?.isInspectionNeeded)) {
      Lookup(query, "inspections", "_id", "inventoryId", "inspection");
      Unwind(query, "$inspection");
    }

    if (postData?.apiType !== "web") {
      // * inGatePass
      const inGatePassLet = {
        inventoryId: "$_id",
        direction: "in",
      };
      const inGatePassPipeline = [
        {
          $match: {
            $expr: {
              $and: [
                {
                  $eq: ["$inventoryId", "$$inventoryId"],
                },
                {
                  $eq: ["$direction", "$$direction"],
                },
              ],
            },
          },
        },
      ];

      LookupWithPipeline(
        query,
        "getpasses",
        inGatePassLet,
        inGatePassPipeline,
        "inGatePass"
      );

      // * outGatePass
      const outGatePassLet = {
        inventoryId: "$_id",
        direction: "out",
      };
      const outGatePassPipeline = [
        {
          $match: {
            $expr: {
              $and: [
                {
                  $eq: ["$inventoryId", "$$inventoryId"],
                },
                {
                  $eq: ["$direction", "$$direction"],
                },
              ],
            },
          },
        },
      ];

      LookupWithPipeline(
        query,
        "getpasses",
        outGatePassLet,
        outGatePassPipeline,
        "outGatePass"
      );

      if (Array.isArray(postData.inGatePassStatus)) {
        InMatch(query, "inGatePass.status", postData.inGatePassStatus);
      }

      if (Array.isArray(postData.outGatePassStatus)) {
        InMatch(query, "outGatePass.status", postData.outGatePassStatus);
      }
    }

    if (postData?.apiType === "web" && checkBoolean(postData?.pagination)) {
      // * auctionVehicles
      const pipeline = [
        {
          $lookup: {
            from: "auctionvehicles",
            let: {
              inventoryId: "$_id",
            },
            pipeline: [
              {
                $match: {
                  $expr: {
                    $and: [
                      { $eq: ["$inventoryId", "$$inventoryId"] },
                      { $eq: ["$status", "pending"] },
                    ],
                  },
                },
              },
            ],
            as: "auctionVehicles",
          },
        },
        {
          $unwind: {
            path: "$auctionVehicles",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "auctionvehicles",
            let: {
              auctionId: "$auctionVehicles.auctionId",
              currentDisplayNo: "$auctionVehicles.displayNo",
            },
            pipeline: [
              {
                $match: {
                  $expr: {
                    $and: [
                      {
                        $eq: ["$auctionId", "$$auctionId"],
                      },
                      { $eq: ["$status", "pending"] },
                      {
                        $eq: [
                          "$displayNo",
                          { $add: ["$$currentDisplayNo", 1] },
                        ],
                      },
                    ],
                  },
                },
              },
            ],
            as: "nextCar",
          },
        },
        {
          $lookup: {
            from: "auctionvehicles",
            let: {
              auctionId: "$auctionVehicles.auctionId",
              currentDisplayNo: "$auctionVehicles.displayNo",
            },
            pipeline: [
              {
                $match: {
                  $expr: {
                    $and: [
                      {
                        $eq: ["$auctionId", "$$auctionId"],
                      },
                      { $eq: ["$status", "pending"] },
                      {
                        $eq: [
                          "$displayNo",
                          { $subtract: ["$$currentDisplayNo", 1] },
                        ],
                      },
                    ],
                  },
                },
              },
            ],
            as: "previousCar",
          },
        },
        {
          $addFields: {
            isNextCarAvailable: {
              $cond: [{ $gt: [{ $size: ["$nextCar"] }, 0] }, true, false],
            },
          },
        },
        {
          $addFields: {
            isPreviousCarAvailable: {
              $cond: [{ $gt: [{ $size: ["$previousCar"] }, 0] }, true, false],
            },
          },
        },
      ];
      query.push(...pipeline);

      const _let = {
        inventoryId: makeObjectId(postData.inventoryId),
        buyerId: makeObjectId(postData.buyerId),
      };
      const _pipeline = [
        {
          $match: {
            $expr: {
              $and: [
                { $eq: ["$inventoryId", "$$inventoryId"] },
                { $eq: ["$buyerId", "$$buyerId"] },
              ],
            },
          },
        },
      ];
      LookupWithPipeline(query, "watchlists", _let, _pipeline, "watchList");
      Unwind(query, "$watchList");
    }

    if (checkBoolean(postData?.needAuctionTitle)) {
      const _let = { inventoryId: "$_id" };
      const _pipeline = [
        {
          $match: {
            $expr: {
              $and: [
                { $eq: ["$inventoryId", "$$inventoryId"] },
                { $eq: ["$status", "pending"] },
              ],
            },
          },
        },
      ];

      LookupWithPipeline(
        query,
        "auctionvehicles",
        _let,
        _pipeline,
        "auctionVehiclesForAuction"
      );
      Unwind(query, "$auctionVehiclesForAuction");

      Lookup(
        query,
        "auctions",
        "auctionVehiclesForAuction.auctionId",
        "_id",
        "auction"
      );
      Unwind(query, "$auction");
    }

    if (postData?.apiType === "web") {
      LookupWithPipeline(
        query,
        "reciepts",
        {
          inventoryId: "$_id",
        },
        [
          {
            $match: {
              $expr: {
                $and: [
                  { $eq: ["$inventoryId", "$$inventoryId"] },
                  { $ne: ["$invoiceStatus", "cancelled"] },
                ],
              },
            },
          },
        ],
        "receipt"
      );
    }

    if (postData.completeRuns) {
      query.push({
        $match: {
          completeRuns: postData.completeRuns,
        },
      });
    }
    if (postData.containerNo) {
      query.push({
        $match: {
          containerNo: postData.containerNo,
        },
      });
    }
    if (postData.sellerDbId) {
      query.push({
        $match: {
          sellerId: mongoose.Types.ObjectId(postData.sellerDbId),
        },
      });
    }
    if (postData?.salesUserId) {
      query.push({
        $match: {
          salesUserId: mongoose.Types.ObjectId(postData?.salesUserId),
        },
      });
    }     
    if (postData.vin) {
      query.push({
        $match: {
          vin: postData.vin,
        },
      });
    }
    if (postData.uniqueIdentifier) {
      query.push({
        $match: {
          uniqueIdentifier: postData.uniqueIdentifier,
        },
      });
    }
    if (postData.status) {
      postData.status = Number(postData.status);
      query.push({
        $match: {
          inventoryStatus: postData.status,
        },
      });
    }
    if (postData?.inventoryType) {
      query.push({
        $match: {
          inventoryType: postData?.inventoryType,
        },
      });
    }

    let inventoryStatusData = [];
    if (isArrayWithLength(postData.inventoryStatus)) {
      let pdata = postData.inventoryStatus;
      for (let i in pdata) {
        inventoryStatusData.push(Number(pdata[i]));
      }
      query.push({
        $match: {
          $and: [
            {
              inventoryStatus: {
                $in: inventoryStatusData,
              },
            },
          ],
        },
      });
    }
    if (postData.processStatus) {
      if (postData.processStatus == "NA") {
        query.push({
          $match: {
            status: " ",
          },
        });
      } else {
        query.push({
          $match: {
            status: postData.processStatus,
          },
        });
      }
    }
    let branchData = [];
    if (postData.branchId) {
      let pdata = postData.branchId;
      for (let i in pdata) {
        branchData.push(mongoose.Types.ObjectId(pdata[i]));
      }
      query.push({
        $match: {
          $and: [
            {
              branchId: {
                $in: branchData,
              },
            },
          ],
        },
      });
    }

    if ([true, "true"].includes(postData.getpass)) {
      LookupWithPipeline(
        query,
        "getpasses",
        {
          inventoryId: "$_id",
          direction: "out",
        },
        [
          {
            $match: {
              $expr: {
                $and: [
                  {
                    $eq: ["$inventoryId", "$$inventoryId"],
                  },
                  {
                    $eq: ["$direction", "$$direction"],
                  },
                ],
              },
            },
          },
        ],
        "outGatePass"
      );

      AddFields(query, "outGatePass", {
        $cond: {
          if: {
            $and: [
              {
                $in: ["$inventoryStatus", [1, 2]],
              },
            ],
          },
          then: [{ status: "pending" }],
          else: "$outGatePass",
        },
      });

      InMatch(query, "outGatePass.status", ["pending", "in warehouse"]);
    }

    if (postData.warehosId) {
      query.push({
        $match: {
          warehosId: mongoose.Types.ObjectId(postData.warehosId),
        },
      });
    }
    let warehosnewData = [];
    if (postData.warehosIds) {
      let pdata = postData.warehosIds;
      for (let i in pdata) {
        warehosnewData.push(mongoose.Types.ObjectId(pdata[i]));
      }
      query.push({
        $match: {
          $and: [
            {
              warehosId: {
                $in: warehosnewData,
              },
            },
          ],
        },
      });
    }
    if (postData.inventoryId) {
      query.push({
        $match: {
          _id: mongoose.Types.ObjectId(postData.inventoryId),
        },
      });

      // * sellerVinImages
      query.push({
        $lookup: {
          from: "vinimages",
          let: {
            inventoryId: "$_id",
            imageType: "inventory",
            type: "seller-car-image",
          },
          pipeline: [
            {
              $match: {
                $expr: {
                  $and: [
                    { $eq: ["$imageType", "$$imageType"] },
                    { $eq: ["$type", "$$type"] },
                    { $eq: ["$referenceId", "$$inventoryId"] },
                  ],
                },
              },
            },
          ],
          as: "sellerVinImages",
        },
      });
    }
    if (isArrayWithLength(postData.statusArr)) {
      InMatch(query, "status", postData.statusArr);
    }

    // * vinimages
    query.push({
      $lookup: {
        from: "vinimages",
        let: {
          inventoryId: "$_id",
          imageType: "inventory",
          type: "carimage",
        },
        pipeline: [
          {
            $match: {
              $expr: {
                $and: [
                  { $eq: ["$imageType", "$$imageType"] },
                  { $eq: ["$type", "$$type"] },
                  { $eq: ["$referenceId", "$$inventoryId"] },
                ],
              },
            },
          },
        ],
        as: "vinimages",
      },
    });

    // * singlevinimages
    query.push({
      $lookup: {
        from: "vinimages",
        // localField: "salesUserId",
        // foreignField: "_id",
        let: {
          inventoryId: "$_id",
          imageType: "inventory",
          type: "carimage",
        },
        pipeline: [
          {
            $match: {
              $expr: {
                $and: [
                  { $eq: ["$imageType", "$$imageType"] },
                  { $eq: ["$type", "$$type"] },
                  { $eq: ["$referenceId", "$$inventoryId"] },
                  { $eq: ["$defaultimage", 1] },
                ],
              },
            },
          },
        ],
        as: "singlevinimages",
      },
    });

    if (postData.search) {
      query.push({
        $match: {
          $and: [
            {
              $or: [
                { vin: { $regex: postData.search, $options: "i" } },
                //{ containerNo: { $regex: postData.search, $options: "i" } },
                { year: { $regex: postData.search, $options: "i" } },
              ],
            },
          ],
        },
      });
    } else {
      query.push({
        $match: {
          $and: [{ costPrice: { $exists: true } }],
        },
      });
    }

    query.push({
      $lookup: {
        from: "reseverprices",
        let: {
          id: "$_id",
          inventoryId: "$inventoryId",
        },
        pipeline: [
          {
            $match: {
              $expr: {
                $and: [{ $eq: ["$inventoryId", "$$id"] }],
              },
            },
          },
        ],
        as: "reseverprices",
      },
    });
    query.push({
      $addFields: {
        reseverprices: { $last: "$reseverprices" },
      },
    });

    const sQuery = [...query];
    let apiType = postData.apiType;
    if (apiType == "web") {
      query.push({
        $project: {
          // sellerId1:{ $ifNull: [ "$users?.uniqueIdentifier", "" ] } ,
          lotNo: 1,
          keyNo: 1,
          vin: 1,
          runs: 1,
          addedFrom: 1,
          auctionId: "$auctionVehicles.auctionId",
          auctionDisplayNo: "$auctionVehicles.displayNo",
          isNextCarAvailable: 1,
          isPreviousCarAvailable: 1,
          branchs: "$branchs.branchName",
          branchId: "$branchs._id",
          bodys: "$bodys.bodyName",
          bodyId: "$bodys._id",
          drivetypes: "$drivetypes.drivetypeName",
          drivetypeId: "$drivetypes._id",
          fueltypes: "$fueltypes.fueltypeName",
          fueltypeId: "$fueltypes._id",
          series: "$series.seriesName",
          seriesId: "$series._id",
          engines: "$engines.engineName",
          enginesId: "$engines._id",
          year: 1,
          exteriorode: "$exteriorcolors.colorCode",
          color: "$exteriorcolors.colorName",
          interiocolorId: "$interiorcolors._id",
          excolorCrcolorId: "$exteriorcolors._id",
          incolorCode: "$interiorcolors.colorCode",
          interiorcolors: "$interiorcolors.colorName",
          make: "$makes.makeName",
          makeId: "$makes._id",
          model: "$models.modelName",
          modelId: "$models._id",
          warehouses: "$warehouses.warehouseName",
          warehosId: "$warehouses._id",
          salesUserName :"$salesusers.name",
          specife: 1,
          costPication: 1,
          milagrice: 1,
          startingBid: 1,
          containerNo: 1,
          reservePrice: 1,
          invoicePrice: 1,
          purchaseFrom: 1,
          sellerReservePrice: 1,
          sellerPriceAccept: 1,
          lastAuctionDate: 1,
          lastBid: 1,
          inventoryStatus: 1,
          planPrice: 1,
          rejectedMsg: 1,
          counterStatus: 1,
          carDocRecieved: 1,
          vccDoc: 1,
          purchaseDoc: 1,
          mulkiya: 1,
          hayaza: 1,
          status: 1,
          createdAt: 1,
          displayNo: 1,
          getpassissue: 1,
          getpassesId: "$getpasses.status",
          reserveprId: 1,
          completriceDoc: 1,
          transfeeRuns: 1,
          inventcopy: 1,
          getpasses: 1,
          reseverId: "$reseverprices._id",
          singleImages: {
            $cond: {
              if: {
                $ne: ["$singlevinimages", []],
              },
              then: { $arrayElemAt: ["$singlevinimages.image", 0] },
              else: config.defaultInventoryImage,
            },
          },
          vinimages: {
            $cond: {
              if: {
                $ne: ["$vinimages", []],
              },
              then: "$vinimages",
              else: [{ image: config.defaultInventoryImage }],
            },
          },
          sellerId: {
            $cond: {
              if: { $eq: ["$users", {}] },
              then: "",
              else: "$users._id",
            },
          },
          sellerDbId: {
            $cond: {
              if: { $eq: ["$users", {}] },
              then: "",
              else: "$users._id",
            },
          },
          isPaymentCleared: 1,
          forReAuction: 1,
          watchList: 1,
          inventoryType: 1,
          receiptId: {
            $arrayElemAt: ["$receipt._id", -1],
          },
          sellerVinImages: {
            $cond: {
              if: {
                $ne: ["$sellerVinImages", []],
              },
              then: "$sellerVinImages",
              else: [],
            },
          },
          salesUserId: 1,
          carDescription: {
            $concat: [
              "$year",
              " ",
              "$makes.makeName",
              " ",
              "$models.modelName",
            ],
          },
          milage: 1,
          inspection: "$inspection.components",
          createdFrom: 1,
        },
      });
    } else {
      query.push({
        $project: {
          // sellerId1:{ $ifNull: [ "$users?.uniqueIdentifier", "" ] } ,
          lotNo: 1,
          keyNo: 1,
          vin: 1,
          addedFrom: 1,
          salesUserName :"$salesusers.name",
          runs: 1,
          make: "$makes",
          model: "$models",
          makeName: "$makes.makeName",
          modelName: "$models.modelName",
          warehouses: 1,
          branchs: 1,
          bodys: 1,
          drivetypes: 1,
          fueltypes: 1,
          series: 1,
          engines: 1,
          year: 1,
          color: "$interiorcolors",
          exteriorcolors: 1,
          specification: 1,
          branchId: "$branchs._id",
          branchName: "$branchs.branchName",
          warehosId: "$warehouses._id",
          warehosIds: "$warehouses._id",
          milage: 1,
          costPrice: 1,
          startingBid: 1,
          containerNo: 1,
          reservePrice: 1,
          invoicePrice: 1,
          purchaseFrom: 1,
          sellerReservePrice: 1,
          sellerPriceAccept: 1,
          lastAuctionDate: 1,
          lastBid: 1,
          inventoryStatus: 1,
          planPrice: 1,
          rejectedMsg: 1,
          counterStatus: 1,
          carDocRecieved: 1,
          vccDoc: 1,
          purchaseDoc: 1,
          status: 1,
          createdAt: 1,
          reseverprices: 1,
          displayNo: 1,
          getpassissue: 1,
          reservepriceDoc: 1,
          completeRuns: 1,
          transferId: 1,
          inventcopy: 1,
          getpasses: 1,
          getpassesId: "$getpasses.status",
          singleImages: {
            $cond: {
              if: {
                $ne: ["$singlevinimages", []],
              },
              then: { $arrayElemAt: ["$singlevinimages.image", 0] },
              else: config.defaultInventoryImage,
            },
          },
          vinimages: {
            $cond: {
              if: {
                $ne: ["$vinimages", []],
              },
              then: "$vinimages",
              else: [{ image: config.defaultInventoryImage }],
            },
          },
          sellerId: {
            $cond: {
              if: { $eq: ["$users", {}] },
              then: "",
              else: "$users",
            },
          },
          sellerDbId: {
            $cond: {
              if: { $eq: ["$users", {}] },
              then: "",
              else: "$users._id",
            },
          },
          isPaymentCleared: 1,
          forReAuction: 1,
          auctionTitle: "$auction.title",
          carDescription: {
            $concat: [
              "$year",
              " ",
              "$makes.makeName",
              " ",
              "$models.modelName",
            ],
          },
          inventoryType: 1,
          inGatePass: {
            $arrayElemAt: ["$inGatePass.status", 0],
          },
          outGatePass: {
            $arrayElemAt: ["$outGatePass.status", -1],
          },
          inspection: "$inspection.components",
          isInventoryClonable: {
            $cond: {
              if: {
                $and: [
                  {
                    $in: ["$inventoryStatus", [3]],
                  },
                  {
                    $eq: [
                      {
                        $arrayElemAt: ["$outGatePass.status", -1],
                      },
                      "out of stock",
                    ],
                  },
                ],
              },
              then: true,
              else: false,
            },
          },
          sellerVinImages: {
            $cond: {
              if: {
                $ne: ["$sellerVinImages", []],
              },
              then: "$sellerVinImages",
              else: [],
            },
          },
          createdFrom: 1,
        },
      });
    }

    if (postData.sortbydisplayNo == true) {
      query.push({ $sort: { displayNo: -1 } });
    } else {
      query.push({ $sort: { createdAt: -1 } });
    }

    sQuery.push({ $count: "totalCount" });

    if (postData.page) {
      query.push({
        $skip: cmethod.pageOffset(postData.page, postData.pageLimit),
      });
      query.push({ $limit: cmethod.pageLimit(postData.pageLimit) });
    }

    // * results
    let [result, [{ totalCount } = {}] = []] = await Promise.all([
      inventoryModal.Inventory.aggregate(query),
      inventoryModal.Inventory.aggregate(sQuery),
    ]);

    res.status(200).json({
      status: true,
      result,
      message: "",
      hasMore: cmethod.hasMoreCount(
        totalCount,
        postData.page,
        postData.pageLimit
      ),
      totalCount,
    });
  } catch (error) {
    logger.error(error);
    cmethod.returnSreverError(res, message[lang]?.technicalError, error);
  }
});
router.post(
  "/carList",
  [midleware.validateFieldValue(["pageLimit", "page"], ["page"])],
  (req, res) => {
    let lang = req.headers["lang"] || config.lang;
    let postData = req.body;
    let query = [];

    const sortKey = postData.sortKey || "createdAt";
    const sortOrder = Number(postData.sortOrder) || -1;

    // * users
    query.push({
      $lookup: {
        from: "users",
        localField: "sellerId",
        foreignField: "_id",
        as: "users",
      },
    });
    query.push({
      $unwind: { path: "$users", preserveNullAndEmptyArrays: true },
    });

    // * interiorcolors
    query.push({
      $lookup: {
        from: "interiorcolors",
        localField: "interiorcolorId",
        foreignField: "_id",
        as: "interiorcolors",
      },
    });
    query.push({
      $unwind: { path: "$interiorcolors", preserveNullAndEmptyArrays: true },
    });

    // * exteriorcolors
    query.push({
      $lookup: {
        from: "exteriorcolors",
        localField: "exteriorcolorId",
        foreignField: "_id",
        as: "exteriorcolors",
      },
    });
    query.push({
      $unwind: { path: "$exteriorcolors", preserveNullAndEmptyArrays: true },
    });

    // * makes
    query.push({
      $lookup: {
        from: "makes",
        localField: "make",
        foreignField: "_id",
        as: "makes",
      },
    });
    query.push({
      $unwind: { path: "$makes", preserveNullAndEmptyArrays: true },
    });

    // * models
    query.push({
      $lookup: {
        from: "models",
        localField: "model",
        foreignField: "_id",
        as: "models",
      },
    });
    query.push({
      $unwind: { path: "$models", preserveNullAndEmptyArrays: true },
    });

    // * bodys
    query.push({
      $lookup: {
        from: "bodys",
        localField: "bodyId",
        foreignField: "_id",
        as: "bodys",
      },
    });
    query.push({
      $unwind: { path: "$bodys", preserveNullAndEmptyArrays: true },
    });

    // * series
    query.push({
      $lookup: {
        from: "series",
        localField: "seriesId",
        foreignField: "_id",
        as: "series",
      },
    });
    query.push({
      $unwind: { path: "$series", preserveNullAndEmptyArrays: true },
    });

    // * fueltypes
    query.push({
      $lookup: {
        from: "fueltypes",
        localField: "fueltypeId",
        foreignField: "_id",
        as: "fueltypes",
      },
    });
    query.push({
      $unwind: { path: "$fueltypes", preserveNullAndEmptyArrays: true },
    });

    // * drivetypes
    query.push({
      $lookup: {
        from: "drivetypes",
        localField: "drivetypeId",
        foreignField: "_id",
        as: "drivetypes",
      },
    });
    query.push({
      $unwind: { path: "$drivetypes", preserveNullAndEmptyArrays: true },
    });

    // * engines
    query.push({
      $lookup: {
        from: "engines",
        localField: "engineId",
        foreignField: "_id",
        as: "engines",
      },
    });
    query.push({
      $unwind: { path: "$engines", preserveNullAndEmptyArrays: true },
    });

    // * branchs
    query.push({
      $lookup: {
        from: "branchs",
        localField: "branchId",
        foreignField: "_id",
        as: "branchs",
      },
    });
    query.push({
      $unwind: { path: "$branchs", preserveNullAndEmptyArrays: true },
    });

    // * warehouses
    query.push({
      $lookup: {
        from: "warehouses",
        localField: "warehosId",
        foreignField: "_id",
        as: "warehouses",
      },
    });
    query.push({
      $unwind: { path: "$warehouses", preserveNullAndEmptyArrays: true },
    });

    // * watchlist
    LookupWithPipeline(
      query,
      "watchlists",
      {
        inventoryId: "$_id",
        buyerId: makeObjectId(postData.buyerId),
      },
      [
        {
          $match: {
            $expr: {
              $and: [
                { $eq: ["$inventoryId", "$$inventoryId"] },
                { $eq: ["$buyerId", "$$buyerId"] },
              ],
            },
          },
        },
      ],
      "watchList"
    );
    Unwind(query, "$watchList");

    if (checkBoolean(postData?.needAuctionId)) {
      const _let = { inventoryId: "$_id" };
      const _pipeline = [
        {
          $match: {
            $expr: {
              $and: [
                { $eq: ["$inventoryId", "$$inventoryId"] },
                { $eq: ["$status", "pending"] },
              ],
            },
          },
        },
      ];

      LookupWithPipeline(
        query,
        "auctionvehicles",
        _let,
        _pipeline,
        "auctionVehiclesForAuction"
      );

      ExactMatch(query, "auctionVehiclesForAuction", { $ne: [] });

      Unwind(query, "$auctionVehiclesForAuction");

      if (postData.auctionId) {
        query.push({
          $match: {
            $and: [
              {
                "auctionVehiclesForAuction.auctionId": mongoose.Types.ObjectId(
                  postData.auctionId
                ),
              },
            ],
          },
        });
      }

      if (Array.isArray(postData.auctionIds)) {
        const auctionIds = makeObjectIds(postData.auctionIds);
        InMatch(query, "auctionVehiclesForAuction.auctionId", auctionIds);
      }
    }

    //----------------------------------------------------------------
    if (postData.sellerDbId) {
      query.push({
        $match: {
          sellerId: mongoose.Types.ObjectId(postData.sellerDbId),
        },
      });
    }
    if (postData.status) {
      postData.status = Number(postData.status);
      query.push({
        $match: {
          inventoryStatus: postData.status,
        },
      });
    }
    let inventoryStatusData = [];
    if (postData.inventoryStatus) {
      let pdata = postData.inventoryStatus;
      for (let i in pdata) {
        inventoryStatusData.push(Number(pdata[i]));
      }
      query.push({
        $match: {
          $and: [
            {
              inventoryStatus: {
                $in: inventoryStatusData,
              },
            },
          ],
        },
      });
    }
    if (postData.processStatus) {
      query.push({
        $match: {
          status: postData.processStatus,
        },
      });
    }
    let branchData = [];
    if (postData.branchId) {
      let pdata = postData.branchId;
      for (let i in pdata) {
        branchData.push(mongoose.Types.ObjectId(pdata[i]));
      }
      query.push({
        $match: {
          $and: [
            {
              branchId: {
                $in: branchData,
              },
            },
          ],
        },
      });
    }
    if (postData.engineId) {
      query.push({
        $match: {
          engineId: mongoose.Types.ObjectId(postData.engineId),
        },
      });
    }
    if (postData.warehosId) {
      query.push({
        $match: {
          warehosId: mongoose.Types.ObjectId(postData.warehosId),
        },
      });
    }
    if (postData.make) {
      query.push({
        $match: {
          make: mongoose.Types.ObjectId(postData.make),
        },
      });
    }
    if (postData.model) {
      query.push({
        $match: {
          model: mongoose.Types.ObjectId(postData.model),
        },
      });
    }
    if (postData.minMilage && postData.maxMilage) {
      query.push({
        $match: {
          milage: {
            $gte: Number(postData.minMilage),
            $lte: Number(postData.maxMilage),
          },
        },
      });
    }
    if (postData.minPrice && postData.maxPrice) {
      query.push({
        $match: {
          startingBid: {
            $gte: Number(postData.minPrice),
            $lte: Number(postData.maxPrice),
          },
        },
      });
    }
    if (postData.year) {
      query.push({
        $match: {
          year: postData.year,
        },
      });
    }
    if (postData.interiorcolorId) {
      query.push({
        $match: {
          interiorcolorId: mongoose.Types.ObjectId(postData.interiorcolorId),
        },
      });
    }
    if (postData.exteriorcolorId) {
      query.push({
        $match: {
          exteriorcolorId: mongoose.Types.ObjectId(postData.exteriorcolorId),
        },
      });
    }
    if (postData.bodyId) {
      query.push({
        $match: {
          bodyId: mongoose.Types.ObjectId(postData.bodyId),
        },
      });
    }
    if (postData.drivetypeId) {
      query.push({
        $match: {
          drivetypeId: mongoose.Types.ObjectId(postData.drivetypeId),
        },
      });
    }
    if (postData.fueltypeId) {
      query.push({
        $match: {
          fueltypeId: mongoose.Types.ObjectId(postData.fueltypeId),
        },
      });
    }
    if (postData.inventoryId) {
      query.push({
        $match: {
          _id: mongoose.Types.ObjectId(postData.inventoryId),
        },
      });

      // let  inventoryId = postData.inventoryId;
      query.push({
        $lookup: {
          from: "vinimages",
          // localField: "salesUserId",
          // foreignField: "_id",
          let: {
            inventoryId: "$_id",
            imageType: "inventory",
          },
          pipeline: [
            {
              $match: {
                $expr: {
                  $and: [
                    { $eq: ["$imageType", "$$imageType"] },
                    { $eq: ["$referenceId", "$$inventoryId"] },
                  ],
                },
              },
            },
          ],
          as: "vinimages",
        },
      });
    }

    if (Array.isArray(postData.bodies)) {
      const bodies = makeObjectIds(postData.bodies);
      InMatch(query, "bodyId", bodies);
    }
    if (Array.isArray(postData.fuelTypes)) {
      const fuelTypes = makeObjectIds(postData.fuelTypes);
      InMatch(query, "fueltypeId", fuelTypes);
    }
    if (Array.isArray(postData.interiorColors)) {
      const interiorColors = makeObjectIds(postData.interiorColors);
      InMatch(query, "interiorcolorId", interiorColors);
    }
    if (Array.isArray(postData.exteriorColors)) {
      const exteriorColors = makeObjectIds(postData.exteriorColors);
      InMatch(query, "exteriorcolorId", exteriorColors);
    }

    query.push({
      $lookup: {
        from: "vinimages",
        // localField: "salesUserId",
        // foreignField: "_id",
        let: {
          inventoryId: "$_id",
          imageType: "inventory",
          type: "carimage",
        },
        pipeline: [
          {
            $match: {
              $expr: {
                $and: [
                  { $eq: ["$imageType", "$$imageType"] },
                  { $eq: ["$type", "$$type"] },
                  { $eq: ["$referenceId", "$$inventoryId"] },
                  { $eq: ["$defaultimage", 1] },
                ],
              },
            },
          },
        ],
        as: "singlevinimages",
      },
    });
    // query.push({
    //   $unwind: { path: "$singlevinimages", preserveNullAndEmptyArrays: true },
    // });
    if (postData.search) {
      query.push({
        $match: {
          $and: [
            {
              $or: [
                { vin: { $regex: postData.search, $options: "i" } },
                { year: { $regex: postData.search, $options: "i" } },
              ],
            },
          ],
        },
      });
    } else {
      query.push({
        $match: {
          $and: [{ costPrice: { $exists: true } }],
        },
      });
    }

    //-----------------------------------------------------------------
    query.push({
      $lookup: {
        from: "reseverprices",
        let: {
          id: "$_id",
          inventoryId: "$inventoryId",
        },
        pipeline: [
          {
            $match: {
              $expr: {
                $and: [{ $eq: ["$inventoryId", "$$id"] }],
              },
            },
          },
        ],
        as: "reseverprices",
      },
    });
    query.push({
      $addFields: {
        reseverprices: { $last: "$reseverprices" },
      },
    });
    //-----------------------------------------------------------------
    const sQuery = [...query];
    let apiType = postData.apiType;
    if (apiType == "web") {
      query.push({
        $project: {
          // sellerId1:{ $ifNull: [ "$users?.uniqueIdentifier", "" ] } ,
          auctionId: "$auctionVehiclesForAuction.auctionId",
          displayNo: "$auctionVehiclesForAuction.displayNo",
          lotNo: 1,
          vin: 1,
          branchs: "$branchs.branchName",
          branchId: "$branchs._id",
          bodys: "$bodys.bodyName",
          bodyId: "$bodys._id",
          drivetypes: "$drivetypes.drivetypeName",
          drivetypeId: "$drivetypes._id",
          fueltypes: "$fueltypes.fueltypeName",
          fueltypeId: "$fueltypes._id",
          series: "$series.seriesName",
          seriesId: "$series._id",
          engines: "$engines.engineName",
          engineId: "$engines._id",
          year: 1,
          exteriorcolorId: "$exteriorcolors._id",
          excolorCode: "$exteriorcolors.colorCode",
          color: "$exteriorcolors.colorName",
          interiorcolorId: "$interiorcolors._id",
          incolorCode: "$interiorcolors.colorCode",
          interiorcolors: "$interiorcolors.colorName",
          make: "$makes.makeName",
          makeId: "$makes._id",
          model: "$models.modelName",
          modelId: "$models._id",
          warehouses: "$warehouses.warehouseName",
          warehosId: "$warehouses._id",
          specification: 1,
          milage: 1,
          costPrice: 1,
          startingBid: 1,
          containerNo: 1,
          reservePrice: 1,
          sellerReservePrice: 1,
          sellerPriceAccept: 1,
          lastAuctionDate: 1,
          lastBid: 1,
          inventoryStatus: 1,
          planPrice: 1,
          rejectedMsg: 1,
          vccDoc: 1,
          purchaseDoc: 1,
          status: 1,
          createdAt: 1,
          //reseverprices: "$reseverprices",
          //singleImages: { $arrayElemAt: ["$singlevinimages.image", 0] },
          //vinimages: 1,
          singleImages: {
            $cond: {
              if: {
                $ne: ["$singlevinimages", []],
              },
              then: { $arrayElemAt: ["$singlevinimages.image", 0] },
              else: config.defaultInventoryImage,
            },
          },
          vinimages: {
            $cond: {
              if: {
                $ne: ["$vinimages", []],
              },
              then: "$vinimages",
              else: config.defaultInventoryImage,
            },
          },
          sellerId: {
            $cond: {
              if: { $eq: ["$users", {}] },
              then: "",
              else: "$users._id",
            },
          },
          sellerDbId: {
            $cond: {
              if: { $eq: ["$users", {}] },
              then: "",
              else: "$users._id",
            },
          },
          watchlistId: "$watchList._id",
          carDescription: {
            $concat: [
              { $ifNull: ["$year", ""] },
              " ",
              { $ifNull: ["$makes.makeName", ""] },
              " ",
              { $ifNull: ["$models.modelName", ""] },
              //" ",
              //{ $ifNull: ["$exteriorcolors.colorName", ""] },
            ],
          },
        },
      });
    } else {
      query.push({
        $project: {
          // sellerId1:{ $ifNull: [ "$users?.uniqueIdentifier", "" ] } ,
          lotNo: 1,
          vin: 1,
          make: "$makes",
          model: "$models",
          makeName: "$makes.makeName",
          modelName: "$models.modelName",
          warehouses: 1,
          branchs: 1,
          bodys: 1,
          drivetypes: 1,
          fueltypes: 1,
          series: 1,
          engines: 1,
          engineId: "$engines._id",
          year: 1,
          color: "$interiorcolors",
          exteriorcolors: 1,
          specification: 1,
          branchId: "$branchs._id",
          branchName: "$branchs.branchName",
          warehosId: "$warehouses._id",
          milage: 1,
          costPrice: 1,
          startingBid: 1,
          containerNo: 1,
          reservePrice: 1,
          sellerReservePrice: 1,
          sellerPriceAccept: 1,
          lastAuctionDate: 1,
          lastBid: 1,
          inventoryStatus: 1,
          planPrice: 1,
          rejectedMsg: 1,
          vccDoc: 1,
          purchaseDoc: 1,
          status: 1,
          createdAt: 1,
          //vinimages: 1,
          reseverprices: 1,
          //singleImages: { $arrayElemAt: ["$singlevinimages.image", 0] },
          singleImages: {
            $cond: {
              if: {
                $ne: ["$singlevinimages", []],
              },
              then: { $arrayElemAt: ["$singlevinimages.image", 0] },
              else: config.defaultInventoryImage,
            },
          },
          vinimages: {
            $cond: {
              if: {
                $ne: ["$vinimages", []],
              },
              then: "$vinimages",
              else: config.defaultInventoryImage,
            },
          },
          sellerId: {
            $cond: {
              if: { $eq: ["$users", {}] },
              then: "",
              else: "$users",
            },
          },
          sellerDbId: {
            $cond: {
              if: { $eq: ["$users", {}] },
              then: "",
              else: "$users._id",
            },
          },
        },
      });
    }

    // query.push({
    //   $project: {
    //     // sellerId1:{ $ifNull: [ "$users?.uniqueIdentifier", "" ] } ,
    //     lotNo: 1,
    //     vin: 1,
    //     make: "$makes",
    //     model: "$models",
    //     makeName: "$makes.makeName",
    //     modelName: "$models.modelName",
    //     warehouses: 1,
    //     branchs: 1,
    //     bodys: 1,
    //     drivetypes: 1,
    //     fueltypes: 1,
    //     series: 1,
    //     engines: 1,
    //     year: 1,
    //     color: "$interiorcolors",
    //     exteriorcolors: 1,
    //     specification: 1,
    //     branchId: "$branchs._id",
    //     branchName: "$branchs.branchName",
    //     warehosId: "$warehouses._id",
    //     milage: 1,
    //     costPrice: 1,
    //     startingBid: 1,
    //     reservePrice: 1,
    //     sellerReservePrice: 1,
    //     sellerPriceAccept: 1,
    //     lastAuctionDate: 1,
    //     lastBid: 1,
    //     inventoryStatus: 1,
    //     planPrice: 1,
    //     rejectedMsg: 1,
    //     vccDoc: 1,
    //     purchaseDoc: 1,
    //     status: 1,
    //     createdAt: 1,
    //     vinimages: 1,
    //     sellerId: {
    //       $cond: {
    //         if: { $eq: ["$users", {}] },
    //         then: "",
    //         else: "$users.uniqueIdentifier",
    //       },
    //     },
    //     sellerDbId: {
    //       $cond: {
    //         if: { $eq: ["$users", {}] },
    //         then: "",
    //         else: "$users._id",
    //       },
    //     },
    //   },
    // });

    query.push({ $sort: { [sortKey]: sortOrder } });
    sQuery.push({ $count: "recordCount" });

    if (postData.page) {
      query.push({
        $skip: cmethod.pageOffset(postData.page, postData.pageLimit),
      });
      query.push({ $limit: cmethod.pageLimit(postData.pageLimit) });
    }

    intventoryDao
      .findInventoryAggregation(query)
      .then(function (data) {
        intventoryDao
          .findInventoryAggregation(sQuery)
          .then(async function (dcount) {
            let tptCnt = 0;
            if (dcount.length > 0) {
              tptCnt = dcount[0].recordCount;
            }
            res.status(200).json({
              status: true,
              result: data,
              message: "",
              hasMore: cmethod.hasMoreCount(
                tptCnt,
                postData.page,
                postData.pageLimit
              ),
              totalCount: tptCnt,
            });
          })
          .catch((err) => {
            cmethod.returnSreverError(res, message[lang].technicalError, err);
          });
      })
      .catch((err) => {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      });
  }
);
router.post("/checkUniqueVin", async (req, res) => {
  const postData = req.body;
  let lang = req.headers["lang"] || config.lang;
  cmethod.checkVinNoWithStatus(postData.vin).then(function (doc) {
    if (!doc.status) {
      cmethod.returnSuccess(res, doc.message);
    } else {
      cmethod.returnSreverError(res, doc.message);
    }
  });
});
router.post(
  "/add",
  [
    midleware.validateFieldValue(
      ["sellerId", "vin", "make", "model", "year", "milage"],
      ["sellerId", "vin", "make", "model", "year", "milage"]
    ),
  ],
  async (req, res) => {
    const postData = req.body;
    //console.log('----------->', postData);
    let checkplanexist = await cmethod.checkuserPlan(
      postData.sellerId,
      postData.branchId
    );
    let vinValidation = await cmethod.vinnosixDigit(postData?.vin);
    //console.log('----------->', checkplanexist); //return false;
    if (checkplanexist == false) {
      cmethod.returrnErrorMessage(res, "Seller not assign any plan !", ["ll"]);
    } else if (!vinValidation) {
      cmethod.returrnErrorMessage(res, "Vin no should be 17 character", ["ll"]);
    } else {
      /*generate unique lot no */
      let lotNoUnique = await cmethod.getLotNo();
      // console.log(stockData);
      postData.lotNo = lotNoUnique;
      /*generate unique lot no */
      intventoryDao.inventoryAdd(res, postData);
    }
  }
);

/*let postData = [
    {
      vin: "1000010",
      make: "",
      model: "ASPIREw",
      seriesId: "1.3",
      year: '',
      //color:"Persian Red",
      milage: 500,
      reservePrice: '',
      interiorcolorId:"Pharlap", 
      exteriorcolorId:"Pharlap", 
      bodyId: "CONVERTIBLE",
      drivetypeId: "4WD",
      engineId: "1.1",      
      fueltypeId: "GAS",    

      //sellerId: "63a1e518806b56345e775b53",
      //branchId: "Sharjahan",
      //warehosId: "W1",  
      //specification: "speCSV",     
      //color: "Pharlap",     
      //exteriorcolorId:"Pharlap",      
      ///startingBid: 550000,
      //reservePrice: 600000,
      key: "Yes",
    },
    {
      vin: "200018",
      make: "FORD",
      model: "",
      seriesId: "1.51",
      year: 20162,
      milage: 300,
      reservePrice: 700000,
      interiorcolorId:"Persian Red",
      exteriorcolorId:"Pharlap",  
      bodyId: "CONVERTIBLE",
      drivetypeId: "4WD",
      engineId: "1.2",     
      fueltypeId: "PETROL",

      //sellerId: "63a1e518806b56345e775b53",
      //branchId: "Sajja",
      //warehosId: "W21",     
      //costPrice: 400000,
      //specification: "speCSV",      
      //color: "Pharlap",           
      //startingBid: 660000,      
      key: "No",
    },
  ];*/
router.post(
  "/import",
  [
    fileUpload.single("file"),
    midleware.validateFieldValue(
      ["userId", "sellerId", "branchId", "warehosId", "status"],
      ["userId", "sellerId", "branchId", "warehosId", "status"]
    ),
  ],
  async (req, res) => {
    const { body, file } = req;

    if (!file) {
      return cmethod.returrnErrorMessage(res, "please upload csv file!");
    }

    let lang = req.headers["lang"] || config.lang;
    let errorData = [];
    let insertData = [];
    let results = [];

    results = await parseCSVFile(file.path);

    const { userId, sellerId, branchId, warehosId, status, createdBy } = body;

    if (results.length > 0) {
      for (let i = 0; i < results.length; i++) {
        const checkplanexist = await cmethod.checkuserPlan(sellerId, branchId);

        if (checkplanexist) {
          if (sellerId) {
            results[i] = await intventoryDao.existMaster(results[i]);
            const getParams = results[i][0].getParams;
            const remarksArrs = results[i][0].remarksArr;
            const rArrayy = remarksArrs.join(" ,");

            insertData.push({
              userId: mongoose.Types.ObjectId(userId),
              sellerId: mongoose.Types.ObjectId(sellerId),
              branchId: mongoose.Types.ObjectId(branchId),
              warehosId: mongoose.Types.ObjectId(warehosId),
              vin: getParams.vin,
              make: getParams.make,
              model: getParams.model,
              year: getParams.year,
              color: getParams.color,
              milage: getParams.milage,
              reservePrice: getParams.reserve_price,
              interiorcolorId: getParams.interior_color,
              exteriorcolorId: getParams.exterior_color,
              bodyId: getParams.body,
              drivetypeId: getParams.drive_type,
              engineId: getParams.engine,
              seriesId: getParams.series,
              fueltypeId: getParams.fuel_type,
              status,
              remarks: rArrayy,
              duplicatetemp: getParams.duplicatetemp,
              startingBid: getParams.starting_bid,
              containerNo: getParams.container_no,
              costPrice: getParams.costPrice,
              createdBy,
            });
          } else {
            let error =
              "row " + index + " sellerId or vin data not correct or invalid";
            errorData.push({
              error: error,
            });
          }
        } else {
          return cmethod.returrnErrorMessage(
            res,
            "Seller's not assign any plan!",
            ["ll"]
          );
        }
      }
    }

    if (insertData.length > 0) {
      await inventoryModal.Inventorytemps.deleteMany({
        userId: mongoose.Types.ObjectId(userId),
      });
      inventoryModal.Inventorytemps.insertMany(insertData, (err, data) => {
        if (err) {
          cmethod.returnSreverError(res, message[lang].technicalError, err);
        } else {
          fileCleaner(file);
          cmethod.returnSuccess(
            res,
            data,
            false,
            "Data has been imported successfully!"
          );
        }
      });
    } else {
      cmethod.returnSreverError(res, message[lang].technicalError, ["ll"]);
    }
  }
);
router.post("/movetempdata", async (req, res) => {
  const {
    body: { userId },
  } = req;

  const filter = { userId: makeObjectId(userId) };
  var postData = await inventoryModal.Inventorytemps.find(filter).exec();
  let lang = req.headers["lang"] || config.lang;
  let errorData = [];
  let insertData = {};
  let statusval;
  //let lotNoUnique = await cmethod.getLotNo();
  if (postData.length > 0) {
    for (var i = 0; i < postData.length; i++) {
      let lotNoUnique = await cmethod.getLotNo();
      // if (i > 0) {
      //   lotNoUnique++;
      // }

      if (postData[i].sellerId != "" && postData[i].vin != "") {
        let vinquery = {
          $and: [
            { vin: postData[i].vin },
            {
              $or: [
                { inventoryStatus: 0 },
                { inventoryStatus: 1 },
                { inventoryStatus: 2 },
              ],
            },
          ],
        };
        let checkUnique = await intventoryDao.checkUniqueVin(vinquery);
        // console.log("22222============>>>>>",checkUnique);
        if (checkUnique == "exist") {
          continue;
        } else {
          if (postData[i].status == "approved") {
            //console.log('---0', postData[i].status);
            postData[i].status = "approved";
            postData[i].inventoryStatus = 0;
            postData[i].getpassissue = 1;
            postData[i].inventoryType = config.inventoryTypes.DIRECT;
          } else if (postData[i].status == "pending") {
            //statusval = postData[i].status;
            //postData[i].status = "pending";
            postData[i].status = "document verify";
            postData[i].inventoryStatus = 0;
            postData[i].inventoryType = config.inventoryTypes.INDIRECT;
          }
          insertData = {
            lotNo: lotNoUnique,
            sellerId: mongoose.Types.ObjectId(postData[i].sellerId),
            vin: postData[i].vin,
            make: mongoose.Types.ObjectId(postData[i].make),
            model: mongoose.Types.ObjectId(postData[i].model),
            // specification: postData[i].specification,
            year: postData[i].year,
            color: mongoose.Types.ObjectId(postData[i].color),
            milage: postData[i].milage,
            seriesId: mongoose.Types.ObjectId(postData[i].seriesId),
            branchId: mongoose.Types.ObjectId(postData[i].branchId),
            warehosId: mongoose.Types.ObjectId(postData[i].warehosId),
            interiorcolorId: mongoose.Types.ObjectId(
              postData[i].interiorcolorId
            ),
            exteriorcolorId: mongoose.Types.ObjectId(
              postData[i].exteriorcolorId
            ),
            bodyId: mongoose.Types.ObjectId(postData[i].bodyId),
            drivetypeId: mongoose.Types.ObjectId(postData[i].drivetypeId),
            engineId: mongoose.Types.ObjectId(postData[i].engineId),
            fueltypeId: mongoose.Types.ObjectId(postData[i].fueltypeId),
            reservePrice: postData[i].reservePrice,
            status: postData[i]?.status ? postData[i]?.status : " ",
            inventoryStatus: postData[i]?.inventoryStatus,
            startingBid: postData[i]?.startingBid,
            containerNo: postData[i]?.containerNo,
            costPrice: postData[i]?.costPrice,
            userId: mongoose.Types.ObjectId(postData[i]?.userId),
            inventoryType: postData[i].inventoryType,
            createdBy: postData[i].createdBy,
          };
        }
        if (postData[i].status == "approved") {
          insertData.getpassissue = 1;
        }
        //console.log("insertData============>>>>>", insertData);
        let datas = await cmethod.addmovedataininventory(insertData);

        if (
          postData[i]?.inventoryStatus == 0 &&
          postData[i]?.status == "approved"
        ) {
          let passNoUnique = await cmethod.getPassNo();
          let savegetPassData = {
            passNo: passNoUnique,
            direction: "in",
            //referenceId: "",
            referenceType: "inventory",
            referenceNo: postData[i].vin,
            inventoryId: mongoose.Types.ObjectId(datas?._id),
            status: "pending",
            gatePassExpired: todayDate(),
            createdBy: "system",
          };
          await cmethod.addgetPass(savegetPassData);

          let docNoUnique = await cmethod.getDocumentpass();
          let savegetDocumentData = {
            passNo: docNoUnique,
            direction: "in",
            //referenceId: "",
            referenceType: "inventory",
            referenceNo: postData[i].vin,
            status: "pending",
            inventoryId: mongoose.Types.ObjectId(datas?._id),
            branchId: mongoose.Types.ObjectId(datas?.branchId),
            warehosId: mongoose.Types.ObjectId(datas?.warehosId),
            createdBy: "system",
          };
          await cmethod.addgetDocument(savegetDocumentData);

          await intventoryDao.addcarPlan(datas?._id);
        } else if (postData[i]?.status == "document verify") {
          await intventoryDao.addcarPlan(datas?._id);

          let reservepricedata = {
            inventoryId: mongoose.Types.ObjectId(datas?._id),
            acaOffer: 0,
            sellerOffer: postData[i].reservePrice
              ? postData[i].reservePrice
              : 0, //
            acaStatus: 0,
            sellerStatus: 1,
            acaofferDate: new Date(),
            sellerofferDate: new Date(),
          };
          const reseverInventory = new inventoryModal.Reseverprice(
            reservepricedata
          );
          reseverInventory.save(
            reservepricedata,
            async function (err, data) {}
          );
        }

        const inspection = {
          inventoryId: makeObjectId(datas?._id),
        };
        await createInspection(inspection);

        //}
      } else {
        let error =
          "row " + index + " sellerId or vin data not correct or invalid";
        errorData.push({
          error: error,
        });
      }
    }
    cmethod.returnSuccess(res, true, "Data has been import successfully.");
  }
});
router.post(
  "/templist",
  [midleware.validateFieldValue(["pageLimit", "page"], ["page"])],
  (req, res) => {
    let lang = req.headers["lang"] || config.lang;
    let postData = req.body;
    let query = [];

    if (postData.userId) {
      query.push({
        $match: {
          $and: [{ userId: mongoose.Types.ObjectId(postData.userId) }],
        },
      });
    } else {
    }

    query.push({
      $lookup: {
        from: "inventorys",
        let: {
          vin: "$vin",
        },
        pipeline: [
          {
            $match: {
              $expr: {
                $and: [{ $eq: ["$vin", "$$vin"] }],
              },
            },
          },
        ],
        as: "inventorys",
      },
    });
    query.push({
      $unwind: { path: "$inventorys", preserveNullAndEmptyArrays: true },
    });
    query.push({
      $lookup: {
        from: "users",
        localField: "sellerId",
        foreignField: "_id",
        as: "users",
      },
    });
    query.push({
      $unwind: { path: "$users", preserveNullAndEmptyArrays: true },
    });
    //----------------------------------------------------------------
    query.push({
      $lookup: {
        from: "interiorcolors",
        localField: "interiorcolorId",
        foreignField: "_id",
        as: "interiorcolors",
      },
    });
    query.push({
      $unwind: { path: "$interiorcolors", preserveNullAndEmptyArrays: true },
    });
    query.push({
      $lookup: {
        from: "exteriorcolors",
        localField: "exteriorcolorId",
        foreignField: "_id",
        as: "exteriorcolors",
      },
    });
    query.push({
      $unwind: { path: "$exteriorcolors", preserveNullAndEmptyArrays: true },
    });
    query.push({
      $lookup: {
        from: "makes",
        localField: "make",
        foreignField: "_id",
        as: "makes",
      },
    });
    query.push({
      $unwind: { path: "$makes", preserveNullAndEmptyArrays: true },
    });
    query.push({
      $lookup: {
        from: "models",
        localField: "model",
        foreignField: "_id",
        as: "models",
      },
    });

    query.push({
      $unwind: { path: "$models", preserveNullAndEmptyArrays: true },
    });
    query.push({
      $lookup: {
        from: "bodys",
        localField: "bodyId",
        foreignField: "_id",
        as: "bodys",
      },
    });
    query.push({
      $unwind: { path: "$bodys", preserveNullAndEmptyArrays: true },
    });
    query.push({
      $lookup: {
        from: "series",
        localField: "seriesId",
        foreignField: "_id",
        as: "series",
      },
    });
    query.push({
      $unwind: { path: "$series", preserveNullAndEmptyArrays: true },
    });
    query.push({
      $lookup: {
        from: "fueltypes",
        localField: "fueltypeId",
        foreignField: "_id",
        as: "fueltypes",
      },
    });
    query.push({
      $unwind: { path: "$fueltypes", preserveNullAndEmptyArrays: true },
    });
    query.push({
      $lookup: {
        from: "drivetypes",
        localField: "drivetypeId",
        foreignField: "_id",
        as: "drivetypes",
      },
    });
    query.push({
      $unwind: { path: "$drivetypes", preserveNullAndEmptyArrays: true },
    });
    query.push({
      $lookup: {
        from: "engines",
        localField: "engineId",
        foreignField: "_id",
        as: "engines",
      },
    });
    query.push({
      $unwind: { path: "$engines", preserveNullAndEmptyArrays: true },
    });
    query.push({
      $lookup: {
        from: "branchs",
        localField: "branchId",
        foreignField: "_id",
        as: "branchs",
      },
    });
    query.push({
      $unwind: { path: "$branchs", preserveNullAndEmptyArrays: true },
    });
    query.push({
      $lookup: {
        from: "warehouses",
        localField: "warehosId",
        foreignField: "_id",
        as: "warehouses",
      },
    });
    query.push({
      $unwind: { path: "$warehouses", preserveNullAndEmptyArrays: true },
    });
    //----------------------------------------------------------------
    if (postData.status) {
      postData.status = Number(postData.status);
      query.push({
        $match: {
          inventoryStatus: postData.status,
        },
      });
    }
    if (postData.processStatus) {
      query.push({
        $match: {
          status: postData.processStatus,
        },
      });
    }
    let branchData = [];
    if (postData.branchId) {
      let pdata = postData.branchId;
      for (let i in pdata) {
        branchData.push(mongoose.Types.ObjectId(pdata[i]));
      }
      query.push({
        $match: {
          $and: [
            {
              branchId: {
                $in: branchData,
              },
            },
          ],
        },
      });
    }
    if (postData.tempId) {
      query.push({
        $match: {
          $and: [{ _id: mongoose.Types.ObjectId(postData.tempId) }],
        },
      });
    }
    if (postData.warehosId) {
      query.push({
        $match: {
          warehosId: mongoose.Types.ObjectId(postData.warehosId),
        },
      });
    }
    if (postData.inventoryId) {
      query.push({
        $match: {
          _id: mongoose.Types.ObjectId(postData.inventoryId),
        },
      });

      query.push({
        $lookup: {
          from: "vinimages",
          // localField: "salesUserId",
          // foreignField: "_id",
          let: {
            inventoryId: "$_id",
            imageType: "inventory",
          },
          pipeline: [
            {
              $match: {
                $expr: {
                  $and: [
                    { $eq: ["$imageType", "$$imageType"] },
                    { $eq: ["$referenceId", "$$inventoryId"] },
                  ],
                },
              },
            },
          ],
          as: "vinimages",
        },
      });
    }
    if (postData.search) {
      query.push({
        $match: {
          $and: [
            {
              $or: [
                { vin: { $regex: postData.search, $options: "i" } },
                { year: { $regex: postData.search, $options: "i" } },
              ],
            },
          ],
        },
      });
    } else {
      query.push({
        $match: {
          $and: [{ costPrice: { $exists: true } }],
        },
      });
    }
    const sQuery = [...query];
    query.push({
      $project: {
        // sellerId1:{ $ifNull: [ "$users?.uniqueIdentifier", "" ] } ,
        lotNo: 1,
        vin: 1,
        make: "$makes",
        model: "$models",
        makeName: "$makes.makeName",
        modelName: "$models.modelName",
        warehouses: 1,
        branchs: 1,
        bodys: 1,
        drivetypes: 1,
        fueltypes: 1,
        series: 1,
        engines: 1,
        year: 1,
        color: "$interiorcolors",
        exteriorcolors: 1,
        specification: 1,
        branchId: "$branchs._id",
        branchName: "$branchs.branchName",
        warehosId: "$warehouses._id",
        milage: 1,
        costPrice: 1,
        startingBid: 1,
        containerNo: 1,
        reservePrice: 1,
        sellerReservePrice: 1,
        sellerPriceAccept: 1,
        lastAuctionDate: 1,
        lastBid: 1,
        inventoryStatus: 1,
        planPrice: 1,
        rejectedMsg: 1,
        vccDoc: 1,
        purchaseDoc: 1,
        status: 1,
        createdAt: 1,
        remarks: 1,
        //vinimages: 1,
        //singleImages: { $arrayElemAt: ["$singlevinimages.image", 0] },
        singleImages: {
          $cond: {
            if: {
              $ne: ["$singlevinimages", []],
            },
            then: { $arrayElemAt: ["$singlevinimages.image", 0] },
            else: config.defaultInventoryImage,
          },
        },
        vinimages: {
          $cond: {
            if: {
              $ne: ["$vinimages", []],
            },
            then: "$vinimages",
            else: config.defaultInventoryImage,
          },
        },
        sellerId: {
          $cond: {
            if: { $eq: ["$users", {}] },
            then: "",
            else: "$users",
          },
        },
        sellerDbId: {
          $cond: {
            if: { $eq: ["$users", {}] },
            then: "",
            else: "$users._id",
          },
        },
      },
    });

    query.push({ $sort: { createdAt: -1 } });
    sQuery.push({ $count: "recordCount" });

    if (postData.page) {
      query.push({
        $skip: cmethod.pageOffset(postData.page, postData.pageLimit),
      });
      query.push({ $limit: cmethod.pageLimit(postData.pageLimit) });
    }

    intventoryDao
      .findInventoryTempAggregation(query)
      .then(function (data) {
        intventoryDao
          .findInventoryTempAggregation(sQuery)
          .then(async function (dcount) {
            let tptCnt = 0;
            if (dcount.length > 0) {
              tptCnt = dcount[0].recordCount;
            }
            res.status(200).json({
              status: true,
              result: data,
              message: "",
              hasMore: cmethod.hasMoreCount(
                tptCnt,
                postData.page,
                postData.pageLimit
              ),
              totalCount: tptCnt,
            });
          })
          .catch((err) => {
            cmethod.returnSreverError(res, message[lang].technicalError, err);
          });
      })
      .catch((err) => {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      });
  }
);
router.delete("/templistalldelete", async (req, res) => {
  let lang = req.headers["lang"] || config.lang;
  let postData = req.body;
  let queryCond = { userId: mongoose.Types.ObjectId(postData.userId) };
  inventoryModal.Inventorytemps.deleteMany(queryCond, function (err, data) {
    if (err) {
      cmethod.returnSreverError(res, message[lang].technicalError, err);
    } else {
      cmethod.returnSuccess(res, [], false, message[lang].Deleted);
    }
  });
});
router.delete(
  "/templistdelete",
  [midleware.validateFieldValue(["tempId"], ["tempId"])],
  (req, res) => {
    let lang = req.headers["lang"] || config.lang;
    let postData = req.body;
    let queryCond = { _id: mongoose.Types.ObjectId(postData.tempId) };
    inventoryModal.Inventorytemps.deleteOne(queryCond, function (err, data) {
      if (err) {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      } else {
        cmethod.returnSuccess(res, [], false, message[lang].Deleted);
      }
    });
  }
);
router.delete(
  "/duplicatetemplistdelete",
  [midleware.validateFieldValue(["duplicatetempId"], ["duplicatetempId"])],
  (req, res) => {
    let lang = req.headers["lang"] || config.lang;
    let postData = req.body;
    let queryCond = {
      duplicatetemp: 1,
      userId: mongoose.Types.ObjectId(postData.userId),
    };
    inventoryModal.Inventorytemps.deleteMany(queryCond, function (err, data) {
      if (err) {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      } else {
        cmethod.returnSuccess(res, [], false, message[lang].Deleted);
      }
    });
  }
);
router.patch(
  "/templistupdate",
  [midleware.validateFieldValue(["templistId"], ["templistId"])],
  async (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let xtoken = req.headers["x-access-token"];
    //{ token: xtoken },
    let queryCond = {
      $and: [{ _id: mongoose.Types.ObjectId(postData.templistId) }],
    };

    //Check duplicate set duplicatetemp=1
    let queryCond2 = { $and: [{ vin: postData.vin }] };
    delete postData.templistId;
    //postData.vin = await cmethod.vinnosixDigit(postData.vin);
    let vintempData2 = await inventoryModal.Inventorytemps.findOne(queryCond2, {
      vin: 1,
    });
    if (vintempData2 != undefined || vintempData2 != null) {
      await inventoryModal.Inventorytemps.updateOne(
        { _id: mongoose.Types.ObjectId(vintempData2._id) },
        { $set: { duplicatetemp: 1 } }
      );
    } else {
      await inventoryModal.Inventorytemps.updateOne(
        { _id: mongoose.Types.ObjectId(postData.templistId) },
        { $set: { duplicatetemp: 0 } }
      );
    }

    inventoryModal.Inventorytemps.findOneAndUpdate(
      queryCond,
      { $set: postData },
      { new: true },
      async function (err, data) {
        if (err) {
          cmethod.returnSreverError(res, message[lang].technicalError, err);
        } else {
          let remarksArr = [];
          if (data.vin) {
            let vinData = await inventoryModal.Inventory.findOne(
              { vin: data.vin },
              { vin: 1, inventoryStatus: 1 }
            );
            //console.log('0--------------------------->', vinData);
            if (vinData) {
              if ([0, 1, 2].includes(vinData?.inventoryStatus)) {
                await inventoryModal.Inventorytemps.updateOne(
                  { _id: mongoose.Types.ObjectId(data._id) },
                  { $set: { duplicatetemp: 1 } }
                );
                remarksArr.push(data.vin + " is dublicate data");
              }
              let checkvinno1 = await cmethod.vinnosixDigit(data.vin);
              //console.log('3100--------------------------->', checkvinno1);
              if (checkvinno1) {
                remarksArr.push(" ");
              } else {
                //console.log('else0--------------------------->');
                remarksArr.push(data.vin + " Vin no should be 17 digit.%");
              }
            } else {
              await inventoryModal.Inventorytemps.updateOne(
                { _id: mongoose.Types.ObjectId(data._id) },
                { $set: { duplicatetemp: 0 } }
              );

              //console.log('1--------------------------->', mongoose.Types.ObjectId(data._id));
              let queryCond = {
                $and: [{ _id: { $ne: mongoose.Types.ObjectId(data._id) } }],
              };

              let vintempData = await inventoryModal.Inventorytemps.findOne(
                queryCond,
                { vin: 1 }
              );
              //console.log('2100--------------------------->', vintempData);
              //console.log('INDIA--------------------------->', postData);
              if (vintempData != undefined || vintempData != null) {
                let checkvinno = await cmethod.vinnosixDigit(data.vin);
                //console.log('38888100--------------------------->', checkvinno);
                if (checkvinno) {
                  remarksArr.push(" ");
                } else {
                  remarksArr.push(data.vin + " Vin no should be 17 digit#.");
                  //console.log('else1--------------------------->');
                }
              } else {
                remarksArr.push("");
              }
            }
          }
          if (remarksArr.length > 0) {
            let text = remarksArr.join("<br>");
            await inventoryModal.Inventorytemps.updateOne(
              { _id: mongoose.Types.ObjectId(data._id) },
              { $set: { remarks: text } }
            );
          }
          //console.log('remarksArr--------------------------->', remarksArr);
          cmethod.returnSuccess(res, data, false, message[lang].Updated);
        }
      }
    );
  }
);
router.patch(
  "/update",
  [midleware.validateFieldValue(["inventoryId"], ["inventoryId"])],
  (req, res) => {
    let postData = req.body;
    const { processedBy, inspection } = postData;
    let lang = req.headers["lang"] || config.lang;
    let xtoken = req.headers["x-access-token"];
    let queryCond = {
      $and: [{ _id: mongoose.Types.ObjectId(postData.inventoryId) }],
    };

    delete postData.inventoryId;
    inventoryModal.Inventory.findOneAndUpdate(
      queryCond,
      { $set: postData },
      { new: true },
      async function (err, data) {
        if (err) {
          cmethod.returnSreverError(res, message[lang].technicalError, err);
        } else {
          const inventoryId = data._id;
          let insertImages = [];
          let allImages = postData?.images;
          if (postData?.images && allImages.length > 0) {
            const { _id: inventoryId } = data;
            const filter = {
              imageType: "inventory",
              type: "carimage",
              referenceId: inventoryId,
              defaultimage: 1,
            };
            const previousVinImagesCount = await Count(
              vinModal.Vinimage,
              filter
            );
            allImages.forEach((value, index) => {
              const addDefaultImage =
                index === 0 && previousVinImagesCount === 0
                  ? { defaultimage: 1 }
                  : {};
              insertImages.push({
                imageType: "inventory",
                referenceId: data._id,
                image: value,
                type: "carimage",
                ...addDefaultImage,
              });
            });
          }
          if (isArrayWithLength(postData?.sellerInventoryImages)) {
            postData?.sellerInventoryImages.forEach((value, index) => {
              insertImages.push({
                imageType: "inventory",
                referenceId: data._id,
                image: value,
                type: "seller-car-image",
                ...(index === 0 && { defaultimage: 1 }),
              });
            });
          }
          if (postData?.vccDoc) {
            insertImages.push({
              imageType: "inventory",
              referenceId: mongoose.Types.ObjectId(data._id),
              image: postData?.vccDoc,
              type: "cardocumnet",
            });
          }
          if (postData?.purchaseDoc) {
            insertImages.push({
              imageType: "inventory",
              referenceId: mongoose.Types.ObjectId(data._id),
              image: postData?.purchaseDoc,
              type: "cardocumnet",
            });
          }
          if (postData?.reservepriceDoc) {
            insertImages.push({
              imageType: "inventory",
              referenceId: mongoose.Types.ObjectId(data._id),
              image: postData?.reservepriceDoc,
              type: "addendum",
            });
          }
          if (data?.mulkiya) {
            insertImages.push({
              imageType: "inventory",
              referenceId: mongoose.Types.ObjectId(data._id),
              image: data?.mulkiya,
              type: "cardocumnet",
            });
          }
          if (data?.hayaza) {
            insertImages.push({
              imageType: "inventory",
              referenceId: mongoose.Types.ObjectId(data._id),
              image: data?.hayaza,
              type: "cardocumnet",
            });
          }
          const inspectionObj =
            inspection && Object.keys(inspection).length > 0;
          if (inspectionObj) {
            const filter = { inventoryId };
            const update = {
              inspectedAt: Date.now(),
              inspectedBy: processedBy,
            };

            for (const key in inspection) {
              update[`components.${key}`] = inspection[key];
            }
            await updateInspection(filter, update);
          }
          await vinModal.Vinimage.insertMany(insertImages);

          cmethod.returnSuccess(res, data, false, message[lang].Updated);
        }
      }
    );
  }
);

router.post(
  "/getPassList",
  //[midleware.validateFieldValue(["pageLimit", "page"], ["page"])],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let query = [];

    NotNullMatch(query, "referenceNo");

    if (postData.fromDate && postData.toDate) {
      query.push({
        $match: {
          $and: [
            {
              createdAt: {
                $gte: new Date(
                  cmethod.startTimeString(new Date(postData.fromDate))
                ),
              },
            },
            {
              createdAt: {
                $lte: new Date(
                  cmethod.endTimeString(new Date(postData.toDate))
                ),
              },
            },
          ],
        },
      });
    }

    if (postData.processedDateFrom && postData.processedDateTo) {
      query.push({
        $match: {
          $and: [
            {
              processedDate: {
                $gte: new Date(
                  cmethod.startTimeString(new Date(postData.processedDateFrom))
                ),
              },
            },
            {
              processedDate: {
                $lte: new Date(
                  cmethod.endTimeString(new Date(postData.processedDateTo))
                ),
              },
            },
          ],
        },
      });
    }

    // * inventorys
    query.push({
      $lookup: {
        from: "inventorys",
        localField: "inventoryId",
        foreignField: "_id",
        as: "inventorys",
      },
    });
    query.push({
      $unwind: { path: "$inventorys", preserveNullAndEmptyArrays: true },
    });

    // * exteriorcolors
    query.push({
      $lookup: {
        from: "exteriorcolors",
        localField: "inventorys.exteriorcolorId",
        foreignField: "_id",
        as: "exteriorcolors",
      },
    });
    query.push({
      $unwind: { path: "$exteriorcolors", preserveNullAndEmptyArrays: true },
    });

    // * makes
    query.push({
      $lookup: {
        from: "makes",
        localField: "inventorys.make",
        foreignField: "_id",
        as: "makes",
      },
    });
    query.push({
      $unwind: { path: "$makes", preserveNullAndEmptyArrays: true },
    });

    // * models
    query.push({
      $lookup: {
        from: "models",
        localField: "inventorys.model",
        foreignField: "_id",
        as: "models",
      },
    });
    query.push({
      $unwind: { path: "$models", preserveNullAndEmptyArrays: true },
    });

    // * branchs
    query.push({
      $lookup: {
        from: "branchs",
        localField: "inventorys.branchId",
        foreignField: "_id",
        as: "branchs",
      },
    });
    query.push({
      $unwind: { path: "$branchs", preserveNullAndEmptyArrays: true },
    });

    // * warehouses
    query.push({
      $lookup: {
        from: "warehouses",
        localField: "inventorys.warehosId",
        foreignField: "_id",
        as: "warehouses",
      },
    });
    query.push({
      $unwind: { path: "$warehouses", preserveNullAndEmptyArrays: true },
    });

    // * commentlogs
    query.push({
      $lookup: {
        from: "commentlogs",
        let: {
          referenceIds: "$referenceId",
          referenceId: "$referenceId",
        },
        pipeline: [
          {
            $match: {
              $expr: {
                $and: [{ $eq: ["$referenceId", "$$referenceIds"] }],
              },
            },
          },
        ],
        as: "commentlogs",
      },
    });

    // * inspection
    if (postData?.direction === "in" && postData?.status === "pending") {
      Lookup(query, "inspections", "inventoryId", "inventoryId", "inspection");
      Unwind(query, "$inspection");
    }

    if (postData.inventoryId) {
      query.push({
        $match: {
          inventoryId: mongoose.Types.ObjectId(postData.inventoryId),
        },
      });
    }
    if (postData.referenceNo) {
      query.push({
        $match: {
          $and: [
            {
              $or: [
                { referenceNo: postData.referenceNo },
                { "inventorys.vin": postData.referenceNo },
              ],
            },
          ],
        },
      });
    }
    if (postData.referenceType) {
      query.push({
        $match: {
          referenceType: postData.referenceType,
        },
      });
    }
    if (postData.search) {
      query.push({
        $match: {
          $and: [
            {
              $or: [
                { referenceNo: { $regex: postData.search, $options: "i" } },
                {
                  "inventorys.vin": { $regex: postData.search, $options: "i" },
                },
              ],
            },
          ],
        },
      });
    }
    if (postData.direction) {
      query.push({
        $match: {
          $and: [{ direction: postData.direction }],
        },
      });
    }
    if (postData.status) {
      query.push({
        $match: {
          $and: [{ status: postData.status }],
        },
      });
    }
    if (postData.inventoryType) {
      query.push({
        $match: {
          $and: [{ "inventorys.inventoryType": postData.inventoryType }],
        },
      });
    }
    if (postData.containerNo) {
      ExactMatch(query, "inventorys.containerNo", postData.containerNo);
    }
    if (postData.processedBy) {
      ExactMatch(query, "processedBy", postData.processedBy);
    }

    let branchData = [];
    if (postData.branchId) {
      let pdata = postData.branchId;
      for (let i in pdata) {
        branchData.push(mongoose.Types.ObjectId(pdata[i]));
      }
      query.push({
        $match: {
          $and: [
            {
              "inventorys.branchId": {
                $in: branchData,
              },
            },
          ],
        },
      });
    }
    let warehosData = [];
    if (postData.warehosId) {
      let pdata = postData.warehosId;
      for (let i in pdata) {
        warehosData.push(mongoose.Types.ObjectId(pdata[i]));
      }
      query.push({
        $match: {
          $and: [
            {
              "inventorys.warehosId": {
                $in: warehosData,
              },
            },
          ],
        },
      });
    }
    // if (postData.warehosId) {
    //   query.push({
    //     $match: {
    //       "inventorys.warehosId": mongoose.Types.ObjectId(postData.warehosId),
    //     },
    //   });
    // }

    // * receipts
    query.push({
      $lookup: {
        from: "reciepts",
        localField: "referenceNo",
        foreignField: "recieptNo",
        as: "receipts",
      },
    });
    query.push({
      $unwind: { path: "$receipts", preserveNullAndEmptyArrays: true },
    });

    // * addFields - gatePassOf
    query.push({
      $addFields: {
        gatePassOf: {
          $cond: {
            if: {
              $and: [
                {
                  $or: [
                    {
                      $eq: ["$direction", "in"],
                    },
                    {
                      $eq: ["$direction", "out"],
                    },
                  ],
                },
                {
                  $eq: ["$referenceType", "inventory"],
                },
              ],
            },
            then: "$inventorys.sellerId",
            else: "$receipts.buyerId",
          },
        },
      },
    });

    // * users
    query.push({
      $lookup: {
        from: "users",
        localField: "gatePassOf",
        foreignField: "_id",
        as: "users",
      },
    });
    query.push({
      $unwind: { path: "$users", preserveNullAndEmptyArrays: true },
    });

    if (postData.userId) {
      query.push({
        $match: {
          "users._id": mongoose.Types.ObjectId(postData.userId),
        },
      });
    }

    query.push({
      $project: {
        userName: "$users.name",
        passNo: 1,
        direction: 1,
        referenceType: 1,
        referenceId: 1,
        referenceNo: 1,
        status: 1,
        createdBy: 1,
        recoveryNo: 1,
        file: 1,
        inventoryId: 1,
        lotNo: "$inventorys.lotNo",
        containerNo: "$inventorys.containerNo",
        vin: "$inventorys.vin",
        commentlogs: "$commentlogs.message",
        warehouseName: "$warehouses.warehouseName",
        warehosId: "$warehouses._id",
        branchName: "$branchs.branchName",
        branchId: "$branchs._id",
        createdAt: 1,
        gatePassExpired: 1,
        exteriorcolors: 1,
        carDescription: {
          $concat: [
            "$inventorys.year",
            " ",
            "$makes.makeName",
            " ",
            "$models.modelName",
          ],
        },
        processedBy: 1,
        processedDate: 1,
        keyNo: "$inventorys.keyNo",
        inspection: "$inspection.components",
        user: {
          name: "$users.name",
          phone: "$users.phone",
          userType: "$users.userType",
          EID: "$users.eid",
          companyDetails: "$users.companyDetails",
        },
      },
    });

    query.push({ $sort: { createdAt: -1 } });

    if (postData.page) {
      query.push({
        $skip: cmethod.pageOffset(postData.page, postData.pageLimit),
      });
      query.push({ $limit: cmethod.pageLimit(postData.pageLimit) });
    }

    intventoryDao
      .findGetPassAggregation(query)
      .then(function (data) {
        const totalCount = (data && data.length) || 0;

        res.status(200).json({
          status: true,
          result: data,
          message: "",
          hasMore: cmethod.hasMoreCount(
            totalCount,
            postData.page,
            postData.pageLimit
          ),
          totalCount,
        });
      })
      .catch((err) => {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      });
  }
);
router.post(
  "/incominggetpass",
  [midleware.validateFieldValue(["pageLimit", "page"], ["page"])],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let query = [];

    // query.push({
    //   $lookup: {
    //     from: "reciepts",
    //     localField: "referenceId",
    //     foreignField: "_id",
    //     as: "reciepts",
    //   },
    // });
    // query.push({
    //   $unwind: { path: "$reciepts", preserveNullAndEmptyArrays: true },
    // });

    query.push({
      $lookup: {
        from: "inventorys",
        localField: "referenceId",
        foreignField: "_id",
        as: "inventorys",
      },
    });
    query.push({
      $unwind: { path: "$inventorys", preserveNullAndEmptyArrays: true },
    });
    query.push({
      $lookup: {
        from: "exteriorcolors",
        localField: "inventorys.exteriorcolorId",
        foreignField: "_id",
        as: "exteriorcolors",
      },
    });
    query.push({
      $unwind: { path: "$exteriorcolors", preserveNullAndEmptyArrays: true },
    });
    query.push({
      $lookup: {
        from: "makes",
        localField: "inventorys.make",
        foreignField: "_id",
        as: "makes",
      },
    });
    query.push({
      $unwind: { path: "$makes", preserveNullAndEmptyArrays: true },
    });
    query.push({
      $lookup: {
        from: "models",
        localField: "inventorys.model",
        foreignField: "_id",
        as: "models",
      },
    });

    query.push({
      $unwind: { path: "$models", preserveNullAndEmptyArrays: true },
    });

    query.push({
      $lookup: {
        from: "branchs",
        localField: "inventorys.branchId",
        foreignField: "_id",
        as: "branchs",
      },
    });
    query.push({
      $unwind: { path: "$branchs", preserveNullAndEmptyArrays: true },
    });
    query.push({
      $lookup: {
        from: "warehouses",
        localField: "inventorys.warehosId",
        foreignField: "_id",
        as: "warehouses",
      },
    });
    query.push({
      $unwind: { path: "$warehouses", preserveNullAndEmptyArrays: true },
    });
    // query.push({
    //   $lookup: {
    //     from: "commentlogs",
    //     localField: "referenceId",
    //     foreignField: "referenceId",
    //     as: "commentlogs",
    //   },
    // });
    // query.push({
    //   $unwind: { path: "$commentlogs", preserveNullAndEmptyArrays: true },
    // });

    query.push({
      $lookup: {
        from: "commentlogs",
        let: {
          referenceIds: "$referenceId",
          referenceId: "$referenceId",
        },
        pipeline: [
          {
            $match: {
              $expr: {
                $and: [{ $eq: ["$referenceId", "$$referenceIds"] }],
              },
            },
          },
        ],
        as: "commentlogs",
      },
    });
    // if (postData.branchId) {
    //   query.push({
    //     $match: {
    //       "inventorys.branchId": mongoose.Types.ObjectId(postData.branchId),
    //     },
    //   });
    // }

    if (postData.referenceNo) {
      query.push({
        $match: {
          $and: [{ referenceNo: postData.referenceNo }],
        },
      });
    }
    if (postData.direction) {
      query.push({
        $match: {
          $and: [{ direction: postData.direction }],
        },
      });
    }

    let branchData = [];
    if (postData.branchId) {
      let pdata = postData.branchId;
      for (let i in pdata) {
        branchData.push(mongoose.Types.ObjectId(pdata[i]));
      }
      query.push({
        $match: {
          $and: [
            {
              "inventorys.branchId": {
                $in: branchData,
              },
            },
          ],
        },
      });
    }
    query.push({
      $project: {
        passNo: 1,
        direction: 1,
        referenceType: 1,
        referenceId: 1,
        reciepts: "$reciepts",
        status: 1,
        createdBy: 1,
        recoveryNo: 1,
        file: 1,
        lotNo: "$inventorys.lotNo",
        vin: "$inventorys.vin",
        commentlogs: "$commentlogs.message",
        warehouseName: "$warehouses.warehouseName",
        branchName: "$branchs.branchName",
        branchId: "$branchs._id",
        inventorys: 1,
        createdBy: 1,
        referenceNo: 1,
        //warehouses: 1,
        createdAt: 1,
        carDescription: {
          $concat: [
            "$inventorys.year",
            " ",
            "$makes.makeName",
            " ",
            "$models.modelName",
            //"$exteriorcolors.colorName",
            //" ",
          ],
        },
      },
    });
    const sQuery = [...query];
    query.push({ $sort: { createdAt: -1 } });
    sQuery.push({ $count: "recordCount" });

    if (postData.page) {
      query.push({
        $skip: cmethod.pageOffset(postData.page, postData.pageLimit),
      });
      query.push({ $limit: cmethod.pageLimit(postData.pageLimit) });
    }

    intventoryDao
      .findGetPassAggregation(query)
      .then(function (data) {
        intventoryDao
          .findGetPassAggregation(sQuery)
          .then(async function (dcount) {
            let tptCnt = 0;
            if (dcount.length > 0) {
              tptCnt = dcount[0].recordCount;
            }
            res.status(200).json({
              status: true,
              result: data,
              message: "",
              hasMore: cmethod.hasMoreCount(
                tptCnt,
                postData.page,
                postData.pageLimit
              ),
              totalCount: tptCnt,
            });
          })
          .catch((err) => {
            cmethod.returnSreverError(res, message[lang].technicalError, err);
          });
      })
      .catch((err) => {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      });
  }
);
router.post(
  "/incomingdocumentpass",
  [midleware.validateFieldValue(["pageLimit", "page"], ["page"])],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let query = [];
    query.push({
      $lookup: {
        from: "inventorys",
        localField: "inventoryId",
        foreignField: "_id",
        as: "inventorys",
      },
    });
    query.push({
      $unwind: { path: "$inventorys", preserveNullAndEmptyArrays: true },
    });
    query.push({
      $lookup: {
        from: "exteriorcolors",
        localField: "inventorys.exteriorcolorId",
        foreignField: "_id",
        as: "exteriorcolors",
      },
    });
    query.push({
      $unwind: { path: "$exteriorcolors", preserveNullAndEmptyArrays: true },
    });
    query.push({
      $lookup: {
        from: "makes",
        localField: "inventorys.make",
        foreignField: "_id",
        as: "makes",
      },
    });
    query.push({
      $unwind: { path: "$makes", preserveNullAndEmptyArrays: true },
    });
    query.push({
      $lookup: {
        from: "models",
        localField: "inventorys.model",
        foreignField: "_id",
        as: "models",
      },
    });

    query.push({
      $unwind: { path: "$models", preserveNullAndEmptyArrays: true },
    });

    query.push({
      $lookup: {
        from: "branchs",
        localField: "inventorys.branchId",
        foreignField: "_id",
        as: "branchs",
      },
    });
    query.push({
      $unwind: { path: "$branchs", preserveNullAndEmptyArrays: true },
    });
    query.push({
      $lookup: {
        from: "warehouses",
        localField: "inventorys.warehosId",
        foreignField: "_id",
        as: "warehouses",
      },
    });
    query.push({
      $unwind: { path: "$warehouses", preserveNullAndEmptyArrays: true },
    });
    query.push({
      $lookup: {
        from: "commentlogs",
        let: {
          referenceIds: "$referenceId",
          referenceId: "$referenceId",
        },
        pipeline: [
          {
            $match: {
              $expr: {
                $and: [{ $eq: ["$referenceId", "$$referenceIds"] }],
              },
            },
          },
        ],
        as: "commentlogs",
      },
    });

    if (postData.referenceNo) {
      query.push({
        $match: {
          $and: [{ referenceNo: postData.referenceNo }],
        },
      });
    }
    if (postData.direction) {
      query.push({
        $match: {
          $and: [{ direction: postData.direction }],
        },
      });
    }

    let branchData = [];
    if (postData.branchId) {
      let pdata = postData.branchId;
      for (let i in pdata) {
        branchData.push(mongoose.Types.ObjectId(pdata[i]));
      }
      query.push({
        $match: {
          $and: [
            {
              "inventorys.branchId": {
                $in: branchData,
              },
            },
          ],
        },
      });
    }
    query.push({
      $project: {
        passNo: 1,
        direction: 1,
        referenceType: 1,
        referenceId: 1,
        // reciepts: "$reciepts",
        status: 1,
        createdBy: 1,
        recoveryNo: 1,
        file: 1,
        lotNo: "$inventorys.lotNo",
        vin: "$inventorys.vin",
        commentlogs: "$commentlogs.message",
        warehouseName: "$warehouses.warehouseName",
        branchName: "$branchs.branchName",
        branchId: "$branchs._id",
        inventorys: 1,
        createdBy: 1,
        referenceNo: 1,
        //warehouses: 1,
        createdAt: 1,
        carDescription: {
          $concat: [
            "$inventorys.year",
            " ",
            "$makes.makeName",
            " ",
            "$models.modelName",
            //" ",
            //"$exteriorcolors.colorName",
            //" ",
          ],
        },
      },
    });
    const sQuery = [...query];
    query.push({ $sort: { createdAt: -1 } });
    sQuery.push({ $count: "recordCount" });

    if (postData.page) {
      query.push({
        $skip: cmethod.pageOffset(postData.page, postData.pageLimit),
      });
      query.push({ $limit: cmethod.pageLimit(postData.pageLimit) });
    }

    intventoryDao
      .findGetDocumentAggregation(query)
      .then(function (data) {
        intventoryDao
          .findGetDocumentAggregation(sQuery)
          .then(async function (dcount) {
            let tptCnt = 0;
            if (dcount.length > 0) {
              tptCnt = dcount[0].recordCount;
            }
            res.status(200).json({
              status: true,
              result: data,
              message: "",
              hasMore: cmethod.hasMoreCount(
                tptCnt,
                postData.page,
                postData.pageLimit
              ),
              totalCount: tptCnt,
            });
          })
          .catch((err) => {
            cmethod.returnSreverError(res, message[lang].technicalError, err);
          });
      })
      .catch((err) => {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      });
  }
);
router.post(
  "/getdocumentList",
  [midleware.validateFieldValue([], [])],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let query = [];

    if (postData.fromDate && postData.toDate) {
      query.push({
        $match: {
          $and: [
            {
              createdAt: {
                $gte: new Date(
                  cmethod.startTimeString(new Date(postData.fromDate))
                ),
              },
            },
            {
              createdAt: {
                $lte: new Date(
                  cmethod.endTimeString(new Date(postData.toDate))
                ),
              },
            },
          ],
        },
      });
    }

    // * inventorys
    query.push({
      $lookup: {
        from: "inventorys",
        localField: "inventoryId",
        foreignField: "_id",
        as: "inventorys",
      },
    });
    query.push({
      $unwind: { path: "$inventorys", preserveNullAndEmptyArrays: true },
    });

    // * exteriorcolors
    query.push({
      $lookup: {
        from: "exteriorcolors",
        localField: "inventorys.exteriorcolorId",
        foreignField: "_id",
        as: "exteriorcolors",
      },
    });
    query.push({
      $unwind: { path: "$exteriorcolors", preserveNullAndEmptyArrays: true },
    });

    // * makes
    query.push({
      $lookup: {
        from: "makes",
        localField: "inventorys.make",
        foreignField: "_id",
        as: "makes",
      },
    });
    query.push({
      $unwind: { path: "$makes", preserveNullAndEmptyArrays: true },
    });

    // * models
    query.push({
      $lookup: {
        from: "models",
        localField: "inventorys.model",
        foreignField: "_id",
        as: "models",
      },
    });
    query.push({
      $unwind: { path: "$models", preserveNullAndEmptyArrays: true },
    });

    // * branchs
    query.push({
      $lookup: {
        from: "branchs",
        localField: "branchId",
        foreignField: "_id",
        as: "branchs",
      },
    });
    query.push({
      $unwind: { path: "$branchs", preserveNullAndEmptyArrays: true },
    });

    // * warehouses
    query.push({
      $lookup: {
        from: "warehouses",
        localField: "warehosId",
        foreignField: "_id",
        as: "warehouses",
      },
    });
    query.push({
      $unwind: { path: "$warehouses", preserveNullAndEmptyArrays: true },
    });

    // * commentlogs
    query.push({
      $lookup: {
        from: "commentlogs",
        localField: "referenceId",
        foreignField: "referenceId",
        as: "commentlogs",
      },
    });
    query.push({
      $unwind: { path: "$commentlogs", preserveNullAndEmptyArrays: true },
    });

    if (postData.referenceNo) {
      query.push({
        $match: {
          $and: [
            {
              $or: [
                { referenceNo: postData.referenceNo },
                { "inventorys.vin": postData.referenceNo },
              ],
            },
          ],
        },
      });
    }
    if (postData.search) {
      query.push({
        $match: {
          $and: [
            {
              $or: [
                { referenceNo: { $regex: postData.search, $options: "i" } },
                {
                  "inventorys.vin": { $regex: postData.search, $options: "i" },
                },
              ],
            },
          ],
        },
      });
    }
    if (postData.direction) {
      query.push({
        $match: {
          $and: [{ direction: postData.direction }],
        },
      });
    }

    let branchData = [];
    if (postData.branchId) {
      let pdata = postData.branchId;
      for (let i in pdata) {
        branchData.push(mongoose.Types.ObjectId(pdata[i]));
      }
      query.push({
        $match: {
          $and: [
            {
              branchId: {
                $in: branchData,
              },
            },
          ],
        },
      });
    }
    let warehosnewData = [];
    if (postData.warehosIds) {
      let pdata = postData.warehosIds;
      for (let i in pdata) {
        warehosnewData.push(mongoose.Types.ObjectId(pdata[i]));
      }
      query.push({
        $match: {
          $and: [
            {
              warehosId: {
                $in: warehosnewData,
              },
            },
          ],
        },
      });
    }
    let statusArr = [];
    if (postData?.allstatus) {
      let status = postData.allstatus;
      for (let i in status) {
        statusArr.push(status[i]);
      }
      query.push({
        $match: {
          $and: [
            {
              status: {
                $in: statusArr,
              },
            },
          ],
        },
      });
    }

    query.push({
      $project: {
        passNo: 1,
        direction: 1,
        referenceType: 1,
        referenceId: 1,
        referenceNo: 1,
        inventoryId: 1,
        status: 1,
        createdBy: 1,
        file: 1,
        lotNo: "$inventorys.lotNo",
        vin: "$inventorys.vin",
        commentlogs: "$commentlogs.message",
        warehouseName: "$warehouses.warehouseName",
        warehosId: "$warehouses._id",
        branchName: "$branchs.branchName",
        branchId: "$branchs._id",
        createdAt: 1,
        transferId: 1,
        carDescription: {
          $concat: [
            "$inventorys.year",
            " ",
            "$makes.makeName",
            " ",
            "$models.modelName",
            //" ",
            //"$exteriorcolors.colorName",
            //" ",
          ],
        },
      },
    });

    const sQuery = [...query];
    query.push({ $sort: { createdAt: -1 } });
    sQuery.push({ $count: "recordCount" });

    if (postData.page) {
      query.push({
        $skip: cmethod.pageOffset(postData.page, postData.pageLimit),
      });
      query.push({ $limit: cmethod.pageLimit(postData.pageLimit) });
    }

    intventoryDao
      .findGetDocumentAggregation(query)
      .then(function (data) {
        intventoryDao
          .findGetDocumentAggregation(sQuery)
          .then(async function (dcount) {
            let tptCnt = 0;
            if (dcount.length > 0) {
              tptCnt = dcount[0].recordCount;
            }
            res.status(200).json({
              status: true,
              result: data,
              message: "",
              hasMore: cmethod.hasMoreCount(
                tptCnt,
                postData.page,
                postData.pageLimit
              ),
              totalCount: tptCnt,
            });
          })
          .catch((err) => {
            cmethod.returnSreverError(res, message[lang].technicalError, err);
          });
      })
      .catch((err) => {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      });
  }
);
async function addSalerSale(recieptId, callback) {
  let query = {
    $and: [{ _id: mongoose.Types.ObjectId(recieptId) }],
  };
  const recieptData = await recieptModal.Reciept.find(query, {
    buyerId: 1,
    inventoryId: 1,
    saleAmount: 1,
    branchId: 1,
    securityAmount: 1,
    taxType: 1,
    auctionId: 1,
  }).sort({ createdAt: -1 });

  if (recieptData) {
    recieptData.forEach(async (element) => {
      //console.log("===========>sec01",element);
      let querysaler = {
        $and: [{ _id: mongoose.Types.ObjectId(element?.inventoryId) }],
      };
      const userData = await inventoryModal.Inventory.findOne(querysaler, {
        sellerId: 1,
        vin: 1,
      }).sort({ createdAt: -1 });

      let sallerData1;
      let sallerData2;
      let securityDeposit = 0;
      let saleAmounts = 0;
      let vatAmounts = 0;
      let taxAmount = 0;
      let paybleAmount = 0;
      let sellerOrderNo = await cmethod.getSaleOrderNo();
      paybleAmount = paybleAmount + parseInt(element?.saleAmount);
      if (element?.taxType == "tax") {
        taxAmount = element?.securityAmount ? element?.securityAmount : 0;
        paybleAmount = parseInt(paybleAmount) + parseInt(taxAmount);
      }
      if (element?.taxType == "security") {
        securityDeposit = element?.securityAmount ? element?.securityAmount : 0;
        // NOTE: not adding security deposit in seller payable
        // paybleAmount = parseInt(paybleAmount) + parseInt(securityDeposit);
      }

      let calauctiondata = await cmethod.calculateauctioncharge(
        element?.inventoryId,
        element?.saleAmount
      );
      //console.log("calauctiondata----------->",calauctiondata);
      vatAmounts = calauctiondata?.vatamount ? calauctiondata?.vatamount : 0;
      saleAmounts = element?.saleAmount ? element?.saleAmount : 0;
      soldtotalpayment = parseFloat(saleAmounts) + parseFloat(vatAmounts);

      auctionprices = calauctiondata?.auctionprice
        ? calauctiondata?.auctionprice
        : 0;
      listingfees = calauctiondata?.listingfee ? calauctiondata?.listingfee : 0;
      auctiontotalpayment =
        parseFloat(auctionprices) +
        parseFloat(listingfees) +
        parseFloat(vatAmounts);

      sallerData1 = {
        saleOrderNo: sellerOrderNo, //n
        sellerId: makeObjectId(userData?.sellerId), //y
        buyerId: makeObjectId(element?.buyerId), //n,
        recieptId: makeObjectId(recieptId),
        inventoryId: makeObjectId(element?.inventoryId), //n
        auctionId: makeObjectId(recieptData?.auctionId), //n
        serviceType: "sold",
        serviceStatus: "sold",
        auctionTotalAmount: auctiontotalpayment,
        saleAmount: element?.saleAmount, //n,
        vatAmount: taxAmount, //n
        securityDeposit: securityDeposit,
        totalPayment: paybleAmount,
      };
      console.log("sallerData1----------->", sallerData1);
      const newsellerdata1 = new saleRecieptModal.Sellerservice(sallerData1);
      await newsellerdata1.save(sallerData1);

      sallerData2 = {
        saleOrderNo: sellerOrderNo, //n
        sellerId: makeObjectId(userData?.sellerId), //y
        buyerId: makeObjectId(element?.buyerId), //n,
        recieptId: makeObjectId(recieptId),
        inventoryId: makeObjectId(element?.inventoryId), //n
        auctionId: makeObjectId(recieptData?.auctionId), //n
        serviceType: "auction",
        serviceStatus: "sold",
        saleTotalAmount: paybleAmount,
        saleAmount: 0, //n,
        auctionFee: calauctiondata?.auctionprice, //n
        listingFee: calauctiondata?.listingfee, //y
        serviceCharge: calauctiondata?.servicecharge,
        vatAmount: calauctiondata?.vatamount, //n
        securityDeposit: 0,
        totalPayment: auctiontotalpayment,
      };
      const newsellerdata2 = new saleRecieptModal.Sellerservice(sallerData2);
      await newsellerdata2.save(sallerData2);

      //add ledger data after payment done by buyer
      /*get seller pay account id base of payment type */
      let ledgerData = [];
      let voucherNoUnique = await cmethod.getVoucherNo();
      //seller
      const sellerData = await userModal.User.findOne(
        { _id: mongoose.Types.ObjectId(userData?.sellerId) },
        {
          uniqueIdentifier: 1,
        }
      ).sort({ createdAt: -1 });
      let sellerNo;
      if (sellerData) {
        sellerNo = sellerData?.uniqueIdentifier;
      }
      //buyer
      const buyerData = await userModal.User.findOne(
        { _id: mongoose.Types.ObjectId(element?.buyerId) },
        {
          uniqueIdentifier: 1,
        }
      ).sort({ createdAt: -1 });

      let buyerNo;
      if (buyerData) {
        buyerNo = buyerData?.uniqueIdentifier;
      }

      const accountpaySellerData = await account.Accountmaster.findOne(
        { markAccountId: "payable-to-seller" },
        {
          markAccountId: 1,
        }
      ).sort({ createdAt: -1 });
      let paySellerAccountId = accountpaySellerData?._id;
      /*get account id base of payment type */
      //for recievable amount or due amount.
      ledgerData.push({
        branchId: mongoose.Types.ObjectId(element?.branchId),
        glAccountId: mongoose.Types.ObjectId(paySellerAccountId),
        voucherNo: voucherNoUnique,
        transactionType: "cr",
        paymentType: "",
        payAmount: Number(paybleAmount),
        referenceType: "seller reciept",
        // referenceId: mongoose.Types.ObjectId(data._id),
        referenceNo: "",
        referenceNo2: userData?.vin,
        buyerNo: buyerNo,
        sellerNo: sellerNo,
        createdBy: "system",
        transDate: new Date(),
        transactionOf: "seller",
      });

      /*get sales account id base of payment type */
      const accountSalesData = await account.Accountmaster.findOne(
        { markAccountId: "sales" },
        {
          markAccountId: 1,
        }
      ).sort({ createdAt: -1 });
      let salesAccountId = accountSalesData?._id;
      /*get sales account id base of payment type */
      //for sales entry.
      ledgerData.push({
        branchId: mongoose.Types.ObjectId(element?.branchId),
        glAccountId: mongoose.Types.ObjectId(salesAccountId),
        voucherNo: voucherNoUnique,
        transactionType: "dr",
        paymentType: "",
        payAmount: Number(element?.saleAmount),
        referenceType: "seller reciept",
        referenceNo: "",
        referenceNo2: userData?.vin,
        buyerNo: buyerNo,
        sellerNo: sellerNo,
        createdBy: "system",
        transDate: new Date(),
        transactionOf: "seller",
      });

      /*get sales account id base of payment type */
      if (taxAmount > 0) {
        const accountGroupData = await account.Accountmaster.findOne(
          { markAccountId: "vat" },
          {
            markAccountId: 1,
          }
        ).sort({ createdAt: -1 });
        let vatAcoountId = accountGroupData?._id;
        /*get sales account id base of payment type */
        //for sales entry.
        ledgerData.push({
          branchId: mongoose.Types.ObjectId(element?.branchId),
          glAccountId: mongoose.Types.ObjectId(vatAcoountId),
          voucherNo: voucherNoUnique,
          transactionType: "dr",
          paymentType: "",
          payAmount: Number(taxAmount),
          referenceType: "seller reciept",
          referenceNo: "",
          referenceNo2: userData?.vin,
          buyerNo: buyerNo,
          sellerNo: sellerNo,
          createdBy: "system",
          transDate: new Date(),
          transactionOf: "seller",
        });
      }

      await account.Accountledger.insertMany(ledgerData);
    });
  }
  return callback(true);
}
router.patch(
  "/getpassupdate",
  [midleware.validateFieldValue(["getpassId"], ["getpassId"])],
  async (req, res) => {
    let postData = req.body;
    const { branchId, warehosId, processedBy, processedDate, inspection } =
      postData;
    //console.log("getpassupdate-----", postData);
    let oldBranchId = "";
    let lang = req.headers["lang"] || config.lang;
    let xtoken = req.headers["x-access-token"];
    //{ token: xtoken },
    var todaydate = new Date(new Date().getTime());
    todaydate.setDate(todaydate.getDate());
    todaydate.setUTCHours(0, 0, 0, 0);

    var expiredate = new Date(postData.gatePassExpired);
    expiredate.setDate(expiredate.getDate());
    expiredate.setUTCHours(0, 0, 0, 0);

    //console.log(todaydate.getTime(), '------------>', expiredate.getTime());

    let queryCond = {
      $and: [{ _id: mongoose.Types.ObjectId(postData.getpassId) }],
    };
    let queryCond2 = {
      $and: [{ _id: mongoose.Types.ObjectId(postData.inventoryId) }],
    };

    delete postData.getpassId;

    if (postData.direction == "in" && postData.status == "in warehouse") {
      if (branchId && warehosId) {
        const Model = inventoryModal.Inventory;
        oldBranchId = await FindByIdWithKey(
          Model,
          postData.inventoryId,
          "branchId"
        );
      }
      //if (todaydate.getTime() == expiredate.getTime()) {
      // warehosId: mongoose.Types.ObjectId(postData?.warehosId), branchId: mongoose.Types.ObjectId(postData?.branchId)
      //update keyNo
      if (postData?.keyNo) {
        await inventoryModal.Inventory.updateOne(queryCond2, {
          $set: {
            keyNo: postData?.keyNo,
          },
        });
      }
      //incomimng getpass
      await inventoryModal.Getpass.updateOne(queryCond, {
        $set: {
          status: postData?.status,
          ...(processedBy && { processedBy }),
          ...(processedDate && { processedDate }),
        },
      });
      inventoryModal.Inventory.findOneAndUpdate(
        queryCond2,
        {
          $set: {
            inventoryStatus: 1,
            getpassissue: 0,
            transferId: null,
            ...(branchId && { branchId }),
            ...(warehosId && { warehosId }),
          },
        }, //
        { new: true },
        async function (err, data) {
          if (err) {
            cmethod.returnSreverError(res, message[lang].technicalError, err);
          } else {
            //add image in vinimage
            let insertImages = [];
            let allgetpassImages = postData?.getpassinImage;
            if (postData?.getpassinImage && allgetpassImages.length > 0) {
              allgetpassImages.forEach((value, index) => {
                insertImages.push({
                  imageType: "inventory",
                  referenceId: mongoose.Types.ObjectId(data._id),
                  image: value,
                  type: "incoming getpass",
                });
              });
              await vinModal.Vinimage.insertMany(insertImages);
            }
            // * add plan
            // await intventoryDao.addcarPlan(data?._id);
            const inventoryId = data?._id;
            if (branchId && warehosId) {
              const isCarPlanAdded = await updateCarWisePlanWithInventoryId(
                inventoryId
              );
              if (isCarPlanAdded) {
                const Model = inventoryModal.Carwisesellerplan;
                const filter = {
                  inventoryId: mongoose.Types.ObjectId(postData.inventoryId),
                  branchId: mongoose.Types.ObjectId(oldBranchId),
                  sellerId: mongoose.Types.ObjectId(data.sellerId),
                };
                await DeleteOne(Model, filter);
              }
            }

            const inspectionObj =
              inspection && Object.keys(inspection).length > 0;
            if (inspectionObj) {
              const filter = { inventoryId };
              const update = {
                inspectedAt: Date.now(),
                inspectedBy: processedBy,
                components: inspection,
              };
              await updateInspection(filter, update);
            }
            cmethod.returnSuccess(res, data, false, message[lang].Updated);
          }
        }
      );
      // } else {
      //   cmethod.returrnErrorMessage(res, message[lang].datenotmatch);
      // }
    } else {
      //console.log('---------------else',postData);
      //outgoing getpass
      let outgetpassImages = postData?.file;
      delete postData.file;
      inventoryModal.Getpass.findOneAndUpdate(
        queryCond,
        { $set: postData },
        { new: true },
        async function (err, data) {
          if (err) {
            cmethod.returnSreverError(res, message[lang].technicalError, err);
          } else {
            //console.log("-----part-101", data);
            //console.log("-----part-102", outgetpassImages);
            let insertImages = [];
            //let outgetpassImages = postData?.file;
            if (outgetpassImages && outgetpassImages.length > 0) {
              outgetpassImages.forEach((value, index) => {
                insertImages.push({
                  imageType: "inventory",
                  referenceId: mongoose.Types.ObjectId(data._id),
                  image: value,
                  type: "outgoing Gatepass",
                });
              });
              await vinModal.Vinimage.insertMany(insertImages);
            }

            //addSalerSale
            if (data?.referenceType == "reciept") {
              var result = await addSalerSale(
                data?.referenceId,
                function (result) {}
              );
            }
            cmethod.returnSuccess(res, data, false, message[lang].Updated);
          }
        }
      );
    }
  }
);
router.patch(
  "/getdocumentupdate",
  [midleware.validateFieldValue(["getdocumentId"], ["getdocumentId"])],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let xtoken = req.headers["x-access-token"];
    //{ token: xtoken },
    let queryCond = {
      $and: [{ _id: mongoose.Types.ObjectId(postData.getdocumentId) }],
    };
    //console.log('getdocumentupdate==========>',postData);
    delete postData.getdocumentId;
    inventoryModal.Getdocument.findOneAndUpdate(
      queryCond,
      { $set: postData },
      { new: true },
      async function (err, data) {
        if (err) {
          cmethod.returnSreverError(res, message[lang].technicalError, err);
        } else {
          if (data?.direction == "in" && data?.inventoryId != "") {
            await inventoryModal.Inventory.findOneAndUpdate(
              { _id: mongoose.Types.ObjectId(data.inventoryId) },
              { $set: { carDocRecieved: 1 } }
            );
          }
          //insert data in database
          let insertdocImages = {
            imageType: "inventory",
            referenceId: mongoose.Types.ObjectId(data?.inventoryId),
            image: data?.file,
            type: "incomingdocument",
          };
          const newData = new vinModal.Vinimage(insertdocImages);
          const addnewData = newData.save(insertdocImages);
          /*add inventory images */
          cmethod.returnSuccess(res, data, false, message[lang].Updated);
        }
      }
    );
  }
);
router.post("/inventorytransferadd", async (req, res) => {
  let postData = req.body.itData;
  //let lang = req.headers["lang"] || config.lang;
  //console.log('inventorytransferadd------------->>>>',postData); return false;
  intventoryDao.inventorytransferadd(res, postData);
});
router.post("/documenttransferadd", async (req, res) => {
  let postData = req.body;
  intventoryDao.documenttransferadd(res, postData);
});
router.post("/internalTransfer", async (req, res) => {
  let postData = req.body;
  intventoryDao.inventoryInternaltransferadd(res, postData);
});

// update User

router.post("/inventorytransferlist", async (req, res) => {
  const { body: postData, headers } = req;
  const lang = headers.lang || config.lang;

  const query = [];

  try {
    if (postData.fromDate && postData.toDate) {
      query.push({
        $match: {
          $and: [
            {
              createdAt: {
                $gte: new Date(
                  cmethod.startTimeString(new Date(postData.fromDate))
                ),
              },
            },
            {
              createdAt: {
                $lte: new Date(
                  cmethod.endTimeString(new Date(postData.toDate))
                ),
              },
            },
          ],
        },
      });
    }

    let warehosnewData = [];
    if (postData.warehosIds) {
      let pdata = postData.warehosIds;
      for (let i in pdata) {
        warehosnewData.push(mongoose.Types.ObjectId(pdata[i]));
      }
      query.push({
        $match: {
          $and: [
            {
              $or: [
                {
                  fromWarehouse: {
                    $in: warehosnewData,
                  },
                },
                {
                  toWarehouse: {
                    $in: warehosnewData,
                  },
                },
              ],
            },
          ],
        },
      });
    }

    let branchData = [];
    if (postData.branchId) {
      let pdata = postData.branchId;
      for (let i in pdata) {
        branchData.push(mongoose.Types.ObjectId(pdata[i]));
      }
      query.push({
        $match: {
          $and: [
            {
              $or: [
                {
                  fromBranch: {
                    $in: branchData,
                  },
                },
                {
                  toBranch: {
                    $in: branchData,
                  },
                },
              ],
            },
          ],
        },
      });
    }

    if (postData.inventoryTransId) {
      query.push({
        $match: {
          $and: [{ _id: mongoose.Types.ObjectId(postData.inventoryTransId) }],
        },
      });
    }
    if (postData.Branch) {
      query.push({
        $match: {
          $and: [
            {
              $or: [
                {
                  fromBranch: mongoose.Types.ObjectId(postData.Branch),
                },
                {
                  toBranch: mongoose.Types.ObjectId(postData.Branch),
                },
              ],
            },
          ],
        },
      });
    }
    if (postData.Warehouse) {
      query.push({
        $match: {
          $and: [
            {
              $or: [
                {
                  fromWarehouse: mongoose.Types.ObjectId(postData.Warehouse),
                },
                {
                  toWarehouse: mongoose.Types.ObjectId(postData.Warehouse),
                },
              ],
            },
          ],
        },
      });
    }
    if (postData.status) {
      query.push({
        $match: {
          $and: [
            {
              status: postData.status,
            },
          ],
        },
      });
    }

    // * inventorys
    query.push({
      $lookup: {
        from: "inventorys",
        localField: "inventoryId",
        foreignField: "_id",
        as: "inventorys",
      },
    });
    query.push({
      $unwind: { path: "$inventorys", preserveNullAndEmptyArrays: true },
    });

    // * frombranchs
    query.push({
      $lookup: {
        from: "branchs",
        localField: "fromBranch",
        foreignField: "_id",
        as: "frombranchs",
      },
    });
    query.push({
      $unwind: { path: "$frombranchs", preserveNullAndEmptyArrays: true },
    });

    // * tobranchs
    query.push({
      $lookup: {
        from: "branchs",
        localField: "toBranch",
        foreignField: "_id",
        as: "tobranchs",
      },
    });
    query.push({
      $unwind: { path: "$tobranchs", preserveNullAndEmptyArrays: true },
    });

    // * fromwarehouses
    query.push({
      $lookup: {
        from: "warehouses",
        localField: "fromWarehouse",
        foreignField: "_id",
        as: "fromwarehouses",
      },
    });
    query.push({
      $unwind: { path: "$fromwarehouses", preserveNullAndEmptyArrays: true },
    });

    // * towarehouses
    query.push({
      $lookup: {
        from: "warehouses",
        localField: "toWarehouse",
        foreignField: "_id",
        as: "towarehouses",
      },
    });
    query.push({
      $unwind: { path: "$towarehouses", preserveNullAndEmptyArrays: true },
    });

    // * models
    query.push({
      $lookup: {
        from: "models",
        localField: "inventorys.model",
        foreignField: "_id",
        as: "models",
      },
    });
    query.push({
      $unwind: { path: "$models", preserveNullAndEmptyArrays: true },
    });

    // * makes
    query.push({
      $lookup: {
        from: "makes",
        localField: "inventorys.make",
        foreignField: "_id",
        as: "makes",
      },
    });
    query.push({
      $unwind: { path: "$makes", preserveNullAndEmptyArrays: true },
    });

    // * exteriorcolors
    query.push({
      $lookup: {
        from: "exteriorcolors",
        localField: "inventorys.exteriorcolorId",
        foreignField: "_id",
        as: "exteriorcolors",
      },
    });
    query.push({
      $unwind: { path: "$exteriorcolors", preserveNullAndEmptyArrays: true },
    });

    if (postData.vin) {
      RegexMatch(query, "inventorys.vin", postData.vin);
    }

    if (postData.search) {
      query.push({
        $match: {
          $and: [
            {
              $or: [
                {
                  "inventorys.vin": {
                    $regex: postData.search,
                    $options: "i",
                  },
                },
              ],
            },
          ],
        },
      });
    }

    // * project
    query.push({
      $project: {
        fromBranchId: "$frombranchs._id",
        fromBranchName: "$frombranchs.branchName",
        fromWarehouseId: "$fromwarehouses._id",
        fromWarehouseName: "$fromwarehouses.warehouseName",
        toBranchId: "$tobranchs._id",
        toBranchName: "$tobranchs.branchName",
        toWarehouseId: "$towarehouses._id",
        toWarehouseName: "$towarehouses.warehouseName",
        inventoryId: "$inventorys._id",
        transferId: "$inventorys.transferId",
        makeName: "$makes.makeName",
        modelName: "$models.modelName",
        recoveryNo: 1,
        filePath: 1,
        inventoryVinNo: "$inventorys.vin",
        status: 1,
        createdBy: 1,
        transverType: 1,
        inventorys: 1,
        exteriorcolors: 1,
        createdAt: 1,
        carDescription: {
          $concat: [
            "$inventorys.year",
            " ",
            "$makes.makeName",
            " ",
            "$models.modelName",
            //" ",
            //"$exteriorcolors.colorName",
          ],
        },
        keyNo: "$inventorys.keyNo",
      },
    });

    const sQuery = [...query];

    query.push({ $sort: { createdAt: -1 } });
    sQuery.push({ $count: "totalCount" });

    if (postData.page) {
      query.push({
        $skip: cmethod.pageOffset(postData.page, postData.pageLimit),
      });
      query.push({ $limit: cmethod.pageLimit(postData.pageLimit) });
    }

    const [result, [{ totalCount } = {}] = []] = await MultiAggregate(
      inventoryModal.Inventorytransfer,
      [query, sQuery]
    );

    res.status(200).json({
      status: true,
      result,
      hasMore: cmethod.hasMoreCount(
        totalCount,
        postData.page,
        postData.pageLimit
      ),
      totalCount,
    });
  } catch (error) {
    logger.error(error.message);
    cmethod.returnSreverError(res, message[lang]?.technicalError, error);
  }
});
router.post(
  "/documenttransferlist",
  [midleware.validateFieldValue([], [])],
  (req, res) => {
    let postData = req.body;

    // console.log('==============>', postData);
    let lang = req.headers["lang"] || config.lang;
    let query = [];
    query.push({
      $lookup: {
        from: "inventorys",
        localField: "inventoryId",
        foreignField: "_id",
        as: "inventorys",
      },
    });
    query.push({
      $unwind: { path: "$inventorys", preserveNullAndEmptyArrays: true },
    });
    query.push({
      $lookup: {
        from: "branchs",
        localField: "fromBranch",
        foreignField: "_id",
        as: "frombranchs",
      },
    });
    query.push({
      $unwind: { path: "$frombranchs", preserveNullAndEmptyArrays: true },
    });
    query.push({
      $lookup: {
        from: "branchs",
        localField: "toBranch",
        foreignField: "_id",
        as: "tobranchs",
      },
    });
    query.push({
      $unwind: { path: "$tobranchs", preserveNullAndEmptyArrays: true },
    });
    query.push({
      $lookup: {
        from: "warehouses",
        localField: "fromWarehouse",
        foreignField: "_id",
        as: "fromwarehouses",
      },
    });
    query.push({
      $unwind: { path: "$fromwarehouses", preserveNullAndEmptyArrays: true },
    });
    query.push({
      $lookup: {
        from: "warehouses",
        localField: "toWarehouse",
        foreignField: "_id",
        as: "towarehouses",
      },
    });
    query.push({
      $unwind: { path: "$towarehouses", preserveNullAndEmptyArrays: true },
    });

    /*query.push({
      $lookup: {
        from: "exteriorcolors",
        localField: "inventorys.exteriorcolorId",
        foreignField: "_id",
        as: "exteriorcolors",
      },
    });
    query.push({
      $unwind: { path: "$exteriorcolors", preserveNullAndEmptyArrays: true },
    });
    query.push({
      $lookup: {
        from: "makes",
        localField: "inventorys.make",
        foreignField: "_id",
        as: "makes",
      },
    });
    query.push({
      $unwind: { path: "$makes", preserveNullAndEmptyArrays: true },
    });
    query.push({
      $lookup: {
        from: "models",
        localField: "inventorys.model",
        foreignField: "_id",
        as: "models",
      },
    });

    query.push({
      $unwind: { path: "$models", preserveNullAndEmptyArrays: true },
    });*/
    query.push({
      $lookup: {
        from: "models",
        localField: "inventorys.model",
        foreignField: "_id",
        as: "models",
      },
    });

    query.push({
      $unwind: { path: "$models", preserveNullAndEmptyArrays: true },
    });
    query.push({
      $lookup: {
        from: "makes",
        localField: "inventorys.make",
        foreignField: "_id",
        as: "makes",
      },
    });
    query.push({
      $unwind: { path: "$makes", preserveNullAndEmptyArrays: true },
    });
    query.push({
      $lookup: {
        from: "exteriorcolors",
        localField: "inventorys.exteriorcolorId",
        foreignField: "_id",
        as: "exteriorcolors",
      },
    });
    query.push({
      $unwind: { path: "$exteriorcolors", preserveNullAndEmptyArrays: true },
    });
    if (postData.inventoryTransId) {
      query.push({
        $match: {
          $and: [{ _id: mongoose.Types.ObjectId(postData.inventoryTransId) }],
        },
      });
    }
    /*
    /*carDescription: {
          $concat: [
            "$makes.makeName",
            " ",
            "$models.modelName",
            " ",
            "$exteriorcolors.colorName",
            " ",
            "$inventorys.year",
          ],
        },*/

    if (postData.Branch) {
      query.push({
        $match: {
          $and: [
            {
              $or: [
                {
                  fromBranch: mongoose.Types.ObjectId(postData.Branch),
                },
                {
                  toBranch: mongoose.Types.ObjectId(postData.Branch),
                },
              ],
            },
          ],
        },
      });
    }
    if (postData.Warehouse) {
      query.push({
        $match: {
          $and: [
            {
              $or: [
                {
                  fromWarehouse: mongoose.Types.ObjectId(postData.Warehouse),
                },
                {
                  toWarehouse: mongoose.Types.ObjectId(postData.Warehouse),
                },
              ],
            },
          ],
        },
      });
    }
    if (postData.status) {
      query.push({
        $match: {
          $and: [
            {
              status: postData.status,
            },
          ],
        },
      });
    }

    if (postData.fromDate && postData.toDate) {
      query.push({
        $match: {
          $and: [
            {
              createdAt: {
                $gte: new Date(
                  cmethod.startTimeString(new Date(postData.fromDate))
                ),
              },
            },
            {
              createdAt: {
                $lte: new Date(
                  cmethod.endTimeString(new Date(postData.toDate))
                ),
              },
            },
          ],
        },
      });
    }

    query.push({
      $project: {
        fromBranchId: "$frombranchs._id",
        fromBranchName: "$frombranchs.branchName",
        fromWarehouseId: "$fromwarehouses._id",
        fromWarehouseName: "$fromwarehouses.warehouseName",
        toBranchId: "$tobranchs._id",
        toBranchName: "$tobranchs.branchName",
        toWarehouseId: "$towarehouses._id",
        toWarehouseName: "$towarehouses.warehouseName",
        inventoryId: "$inventorys._id",
        transferId: 1,
        makeName: "$makes.makeName",
        modelName: "$models.modelName",
        recoveryNo: 1,
        filePath: 1,
        lotNo: "$inventorys.lotNo",
        vin: "$inventorys.vin",
        status: 1,
        createdBy: 1,
        transverType: 1,
        inventorys: 1,
        //exteriorcolorId:"$inventorys.exteriorcolorId",
        exteriorcolors: 1,
        createdAt: 1,
        carDescription: {
          $concat: [
            "$inventorys.year",
            " ",
            "$makes.makeName",
            " ",
            "$models.modelName",
            //" ",
            //"$exteriorcolors.colorName",
          ],
        },
      },
    });
    const sQuery = [...query];
    query.push({ $sort: { createdAt: -1 } });
    sQuery.push({ $count: "recordCount" });

    if (postData.page) {
      query.push({
        $skip: cmethod.pageOffset(postData.page, postData.pageLimit),
      });
      query.push({ $limit: cmethod.pageLimit(postData.pageLimit) });
    }

    intventoryDao
      .findDocumentTransferAggregation(query)
      .then(function (data) {
        intventoryDao
          .findDocumentTransferAggregation(sQuery)
          .then(async function (dcount) {
            let tptCnt = 0;
            if (dcount.length > 0) {
              tptCnt = dcount[0].recordCount;
            }
            res.status(200).json({
              status: true,
              result: data,
              message: "",
              hasMore: cmethod.hasMoreCount(
                tptCnt,
                postData.page,
                postData.pageLimit
              ),
              totalCount: tptCnt,
            });
          })
          .catch((err) => {
            cmethod.returnSreverError(res, message[lang].technicalError, err);
          });
      })
      .catch((err) => {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      });
  }
);
router.patch(
  "/documenttransferupdate",
  [
    midleware.validateFieldValue(
      ["inventorytransferId"],
      ["inventorytransferId"]
    ),
  ],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let xtoken = req.headers["x-access-token"];
    let queryCond = {
      $and: [{ _id: mongoose.Types.ObjectId(postData.inventorytransferId) }],
    };
    delete postData.inventorytransferId;
    if (postData.status) {
      postData.status = "Transfer";
    }
    inventoryModal.DocumentTransfer.findOneAndUpdate(
      queryCond,
      { $set: postData },
      { new: true },
      async function (err, data) {
        //update in document table ALSO
        await inventoryModal.Getdocument.findOneAndUpdate(
          { _id: data.inventoryId },
          {
            $set: {
              branchId: data.toBranch,
              warehosId: data.toWarehouse,
              status: "instock",
              transferId: null,
            },
          }
        );

        if (err) {
          cmethod.returnSreverError(res, message[lang].technicalError, err);
        } else {
          cmethod.returnSuccess(res, data, false, message[lang].profileUpdate);
        }
      }
    );
  }
);
router.patch(
  "/inventorytransferupdate",
  [
    midleware.validateFieldValue(
      ["inventorytransferId"],
      ["inventorytransferId"]
    ),
  ],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let xtoken = req.headers["x-access-token"];
    let queryCond = {
      $and: [{ _id: mongoose.Types.ObjectId(postData.inventorytransferId) }],
    };
    delete postData.inventorytransferId;
    if (postData.status == "Transfer") {
      postData.status = "Transfer";
    }
    inventoryModal.Inventorytransfer.findOneAndUpdate(
      queryCond,
      { $set: postData },
      { new: true },
      async function (err, data) {
        //update in inventory ALSO
        let setData = {
          branchId: data.toBranch,
          warehosId: data.toWarehouse,
          ...(postData?.keyNo && { keyNo: postData?.keyNo }),
        };
        if (postData.status == "Transfer") {
          setData["transferId"] = null;
        } else {
          //reschedule case
        }

        await inventoryModal.Inventory.findOneAndUpdate(
          { _id: data.inventoryId },
          {
            $set: setData,
          }
        );

        if (err) {
          cmethod.returnSreverError(res, message[lang].technicalError, err);
        } else {
          cmethod.returnSuccess(res, data, false, message[lang].profileUpdate);
        }
      }
    );
  }
);
router.delete(
  "/inventorytransferdelete",
  [
    midleware.validateFieldValue(
      ["inventorytransferId"],
      ["inventorytransferId"]
    ),
  ],
  (req, res) => {
    let lang = req.headers["lang"] || config.lang;
    let postData = req.body;
    let queryCond = {
      _id: mongoose.Types.ObjectId(postData.inventorytransferId),
    };
    inventoryModal.Inventorytransfer.deleteOne(queryCond, function (err, data) {
      if (err) {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      } else {
        cmethod.returnSuccess(res, [], false, message[lang].Deleted);
      }
    });
  }
);
router.delete(
  "/documenttransferdelete",
  [
    midleware.validateFieldValue(
      ["inventorytransferId"],
      ["inventorytransferId"]
    ),
  ],
  (req, res) => {
    let lang = req.headers["lang"] || config.lang;
    let postData = req.body;
    let queryCond = {
      _id: mongoose.Types.ObjectId(postData.inventorytransferId),
    };
    inventoryModal.DocumentTransfer.deleteOne(queryCond, function (err, data) {
      if (err) {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      } else {
        cmethod.returnSuccess(res, [], false, message[lang].Deleted);
      }
    });
  }
);
router.post(
  "/watchlistadd",
  [
    midleware.validateFieldValue(
      ["inventoryId", "auctionId", "buyerId"],
      ["inventoryId", "auctionId", "buyerId"]
    ),
  ],
  async (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;

    let queryCond = {
      inventoryId: mongoose.Types.ObjectId(postData.inventoryId),
      auctionId: mongoose.Types.ObjectId(postData.auctionId),
      buyerId: mongoose.Types.ObjectId(postData.buyerId),
    };

    intventoryDao.checkwatchlist(queryCond).then(function (doc) {
      if (doc == true) {
        cmethod.returrnErrorMessage(res, message[lang].docExist);
      } else {
        intventoryDao.watchlistAdd(res, postData);
      }
    });
  }
);
router.delete(
  "/watchlistdelete",
  [midleware.validateFieldValue(["watchlistId"], ["watchlistId"])],
  async (req, res) => {
    const { body, headers } = req;
    const lang = headers.lang || config.lang;

    try {
      const { watchlistId } = body;

      const watchlist = await DeleteById(inventoryModal.Watchlist, watchlistId);

      if (!watchlist) {
        return cmethod.returrnErrorMessage(res, "Watchlist not found!");
      }

      cmethod.returnSuccess(res, [], false, "Successfully deleted!");
    } catch (error) {
      logger.error(error.message);
      cmethod.returnSreverError(res, message[lang]?.technicalError, err);
    }
  }
);
router.post(
  "/watchlistlist",
  [midleware.validateFieldValue(["pageLimit", "page"], ["page"])],
  async (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let query = [];

    if (postData.buyerId) {
      query.push({
        $match: {
          $and: [{ buyerId: mongoose.Types.ObjectId(postData.buyerId) }],
        },
      });
    }

    // * inventorys
    query.push({
      $lookup: {
        from: "inventorys",
        localField: "inventoryId",
        foreignField: "_id",
        as: "inventorys",
      },
    });
    query.push({
      $unwind: { path: "$inventorys", preserveNullAndEmptyArrays: true },
    });

    // * branchs
    query.push({
      $lookup: {
        from: "branchs",
        localField: "branchId",
        foreignField: "_id",
        as: "branchs",
      },
    });
    query.push({
      $unwind: { path: "$branchs", preserveNullAndEmptyArrays: true },
    });

    // * interiorcolors
    query.push({
      $lookup: {
        from: "interiorcolors",
        localField: "inventorys.interiorcolorId",
        foreignField: "_id",
        as: "interiorcolors",
      },
    });
    query.push({
      $unwind: { path: "$interiorcolors", preserveNullAndEmptyArrays: true },
    });

    // * exteriorcolors
    query.push({
      $lookup: {
        from: "exteriorcolors",
        localField: "inventorys.exteriorcolorId",
        foreignField: "_id",
        as: "exteriorcolors",
      },
    });
    query.push({
      $unwind: { path: "$exteriorcolors", preserveNullAndEmptyArrays: true },
    });

    // * makes
    query.push({
      $lookup: {
        from: "makes",
        localField: "inventorys.make",
        foreignField: "_id",
        as: "makes",
      },
    });
    query.push({
      $unwind: { path: "$makes", preserveNullAndEmptyArrays: true },
    });

    // * models
    query.push({
      $lookup: {
        from: "models",
        localField: "inventorys.model",
        foreignField: "_id",
        as: "models",
      },
    });
    query.push({
      $unwind: { path: "$models", preserveNullAndEmptyArrays: true },
    });

    // * bodys
    query.push({
      $lookup: {
        from: "bodys",
        localField: "inventorys.bodyId",
        foreignField: "_id",
        as: "bodys",
      },
    });
    query.push({
      $unwind: { path: "$bodys", preserveNullAndEmptyArrays: true },
    });

    // * drivetypes
    query.push({
      $lookup: {
        from: "drivetypes",
        localField: "inventorys.drivetypeId",
        foreignField: "_id",
        as: "drivetypes",
      },
    });
    query.push({
      $unwind: { path: "$drivetypes", preserveNullAndEmptyArrays: true },
    });

    // * series
    query.push({
      $lookup: {
        from: "series",
        localField: "inventorys.seriesId",
        foreignField: "_id",
        as: "series",
      },
    });
    query.push({
      $unwind: { path: "$series", preserveNullAndEmptyArrays: true },
    });

    // * fueltypes
    query.push({
      $lookup: {
        from: "fueltypes",
        localField: "inventorys.fueltypeId",
        foreignField: "_id",
        as: "fueltypes",
      },
    });
    query.push({
      $unwind: { path: "$fueltypes", preserveNullAndEmptyArrays: true },
    });

    // * drivetypes
    query.push({
      $lookup: {
        from: "drivetypes",
        localField: "inventorys.drivetypeId",
        foreignField: "_id",
        as: "drivetypes",
      },
    });
    query.push({
      $unwind: { path: "$drivetypes", preserveNullAndEmptyArrays: true },
    });

    // * engines
    query.push({
      $lookup: {
        from: "engines",
        localField: "inventorys.engineId",
        foreignField: "_id",
        as: "engines",
      },
    });
    query.push({
      $unwind: { path: "$engines", preserveNullAndEmptyArrays: true },
    });

    // * buyersdata
    query.push({
      $lookup: {
        from: "users",
        localField: "buyerId",
        foreignField: "_id",
        as: "buyersdata",
      },
    });
    query.push({
      $unwind: { path: "$buyersdata", preserveNullAndEmptyArrays: true },
    });

    // * singlevinimages
    query.push({
      $lookup: {
        from: "vinimages",
        let: {
          inventoryId: "$inventorys._id",
          imageType: "inventory",
          type: "carimage",
        },
        pipeline: [
          {
            $match: {
              $expr: {
                $and: [
                  { $eq: ["$imageType", "$$imageType"] },
                  { $eq: ["$type", "$$type"] },
                  { $eq: ["$referenceId", "$$inventoryId"] },
                  { $eq: ["$defaultimage", 1] },
                ],
              },
            },
          },
        ],
        as: "singlevinimages",
      },
    });

    // * project
    query.push({
      $project: {
        lotNo: "$inventorys.lotNo",
        vin: "$inventorys.vin",
        //vin: "$inventorys.bidAmount",
        startingBid: "$inventorys.startingBid",
        buyerId: 1,
        inventoryId: 1,
        buyersdata: "$buyersdata",
        // inventorys:"$inventorys".
        branchs: "$branchs.branchName",
        branchId: "$branchs._id",
        bodys: "$bodys.bodyName",
        bodyId: "$bodys._id",
        drivetypes: "$drivetypes.drivetypeName",
        drivetypeId: "$drivetypes._id",
        fueltypes: "$fueltypes.fueltypeName",
        fueltypeId: "$fueltypes._id",
        series: "$series.seriesName",
        seriesId: "$series._id",
        engines: "$engines.engineName",
        enginesId: "$engines._id",
        year: "$inventorys.year",
        color: "$exteriorcolors.colorName",
        exteriorcolorId: "$exteriorcolors._id",
        interiorcolors: "$interiorcolors.colorName",
        interiorcolorId: "$interiorcolors._id",
        make: "$makes.makeName",
        makeId: "$makes._id",
        model: "$models.modelName",
        modelId: "$models._id",
        warehouses: "$warehouses.warehouseName",
        warehosId: "$warehouses._id",
        carDescription: {
          $concat: [
            "$inventorys.year",
            " ",
            "$makes.makeName",
            " ",
            "$models.modelName",
          ],
        },
        singleImages: {
          $cond: {
            if: {
              $ne: ["$singlevinimages", []],
            },
            then: { $arrayElemAt: ["$singlevinimages.image", 0] },
            else: config.defaultInventoryImage,
          },
        },
      },
    });

    const sQuery = [...query];
    query.push({ $sort: { createdAt: -1 } });
    sQuery.push({ $count: "recordCount" });

    if (postData.page) {
      query.push({
        $skip: cmethod.pageOffset(postData.page, postData.pageLimit),
      });
      query.push({ $limit: cmethod.pageLimit(postData.pageLimit) });
    }

    intventoryDao
      .findWatchlistAggregation(query)
      .then(function (data) {
        intventoryDao
          .findWatchlistAggregation(sQuery)
          .then(async function (dcount) {
            let tptCnt = 0;
            if (dcount.length > 0) {
              tptCnt = dcount[0].recordCount;
            }
            res.status(200).json({
              status: true,
              result: data,
              message: "",
              hasMore: cmethod.hasMoreCount(
                tptCnt,
                postData.page,
                postData.pageLimit
              ),
              totalCount: tptCnt,
            });
          })
          .catch((err) => {
            cmethod.returnSreverError(res, message[lang].technicalError, err);
          });
      })
      .catch((err) => {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      });
  }
);
router.post(
  "/addreseverprice",
  [midleware.validateFieldValue(["inventoryId"], ["inventoryId"])],
  async (req, res) => {
    const postData = req.body;
    postData.acaofferDate = Date();
    postData.sellerofferDate = Date();
    intventoryDao.addreseverPrice(res, postData);
  }
);
router.post(
  "/addreseverpricelist",
  [midleware.validateFieldValue(["pageLimit", "page"], ["page"])],
  async (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let query = [];

    if (postData.inventoryId) {
      query.push({
        $match: {
          $and: [
            { inventoryId: mongoose.Types.ObjectId(postData.inventoryId) },
          ],
        },
      });
    }

    query.push({
      $project: {
        inventoryId: 1,
        acaOffer: 1,
        sellerOffer: 1,
        acaStatus: 1,
        sellerStatus: 1,
        createdAt: 1,
        acaofferDate: 1,
        sellerofferDate: 1,
      },
    });
    const sQuery = [...query];
    query.push({ $sort: { createdAt: -1 } });
    sQuery.push({ $count: "recordCount" });

    if (postData.page) {
      query.push({
        $skip: cmethod.pageOffset(postData.page, postData.pageLimit),
      });
      query.push({ $limit: cmethod.pageLimit(postData.pageLimit) });
    }

    intventoryDao
      .findAddreseverpriceAggregation(query)
      .then(function (data) {
        intventoryDao
          .findAddreseverpriceAggregation(sQuery)
          .then(async function (dcount) {
            let tptCnt = 0;
            if (dcount.length > 0) {
              tptCnt = dcount[0].recordCount;
            }
            res.status(200).json({
              status: true,
              result: data,
              message: "",
              hasMore: cmethod.hasMoreCount(
                tptCnt,
                postData.page,
                postData.pageLimit
              ),
              totalCount: tptCnt,
            });
          })
          .catch((err) => {
            cmethod.returnSreverError(res, message[lang].technicalError, err);
          });
      })
      .catch((err) => {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      });
  }
);
router.patch(
  "/inventoryRequestUpdate",
  [midleware.validateFieldValue(["inventoryId"], ["inventoryId"])],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let queryCond = {
      $and: [{ _id: mongoose.Types.ObjectId(postData.inventoryId) }],
    };
    delete postData.inventoryId;
    if (postData.status == "approved") {
      postData.status = "approved";
      inventoryModal.Inventory.findOneAndUpdate(
        queryCond,
        { $set: { status: "approved" } }, //, inventoryStatus: 1
        { new: true },
        async function (err, data) {
          if (err) {
            cmethod.returnSreverError(res, message[lang].technicalError, err);
          } else {
            //console.log('inventoryRequestUpdate======---------->>>>>',data);
            // Add get pass
            // let passNoUnique = await cmethod.getPassNo();
            // let savegetPassData = {
            //   passNo: passNoUnique,
            //   direction: "in",
            //   referenceType: "inventory",
            //   referenceNo: data?.vin,
            //   inventoryId: mongoose.Types.ObjectId(data?._id),
            //   status: "pending",
            //   gatePassExpired: postData?.gatePassExpired,
            //   createdBy: data?.createdBy,
            // }
            // await cmethod.addgetPass(savegetPassData);

            // Add get document
            let docNoUnique = await cmethod.getDocumentpass();
            let savegetDocumentData = {
              passNo: docNoUnique,
              direction: "in",
              referenceType: "inventory",
              referenceNo: data?.vin,
              status: "pending",
              inventoryId: mongoose.Types.ObjectId(data?._id),
              branchId: mongoose.Types.ObjectId(data?.branchId),
              warehosId: mongoose.Types.ObjectId(data?.warehosId),
              createdBy: data?.createdBy,
            };
            await cmethod.addgetDocument(savegetDocumentData);
            if (postData?.message != "") {
              let saveCommentLogData = {
                referenceType: "inventory",
                referenceId: mongoose.Types.ObjectId(data?._id),
                message: postData?.message + " approved!",
                commentBy: postData?.createdBy,
              };
              cmethod.addcommentsLog(saveCommentLogData);
            }

            cmethod.returnSuccess(
              res,
              data,
              false,
              message[lang].profileUpdate
            );
          }
        }
      );
    } else {
      //console.log('=============>else', postData);
      inventoryModal.Inventory.findOneAndUpdate(
        queryCond,
        { $set: { status: postData?.status } }, // * changed from { $set: postData } to this because createdBy of inventory was updating
        { new: true },
        async function (err, data) {
          if (err) {
            cmethod.returnSreverError(res, message[lang].technicalError, err);
          } else {
            if (postData?.status == "pending") {
              let saveCommentLogData = {
                referenceType: "inventory",
                referenceId: mongoose.Types.ObjectId(data?._id),
                message: postData?.message + " document verify accepted!",
                commentBy: postData?.createdBy,
              };
              cmethod.addcommentsLog(saveCommentLogData);
            } else if (postData?.status == "reject") {
              let saveCommentLogData = {
                referenceType: "inventory",
                referenceId: mongoose.Types.ObjectId(data?._id),
                message: postData?.message + " rejected!",
                commentBy: postData?.createdBy,
              };
              cmethod.addcommentsLog(saveCommentLogData);

              const { vin } = data;
              const filter = {
                referenceName: vin,
                referenceId: mongoose.Types.ObjectId(data?._id),
              };

              const isAlreadyRejected = await getComment(filter);

              if (isArrayWithLength(isAlreadyRejected)) {
                const hierarchy = {
                  message: `REJECTED: ${postData?.message}`,
                  by: postData?.createdBy,
                };
                const update = { $push: { hierarchy } };
                await updateComment(filter, update);
              } else {
                const log = {
                  referenceName: vin,
                  referenceType: "inventory",
                  referenceId: mongoose.Types.ObjectId(data?._id),
                  commentBy: postData?.createdBy,
                  hierarchy: {
                    message: `REJECTED: ${postData?.message}`,
                    by: postData?.createdBy,
                  },
                };
                await createComment(log);
              }
            } else if (postData?.status == "verifyAddendum") {
              let saveCommentLogData = {
                referenceType: "inventory",
                referenceId: mongoose.Types.ObjectId(data?._id),
                message: postData?.message + "  again accepted!",
                commentBy: postData?.createdBy,
              };
              cmethod.addcommentsLog(saveCommentLogData);

              if (postData?.sellerOffer) {
                const reservePriceAcceptedComment = {
                  referenceType: "inventory",
                  referenceId: mongoose.Types.ObjectId(data?._id),
                  message: `Reserve price - Counter offer accepted of: ${postData.sellerOffer}`,
                  commentBy: postData?.createdBy,
                };
                cmethod.addcommentsLog(reservePriceAcceptedComment);
              }
            }
            cmethod.returnSuccess(
              res,
              data,
              false,
              message[lang].profileUpdate
            );
          }
        }
      );
    }
  }
);
router.patch(
  "/selleracceptanceUpdate",
  [midleware.validateFieldValue(["reseverId"], ["reseverId"])],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let xtoken = req.headers["x-access-token"];
    let queryCond = {
      $and: [{ _id: mongoose.Types.ObjectId(postData.reseverId) }],
    };
    delete postData.reseverId;
    inventoryModal.Reseverprice.findOneAndUpdate(
      queryCond,
      { $set: postData },
      { new: true },
      async function (err, data) {
        if (err) {
          //console.log('selleracceptanceUpdate---------------', err);
          cmethod.returnSreverError(res, message[lang].technicalError, err);
        } else {
          let setData = {};
          if (data?.acaOffer) {
            setData["reservePrice"] = data?.acaOffer;
          }
          if (data?.sellerOffer) {
            setData["reservePrice"] = data?.sellerOffer;
          }
          if (postData?.reservepriceDoc) {
            setData["reservepriceDoc"] = postData?.reservepriceDoc;
          }
          if (postData?.counterStatus) {
            setData["counterStatus"] = postData?.counterStatus;
          }
          if (postData?.status) {
            setData["status"] = postData?.status;
          }
          inventoryModal.Inventory.findOneAndUpdate(
            { _id: mongoose.Types.ObjectId(data?.inventoryId) },
            { $set: setData },
            async function (err, idata) {
              if (err) {
                cmethod.returnSreverError(res, "inventory Not updated.", err);
              } else {
                //if car is approved that time run this code only
                if (postData?.status == "approved") {
                  let docNoUnique = await cmethod.getDocumentpass();
                  let savegetDocumentData = {
                    passNo: docNoUnique,
                    direction: "in",
                    referenceType: "inventory",
                    referenceNo: idata?.vin,
                    status: "pending",
                    inventoryId: mongoose.Types.ObjectId(idata?._id),
                    branchId: mongoose.Types.ObjectId(idata?.branchId),
                    warehosId: mongoose.Types.ObjectId(idata?.warehosId),
                    createdBy: "system",
                  };
                  await cmethod.addgetDocument(savegetDocumentData);
                  if (postData?.message != "") {
                    let saveCommentLogData = {
                      referenceType: "inventory",
                      referenceId: mongoose.Types.ObjectId(idata?._id),
                      message: "approve by" + postData?.createdBy,
                      commentBy: postData?.createdBy,
                    };
                    cmethod.addcommentsLog(saveCommentLogData);
                  }
                }
                //end if car is approved that time run this code only
              }
            }
          );

          cmethod.returnSuccess(res, data, false, message[lang].profileUpdate);
        }
      }
    );
  }
);
router.patch(
  "/updatesellerplan",
  [midleware.validateFieldValue(["userId"], ["userId"])],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let xtoken = req.headers["x-access-token"];
    let queryCond = {
      $and: [{ _id: mongoose.Types.ObjectId(postData.userId) }],
    };
    let uid = postData.userId;
    let pid = postData.planId;
    delete postData.userId;
    userModal.User.findOneAndUpdate(
      queryCond,
      { $set: postData },
      { new: true },
      async function (err, data) {
        if (err) {
          cmethod.returnSreverError(res, message[lang].technicalError, err);
        } else {
          let insertData = [];
          let commentData = [];
          //inventory
          //update/insert check
          ////////jojn new table and inventory table
          let queryCond3 = { $and: [{ _id: mongoose.Types.ObjectId(pid) }] };
          let sellerplanData2 = await masterModal.Sellerplan.findOne(
            queryCond3
          );
          if (sellerplanData2) {
            let queryCond2 = {
              $and: [
                { sellerId: mongoose.Types.ObjectId(uid), inventoryStatus: 1 },
              ],
            };
            let inventoryData2 = await inventoryModal.Inventory.find(
              queryCond2,
              { inventoryStatus: 1 }
            );
            for (var i = 0; i < inventoryData2.length; i++) {
              await intventoryDao.addcarPlan(inventoryData2[i]._id); // common function used karana
            }
          }
          cmethod.returnSuccess(res, data, false, message[lang].profileUpdate);
          //comment logs
        }
      }
    );
  }
);
router.post(
  "/inventoryCopy",
  [midleware.validateFieldValue(["inventoryId"], ["inventoryId"])],
  async (req, res) => {
    try {
      const {
        body: { inventoryId, createdBy },
      } = req;

      const copyStatus = "unsold";

      const makeInventoryCopies = await makeInventoryRelatedCopies(
        inventoryId,
        copyStatus,
        createdBy
      );

      if (!makeInventoryCopies) {
        return cmethod.returnSreverError(res, message.technicalError, err);
      }

      cmethod.returnSuccess(
        res,
        makeInventoryCopies,
        false,
        message.signupsuccess
      );
    } catch (err) {
      cmethod.returnSreverError(res, message.technicalError, err);
    }
  }
);
router.post(
  "/vehiclenoOfrunlist",
  [midleware.validateFieldValue(["pageLimit", "page"], ["pageLimit", "page"])],
  (req, res) => {
    // console.log("washi first routing")
    let lang = req.headers["lang"] || config.lang;
    let postData = req.body;
    let query = [];
    if (postData.inventoryId) {
      query.push({
        $match: {
          _id: mongoose.Types.ObjectId(postData.inventoryId),
        },
      });
    }
    query.push({
      $lookup: {
        from: "auctionvehicles",
        localField: "inventoryId",
        foreignField: "_id",
        as: "auctionvehicles",
      },
    });
    query.push({
      $unwind: { path: "$auctionvehicles", preserveNullAndEmptyArrays: true },
    });
    //add branch lookup
    query.push({
      $lookup: {
        from: "auctions",
        localField: "inventoryId",
        foreignField: "_id",
        as: "auctions",
      },
    });
    query.push({
      $unwind: { path: "$auctions", preserveNullAndEmptyArrays: true },
    });

    const sQuery = [...query];
    query.push({
      $project: {
        lotNo: 1,
        vin: 1,
        branchId: "$branchs._id",
        auctiontitle: "$auctions.title",
        auctionDate: "$auctions.auctionDate",
        lastbid: "$auctionvehicles.runNumber",
        status: "$auctionvehicles.status",
      },
    });

    query.push({ $sort: { createdAt: -1 } });
    sQuery.push({ $count: "recordCount" });

    if (postData.page) {
      query.push({
        $skip: cmethod.pageOffset(postData.page, postData.pageLimit),
      });
      query.push({ $limit: cmethod.pageLimit(postData.pageLimit) });
    }

    intventoryDao
      .findInventoryAggregation(query)
      .then(function (data) {
        intventoryDao
          .findInventoryAggregation(sQuery)
          .then(async function (dcount) {
            let tptCnt = 0;
            if (dcount.length > 0) {
              tptCnt = dcount[0].recordCount;
            }
            res.status(200).json({
              status: true,
              result: data,
              message: "",
              hasMore: cmethod.hasMoreCount(
                tptCnt,
                postData.page,
                postData.pageLimit
              ),
              totalCount: tptCnt,
            });
          })
          .catch((err) => {
            cmethod.returnSreverError(res, message[lang].technicalError, err);
          });
      })
      .catch((err) => {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      });
  }
);
router.post(
  "/getpassadd",
  [
    midleware.validateFieldValue(
      ["branchId", "warehosId"],
      ["branchId", "warehosId"]
    ),
  ],
  async (req, res) => {
    const postData = req.body;
    intventoryDao.inventorypassAdd(res, postData);
  }
);
router.patch(
  "/getpassrescheduleupdate",
  [
    midleware.validateFieldValue(
      ["inventoryId", "gatepassId"],
      ["inventoryId", "gatepassId"]
    ),
  ],
  async (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let xtoken = req.headers["x-access-token"];
    //console.log('===========================',postData);
    // let queryCond = {
    //   $and: [{ _id: mongoose.Types.ObjectId(postData.inventoryId) }],
    // };
    // delete postData.inventoryId;

    /*inventoryModal.Inventory.findOneAndUpdate(
      queryCond,
      { $set: { branchId: mongoose.Types.ObjectId(postData.branchId), warehosId: mongoose.Types.ObjectId(postData.warehosId) } },
      { new: true },
      async function (err, data) {
        if (err) {
          cmethod.returnSreverError(res, message[lang].technicalError, err);
        } else {
          await inventoryModal.Getpass.updateOne(
            { _id: mongoose.Types.ObjectId(data?.gatepassId) },
            { $set: { gatePassExpired: data?.expiredDate } }
          );
          cmethod.returnSuccess(res, data, false, message[lang].profileUpdate);
        }
      }
    );*/
    if (postData?.inventoryId) {
      await inventoryModal.Inventory.updateOne(
        { _id: mongoose.Types.ObjectId(postData?.inventoryId) },
        {
          $set: {
            branchId: mongoose.Types.ObjectId(postData.branchId),
            warehosId: mongoose.Types.ObjectId(postData.warehosId),
          },
        }
      );
    }

    if (postData?.gatepassId) {
      await inventoryModal.Getpass.updateOne(
        { _id: mongoose.Types.ObjectId(postData?.gatepassId) },
        { $set: { gatePassExpired: postData?.expiredDate } }
      );
    }

    cmethod.returnSuccess(res, [], false, message[lang].profileUpdate);
  }
);

router.post(
  "/carwiseplanList",
  [midleware.validateFieldValue(["pageLimit", "page"], ["page"])],
  async (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let query = [];

    query.push({
      $lookup: {
        from: "branchs",
        localField: "branchId",
        foreignField: "_id",
        as: "branchs",
      },
    });
    query.push({
      $unwind: { path: "$branchs", preserveNullAndEmptyArrays: true },
    });

    query.push({
      $lookup: {
        from: "inventorys",
        localField: "inventoryId",
        foreignField: "_id",
        as: "inventorys",
      },
    });
    query.push({
      $unwind: { path: "$inventorys", preserveNullAndEmptyArrays: true },
    });
    query.push({
      $lookup: {
        from: "users",
        localField: "sellerId",
        foreignField: "_id",
        as: "users",
      },
    });
    query.push({
      $unwind: { path: "$users", preserveNullAndEmptyArrays: true },
    });
    if (postData.sellerId) {
      query.push({
        $match: {
          $and: [{ sellerId: mongoose.Types.ObjectId(postData.sellerId) }],
        },
      });
    }
    if (postData.inventoryId) {
      query.push({
        $match: {
          $and: [
            { inventoryId: mongoose.Types.ObjectId(postData.inventoryId) },
          ],
        },
      });
    }
    query.push({
      $project: {
        sellerId: 1,
        inventoryId: 1,
        inventorys: 1,
        branchName: "$branchs.branchName",
        branchId: "$branchs._id",
        planName: 1,
        storage: 1,
        parkingDays: 1,
        listingFee: 1,
        runs: 1,
        auctionTypeFee: 1,
        increment: 1,
        amountValue: 1,
        status: 1,
        initialfee: 1,
        sellerName: {
          $cond: {
            if: { $eq: ["$users", {}] },
            then: "",
            else: "$users.name",
          },
        },
        createdAt: 1,
      },
    });
    const sQuery = [...query];
    query.push({ $sort: { createdAt: -1 } });
    sQuery.push({ $count: "recordCount" });

    if (postData.page) {
      query.push({
        $skip: cmethod.pageOffset(postData.page, postData.pageLimit),
      });
      query.push({ $limit: cmethod.pageLimit(postData.pageLimit) });
    }

    intventoryDao
      .findCarwiseplanlistAggregation(query)
      .then(function (data) {
        intventoryDao
          .findCarwiseplanlistAggregation(sQuery)
          .then(async function (dcount) {
            let tptCnt = 0;
            if (dcount.length > 0) {
              tptCnt = dcount[0].recordCount;
            }
            res.status(200).json({
              status: true,
              result: data,
              message: "",
              hasMore: cmethod.hasMoreCount(
                tptCnt,
                postData.page,
                postData.pageLimit
              ),
              totalCount: tptCnt,
            });
          })
          .catch((err) => {
            cmethod.returnSreverError(res, message[lang].technicalError, err);
          });
      })
      .catch((err) => {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      });
  }
);
router.post(
  "/addsellermappingbranch",
  [
    midleware.validateFieldValue(
      ["sellerId", "planIds", "branchIds"],
      ["sellerId", "planIds", "branchIds"]
    ),
  ],
  async (req, res) => {
    const postData = req.body;
    //let checkplanexist = await cmethod.checkuserPlan(postData.sellerId);
    //console.log('----------->', checkplanexist); //return false;
    /*if (checkplanexist == false) {
      cmethod.returrnErrorMessage(res, "Seller not assign any plan !", ["ll"]);
    } else {
      intventoryDao.inventoryAdd(res, postData);
    }*/
    intventoryDao.sellermappingbranchAdd(res, postData);
  }
);
router.post(
  "/sellermappingbranchList",
  [midleware.validateFieldValue(["pageLimit", "page"], ["page"])],
  async (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let query = [];

    // * branchs
    query.push({
      $lookup: {
        from: "branchs",
        localField: "branchId",
        foreignField: "_id",
        as: "branchs",
      },
    });
    query.push({
      $unwind: { path: "$branchs", preserveNullAndEmptyArrays: true },
    });

    // * sellerplans
    query.push({
      $lookup: {
        from: "sellerplans",
        localField: "planId",
        foreignField: "_id",
        as: "sellerplans",
      },
    });
    query.push({
      $unwind: { path: "$sellerplans", preserveNullAndEmptyArrays: true },
    });

    // * users
    query.push({
      $lookup: {
        from: "users",
        localField: "sellerId",
        foreignField: "_id",
        as: "users",
      },
    });
    query.push({
      $unwind: { path: "$users", preserveNullAndEmptyArrays: true },
    });

    // * match
    if (postData?.shouldFilterInactivePlan) {
      ExactMatch(query, "sellerplans.status", 1);
    }

    if (postData.sellerId) {
      query.push({
        $match: {
          $and: [{ sellerId: mongoose.Types.ObjectId(postData.sellerId) }],
        },
      });
    }
    if (postData.branchId) {
      query.push({
        $match: {
          $and: [{ branchId: mongoose.Types.ObjectId(postData.branchId) }],
        },
      });
    }

    // * project
    query.push({
      $project: {
        sellerId: 1,
        branchName: "$branchs.branchName",
        branchId: "$branchs._id",
        planId: 1,
        planName: "$sellerplans.planName",
        listingFee: "$sellerplans.listingFee",
        runs: "$sellerplans.runs",
        auctionTypeFee: "$sellerplans.auctionTypeFee",
        increment: "$sellerplans.increment",
        amountValue: "$sellerplans.amountValue",
        status: "$sellerplans.status",
        status: "$sellerplans.status",
        parkingDays: "$sellerplans.parkingDays",
        storage: "$sellerplans.storage",
        initialfee: "$sellerplans.initialfee",
        defaultbranchplan: "$sellerplans.defaultbranchplan",
        sellerName: {
          $cond: {
            if: { $eq: ["$users", {}] },
            then: "",
            else: "$users.name",
          },
        },
      },
    });

    const sQuery = [...query];
    query.push({ $sort: { createdAt: -1 } });
    sQuery.push({ $count: "recordCount" });

    if (postData.page) {
      query.push({
        $skip: cmethod.pageOffset(postData.page, postData.pageLimit),
      });
      query.push({ $limit: cmethod.pageLimit(postData.pageLimit) });
    }

    intventoryDao
      .findSellermappingbranchAggregation(query)
      .then(function (data) {
        intventoryDao
          .findSellermappingbranchAggregation(sQuery)
          .then(async function (dcount) {
            let tptCnt = 0;
            if (dcount.length > 0) {
              tptCnt = dcount[0].recordCount;
            }
            res.status(200).json({
              status: true,
              result: data,
              message: "",
              hasMore: cmethod.hasMoreCount(
                tptCnt,
                postData.page,
                postData.pageLimit
              ),
              totalCount: tptCnt,
            });
          })
          .catch((err) => {
            cmethod.returnSreverError(res, message[lang].technicalError, err);
          });
      })
      .catch((err) => {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      });
  }
);
router.patch(
  "/unsoldmark",
  [midleware.validateFieldValue(["inventoryId"], ["inventoryId"])],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let xtoken = req.headers["x-access-token"];
    //{ token: xtoken },
    let queryCond = {
      $and: [{ _id: mongoose.Types.ObjectId(postData.inventoryId) }],
    };
    //console.log('postData=>',postData);
    delete postData.inventoryId;
    inventoryModal.Inventory.findOneAndUpdate(
      queryCond,
      { $set: { inventoryStatus: 4 } },
      { new: true },
      async function (err, data) {
        if (err) {
          cmethod.returnSreverError(res, message[lang].technicalError, err);
        } else {
          if (data) {
            //Add get pass
            let passNoUnique = await cmethod.getPassNo();
            let savegetPassData = {
              passNo: passNoUnique,
              direction: "out",
              referenceType: "inventory",
              referenceNo: data?.vin,
              inventoryId: mongoose.Types.ObjectId(data?._id),
              status: "out of stock",
              createdBy: data?.createdBy,
            };
            await cmethod.addgetPass(savegetPassData);
          }

          /*add inventory images */
          cmethod.returnSuccess(res, data, false, message[lang].Updated);
        }
      }
    );
  }
);
router.post(
  "/generateQrCode",
  midleware.validateFieldValue(
    ["inventoryId", "lotNo"],
    ["inventoryId", "lotNo"]
  ),
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    // console.log("washi",postData?.lotNo);
    let fileName = postData?.lotNo + ".png";
    let filePath = "./public/temp/" + fileName;
    QRCode.toFile(
      filePath,
      postData?.lotNo,
      {
        errorCorrectionLevel: "H",
      },
      function (err) {
        if (err) throw err;
        cmethod
          .uplaodfilesAWS(fileName, filePath, "assets", "image/png")
          .then(async function (data) {
            // fs.unlink(req.file.path, function (err) {});
            let object = { imgPath: data.Location };
            //insert data in database
            let insertImages = {
              imageType: "inventory",
              referenceId: mongoose.Types.ObjectId(postData?.inventoryId),
              image: data.Location,
              type: "qrcode",
            };
            const newData = new vinModal.Vinimage(insertImages);
            const addnewData = newData.save(insertImages);
            //add data in inventory
            await inventoryModal.Inventory.findOneAndUpdate(
              { _id: postData?.inventoryId },
              { $set: { QRCode: data.Location } }
            );
            res.status(200).json({
              status: true,
              message: message[lang].imgUpload,
              result: object,
            });
          })
          .catch(function (error) {
            console.log(error);
            res
              .status(500)
              .json({ status: false, message: message[lang].technicalError });
          });
      }
    );
  }
);
router.patch(
  "/defaultimageupdate",
  [midleware.validateFieldValue(["vinId"], ["vinId"])],
  async (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let xtoken = req.headers["x-access-token"];
    //{ token: xtoken },
    let queryCond = {
      $and: [{ _id: mongoose.Types.ObjectId(postData.vinId) }],
    };
    // console.log("=======================>", postData);
    if (postData?.type == "carimage" && postData.inventId) {
      await vinModal.Vinimage.updateMany(
        {
          referenceId: mongoose.Types.ObjectId(postData?.inventId),
          type: "carimage",
        },
        { $set: { defaultimage: 0 } }
      );
    }

    delete postData.vinId;
    delete postData.type;
    //console.log("=======================>", postData);
    //console.log("queryCond=======================>", queryCond);
    vinModal.Vinimage.findOneAndUpdate(
      queryCond,
      { $set: postData },
      { new: true },
      async function (err, data) {
        if (err) {
          cmethod.returnSreverError(res, message[lang].technicalError, err);
        } else {
          cmethod.returnSuccess(res, data, false, message[lang].profileUpdate);
        }
      }
    );
  }
);
router.post("/checksaledate", async (req, res) => {
  const postData = req.body;
  let lang = req.headers["lang"] || config.lang;
  console.log("==========>", postData);
  //return false;
  cmethod.checksaleDates(postData).then(function (doc) {
    cmethod.returnSuccess(res, doc);
  });
});

// * inventory-by-auction-display
router.post(
  "/inventory-by-auction-display",
  [
    midleware.validateFieldValue(
      ["auctionId", "displayNo"],
      ["auctionId", "displayNo"]
    ),
  ],
  async (req, res) => {
    const {
      body,
      headers: { lang = config.lang },
    } = req;

    const query = [];

    try {
      let { displayNo, auctionId } = body;
      const decider = checkBoolean(body.next) ? "$gt" : "$lt";
      const order = checkBoolean(body.next) ? 1 : -1;

      displayNo = Number(displayNo);
      auctionId = makeObjectId(auctionId);

      // * match
      query.push({
        $match: {
          auctionId,
          status: "pending",
          displayNo: { [decider]: displayNo },
        },
      });

      // * sort
      query.push({
        $sort: { displayNo: order },
      });

      // * limit
      query.push({
        $limit: 1,
      });

      // * nextCar
      query.push({
        $lookup: {
          from: "auctionvehicles",
          let: { nextDisplayNo: { $add: ["$displayNo", 1] } },
          pipeline: [
            {
              $match: {
                $expr: {
                  $and: [
                    { $eq: ["$auctionId", auctionId] },
                    { $eq: ["$status", "pending"] },
                    { $eq: ["$displayNo", "$$nextDisplayNo"] },
                  ],
                },
              },
            },
          ],
          as: "nextCar",
        },
      });
      query.push({
        $addFields: {
          isNextCarAvailable: {
            $cond: [{ $gt: [{ $size: ["$nextCar"] }, 0] }, true, false],
          },
        },
      });

      // * previousCar
      query.push({
        $lookup: {
          from: "auctionvehicles",
          let: { previousDisplayNo: { $subtract: ["$displayNo", 1] } },
          pipeline: [
            {
              $match: {
                $expr: {
                  $and: [
                    { $eq: ["$auctionId", auctionId] },
                    { $eq: ["$status", "pending"] },
                    { $eq: ["$displayNo", "$$previousDisplayNo"] },
                  ],
                },
              },
            },
          ],
          as: "previousCar",
        },
      });
      query.push({
        $addFields: {
          isPreviousCarAvailable: {
            $cond: [{ $gt: [{ $size: ["$previousCar"] }, 0] }, true, false],
          },
        },
      });

      // * inventories
      query.push({
        $lookup: {
          from: "inventorys",
          let: { inventoryId: "$inventoryId", inventoryStatus: 2 },
          pipeline: [
            {
              $match: {
                $expr: {
                  $and: [
                    { $eq: ["$_id", "$$inventoryId"] },
                    { $eq: ["$inventoryStatus", "$$inventoryStatus"] },
                  ],
                },
              },
            },
          ],
          as: "inventories",
        },
      });
      query.push({
        $unwind: {
          path: "$inventories",
          preserveNullAndEmptyArrays: true,
        },
      });

      // * users
      query.push({
        $lookup: {
          from: "users",
          localField: "inventories.sellerId",
          foreignField: "_id",
          as: "users",
        },
      });
      query.push({
        $unwind: { path: "$users", preserveNullAndEmptyArrays: true },
      });

      // * interiorcolors
      query.push({
        $lookup: {
          from: "interiorcolors",
          localField: "inventories.interiorcolorId",
          foreignField: "_id",
          as: "interiorcolors",
        },
      });
      query.push({
        $unwind: { path: "$interiorcolors", preserveNullAndEmptyArrays: true },
      });

      // * exteriorcolors
      query.push({
        $lookup: {
          from: "exteriorcolors",
          localField: "inventories.exteriorcolorId",
          foreignField: "_id",
          as: "exteriorcolors",
        },
      });
      query.push({
        $unwind: { path: "$exteriorcolors", preserveNullAndEmptyArrays: true },
      });

      // * makes
      query.push({
        $lookup: {
          from: "makes",
          localField: "inventories.make",
          foreignField: "_id",
          as: "makes",
        },
      });
      query.push({
        $unwind: { path: "$makes", preserveNullAndEmptyArrays: true },
      });

      // * models
      query.push({
        $lookup: {
          from: "models",
          localField: "inventories.model",
          foreignField: "_id",
          as: "models",
        },
      });
      query.push({
        $unwind: { path: "$models", preserveNullAndEmptyArrays: true },
      });

      // * bodys
      query.push({
        $lookup: {
          from: "bodys",
          localField: "inventories.bodyId",
          foreignField: "_id",
          as: "bodys",
        },
      });
      query.push({
        $unwind: { path: "$bodys", preserveNullAndEmptyArrays: true },
      });

      // * series
      query.push({
        $lookup: {
          from: "series",
          localField: "inventories.seriesId",
          foreignField: "_id",
          as: "series",
        },
      });
      query.push({
        $unwind: { path: "$series", preserveNullAndEmptyArrays: true },
      });

      // * fueltypes
      query.push({
        $lookup: {
          from: "fueltypes",
          localField: "inventories.fueltypeId",
          foreignField: "_id",
          as: "fueltypes",
        },
      });
      query.push({
        $unwind: { path: "$fueltypes", preserveNullAndEmptyArrays: true },
      });

      // * drivetypes
      query.push({
        $lookup: {
          from: "drivetypes",
          localField: "inventories.drivetypeId",
          foreignField: "_id",
          as: "drivetypes",
        },
      });
      query.push({
        $unwind: { path: "$drivetypes", preserveNullAndEmptyArrays: true },
      });

      // * engines
      query.push({
        $lookup: {
          from: "engines",
          localField: "inventories.engineId",
          foreignField: "_id",
          as: "engines",
        },
      });
      query.push({
        $unwind: { path: "$engines", preserveNullAndEmptyArrays: true },
      });

      // * branchs
      query.push({
        $lookup: {
          from: "branchs",
          localField: "inventories.branchId",
          foreignField: "_id",
          as: "branchs",
        },
      });
      query.push({
        $unwind: { path: "$branchs", preserveNullAndEmptyArrays: true },
      });

      // * warehouses
      query.push({
        $lookup: {
          from: "warehouses",
          localField: "inventories.warehosId",
          foreignField: "_id",
          as: "warehouses",
        },
      });
      query.push({
        $unwind: { path: "$warehouses", preserveNullAndEmptyArrays: true },
      });

      // * vinimages
      query.push({
        $lookup: {
          from: "vinimages",
          let: {
            inventoryId: "$inventories._id",
            imageType: "inventory",
            type: "carimage",
          },
          pipeline: [
            {
              $match: {
                $expr: {
                  $and: [
                    { $eq: ["$imageType", "$$imageType"] },
                    { $eq: ["$referenceId", "$$inventoryId"] },
                    { $eq: ["$type", "$$type"] },
                  ],
                },
              },
            },
          ],
          as: "vinimages",
        },
      });

      // * singlevinimages
      query.push({
        $lookup: {
          from: "vinimages",
          let: {
            inventoryId: "$inventories._id",
            imageType: "inventory",
            type: "carimage",
          },
          pipeline: [
            {
              $match: {
                $expr: {
                  $and: [
                    { $eq: ["$imageType", "$$imageType"] },
                    { $eq: ["$type", "$$type"] },
                    { $eq: ["$referenceId", "$$inventoryId"] },
                    { $eq: ["$defaultimage", 1] },
                  ],
                },
              },
            },
          ],
          as: "singlevinimages",
        },
      });

      // * reseverprices
      query.push({
        $lookup: {
          from: "reseverprices",
          let: {
            id: "$inventories._id",
            inventoryId: "$inventoryId",
          },
          pipeline: [
            {
              $match: {
                $expr: {
                  $and: [{ $eq: ["$inventoryId", "$$id"] }],
                },
              },
            },
          ],
          as: "reseverprices",
        },
      });
      query.push({
        $addFields: {
          reseverprices: { $last: "$reseverprices" },
        },
      });

      // * project
      query.push({
        $project: {
          _id: "$inventories._id",
          isNextCarAvailable: 1,
          isPreviousCarAvailable: 1,
          lotNo: "$inventories.lotNo",
          vin: "$inventories.vin",
          year: "$inventories.year",
          auctionId: 1,
          auctionDisplayNo: "$displayNo",
          branchs: "$branchs.branchName",
          branchId: "$branchs._id",
          bodys: "$bodys.bodyName",
          bodyId: "$bodys._id",
          drivetypes: "$drivetypes.drivetypeName",
          drivetypeId: "$drivetypes._id",
          fueltypes: "$fueltypes.fueltypeName",
          fueltypeId: "$fueltypes._id",
          series: "$series.seriesName",
          seriesId: "$series._id",
          engines: "$engines.engineName",
          engineId: "$engines._id",
          exteriorcolorId: "$exteriorcolors._id",
          excolorCode: "$exteriorcolors.colorCode",
          color: "$exteriorcolors.colorName",
          interiorcolorId: "$interiorcolors._id",
          incolorCode: "$interiorcolors.colorCode",
          interiorcolors: "$interiorcolors.colorName",
          make: "$makes.makeName",
          makeId: "$makes._id",
          model: "$models.modelName",
          modelId: "$models._id",
          warehouses: "$warehouses.warehouseName",
          warehosId: "$warehouses._id",
          specification: "$inventories.specification",
          milage: "$inventories.milage",
          costPrice: "$inventories.costPrice",
          startingBid: "$inventories.startingBid",
          containerNo: "$inventories.containerNo",
          reservePrice: "$inventories.reservePrice",
          sellerReservePrice: "$inventories.sellerReservePrice",
          sellerPriceAccept: "$inventories.sellerPriceAccept",
          lastAuctionDate: "$inventories.lastAuctionDate",
          lastBid: "$inventories.lastBid",
          inventoryStatus: "$inventories.inventoryStatus",
          planPrice: "$inventories.planPrice",
          rejectedMsg: "$inventories.rejectedMsg",
          vccDoc: "$inventories.vccDoc",
          purchaseDoc: "$inventories.purchaseDoc",
          status: "$inventories.status",
          createdAt: "$inventories.createdAt",
          singleImages: {
            $cond: {
              if: {
                $ne: ["$singlevinimages", []],
              },
              then: {
                $arrayElemAt: ["$singlevinimages.image", 0],
              },
              else: config.defaultInventoryImage,
            },
          },
          vinimages: {
            $cond: {
              if: {
                $ne: ["$vinimages", []],
              },
              then: "$vinimages",
              else: [{ image: config.defaultInventoryImage }],
            },
          },
          sellerId: {
            $cond: {
              if: { $eq: ["$users", {}] },
              then: "",
              else: "$users._id",
            },
          },
          sellerDbId: {
            $cond: {
              if: { $eq: ["$users", {}] },
              then: "",
              else: "$users._id",
            },
          },
        },
      });

      const results = await Auctionvehicle.aggregate(query);

      res.status(200).json({
        status: true,
        result: results,
        message: "",
        hasMore: false,
        totalCount: results.length,
      });
    } catch (error) {
      logger.error(error);
      cmethod.returnSreverError(res, message[lang].technicalError, error);
    }
  }
);

// * withdraw-inventory
router.post(
  "/withdraw-inventory",
  [midleware.validateFieldValue(["inventoryId"], ["inventoryId"])],
  async (req, res) => {
    const { body } = req;

    try {
      const { inventoryId, type } = body;
      const withdrawnInventory = await withdrawInventory(
        inventoryId,
        type,
        cmethod
      );

      res.status(200).json({
        status: true,
        result: withdrawnInventory,
        message: "",
        hasMore: false,
      });
    } catch (error) {
      logger.error(error.message);
      res.status(500).json({
        status: false,
        message: error.message,
      });
    }
  }
);

module.exports = router;
/**
 * @swagger
 * /api/inventory/add:
 *   post:
 *     tags: [Inventory]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: salesUserId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: branchId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: warehosId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: sellerId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: vin
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: make
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: model
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: year
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: interiorcolorId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: exteriorcolorId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: bodyId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: drivetypeId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: engineId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: seriesId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: fueltypeId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: milage
 *         in: formData
 *         type: number
 *         required: true
 *         description:
 *       - name: startingBid
 *         in: formData
 *         type: number
 *         required: false
 *         description:
 *       - name: containerNo
 *         in: formData
 *         type: number
 *         required: false
 *         description:
 *       - name: costPrice
 *         in: formData
 *         type: number
 *         required: false
 *         description:
 *       - name: mulkiya
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: hayaza
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: addedFrom
 *         in: formData
 *         type: srting
 *         required: false
 *         description:
 *              ex- web app admin
 *     responses:
 *       200:
 *         description: Reciepts.
 *
 */
/**
 * @swagger
 * /api/inventory/list:
 *   post:
 *     tags: [Inventory]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: fromDate
 *         in: formData
 *         type: string
 *         required: false
 *         description: from date
 *       - name: toDate
 *         in: formData
 *         type: string
 *         required: false
 *         description: to date
 *       - name: sellerDbId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: salesUserId
 *         in: formData
 *         type: string
 *         required: false
 *         description: salesmanId
 *       - name: vin
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: uniqueIdentifier
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: search
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: inventoryType
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: status
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *          ex- 1- in stock, 2- in auction, 3-sold, 4-out of stock, 5-unsold
 *       - name: inventoryStatus[]
 *         in: formData
 *         type: array
 *         items:
 *           type: string
 *         collectionFormat: multi
 *         required: false
 *         description:
 *       - name: processStatus
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *          pending,approved, ready to auction
 *       - name: inventoryId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: branchId
 *         in: formData
 *         type: array
 *         items:
 *           type: string
 *         required: false
 *         description:
 *       - name: warehosIds[]
 *         in: formData
 *         type: array
 *         items:
 *           type: string
 *         required: false
 *         description:
 *       - name: apiType
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *           ex- 1- web, 2- default
 *       - name: sortbydisplayNo
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *           ex- true only
 *       - name: completeRuns
 *         in: formData
 *         type: Number
 *         required: false
 *         description:
 *       - name: containerNo
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: pagination
 *         in: formData
 *         type: boolean
 *         required: false
 *         description:
 *       - name: getpass
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: needAuctionTitle
 *         in: formData
 *         type: boolean
 *         required: false
 *         description:
 *       - name: getpassstatus[]
 *         in: formData
 *         type: array
 *         items:
 *           type: string
 *         collectionFormat: multi
 *         required: false
 *         description:
 *       - name: inGatePassStatus[]
 *         in: formData
 *         type: array
 *         items:
 *           type: string
 *         collectionFormat: multi
 *         required: false
 *         description:
 *       - name: outGatePassStatus[]
 *         in: formData
 *         type: array
 *         items:
 *           type: string
 *         collectionFormat: multi
 *         required: false
 *         description:
 *       - name: addedFrom
 *         in: formData
 *         type: srting
 *         required: false
 *         description:
 *              ex- web app admin
 *       - name: salesUserId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: pageLimit
 *         in: formData
 *         type: number
 *         required: false
 *         description:
 *       - name: page
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *     responses:
 *       200:
 *         description: Reciepts.
 *
 */
/**
 * @swagger
 * /api/inventory/carList:
 *   post:
 *     tags: [Inventory]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: sellerDbId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: search
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: status
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *          ex- 1- in stock, 2- in auction, 3-sold
 *       - name: inventoryStatus
 *         in: formData
 *         type: array
 *         items:
 *           type: string
 *         required: false
 *         description:
 *       - name: processStatus
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *          pending,approved, ready to auction
 *       - name: inventoryId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: branchId
 *         in: formData
 *         type: array
 *         items:
 *           type: string
 *         required: false
 *         description:
 *       - name: warehosId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: engineId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: make
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: year
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: minMilage
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: maxMilage
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: minPrice
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: maxPrice
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: startingBid
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: model
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: interiorcolorId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: exteriorcolorId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: bodyId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: fueltypeId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: drivetypeId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: apiType
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *           ex- 1- web, 2- default
 *       - name: sortKey
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: sortOrder
 *         in: formData
 *         type: number // 1, -1
 *         required: false
 *         description:
 *       - name: auctionId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: displayNo
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: needAuctionId
 *         in: formData
 *         type: boolean
 *         required: false
 *         description:
 *       - name: bodies[]
 *         in: formData
 *         type: array
 *         items:
 *           type: string
 *         collectionFormat: multi
 *         required: false
 *         description:
 *       - name: fuelTypes[]
 *         in: formData
 *         type: array
 *         items:
 *           type: string
 *         collectionFormat: multi
 *         required: false
 *         description:
 *       - name: interiorColors[]
 *         in: formData
 *         type: array
 *         items:
 *           type: string
 *         collectionFormat: multi
 *         required: false
 *         description:
 *       - name: exteriorColors[]
 *         in: formData
 *         type: array
 *         items:
 *           type: string
 *         collectionFormat: multi
 *         required: false
 *         description:
 *       - name: auctionIds[]
 *         in: formData
 *         type: array
 *         items:
 *           type: string
 *         collectionFormat: multi
 *         required: false
 *         description:
 *       - name: pageLimit
 *         in: formData
 *         type: number
 *         required: true
 *         description:
 *       - name: page
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: Reciepts.
 *
 */
/**
 * @swagger
 * /api/inventory/update:
 *   patch:
 *     tags: [Inventory]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: inventoryId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: status
 *         in: formData
 *         type: number
 *         required: false
 *         description:
 *           pending,approved, ready to auction
 *     responses:
 *       200:
 *         description: update all fields using above api.
 *
 */
/**
 * @swagger
 * /api/inventory/checkUniqueVin:
 *   post:
 *     tags: [Inventory]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: vin
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *     responses:
 *       200:
 *         description: checkUniqueVin.
 *
 */
/**
 * @swagger
 * /api/inventory/templist:
 *   post:
 *     tags: [Inventory]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: tempId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: userId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: pageLimit
 *         in: formData
 *         type: number
 *         required: true
 *         description:
 *       - name: page
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: Reciepts.
 *
 */
/**
 * @swagger
 * /api/inventory/templistupdate:
 *   patch:
 *     tags: [Inventory]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: templistId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: salesUserId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: branchId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: warehosId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: sellerId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: vin
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: make
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: model
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: specification
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: year
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: interiorcolorId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: exteriorcolorId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: bodyId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: drivetypeId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: engineId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: seriesId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: fueltypeId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: milage
 *         in: formData
 *         type: number
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: temp list update.
 *
 */
/**
 * @swagger
 * /api/inventory/duplicatetemplistdelete:
 *   delete:
 *     tags: [Inventory]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: duplicatetempId
 *         in: formData
 *         type: Number
 *         required: false
 *         description:
 *       - name: userId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *     responses:
 *       200:
 *         description: duplicatetemplistdelete.
 *
 */
/**
 * @swagger
 * /api/inventory/templistdelete:
 *   delete:
 *     tags: [Inventory]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: tempId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: templistdelete.
 *
 */
/**
 * @swagger
 * /api/inventory/templistalldelete:
 *   delete:
 *     tags: [Inventory]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: deleteAllTempData
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *            exa: all
 *       - name: userId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *     responses:
 *       200:
 *         description: templistalldelete.
 *
 */
/**
 * @swagger
 * /api/inventory/getdocumentList:
 *   post:
 *     tags: [Inventory]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: fromDate
 *         in: formData
 *         type: string
 *         required: false
 *         description: from date
 *       - name: toDate
 *         in: formData
 *         type: string
 *         required: false
 *         description: to date
 *       - name: branchId[]
 *         in: formData
 *         type: array
 *         items:
 *           type: string
 *         required: false
 *         description:
 *       - name: warehosId[]
 *         in: formData
 *         type: array
 *         items:
 *           type: string
 *         required: false
 *         description:
 *       - name: allstatus[]
 *         in: formData
 *         type: array
 *         items:
 *           type: string
 *         required: false
 *         description:
 *       - name: referenceNo
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: search
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: direction
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: pageLimit
 *         in: formData
 *         type: number
 *         required: false
 *         description:
 *       - name: page
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *     responses:
 *       200:
 *         description: getdocument List.
 *
 */
/**
 * @swagger
 * /api/inventory/getPassList:
 *   post:
 *     tags: [Inventory]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: fromDate
 *         in: formData
 *         type: string
 *         required: false
 *         description: from date
 *       - name: toDate
 *         in: formData
 *         type: string
 *         required: false
 *         description: to date
 *       - name: branchId[]
 *         in: formData
 *         type: array
 *         items:
 *           type: string
 *         required: false
 *         description:
 *       - name: warehosId[]
 *         in: formData
 *         type: array
 *         items:
 *           type: string
 *         required: false
 *         description:
 *       - name: referenceNo
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: referenceType
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: search
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: direction
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: status
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: inventoryId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: inventoryType
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: containerNo
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: userId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: pageLimit
 *         in: formData
 *         type: number
 *         required: false
 *         description:
 *       - name: page
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *     responses:
 *       200:
 *         description: getPass List.
 *
 */
/**
 * @swagger
 * /api/inventory/incominggetpass:
 *   post:
 *     tags: [Inventory]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: branchId[]
 *         in: formData
 *         type: array
 *         items:
 *           type: string
 *         required: false
 *         description:
 *       - name: referenceNo
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: direction
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: pageLimit
 *         in: formData
 *         type: number
 *         required: true
 *         description:
 *       - name: page
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: inventory transfer list.
 *
 */
/**
 * @swagger
 * /api/inventory/incomingdocumentpass:
 *   post:
 *     tags: [Inventory]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: branchId[]
 *         in: formData
 *         type: array
 *         items:
 *           type: string
 *         required: false
 *         description:
 *       - name: referenceNo
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: direction
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: pageLimit
 *         in: formData
 *         type: number
 *         required: true
 *         description:
 *       - name: page
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: inventory transfer list.
 *
 */
/**
 * @swagger
 * /api/inventory/getpassupdate:
 *   patch:
 *     tags: [Inventory]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: getpassId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: direction
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *            ex -in , out
 *       - name: recoveryNo
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: file
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: status
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: processedBy
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: processedDate
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *     responses:
 *       200:
 *         description: update all fields using above api.
 *
 */
/**
 * @swagger
 * /api/inventory/getdocumentupdate:
 *   patch:
 *     tags: [Inventory]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: getdocumentId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: file
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: status
 *         in: formData
 *         type: number
 *         required: false
 *         description:
 *     responses:
 *       200:
 *         description: update all fields using above api.
 *
 */
/**
 * @swagger
 * /api/inventory/inventorytransferadd:
 *   post:
 *     tags: [Inventory]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: fromBranch
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: fromWarehouse
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: toBranch
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: toWarehouse
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: inventoryId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: transverType
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: createdBy
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: status
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *              default pending, otherwise Transfer
 *     responses:
 *       200:
 *         description: inventory transfer add.
 *
 */
/**
 * @swagger
 * /api/inventory/internalTransfer:
 *   post:
 *     tags: [Inventory]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: fromBranch
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: fromWarehouse
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: toBranch
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: toWarehouse
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: inventoryId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: createdBy
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: status
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *              default pending, otherwise Transfer
 *     responses:
 *       200:
 *         description: inventory transfer add.
 *
 */
/**
 * @swagger
 * /api/inventory/inventorytransferupdate:
 *   patch:
 *     tags: [Inventory]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: inventorytransferId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: fromBranch
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: fromWarehouse
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: toBranch
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: toWarehouse
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: inventoryId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: transverType
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: createdBy
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: status
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *              default pending, otherwise Transfer
 *     responses:
 *       200:
 *         description: update all fields using above api.
 *
 */
/**
 * @swagger
 * /api/inventory/inventorytransferlist:
 *   post:
 *     tags: [Inventory]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: fromDate
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: toData
 *         in: formDate
 *         type: string
 *         required: false
 *         description:
 *       - name: inventoryTransId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: search
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: Branch
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: warehouse
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: branchId[]
 *         in: formData
 *         type: array
 *         items:
 *           type: string
 *         required: false
 *         description:
 *       - name: warehosIds[]
 *         in: formData
 *         type: array
 *         items:
 *           type: string
 *         required: false
 *         description:
 *       - name: status
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *            ex - bydefault inTransit
 *       - name: pageLimit
 *         in: formData
 *         type: number
 *         required: false
 *         description:
 *       - name: page
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *     responses:
 *       200:
 *         description: inventory transfer list.
 *
 */
/**
 * @swagger
 * /api/inventory/inventorytransferdelete:
 *   delete:
 *     tags: [Inventory]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: inventorytransferId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: inventorytransferdelete.
 *
 */
/**
 * @swagger
 * /api/inventory/watchlistadd:
 *   post:
 *     tags: [Inventory]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: inventoryId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: buyerId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: watchlistadd.
 *
 */
/**
 * @swagger
 * /api/inventory/watchlistdelete:
 *   delete:
 *     tags: [Inventory]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: watchlistId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: watchlistdelete.
 *
 */
/**
 * @swagger
 * /api/inventory/watchlistlist:
 *   post:
 *     tags: [Inventory]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: buyerId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: pageLimit
 *         in: formData
 *         type: number
 *         required: true
 *         description:
 *       - name: page
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: watchlistlist.
 *
 */
/**
 * @swagger
 * /api/inventory/addreseverprice:
 *   post:
 *     tags: [Inventory]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: inventoryId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: acaOffer
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: sellerOffer
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: acaStatus
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: sellerStatus
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *     responses:
 *       200:
 *         description: Reciepts.
 *
 */
/**
 * @swagger
 * /api/inventory/addreseverpricelist:
 *   post:
 *     tags: [Inventory]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: inventoryId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: pageLimit
 *         in: formData
 *         type: number
 *         required: true
 *         description:
 *       - name: page
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: addreseverpricelist.
 *
 */
/**
 * @swagger
 * /api/inventory/inventoryRequestUpdate:
 *   patch:
 *     tags: [Inventory]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: inventoryId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: status
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *            ex- approved, reject
 *       - name: message
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *     responses:
 *       200:
 *         description: inventoryRequestUpdate.
 *
 */
/**
 * @swagger
 * /api/inventory/selleracceptanceUpdate:
 *   patch:
 *     tags: [Inventory]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: reseverId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: from
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: acaOffer
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: sellerOffer
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: acaStatus
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: sellerStatus
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *     responses:
 *       200:
 *         description: inventoryRequestUpdate.
 *
 */
/**
 * @swagger
 * /api/inventory/updatesellerplan:
 *   patch:
 *     tags: [Inventory]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: userId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: planId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *     responses:
 *       200:
 *         description: updatesellerplan.
 *
 */
/**
 * @swagger
 * /api/inventory/inventoryCopy:
 *   post:
 *     tags: [Inventory]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: inventoryId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: inventoryCopy.
 *
 */
/**
 * @swagger
 * /api/inventory/vehiclenoOfrunlist:
 *   post:
 *     tags: [Inventory]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: inventoryId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: pageLimit
 *         in: formData
 *         type: number
 *         required: true
 *         description:
 *       - name: page
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: vehiclenoOfrunlist.
 *
 */
/**
 * @swagger
 * /api/inventory/getpassadd:
 *   post:
 *     tags: [Inventory]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: branchId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: warehosId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: inventoryId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: direction
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: getpassadd.
 *
 */
/**
 * @swagger
 * /api/inventory/getpassrescheduleupdate:
 *   patch:
 *     tags: [Inventory]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: inventoryId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: branchId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: warehosId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: gatepassId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: expiredDate
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *     responses:
 *       200:
 *         description: getdocument List.
 *
 */
/**
 * @swagger
 * /api/inventory/carwiseplanList:
 *   post:
 *     tags: [Inventory]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: sellerId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: inventoryId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: pageLimit
 *         in: formData
 *         type: number
 *         required: true
 *         description:
 *       - name: page
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: watchlistlist.
 *
 */
/**
 * @swagger
 * /api/inventory/addsellermappingbranch:
 *   post:
 *     tags: [Inventory]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: sellerId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: planIds[]
 *         in: formData
 *         type: array
 *         items:
 *           type: string
 *         required: true
 *         description:
 *       - name: branchIds[]
 *         in: formData
 *         type: array
 *         items:
 *           type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: addsellermappingbranch.
 *
 */
/**
 * @swagger
 * /api/inventory/sellermappingbranchList:
 *   post:
 *     tags: [Inventory]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: sellerId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: branchId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: pageLimit
 *         in: formData
 *         type: number
 *         required: true
 *         description:
 *       - name: page
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: Reciepts.
 *
 */
/**
 * @swagger
 * /api/inventory/documenttransferadd:
 *   post:
 *     tags: [Inventory]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: fromBranch
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: fromWarehouse
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: toBranch
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: toWarehouse
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: inventoryId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: transferType
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: createdBy
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: status
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *              default pending, otherwise Transfer
 *     responses:
 *       200:
 *         description: inventory transfer add.
 *
 */
/**
 * @swagger
 * /api/inventory/documenttransferlist:
 *   post:
 *     tags: [Inventory]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: fromDate
 *         in: formData
 *         type: string
 *         required: false
 *         description: from date
 *       - name: toDate
 *         in: formData
 *         type: string
 *         required: false
 *         description: to date
 *       - name: inventoryTransId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: Branch
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: Warehouse
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: status
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *            ex - bydefault inTransit
 *       - name: pageLimit
 *         in: formData
 *         type: number
 *         required: false
 *         description:
 *       - name: page
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *     responses:
 *       200:
 *         description: inventory transfer list.
 *
 */
/**
 * @swagger
 * /api/inventory/documenttransferupdate:
 *   patch:
 *     tags: [Inventory]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: inventorytransferId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: fromBranch
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: fromWarehouse
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: toBranch
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: toWarehouse
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: inventoryId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: transverType
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: createdBy
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: status
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *              default pending, otherwise Transfer
 *     responses:
 *       200:
 *         description: update all fields using above api.
 *
 */
/**
 * @swagger
 * /api/inventory/documenttransferdelete:
 *   delete:
 *     tags: [Inventory]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: inventorytransferId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: documenttransferdelete.
 *
 */
/**
 * @swagger
 * /api/inventory/unsoldmark:
 *   patch:
 *     tags: [Inventory]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: inventoryId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: unsoldmark.
 *
 */

/**
 * @swagger
 * /api/inventory/generateQrCode:
 *   post:
 *     tags: [Inventory]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: inventoryId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: lotNo
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: Reciepts.
 *
 */
/**
 * @swagger
 * /api/inventory/defaultimageupdate:
 *   patch:
 *     tags: [Inventory]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: inventId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: vinId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: type
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *              ex-carimage
 *       - name: defaultimage
 *         in: formData
 *         type: Number
 *         required: false
 *         description:
 *              ex - 1
 *     responses:
 *       200:
 *         description: sellerplanupdate.
 *
 */
/**
 * @swagger
 * /api/inventory/get-inventory-milage:
 *   post:
 *     tags: [Inventory]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: milage
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: pageLimit
 *         in: formData
 *         type: number
 *         required: true
 *         description:
 *       - name: page
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: Get - Inventory - Milage.
 *
 */

/**
 * @swagger
 * /api/inventory/import:
 *   post:
 *     tags: [Inventory]
 *     consumes:
 *       - multipart/form-data
 *     parameters:
 *       - name: file
 *         in: formData
 *         type: file
 *         required: true
 *         description:
 *       - name: userId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: sellerId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: branchId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: warehosId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: status
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: Inventory - Import
 *
 */

/**
 * @swagger
 * /api/inventory/movetempdata:
 *   post:
 *     tags: [Inventory]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: userId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: Inventory - Import BACKUP
 *
 */
/**
 * @swagger
 * /api/inventory/checksaledate:
 *   post:
 *     tags: [Inventory]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: recieptId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: saledate
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *     responses:
 *       200:
 *         description: checksaledate.
 *
 */

/**
 * @swagger
 * /api/inventory/inventory-by-auction-display:
 *   post:
 *     tags: [Inventory]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: auctionId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: displayNo
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: next
 *         in: formData
 *         type: boolean
 *         required: false
 *         description:
 *       - name: previous
 *         in: formData
 *         type: boolean
 *         required: false
 *         description:
 *     responses:
 *       200:
 *         description: Inventory By Auction
 *
 */
/**
 * @swagger
 * /api/inventory/withdraw-inventory:
 *   post:
 *     tags: [Inventory]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: inventoryId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: type
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: Inventory - Withdraw
 *
 */
