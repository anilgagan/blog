const mongoose = require("mongoose");
const Schema = mongoose.Schema;
const { connWrite } = require("./../../config/database");

const inventorySchema = new Schema(
  {
    lotNo: { type: Number, default: 0 },
    keyNo: { type: String, default: "" },
    branchId: {
      type: mongoose.Types.ObjectId,
      default: mongoose.Types.ObjectId(),
      index: true,
    },
    warehosId: {
      type: mongoose.Types.ObjectId,
      default: mongoose.Types.ObjectId(),
      index: true,
    },
    sellerId: {
      type: mongoose.Types.ObjectId,
      default: mongoose.Types.ObjectId(),
      index: true,
    },
    salesUserId: {
      type: mongoose.Types.ObjectId,
      default: mongoose.Types.ObjectId(),
      index: true,
    },
    vin: {
      type: String,
      index: true,
    },
    make: {
      type: mongoose.Types.ObjectId,
      default: null,
      index: true,
    },
    model: {
      type: mongoose.Types.ObjectId,
      default: null,
      index: true,
    },
    specification: String,
    year: String,
    interiorcolorId: {
      type: mongoose.Types.ObjectId,
      default: null,
      index: true,
    },
    exteriorcolorId: {
      type: mongoose.Types.ObjectId,
      default: mongoose.Types.ObjectId(),
      index: true,
    },
    bodyId: {
      type: mongoose.Types.ObjectId,
      default: mongoose.Types.ObjectId(),
      index: true,
    },
    drivetypeId: {
      type: mongoose.Types.ObjectId,
      default: mongoose.Types.ObjectId(),
      index: true,
    },
    engineId: {
      type: mongoose.Types.ObjectId,
      default: mongoose.Types.ObjectId(),
      index: true,
    },
    seriesId: {
      type: mongoose.Types.ObjectId,
      default: mongoose.Types.ObjectId(),
      index: true,
    },
    fueltypeId: {
      type: mongoose.Types.ObjectId,
      default: mongoose.Types.ObjectId(),
      index: true,
    },
    milage: Number,
    costPrice: { type: Number, default: 0 },
    startingBid: { type: Number, default: 0 },
    containerNo: { type: String, default: "" },
    reservePrice: { type: Number, default: 0 },
    invoicePrice: { type: Number, default: 0 },
    purchaseFrom: { type: String, default: "" },
    sellerReservePrice: { type: Number, default: 0 },
    sellerPriceAccept: String,
    lastAuctionDate: { type: Date },
    lastBid: { type: String, default: "" },
    inventoryStatus: { type: Number, default: 1, index: true }, //0:pending,  1: approved, 2: in auction, 3:sold, 4:unsold, 5:re-auction
    planPrice: Number,
    rejectedMsg: String,
    carDocRecieved: { type: Number, default: 0 },
    vccDoc: String,
    mulkiya: String,
    hayaza: String,
    purchaseDoc: String,
    reservepriceDoc: String, // FILE UPLAOD AFTER signature
    QRCode: String, //qrCode path
    counterStatus: String,
    status: String, //pending,waiting for car,approved, ready to auction
    key: String,
    displayNo: { type: Number, default: 0 },
    getpassissue: { type: Number, default: 0 }, //add on 20-06-2023 as disciuss
    completeRuns: { type: Number, default: 0 },
    inventcopy: { type: Number, default: 0 },
    transferId: {
      type: mongoose.Types.ObjectId,
      default: null,
      index: true,
    },
    inventoryPlanId: {
      type: mongoose.Types.ObjectId,
      default: null,
      index: true,
    },
    inventoryType: { type: String, default: "" },
    createdBy: { type: String, default: "" },
    isPaymentCleared: { type: Boolean, default: false, index: true },
    forReAuction: { type: Boolean, default: false, index: true },
    createdFrom: String,
    addedFrom: String,
  },
  {
    timestamps: {
      createdAt: "createdAt",
      updatedAt: "updatedAt",
    },
  }
);
inventorySchema.index({ vin: 1 }, { collation: { locale: "en", strength: 2 } });

const inventoryTempSchema = new Schema(
  {
    branchId: {
      type: mongoose.Types.ObjectId,
      default: null,
      index: true,
    },
    userId: {
      type: mongoose.Types.ObjectId,
      default: null,
      index: true,
    },
    warehosId: {
      type: mongoose.Types.ObjectId,
      default: null,
      index: true,
    },
    sellerId: {
      type: mongoose.Types.ObjectId,
      default: null,
      index: true,
    },
    vin: {
      type: String,
      index: true,
    },
    make: {
      type: mongoose.Types.ObjectId,
      default: null,
      index: true,
    },
    model: {
      type: mongoose.Types.ObjectId,
      default: null,
      index: true,
    },
    specification: String,
    year: String,
    interiorcolorId: {
      type: mongoose.Types.ObjectId,
      default: null,
      index: true,
    },
    exteriorcolorId: {
      type: mongoose.Types.ObjectId,
      default: null,
      index: true,
    },
    bodyId: {
      type: mongoose.Types.ObjectId,
      default: null,
      index: true,
    },
    drivetypeId: {
      type: mongoose.Types.ObjectId,
      default: null,
      index: true,
    },
    engineId: {
      type: mongoose.Types.ObjectId,
      default: null,
      index: true,
    },
    seriesId: {
      type: mongoose.Types.ObjectId,
      default: null,
      index: true,
    },
    fueltypeId: {
      type: mongoose.Types.ObjectId,
      default: null,
      index: true,
    },
    milage: Number,
    costPrice: { type: Number, default: 0 },
    startingBid: { type: Number, default: 0 },
    containerNo: { type: String, default: "" },
    reservePrice: { type: Number, default: 0 },
    key: String,
    remarks: String,
    status: String, //pending,waiting for car,approved, ready to auction
    duplicatetemp: { type: Number, default: 0 },
    createdBy: { type: String, default: "" },
  },
  {
    timestamps: {
      createdAt: "createdAt",
      updatedAt: "updatedAt",
    },
  }
);

const getPassSchema = new Schema(
  {
    passNo: String,
    direction: String, //in,out,in-transit
    referenceType: String, //reciept
    recoveryNo: String,
    referenceNo: String,
    file: String,
    referenceId: {
      type: mongoose.Types.ObjectId,
      default: null,
      index: true,
    },
    inventoryId: {
      type: mongoose.Types.ObjectId,
      default: null,
      index: true,
    },
    status: { type: String, default: "pending" }, //pending,in warehouse, out of stock
    parkingDays: { type: Number, default: 0 },
    parkedDays: { type: Number, default: 0 },
    gatePassExpired: { type: Date },
    gatePassExpiredDate: { type: Date },
    createdBy: String,
    processedBy: { type: String, default: "" },
    processedDate: { type: Date, default: null },
  },
  {
    timestamps: {
      createdAt: "createdAt",
      updatedAt: "updatedAt",
    },
  }
);

const getdocumentSchema = new Schema(
  {
    passNo: String,
    direction: String, //in,out,in-transit
    referenceType: String, //in warehouse, out of stock
    file: String,
    referenceNo: String,
    referenceId: {
      type: mongoose.Types.ObjectId,
      default: null,
      index: true,
    },
    inventoryId: {
      type: mongoose.Types.ObjectId,
      default: null,
      index: true,
    },
    branchId: {
      type: mongoose.Types.ObjectId,
      default: null,
      index: true,
    },
    warehosId: {
      type: mongoose.Types.ObjectId,
      default: null,
      index: true,
    },
    transferId: {
      type: mongoose.Types.ObjectId,
      default: null,
      index: true,
    },
    status: { type: String, default: "pending" }, //pending issued,given
    createdBy: String,
  },
  {
    timestamps: {
      createdAt: "createdAt",
      updatedAt: "updatedAt",
    },
  }
);
const inventoryTransferSchema = new Schema(
  {
    fromBranch: {
      type: mongoose.Types.ObjectId,
      default: null,
      index: true,
    },
    fromWarehouse: {
      type: mongoose.Types.ObjectId,
      default: null,
      index: true,
    },
    toBranch: {
      type: mongoose.Types.ObjectId,
      default: null,
      index: true,
    },
    toWarehouse: {
      type: mongoose.Types.ObjectId,
      default: null,
      index: true,
    },
    inventoryId: {
      type: mongoose.Types.ObjectId,
      default: null,
      index: true,
    },
    recoveryNo: String,
    transverType: String, //fromgatepass,bulk
    filePath: String,
    status: { type: String, default: "Pending" }, //default pending ,inTransit, reveived, Transfer
    //status: { type: String, default: "inTransit" },
    createdBy: String,
  },
  {
    timestamps: {
      createdAt: "createdAt",
      updatedAt: "updatedAt",
    },
  }
);
const documentTransferSchema = new Schema(
  {
    fromBranch: {
      type: mongoose.Types.ObjectId,
      default: null,
      index: true,
    },
    fromWarehouse: {
      type: mongoose.Types.ObjectId,
      default: null,
      index: true,
    },
    toBranch: {
      type: mongoose.Types.ObjectId,
      default: null,
      index: true,
    },
    toWarehouse: {
      type: mongoose.Types.ObjectId,
      default: null,
      index: true,
    },
    inventoryId: {
      type: mongoose.Types.ObjectId,
      default: null,
      index: true,
    },
    recoveryNo: String,
    transferType: String, //fromgatepass,bulk
    filePath: String,
    status: { type: String, default: "Pending" }, //default pending ,inTransit, reveived, Transfer
    //status: { type: String, default: "inTransit" },
    createdBy: String,
  },
  {
    timestamps: {
      createdAt: "createdAt",
      updatedAt: "updatedAt",
    },
  }
);
const watchlistSchema = new Schema(
  {
    inventoryId: {
      type: mongoose.Types.ObjectId,
      default: null,
      index: true,
    },
    auctionId: {
      type: mongoose.Types.ObjectId,
      default: null,
      index: true,
    },
    buyerId: {
      type: mongoose.Types.ObjectId,
      default: null,
      index: true,
    },
  },
  {
    timestamps: {
      createdAt: "createdAt",
      updatedAt: "updatedAt",
    },
  }
);
const reseverPriceSchema = new Schema(
  {
    inventoryId: {
      type: mongoose.Types.ObjectId,
      default: null,
      index: true,
    },
    acaOffer: { type: Number, default: 0 },
    sellerOffer: { type: Number, default: 0 },
    acaStatus: { type: Number, default: 0 },
    sellerStatus: { type: Number, default: 0 },
    acaofferDate: { type: Date },
    sellerofferDate: { type: Date },
    from: String,
  },
  {
    timestamps: {
      createdAt: "createdAt",
      updatedAt: "updatedAt",
    },
  }
);

const carwisesellerplan = new Schema(
  {
    sellerId: {
      type: mongoose.Types.ObjectId,
      default: null,
      index: true,
    },
    inventoryId: {
      type: mongoose.Types.ObjectId,
      default: mongoose.Types.ObjectId(),
      index: true,
    },
    branchId: {
      type: mongoose.Types.ObjectId,
      default: mongoose.Types.ObjectId(),
      index: true,
    },
    planName: String,
    listingFee: { type: Number, default: 0 },
    runs: { type: Number, default: 0 },
    auctionTypeFee: String,
    increment: { type: Number, default: 0 },
    amountValue: { type: Number, default: 0 },
    status: { type: Number, default: 0 },
    parkingDays: { type: Number, default: 0 },
    storage: { type: Number, default: 0 },
    initialfee: { type: Number, default: 0 },
  },
  {
    timestamps: {
      createdAt: "createdAt",
      updatedAt: "updatedAt",
    },
  }
);

const getPassaddschema = new Schema(
  {
    branchId: {
      type: mongoose.Types.ObjectId,
      default: null,
      index: true,
    },
    warehosId: {
      type: mongoose.Types.ObjectId,
      default: null,
      index: true,
    },
    direction: String,
  },
  {
    timestamps: {
      createdAt: "createdAt",
      updatedAt: "updatedAt",
    },
  }
);
const sellermappingbranchSchema = new Schema(
  {
    sellerId: {
      type: mongoose.Types.ObjectId,
      default: null,
      index: true,
    },
    planId: {
      type: mongoose.Types.ObjectId,
      default: null,
      index: true,
    },
    branchId: {
      type: mongoose.Types.ObjectId,
      default: null,
      index: true,
    },
  },
  {
    timestamps: {
      createdAt: "createdAt",
      updatedAt: "updatedAt",
    },
  }
);

const Inventorytransfer = connWrite.model(
  "inventorytransfers",
  inventoryTransferSchema
);
const Inventory = connWrite.model("inventorys", inventorySchema);
const Inventorytemps = connWrite.model("inventorytemps", inventoryTempSchema);
const Getpass = connWrite.model("getpass", getPassSchema);
const Getdocument = connWrite.model("getdocument", getdocumentSchema);
const Watchlist = connWrite.model("watchlists", watchlistSchema);
const Reseverprice = connWrite.model("reseverprices", reseverPriceSchema);
const Carwisesellerplan = connWrite.model(
  "carwisesellerplans",
  carwisesellerplan
);
const Sellermappingbranch = connWrite.model(
  "sellermappingbranchs",
  sellermappingbranchSchema
);
const DocumentTransfer = connWrite.model(
  "documenttransfers",
  documentTransferSchema
);

module.exports = {
  Inventory,
  Inventorytemps,
  Inventorytransfer,
  Getpass,
  Getdocument,
  Watchlist,
  Reseverprice,
  Carwisesellerplan,
  Sellermappingbranch,
  DocumentTransfer,
};
