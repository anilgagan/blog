const { number } = require("@hapi/joi");
const mongoose = require("mongoose");
const Schema = mongoose.Schema;
const { connWrite } = require("../../config/database");

const orderSchema = new Schema(
  {
    orderNo: { type: String, default: "" },
    userId: {
      type: mongoose.Types.ObjectId,
      default: mongoose.Types.ObjectId(),
      index: true,
    },
    plan: { type: String, default: "", index: true },
    deposit: { type: Number, default: 0, index: true },
    creditLimit: { type: Number, default: 0, index: true },
    status: { type: String, default: "Open", index: true }, // Sucess, Pending, Rejected
    orderType: { type: String, default: "Plan", index: true }, // Plan, Deposit
    buyMethod: { type: String, default: "offline", index: true }, // offline, online
    proofing: { type: String, default: "", index: true },
    bankReferenceNo: { type: String, default: "", index: true },
  },
  {
    timestamps: {
      createdAt: "createdAt",
      updatedAt: "updatedAt",
    },
  }
);

const creditCalHistorySchema = new Schema(
  {
    userId: {
      type: mongoose.Types.ObjectId,
      default: mongoose.Types.ObjectId(),
      index: true,
    },
    deposit: { type: Number, default: 0, index: true },
    creditLimit: { type: Number, default: 0, index: true },
    creditType: { type: String, default: "CR", index: true },
    balance: { type: Number, default: 0, index: true },
  },
  {
    timestamps: {
      createdAt: "createdAt",
      updatedAt: "updatedAt",
    },
  }
);

const Order = connWrite.model("order", orderSchema);
const creditCalHistory = connWrite.model(
  "creditCalHistory",
  creditCalHistorySchema
);
module.exports = {
  Order,
  creditCalHistory,
};
