const masterModal = require("../master/masterModal");
const message = require("../../config/message");
const cmethod = require("../../middleware/common-fun");
const orderModel = require("./orderModel");
const userModel = require("../user/userModal");
const { default: mongoose } = require("mongoose");

const findPlan = function (query) {
  return new Promise(function (resolve, reject) {
    masterModal.Buyerlimit.find(query, function (err, data) {
      if (err) {
        reject(err);
      } else {
        resolve(data);
      }
    });
  });
};
const findPurchagePlan = function (query) {
  return new Promise(function (resolve, reject) {
    orderModel.Order.find(query, function (err, data) {
      if (err) {
        reject(err);
      } else {
        resolve(data);
      }
    });
  });
};

const findPurchagePlanAggregation = function (query) {
  return new Promise(function (resolve, reject) {
    orderModel.Order.aggregate(query, function (err, data) {
      if (err) {
        reject(err);
      } else {
        resolve(data);
      }
    });
  });
};

const findCreditHistoryAggregation = function (query) {
  return new Promise(function (resolve, reject) {
    orderModel.creditCalHistory.aggregate(query, function (err, data) {
      if (err) {
        reject(err);
      } else {
        resolve(data);
      }
    });
  });
};

const updatePurchagePlan = function (query, data) {
  return new Promise(function (resolve, reject) {
    orderModel.Order.updateOne(query, { $set: data }, function (err, data) {
      if (err) {
        reject(err);
      } else {
        resolve(data);
      }
    });
  });
};

const updateCredit = function (query, data) {
  return new Promise(function (resolve, reject) {
    userModel.User.updateOne(query, data, function (err, data) {
      if (err) {
        reject(err);
      } else {
        resolve(data);
      }
    });
  });
};

const createPlan = function (userId, planData, buyMethod, proofImg, orderNo) {
  return new Promise(function (resolve, reject) {
    let data = {
      orderNo,
      userId: userId,
      plan: planData.package,
      deposit: planData.deposit,
      creditLimit: planData.creditlimit,
      status: "Pending",
      buyMethod: buyMethod,
      proofing: proofImg,
    };
    orderModel.Order.create(data)
      .then((result) => {
        resolve(result);
      })
      .catch((err) => {
        reject(err);
      });
  });
};

const createDepositPlan = function (data) {
  return new Promise(function (resolve, reject) {
    orderModel.Order.create(data)
      .then((result) => {
        resolve(result);
      })
      .catch((err) => {
        reject(err);
      });
  });
};
const createTransactionHistory = function (type, data) {
  // {
  //   userId: userId,
  //   deposit: planData.deposit,
  //   creditLimit: planData.creditlimit,
  //   creditType: "CR",
  // }
  if (type == "PlanApprove") {
    orderModel.creditCalHistory
      .create(data)
      .then((reslt) => {
        orderModel.creditCalHistory
          .updateOne(
            { _id: mongoose.Types.ObjectId(reslt._id) },
            { $inc: { balance: planData.creditlimit } }
          )
          .then((err) => {
            console.log(err);
          });
      })
      .catch((err) => {
        console.log(err);
      });
  } else if (type == "PlanApprove") {
  }

  return true;
};

module.exports = {
  findPlan,
  createPlan,
  createDepositPlan,
  findPurchagePlan,
  updatePurchagePlan,
  updateCredit,
  findPurchagePlanAggregation,
  findCreditHistoryAggregation,
  createTransactionHistory
};
