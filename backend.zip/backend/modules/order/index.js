const express = require("express");
const router = express.Router();
const auctionDao = require("./../auction/auctionDao");
const auctionModal = require("../auction/auctionModal");
const account = require("../account/accountModal");
const inventoryModal = require("../inventory/inventoryModal");
const message = require("../../config/message");
const config = require("../../config");
const midleware = require("../../middleware/validation");
const cmethod = require("../../middleware/common-fun");
var mongoose = require("mongoose");
const http = require("http");
const { dirname } = require("path");
const path = require("path");
const { middleware } = require("json2xls");
const oderDao = require("./ordeDao");
const sellerReciptModel = require("../../modules/saleReciept/saleRecieptModal");
const recieptModel = require("../reciept/recieptModal");
const { User } = require("../user/userModal");
const userModel = require("../user/userModal");
const logger = require("../../config/logger");
const { calculateBuyerDueAmount } = require("../../services/order.service");
const { FindByIdAndUpdate } = require("../../models/factory");
const { Order } = require("./orderModel");
const { ExactMatch } = require("../../functions/mongoose.functions");
// Creat Ordre
router.post(
  "/create",
  [midleware.validateFieldValue(["userId"], ["userId"])],
  async (req, res) => {
    const postData = req.body;

    if (postData?.orderType) {
      const orderNo = await cmethod.getUserOrderNo();

      const { userId, deposit, orderType, buyMethod, proofing } = postData;

      const orderData = {
        orderNo,
        userId,
        deposit,
        status: "Pending",
        orderType,
        buyMethod,
        proofing,
      };

      oderDao
        .createDepositPlan(orderData)
        .then((succ) => {
          cmethod.returnSuccess(res, succ, false, message["eng"].Updated);
        })
        .catch((err) => {
          console.error(err);
          cmethod.returrnErrorMessage(res, "Please try again.");
        });
    } else {
      const orderNo = await cmethod.getUserOrderNo();

      oderDao
        .findPlan({ _id: mongoose.Types.ObjectId(postData.planId) })
        .then((data) => {
          oderDao
            .createPlan(
              postData.userId,
              data[0],
              postData.planType,
              postData.proofingImg,
              orderNo
            )
            .then((succ) => {
              cmethod.returnSuccess(res, succ, false, message["eng"].Updated);
            })
            .catch((err) => {
              console.log(err);
              cmethod.returrnErrorMessage(res, "Please try again.");
            });
        })
        .catch((err) => {
          console.log(err);
          cmethod.returrnErrorMessage(res, "Please try again.");
        });
    }
  }
);

/* List Order  */
router.post(
  "/list",
  [midleware.validateFieldValue([], [])],
  async (req, res) => {
    const postData = req.body;
    let q = [];

    q.push({
      $lookup: {
        from: "users",
        localField: "userId",
        foreignField: "_id",
        as: "users",
      },
    });

    if (postData.userId) {
      q.push({
        $match: {
          userId: mongoose.Types.ObjectId(postData.userId),
        },
      });
    }
    if (postData.plan) {
      q.push({
        $match: {
          plan: postData.plan,
        },
      });
    }
    if (postData?.search) {
      q.push({
        $match: {
          $and: [
            {
              $or: [
                { orderNo: { $regex: postData.search, $options: "i" } },
                { "users.email": { $regex: postData.search, $options: "i" } },
                { "users.name": { $regex: postData.search, $options: "i" } },
                { "users.phone": { $regex: postData.search, $options: "i" } },
                {
                  "users.uniqueIdentifier": {
                    $regex: postData.search,
                    $options: "i",
                  },
                },
              ],
            },
          ],
        },
      });
    }

    if (postData.status) ExactMatch(q, "status", postData.status);
    if (postData.bankReferenceNo) {
      ExactMatch(q, "bankReferenceNo", postData.bankReferenceNo);
    }

    q.push({ $sort: { createdAt: -1 } });

    if (postData.page) {
      q.push({
        $skip: cmethod.pageOffset(postData.page, postData.pageLimit),
      });
      q.push({ $limit: cmethod.pageLimit(postData.pageLimit) });
    }

    q.push({
      $project: {
        _id: 1,
        userId: 1,
        plan: 1,
        deposit: 1,
        creditLimit: 1,
        orderNo: 1,
        status: 1,
        orderType: 1,
        userUnqiId: 1,
        userName: 1,
        plan: 1,
        buyMethod: 1,
        proofing: 1,
        createdAt: 1,
        userUnqiId: { $arrayElemAt: ["$users.uniqueIdentifier", 0] },
        userName: { $arrayElemAt: ["$users.name", 0] },
      },
    });
    //const sQuery = [...q];
    // sQuery.push({ $count: "recordCount" });

    oderDao
      .findPurchagePlanAggregation(q)
      .then((data) => {
        cmethod.returnSuccess(res, data, false, "");
      })
      .catch((err) => {
        console.log(err);
        cmethod.returnSreverError(res, "Server Error");
      });
  }
);

// Approve Plan
router.post(
  "/approve",
  [
    midleware.validateFieldValue(
      ["userId", "planId", "orderType"],
      ["userId", "planId", "orderType"]
    ),
  ],
  async (req, res) => {
    const postData = req.body;

    if (postData.orderType === "Deposit") {
      const filter = {
        userId: mongoose.Types.ObjectId(postData.userId),
        _id: mongoose.Types.ObjectId(postData.planId),
      };

      const [orderData] = await oderDao.findPurchagePlan(filter);

      if (orderData) {
        const { buyMethod, deposit, userId, orderNo } = orderData;

        const { glAccountId, transactionDate } = postData;

        const accountLedgerArr = [];

        // * Account Ledger Entry
        // * wallet
        const voucherNoUnique = await cmethod.getVoucherNo();

        const updateWalletAmount = {
          $inc: {
            walletAmount: deposit,
          },
        };

        const buyer = await User.findByIdAndUpdate(userId, updateWalletAmount);

        const walletAccount = await account.Accountmaster.findOne(
          { markAccountId: "wallet" },
          {
            markAccountId: 1,
          }
        ).sort({ createdAt: -1 });

        const { _id: walletAccountId } = walletAccount;

        // * Wallet Deposit CR Entry
        accountLedgerArr.push({
          glAccountId: mongoose.Types.ObjectId(walletAccountId),
          voucherNo: voucherNoUnique,
          transactionType: "cr",
          paymentType: buyMethod,
          payAmount: deposit,
          referenceType: "customer payment receipt",
          referenceNo: orderNo,
          referenceNo2: "",
          description: "User Wallet Credited",
          buyerNo: buyer?.uniqueIdentifier,
          createdBy: "system",
          transDate: new Date(),
          transactionOf: "buyer",
        });

        // * Bank Deposit DR Entry
        accountLedgerArr.push({
          glAccountId,
          voucherNo: voucherNoUnique,
          transactionType: "dr",
          paymentType: buyMethod,
          payAmount: deposit,
          referenceType: "bank payment receipt",
          referenceNo: orderNo,
          referenceNo2: "",
          description: "Bank Account Debited",
          buyerNo: buyer?.uniqueIdentifier,
          createdBy: "system",
          transDate: transactionDate,
          transactionOf: "buyer",
        });

        await account.Accountledger.insertMany(accountLedgerArr);

        // * Order Success Status
        await oderDao.updatePurchagePlan(filter, {
          status: "Sucess",
        });

        cmethod.returnSuccess(res, true, false, "Updated Successfully");
      } else {
        console.log(err);
        cmethod.returnSreverError(res, "Server Error");
      }
    } else {
      oderDao
        .updatePurchagePlan(
          {
            userId: mongoose.Types.ObjectId(postData.userId),
            _id: mongoose.Types.ObjectId(postData.planId),
          },
          { status: "Sucess" }
        )
        .then((data) => {
          oderDao
            .findPurchagePlan({
              userId: mongoose.Types.ObjectId(postData.userId),
              _id: mongoose.Types.ObjectId(postData.planId),
            })
            .then((result) => {
              console.log(postData.userId, "result", result);
              oderDao
                .updateCredit(
                  {
                    _id: mongoose.Types.ObjectId(postData.userId),
                  },
                  {
                    $inc: {
                      creditLimit: result[0].creditLimit,
                      depositAmt: result[0].deposit,
                    },
                  }
                )
                .then(async (data) => {
                  if (result.length) {
                    const [{ orderNo, userId, deposit, buyMethod }] = result;
                    const { glAccountId, transactionDate } = postData;

                    // * Account Ledger Entry
                    const accountLedgerArr = [];

                    const buyer = await User.findById(userId);

                    const walletAccount = await account.Accountmaster.findOne(
                      { markAccountId: "wallet" },
                      {
                        markAccountId: 1,
                      }
                    ).sort({ createdAt: -1 });

                    const { _id: walletAccountId } = walletAccount;

                    const voucherNoUnique = await cmethod.getVoucherNo();

                    // * Wallet Plan CR Entry
                    accountLedgerArr.push({
                      glAccountId: mongoose.Types.ObjectId(walletAccountId),
                      voucherNo: voucherNoUnique,
                      transactionType: "cr",
                      paymentType: buyMethod,
                      payAmount: deposit,
                      referenceType: "customer plan receipt",
                      referenceNo: orderNo,
                      referenceNo2: "",
                      description: "User Plan Credited",
                      buyerNo: buyer?.uniqueIdentifier,
                      createdBy: "system",
                      transDate: new Date(),
                      transactionOf: "buyer",
                    });

                    // * Bank Plan DR Entry
                    accountLedgerArr.push({
                      glAccountId,
                      voucherNo: voucherNoUnique,
                      transactionType: "dr",
                      paymentType: buyMethod,
                      payAmount: deposit,
                      referenceType: "bank plan receipt",
                      referenceNo: orderNo,
                      referenceNo2: "",
                      description: "Bank Account Debited",
                      buyerNo: buyer?.uniqueIdentifier,
                      createdBy: "system",
                      transDate: transactionDate,
                      transactionOf: "buyer",
                    });

                    await account.Accountledger.insertMany(accountLedgerArr);

                    cmethod.returnSuccess(
                      res,
                      data,
                      false,
                      "Update Successfully"
                    );
                  }
                });
            });
        })
        .catch((err) => {
          console.log(err);
          cmethod.returnSreverError(res, "Server Error");
        });
    }
  }
);

/*List Of credit History */

/* List Order  */
router.post(
  "/credit-list",
  [midleware.validateFieldValue([], [])],
  async (req, res) => {
    const postData = req.body;
    let query = {};
    let q = [];
    if (postData.userId) {
      query = {
        userId: mongoose.Types.ObjectId(postData.userId),
      };
      q.push({
        $match: {
          userId: mongoose.Types.ObjectId(postData.userId),
        },
      });
    }

    q.push({
      $lookup: {
        from: "users",
        localField: "userId",
        foreignField: "_id",
        as: "users",
      },
    });

    q.push({
      $project: {
        _id: 1,
        userId: 1,
        deposit: 1,
        creditLimit: 1,
        userUnqiId: { $arrayElemAt: ["$users.uniqueIdentifier", 0] },
        userName: { $arrayElemAt: ["$users.name", 0] },
      },
    });
    q.push({ $sort: { createdAt: -1 } });
    //const sQuery = [...q];
    // sQuery.push({ $count: "recordCount" });

    oderDao
      .findCreditHistoryAggregation(q)
      .then((data) => {
        cmethod.returnSuccess(res, data, false, "");
      })
      .catch((err) => {
        console.log(err);
        cmethod.returnSreverError(res, "Server Error");
      });
  }
);

// * buyer Dashboard analytics
router.post(
  "/buyer-analytics",
  [midleware.validateFieldValue([], [])],
  async (req, res) => {
    const postData = req.body;
    let storageCount = 0;
    let releaseCount = 0;
    let storageAmt = 0;
    let dueAmt = 0;
    //let inventoryIds =  await recieptModel.Reciept.find({buyerId:mongoose.Types.ObjectId(postData.userId)},{inventoryId:1});
    let userData = await userModel.User.findOne(
      {
        _id: mongoose.Types.ObjectId(postData.userId),
      },
      {
        creditLimit: 1,
        depositAmt: 1,
        unpaidAmt: 1,
        overdueAmt: 1,
        curBalance: 1,
      }
    );
    let storageAmtData = await recieptModel.Reciept.aggregate([
      { $match: { buyerId: mongoose.Types.ObjectId(postData.userId) } },
      {
        $group: {
          _id: { buyerId: "$buyerId" },
          totalSum: { $sum: "$storageAmount" },
        },
      },
    ]);

    let totalNetAmount = await recieptModel.Reciept.aggregate([
      { $match: { buyerId: mongoose.Types.ObjectId(postData.userId) } },
      {
        $group: {
          _id: { buyerId: "$buyerId" },
          totalSum: { $sum: "$totalNetAmount" },
        },
      },
    ]);

    let paidAmount = await recieptModel.Reciept.aggregate([
      { $match: { buyerId: mongoose.Types.ObjectId(postData.userId) } },
      {
        $group: {
          _id: { buyerId: "$buyerId" },
          totalSum: { $sum: "$paidAmount" },
        },
      },
    ]);

    if (storageAmtData.length > 0) {
      storageAmt = storageAmtData[0].totalSum;
    }

    if (totalNetAmount.length > 0) {
      dueAmt = totalNetAmount[0].totalSum - paidAmount[0].totalSum;
    }

    //console.log(storageAmount);

    let totalPurchage = await recieptModel.Reciept.countDocuments({
      buyerId: mongoose.Types.ObjectId(postData.userId),
      recieptType: "sold",
    });
    let dueCars = await recieptModel.Reciept.countDocuments({
      buyerId: mongoose.Types.ObjectId(postData.userId),
      recieptType: "sold",
      payStatus: 0,
    });
    /* Get Storage Count */
    let query = [];
    query.push({
      $lookup: {
        from: "getpasses",
        let: {
          inventoryId: "$inventoryId",
        },
        pipeline: [
          {
            $match: {
              $expr: { $eq: ["$inventoryId", "$$inventoryId"] },
              $and: [{ referenceType: "storage" }, { status: "in warehouse" }],
            },
          },
        ],
        as: "sellerservices",
      },
    });
    query.push({
      $match: {
        $and: [
          { buyerId: mongoose.Types.ObjectId(postData.userId) },
          { payStatus: 1 },
        ],
      },
    });
    query.push({ $count: "recordCount" });
    let storageCountRow = await recieptModel.Reciept.aggregate(query);
    if (storageCountRow && storageCountRow.length > 0) {
      storageCount = storageCountRow[0].recordCount;
    }

    /* Get relase Cars */
    let rQuery = [];
    rQuery.push({
      $lookup: {
        from: "getpasses",
        let: {
          inventoryId: "$inventoryId",
        },
        pipeline: [
          {
            $match: {
              $expr: { $eq: ["$inventoryId", "$$inventoryId"] },
              $and: [{ referenceType: "reciept" }, { direction: "out" }],
            },
          },
        ],
        as: "sellerservices",
      },
    });
    rQuery.push({
      $match: {
        $and: [
          { buyerId: mongoose.Types.ObjectId(postData.userId) },
          { payStatus: 1 },
        ],
      },
    });
    query.push({ $count: "recordCount" });
    let releaseCountRow = await recieptModel.Reciept.aggregate(query);
    if (releaseCountRow && releaseCountRow.length > 0) {
      releaseCount = releaseCountRow[0].recordCount;
    }

    let data = {
      totalPurchage: totalPurchage ? totalPurchage : 0,
      dueCars: dueCars ? dueCars : 0,
      storageCount: storageCount,
      releaseCount: releaseCount,
      storageAmt: storageAmt,
      dueAmt: dueAmt,
      creditLimit: userData.creditLimit,
      depositAmt: userData.depositAmt,
    };
    cmethod.returnSuccess(res, data, false, "Get Data Successfully");
  }
);

router.post(
  "/transaction-analytics",
  [midleware.validateFieldValue([], [])],
  async (req, res) => {
    const postData = req.body;
    let storageAmt = 0;
    let dueAmt = 0;
    //let inventoryIds =  await recieptModel.Reciept.find({buyerId:mongoose.Types.ObjectId(postData.userId)},{inventoryId:1});
    let userData = await userModel.User.findOne(
      {
        _id: mongoose.Types.ObjectId(postData.userId),
      },
      {
        walletAmount: 1,
        creditLimit: 1,
        depositAmt: 1,
        unpaidAmt: 1,
        overdueAmt: 1,
        curBalance: 1,
      }
    );
    let storageAmtData = await recieptModel.Reciept.aggregate([
      { $match: { buyerId: mongoose.Types.ObjectId(postData.userId) } },
      {
        $group: {
          _id: { buyerId: "$buyerId" },
          totalSum: { $sum: "$storageAmount" },
        },
      },
    ]);

    let totalNetAmount = await recieptModel.Reciept.aggregate([
      { $match: { buyerId: mongoose.Types.ObjectId(postData.userId) } },
      {
        $group: {
          _id: { buyerId: "$buyerId" },
          totalSum: { $sum: "$totalNetAmount" },
        },
      },
    ]);

    let paidAmount = await recieptModel.Reciept.aggregate([
      { $match: { buyerId: mongoose.Types.ObjectId(postData.userId) } },
      {
        $group: {
          _id: { buyerId: "$buyerId" },
          totalSum: { $sum: "$paidAmount" },
        },
      },
    ]);

    if (storageAmtData.length > 0) {
      storageAmt = storageAmtData[0].totalSum;
    }

    if (totalNetAmount.length > 0) {
      dueAmt = totalNetAmount[0].totalSum - paidAmount[0].totalSum;
    }

    const totalDueAmount = await calculateBuyerDueAmount(postData.userId);

    let data = {
      storageAmt: storageAmt,
      dueAmt: dueAmt,
      walletAmount: userData.walletAmount,
      creditLimit: userData.creditLimit,
      depositAmt: userData.depositAmt,
      unpaidAmt: userData.unpaidAmt,
      overdueAmt: userData.overdueAmt,
      curBalance: userData.curBalance,
      totalDueAmount,
    };
    cmethod.returnSuccess(res, data, false, "Get Data Successfully");
  }
);

router.patch(
  "/update-order",
  [midleware.validateFieldValue(["orderId"], ["orderId"])],
  async (req, res) => {
    const {
      body,
      headers: { lang = config.lang },
    } = req;

    try {
      const { orderId, ...rest } = body;

      const projection = { new: true };
      const updateOrder = await FindByIdAndUpdate(
        Order,
        orderId,
        rest,
        projection
      );

      res.status(200).json({
        status: true,
        result: updateOrder,
        message: "",
        hasMore: false,
      });
    } catch (error) {
      logger.error(error);
      cmethod.returnSreverError(res, message[lang].technicalError, error);
    }
  }
);

module.exports = router;

/**
 * @swagger
 * /api/order/buyer-analytics:
 *   post:
 *     tags: [Order]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: userId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: Analytics Data.
 * 
 * 
 * 
 * 
 * /api/order/credit-list:
 *   post:
 *     tags: [Order]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: userId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: Analytics Data.
 *

 */

/**
 * @swagger
 * /api/order/create:
 *   post:
 *     tags: [Order]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: userId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: planId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: deposit
 *         in: formData
 *         type: number
 *         required: false
 *         description:
 *       - name: orderType
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: buyMethod
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: proofing
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *
 *     responses:
 *       200:
 *         description: Order - Create
 *
 */

/**
 * @swagger
 * /api/order/approve:
 *   post:
 *     tags: [Order]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: userId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: planId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: orderType
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: glAccountId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: transactionDate
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *
 *     responses:
 *       200:
 *         description: Order - Approve
 *
 */
/**
 * @swagger
 * /api/order/list:
 *   post:
 *     tags: [Order]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: userId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: plan
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: search
 *         in: formData
 *         type: string
 *         required: false
 *         description: ex- name,email,phone,userId-BAQ100101
 *     responses:
 *       200:
 *         description: Analytics Data.
 *
 */

/**
 * @swagger
 * /api/order/update-order:
 *   patch:
 *     tags: [Order]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: orderId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: status
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *     responses:
 *       200:
 *         description: Update - Order
 *
 */
