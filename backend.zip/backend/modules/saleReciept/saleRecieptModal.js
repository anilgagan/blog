const { number } = require("@hapi/joi");
const mongoose = require("mongoose");
const Schema = mongoose.Schema;
const { connWrite } = require("../../config/database");

const saleRecieptSchema = new Schema(
  {
    saleRecieptNo: String,
    salerId: {
      type: mongoose.Types.ObjectId,
      default: null,
      index: true,
    },
    buyerId: {
      type: mongoose.Types.ObjectId,
      default: null,
      index: true,
    },
    inventoryId: {
      type: mongoose.Types.ObjectId,
      default: null,
      index: true,
    },
    recieptId: {
      type: mongoose.Types.ObjectId,
      default: null,
      index: true,
    },
    saleAmount: Number,
    paybleAmount: Number,
    paidAmount: Number,
    vatAmout: Number,
    handlingFees: Number,
    auctionFees: Number,
    listingFee: Number,
    paymentMethod: String,
    checkNo: Number,
    checkDate: { type: Date },
    checkImg: String,
    status: { type: String, default: "pending" },
    taxAmount: Number,
    securityDeposit: Number,
  },
  {
    timestamps: {
      createdAt: "createdAt",
      updatedAt: "updatedAt",
    },
  }
);
const sellerPayableSchema = new Schema(
  {
    payableNo: String,
    sellerId: {
      type: mongoose.Types.ObjectId,
      default: null,
      index: true,
    },
    branchId: {
      type: mongoose.Types.ObjectId,
      default: null,
      index: true,
    },
    inventoryId: [
      {
        type: mongoose.Types.ObjectId,
        default: [],
        index: true,
      },
    ],
    glAccountId: {
      type: mongoose.Types.ObjectId,
      default: null,
      index: true,
    },
    totalPayable: { type: Number, default: 0 },
    totalReceivable: { type: Number, default: 0 },
    netPayBalance: { type: Number, default: 0 },
    // vatAmount: { type: Number, default: 0 },
    // auctionFees: { type: Number, default: 0 },
    // listingFee: { type: Number, default: 0 },
    balanceType: String,
    paymentMethod: String,
    checkNo: { type: Number, default: 0 },
    checkDate: { type: Date },
    transactionDate: { type: Date },
    checkImg: String,
    status: { type: String, default: "pending" }, // * pending|approved|processed|paid|rejected
    chequeClearStatus: { type: String, default: "pending" }, // pending, approved, rejected
    chequeApprovedBy: { type: String, default: "" },
    chequeRejectedBy: { type: String, default: "" },
    chequeApprovedRemarks: { type: String, default: "" },
    chequeRejectedRemarks: { type: String, default: "" },
    chequeApprovedDate: { type: Date, default: null },
    chequeRejectedDate: { type: Date, default: null },
    payableStatus: { type: String, default: "" },
    payableRemarks: { type: String, default: "" },
    createdBy: { type: String, default: "" },
    sellerServiceOrderNumbers: { type: [String], default: [] },
  },
  {
    timestamps: {
      createdAt: "createdAt",
      updatedAt: "updatedAt",
    },
  }
);
const sellerServiceSchemaold = new Schema(
  {
    saleOrderNo: String,
    sellerId: {
      type: mongoose.Types.ObjectId,
      default: null,
      index: true,
    },
    inventoryId: {
      type: mongoose.Types.ObjectId,
      default: null,
      index: true,
    },
    serviceType: { type: String, default: "auction" }, //storage, auction
    auctionFee: Number,
    listingFee: Number,
    vatAmount: Number,
    totalPayment: Number,
    status: String,
    serviceCharge: Number, //auction fee + listing fee
  },
  {
    timestamps: {
      createdAt: "createdAt",
      updatedAt: "updatedAt",
    },
  }
);
const sellerServiceSchema = new Schema(
  {
    saleOrderNo: String,
    sellerId: {
      type: mongoose.Types.ObjectId,
      default: null,
      index: true,
    },
    buyerId: {
      type: mongoose.Types.ObjectId,
      default: null,
      index: true,
    },
    recieptId: {
      type: mongoose.Types.ObjectId,
      default: null,
      index: true,
    },
    inventoryId: {
      type: mongoose.Types.ObjectId,
      default: null,
      index: true,
    },
    auctionId: {
      type: mongoose.Types.ObjectId,
      default: null,
      index: true,
    },
    serviceType: { type: String, default: "sold" }, //storage, auction,sold
    saleTotalAmount: { type: Number, default: 0 },
    auctionTotalAmount: { type: Number, default: 0 },
    saleAmount: { type: Number, default: 0 },
    auctionFee: { type: Number, default: 0 },
    listingFee: { type: Number, default: 0 },
    serviceCharge: { type: Number, default: 0 }, //auction fee + listing fee or storage
    vatAmount: { type: Number, default: 0 },
    securityDeposit: { type: Number, default: 0 },
    totalPayment: { type: Number, default: 0 },
    auctionDiscount: { type: Number, default: 0 },
    listingDiscount: { type: Number, default: 0 },
    storageDiscount: { type: Number, default: 0 },
    totalDiscount: { type: Number, default: 0 },
    serviceStatus: { type: String, default: "pending" }, // sold, unsold, onbid
    status: { type: String, default: "pending" },
    gatePassStatus: { type: String, default: "pending" }, // pending, issued (for current slip of gate pass)
    gatePassExpiredDate: { type: Date, default: null },
    gatePassParkingDays: { type: Number, default: 0 },
    refundStatus: { type: String, default: "" },
    isRefundAdjusted: { type: Boolean, default: false },
  },
  {
    timestamps: {
      createdAt: "createdAt",
      updatedAt: "updatedAt",
    },
  }
);
const Salereciept = connWrite.model("salereciepts", saleRecieptSchema);
const Sellerservice = connWrite.model("sellerservices", sellerServiceSchema);
const SellerPayable = connWrite.model("sellerpayables", sellerPayableSchema);

module.exports = {
  Salereciept,
  Sellerservice,
  SellerPayable,
};
