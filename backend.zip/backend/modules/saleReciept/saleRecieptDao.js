const salereciept = require("../saleReciept/saleRecieptModal");
const message = require("../../config/message");
const cmethod = require("../../middleware/common-fun");
var mongoose = require("mongoose");
const {
  isNumberLessThanZero,
  makeAbsoluteNumber,
  uniqueItemsToArray,
} = require("../../functions/global.functions");
const {
  updateSellerServiceAuctionEntries,
  updateSellerServiceStorageEntries,
} = require("../../helpers/saleReceipt.helper");

const { createCommonLog } = require("../../services/comment.service");

const salerecieptAdd = async function (res, postData) {
  const newSalereciept = new salereciept.Salereciept(postData);

  newSalereciept.save(postData, async function (err, data) {
    if (err) {
      //console.log(err);
      cmethod.returnSreverError(res, message.technicalError, err);
    } else {
      cmethod.returnSuccess(res, data, false, message.signupsuccess);
    }
  });
};
const findSalerecieptWithFiled = async function (query) {
  return new Promise(function (resolve, reject) {
    salereciept.Salereciept.find(
      { costPrice: { $exists: true } },
      { make: 1, model: 1 },
      function (err, data) {
        if (err) {
          reject(err);
        } else {
          resolve(data);
        }
      }
    );
  });
};
const findSalerecieptAggregation = function (query) {
  return new Promise(function (resolve, reject) {
    salereciept.Salereciept.aggregate(query, function (err, data) {
      if (err) {
        reject(err);
      } else {
        resolve(data);
      }
    });
  });
};
const findServicechargelistAggregation = function (query) {
  return new Promise(function (resolve, reject) {
    salereciept.Sellerservice.aggregate(query, function (err, data) {
      if (err) {
        reject(err);
      } else {
        resolve(data);
      }
    });
  });
};
const findSellerpaybaleAggregation = function (query) {
  return new Promise(function (resolve, reject) {
    salereciept.SellerPayable.aggregate(query, function (err, data) {
      if (err) {
        reject(err);
      } else {
        resolve(data);
      }
    });
  });
};
const findSellerpayablelistAggregation = function (query) {
  return new Promise(function (resolve, reject) {
    salereciept.SellerPayable.aggregate(query, function (err, data) {
      if (err) {
        reject(err);
      } else {
        resolve(data);
      }
    });
  });
};

const findSelRecipt = async function (res, query) {
  return new Promise(function (resolve, reject) {
    salereciept.Salereciept.find(query, function (err, data) {
      if (err) {
        reject(err);
      } else {
        resolve(data);
      }
    });
  });
};

const findSellerPaybale = async function (res, query) {
  return new Promise(function (resolve, reject) {
    salereciept.SellerPayable.find(query, function (err, data) {
      if (err) {
        reject(err);
      } else {
        resolve(data);
      }
    });
  });
};

const findOneSellerPaybale = async function (res, query) {
  return new Promise(function (resolve, reject) {
    salereciept.SellerPayable.findOne(query, function (err, data) {
      if (err) {
        reject(err);
      } else {
        resolve(data);
      }
    });
  });
};

const findSellerServices = async function (res, query) {
  return new Promise(function (resolve, reject) {
    salereciept.Sellerservice.find(query, function (err, data) {
      if (err) {
        reject(err);
      } else {
        resolve(data);
      }
    });
  });
};

module.exports = {
  salerecieptAdd,
  findSalerecieptWithFiled,
  findSalerecieptAggregation,
  findServicechargelistAggregation,
  findSellerpayablelistAggregation,
  findSellerpaybaleAggregation,
  findSelRecipt,
  findSellerPaybale,
  findOneSellerPaybale,
  findSellerServices,
};
