const express = require("express");
const router = express.Router();
const saleRecieptModal = require("../saleReciept/saleRecieptModal");
const message = require("../../config/message");
const config = require("../../config");
const midleware = require("../../middleware/validation");
const cmethod = require("../../middleware/common-fun");
const salerecieptDao = require("./saleRecieptDao");
var mongoose = require("mongoose");
const {
  checkBoolean,
  regexSearch,
} = require("../../functions/global.functions");
const {
  reverseCalculateAuctionServiceCharges,
  reverseCalculateStorageServiceCharges,
} = require("../../helpers/saleReceipt.helper");
const logger = require("../../config/logger");
const {
  ExactMatch,
  DateMatch,
  IDMatch,
  Lookup,
  Unwind,
  LookupWithPipeline,
  AddFields,
} = require("../../functions/mongoose.functions");
const {
  processSellerData,
  addSellerPayable,
  updateSellerPayable,
} = require("../../services/sellerReceipt.service");

router.post(
  "/add",
  [
    midleware.validateFieldValue(
      [
        "salerId",
        "buyerId",
        "inventoryId",
        "recieptId",
        "saleAmount",
        "paybleAmount",
      ],
      [
        "salerId",
        "buyerId",
        "inventoryId",
        "recieptId",
        "saleAmount",
        "paybleAmount",
      ]
    ),
  ],
  async (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;

    let queryUnique = {
      $and: [
        { saleRecieptNo: { $exists: true } },
        { saleRecieptNo: { $gt: 0 } },
      ],
    };
    let recieptNoUnique = 0;
    const recieptData = await saleRecieptModal.Salereciept.findOne(
      queryUnique,
      { saleRecieptNo: 1 }
    ).sort({ createdAt: -1 });

    if (recieptData) {
      if (recieptData.saleRecieptNo == 0 || !recieptData.saleRecieptNo) {
        recieptNoUnique = 100101;
      } else {
        recieptNoUnique = recieptData.saleRecieptNo + 1;
      }
    } else {
      recieptNoUnique = 100101;
    }
    postData.saleRecieptNo = recieptNoUnique;
    salerecieptDao.salerecieptAdd(res, postData);
  }
);
router.patch(
  "/update",
  [
    midleware.validateFieldValue(
      ["salerecieptId", "updateType"],
      ["salerecieptId", "updateType"]
    ),
  ],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;

    let queryCond = {
      $and: [{ _id: mongoose.Types.ObjectId(postData.salerecieptId) }],
    };
    //   delete postData.salerecieptId;
    let setData;
    if (postData.updateType && postData.updateType == "status") {
      setData = {
        status: postData.status,
      };
    } else {
      setData = {
        paidAmount: postData.paidAmount,
        paymentMethod: postData.paymentMethod,
        checkNo: postData.checkNo,
        checkDate: postData.checkDate,
        checkImg: postData.checkImg,
        status: postData.status,
      };
    }

    saleRecieptModal.Salereciept.findOneAndUpdate(
      queryCond,
      { $set: setData },
      { new: true },
      async function (err, data) {
        if (err) {
          cmethod.returnSreverError(res, message[lang].technicalError, err);
        } else {
          cmethod.returnSuccess(res, data, false, message[lang].Updated);
        }
      }
    );
  }
);
router.post(
  "/list",
  [midleware.validateFieldValue(["pageLimit", "page"], ["page"])],
  async (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;

    let query = [];

    query.push({
      $lookup: {
        from: "inventorys",
        localField: "inventoryId",
        foreignField: "_id",
        as: "inventorys",
      },
    });
    query.push({
      $unwind: { path: "$inventorys", preserveNullAndEmptyArrays: true },
    });
    query.push({
      $lookup: {
        from: "users",
        localField: "salerId",
        foreignField: "_id",
        as: "sellerUsers",
      },
    });

    query.push({
      $unwind: { path: "$sellerUsers", preserveNullAndEmptyArrays: true },
    });
    query.push({
      $lookup: {
        from: "users",
        localField: "buyerId",
        foreignField: "_id",
        as: "buyerUsers",
      },
    });
    query.push({
      $unwind: { path: "$buyerUsers", preserveNullAndEmptyArrays: true },
    });

    query.push({
      $lookup: {
        from: "interiorcolors",
        localField: "inventorys.interiorcolorId",
        foreignField: "_id",
        as: "interiorcolors",
      },
    });
    query.push({
      $unwind: { path: "$interiorcolors", preserveNullAndEmptyArrays: true },
    });
    query.push({
      $lookup: {
        from: "exteriorcolors",
        localField: "inventorys.exteriorcolorId",
        foreignField: "_id",
        as: "exteriorcolors",
      },
    });
    query.push({
      $unwind: { path: "$exteriorcolors", preserveNullAndEmptyArrays: true },
    });

    query.push({
      $lookup: {
        from: "makes",
        localField: "inventorys.make",
        foreignField: "_id",
        as: "makes",
      },
    });
    query.push({
      $unwind: { path: "$makes", preserveNullAndEmptyArrays: true },
    });
    query.push({
      $lookup: {
        from: "models",
        localField: "inventorys.model",
        foreignField: "_id",
        as: "models",
      },
    });
    query.push({
      $unwind: { path: "$models", preserveNullAndEmptyArrays: true },
    });
    if (postData.status) {
      query.push({
        $match: {
          $and: [{ status: Number(postData.status) }],
        },
      });
    }
    if (postData.salerecieptId) {
      query.push({
        $match: {
          $and: [{ _id: mongoose.Types.ObjectId(postData.salerecieptId) }],
        },
      });
    }

    if (postData.search) {
      query.push({
        $match: {
          $and: [
            {
              $or: [
                {
                  "inventorys.vin": { $regex: postData.search, $options: "i" },
                },
                { saleRecieptNo: { $regex: postData.search, $options: "i" } },
              ],
            },
          ],
        },
      });
    }
    const sQuery = [...query];
    query.push({
      $project: {
        saleRecieptNo: 1,
        sellerId: "$sellerUsers.uniqueIdentifier",
        sellerName: "$sellerUsers.name",
        buyerId: "$buyerUsers.uniqueIdentifier",
        buyerName: "$buyerUsers.name",
        vinNo: "$inventorys.vinNo",
        saleAmount: 1,
        taxAmount: 1,
        securityDeposit: 1,
        paybleAmount: 1,
        status: 1,
        carDescription: {
          $concat: [
            "$inventorys.year",
            " ",
            "$makes.makeName",
            " ",
            "$models.modelName",
          ],
        },
        createdAt: 1,
      },
    });

    query.push({ $sort: { createdAt: -1 } });
    sQuery.push({ $count: "recordCount" });

    if (postData.page) {
      query.push({
        $skip: cmethod.pageOffset(postData.page, postData.pageLimit),
      });
      query.push({ $limit: cmethod.pageLimit(postData.pageLimit) });
    }

    salerecieptDao
      .findSalerecieptAggregation(query)
      .then(function (data) {
        salerecieptDao
          .findSalerecieptAggregation(sQuery)
          .then(async function (dcount) {
            let tptCnt = 0;
            if (dcount.length > 0) {
              tptCnt = dcount[0].recordCount;
            }
            res.status(200).json({
              status: true,
              result: data,
              message: "",
              hasMore: cmethod.hasMoreCount(
                tptCnt,
                postData.page,
                postData.pageLimit
              ),
              totalCount: tptCnt,
            });
          })
          .catch((err) => {
            cmethod.returnSreverError(res, message[lang].technicalError, err);
          });
      })
      .catch((err) => {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      });
  }
);
router.post(
  "/servicechargelist",
  [midleware.validateFieldValue([], [])],
  async (req, res) => {
    const {
      body: postData,
      headers: { lang = config.lang },
    } = req;

    const query = [];

    try {
      // * createdAt
      if (postData.fromDate && postData.toDate) {
        DateMatch(query, "createdAt", postData.fromDate, postData.toDate);
      }

      // * inventorys
      query.push({
        $lookup: {
          from: "inventorys",
          localField: "inventoryId",
          foreignField: "_id",
          as: "inventorys",
        },
      });
      query.push({
        $unwind: { path: "$inventorys", preserveNullAndEmptyArrays: true },
      });

      // * sellerUsers
      query.push({
        $lookup: {
          from: "users",
          localField: "sellerId",
          foreignField: "_id",
          as: "sellerUsers",
        },
      });
      query.push({
        $unwind: { path: "$sellerUsers", preserveNullAndEmptyArrays: true },
      });

      // * buyerUsers
      query.push({
        $lookup: {
          from: "users",
          localField: "buyerId",
          foreignField: "_id",
          as: "buyerUsers",
        },
      });
      query.push({
        $unwind: { path: "$buyerUsers", preserveNullAndEmptyArrays: true },
      });

      // * makes
      query.push({
        $lookup: {
          from: "makes",
          localField: "inventorys.make",
          foreignField: "_id",
          as: "makes",
        },
      });
      query.push({
        $unwind: { path: "$makes", preserveNullAndEmptyArrays: true },
      });

      // * models
      query.push({
        $lookup: {
          from: "models",
          localField: "inventorys.model",
          foreignField: "_id",
          as: "models",
        },
      });
      query.push({
        $unwind: { path: "$models", preserveNullAndEmptyArrays: true },
      });

      // * singlevinimages
      query.push({
        $lookup: {
          from: "vinimages",
          let: {
            inventoryId: "$inventorys._id",
            imageType: "inventory",
            type: "carimage",
          },
          pipeline: [
            {
              $match: {
                $expr: {
                  $and: [
                    { $eq: ["$imageType", "$$imageType"] },
                    { $eq: ["$type", "$$type"] },
                    { $eq: ["$referenceId", "$$inventoryId"] },
                  ],
                },
              },
            },
          ],
          as: "singlevinimages",
        },
      });

      // * branches
      query.push({
        $lookup: {
          from: "branchs",
          localField: "inventorys.branchId",
          foreignField: "_id",
          as: "branches",
        },
      });
      query.push({
        $unwind: { path: "$branches", preserveNullAndEmptyArrays: true },
      });

      if (postData.apiType === "web") {
        Lookup(query, "reciepts", "recieptId", "_id", "receipt");
        Unwind(query, "$receipt");
      }

      if (postData.servicechargeId) {
        query.push({
          $match: {
            $and: [{ _id: mongoose.Types.ObjectId(postData.servicechargeId) }],
          },
        });
      }
      if (postData.serviceType) {
        query.push({
          $match: {
            serviceType: { $in: postData.serviceType },
          },
        });
      }
      if (postData.sellerId) {
        query.push({
          $match: {
            sellerId: mongoose.Types.ObjectId(postData.sellerId),
          },
        });
      }
      if (postData.serviceStatus) {
        query.push({
          $match: {
            serviceStatus: postData.serviceStatus,
          },
        });
      }
      if (postData.saleOrderNo) {
        query.push({
          $match: {
            saleOrderNo: postData.saleOrderNo,
          },
        });
      }
      if (postData.vinNo) {
        query.push({
          $match: {
            $and: [{ "inventorys.vin": regexSearch(postData.vinNo) }],
          },
        });
      }
      if (postData.inventoryCreatedBy) {
        query.push({
          $match: {
            $and: [
              {
                "inventorys.createdBy": regexSearch(
                  postData.inventoryCreatedBy
                ),
              },
            ],
          },
        });
      }
      const sQuery = [...query];

      query.push({
        $project: {
          inventoryCreatedBy: "$inventorys.createdBy",
          saleOrderNo: 1,
          sellerId: "$sellerUsers.uniqueIdentifier",
          sellerName: "$sellerUsers.name",
          sellerUserType: "$sellerUsers.userType",
          sellerCompanyDetails: "$sellerUsers.companyDetails",
          buyerId: "$buyerUsers.uniqueIdentifier",
          buyerName: "$buyerUsers.name",
          buyerUserType: "$buyerUsers.userType",
          buyerCompanyDetails: "$buyerUsers.companyDetails",
          recieptId: 1,
          vin: "$inventorys.vin",
          lotNo: "$inventorys.lotNo",
          branchName: "$branches.branchName",
          inventoryId: "$inventorys._id",
          carDescription: {
            $concat: [
              "$inventorys.year",
              " ",
              "$makes.makeName",
              " ",
              "$models.modelName",
            ],
          },
          singleImage: {
            $cond: {
              if: { $eq: ["$singlevinimages", []] },
              then: config.defaultInventoryImage,
              else: { $arrayElemAt: ["$singlevinimages.image", 0] },
            },
          },
          serviceType: 1,
          saleAmount: 1,
          auctionFee: 1,
          listingFee: 1,
          serviceCharge: 1,
          vatAmount: 1,
          securityDeposit: 1,
          totalPayment: 1,
          saleTotalAmount: 1,
          auctionTotalAmount: 1,
          status: 1,
          serviceStatus: 1,
          createdAt: 1,
          sellerInvoice: "$receipt.sellerInvoice",
        },
      });

      query.push({ $sort: { createdAt: -1 } });
      sQuery.push({ $count: "totalCount" });

      if (postData.page) {
        query.push({
          $skip: cmethod.pageOffset(postData.page, postData.pageLimit),
        });
        query.push({ $limit: cmethod.pageLimit(postData.pageLimit) });
      }

      // * results
      const [result, [{ totalCount } = {}] = []] = await Promise.all([
        saleRecieptModal.Sellerservice.aggregate(query),
        saleRecieptModal.Sellerservice.aggregate(sQuery),
      ]);

      res.status(200).json({
        status: true,
        result,
        message: "",
        hasMore: cmethod.hasMoreCount(
          totalCount,
          postData.page,
          postData.pageLimit
        ),
        totalCount,
      });
    } catch (error) {
      logger.error(error);
      cmethod.returnSreverError(res, message[lang]?.technicalError, error);
    }
  }
);
router.patch(
  "/servicechargeupdate",
  [midleware.validateFieldValue(["servicechargeId"], ["servicechargeId"])],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;

    let queryCond = {
      $and: [{ _id: mongoose.Types.ObjectId(postData.servicechargeId) }],
    };

    saleRecieptModal.Sellerservice.findOneAndUpdate(
      queryCond,
      { $set: postData },
      { new: true },
      async function (err, data) {
        if (err) {
          cmethod.returnSreverError(res, message[lang].technicalError, err);
        } else {
          cmethod.returnSuccess(res, data, false, message[lang].Updated);
        }
      }
    );
  }
);
router.post(
  "/getsellerpayablelist",
  [midleware.validateFieldValue(["pageLimit", "page"], ["page"])],
  async (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let query = [];

    // * getPass
    const getPassLet = {
      inventoryId: "$inventoryId",
      direction: "out",
      status: "pending",
    };
    const getPassPipeline = [
      {
        $match: {
          $expr: {
            $and: [
              { $eq: ["$inventoryId", "$$inventoryId"] },
              { $eq: ["$direction", "out"] },
              { $eq: ["$status", "pending"] },
            ],
          },
        },
      },
    ];
    LookupWithPipeline(
      query,
      "getpasses",
      getPassLet,
      getPassPipeline,
      "getPass"
    );

    // * sellerservices
    query.push({
      $lookup: {
        from: "sellerservices",
        let: {
          inventoryId: "$inventoryId",
        },
        pipeline: [
          {
            $match: {
              $expr: { $eq: ["$inventoryId", "$$inventoryId"] },
              $or: [{ serviceType: "auction" }, { serviceType: "storage" }],
            },
          },
        ],
        as: "sellerservices",
      },
    });
    query.push({
      $unwind: { path: "$sellerservices", preserveNullAndEmptyArrays: true },
    });

    // * inventorys
    query.push({
      $lookup: {
        from: "inventorys",
        localField: "inventoryId",
        foreignField: "_id",
        as: "inventorys",
      },
    });
    query.push({
      $unwind: { path: "$inventorys", preserveNullAndEmptyArrays: true },
    });

    if (postData.sellerpayableId && postData.branchId) {
      query.push({
        $match: {
          $and: [
            { sellerId: mongoose.Types.ObjectId(postData.sellerpayableId) },
            {
              "inventorys.branchId": mongoose.Types.ObjectId(postData.branchId),
            },
          ],
        },
      });
    }
    if (postData.vinNo) {
      query.push({
        $match: {
          $and: [{ "inventorys.vin": regexSearch(postData.vinNo) }],
        },
      });
    }

    // * branchs
    query.push({
      $lookup: {
        from: "branchs",
        localField: "inventorys.branchId",
        foreignField: "_id",
        as: "branchs",
      },
    });
    query.push({
      $unwind: { path: "$branchs", preserveNullAndEmptyArrays: true },
    });

    // * match
    query.push({
      $match: {
        $and: [{ "sellerservices.status": "pending" }, { status: "pending" }],
      },
    });

    // * seller
    Lookup(query, "users", "inventorys.sellerId", "_id", "seller");
    Unwind(query, "$seller");

    // * buyer
    Lookup(query, "users", "buyerId", "_id", "buyer");
    Unwind(query, "$buyer");

    // * receipts
    const receiptLet = {
      inventoryId: "$inventoryId",
      buyerId: "$buyerId",
    };
    const receiptPipeline = [
      {
        $match: {
          $expr: {
            $and: [
              { $eq: ["$inventoryId", "$$inventoryId"] },
              { $eq: ["$buyerId", "$$buyerId"] },
            ],
          },
        },
      },
    ];
    LookupWithPipeline(
      query,
      "reciepts",
      receiptLet,
      receiptPipeline,
      "receipts"
    );
    Unwind(query, "$receipts");

    // * auctionVehicles
    const auctionVehiclesLet = {
      inventoryId: "$inventoryId",
      status: "$serviceStatus",
    };
    const auctionVehiclesPipeline = [
      {
        $match: {
          $expr: {
            $and: [
              {
                $eq: ["$inventoryId", "$$inventoryId"],
              },
              {
                $eq: ["$status", "$$status"],
              },
            ],
          },
        },
      },
    ];
    LookupWithPipeline(
      query,
      "auctionvehicles",
      auctionVehiclesLet,
      auctionVehiclesPipeline,
      "auctionVehicles"
    );

    // * lastVehicleAuctionId
    const lastVehicleAuctionId = {
      $arrayElemAt: ["$auctionVehicles.auctionId", -1],
    };
    AddFields(query, "lastVehicleAuctionId", lastVehicleAuctionId);

    // * auction
    Lookup(query, "auctions", "lastVehicleAuctionId", "_id", "auction");
    Unwind(query, "$auction");

    // * group
    query.push({
      $group: {
        _id: "$inventoryId",
        branchs: { $first: "$branchs" },
        salerId: { $first: "$sellerId" },
        date: { $first: "$createdAt" },
        inventorys: { $first: "$inventorys" },
        inventoryId: { $first: "$inventoryId" },
        sellerName: { $first: "$seller.name" },
        sellerUserType: { $first: "$seller.userType" },
        sellerCompanyDetails: { $first: "$seller.companyDetails" },
        buyerName: { $first: "$buyer.name" },
        buyerUserType: { $first: "$buyer.userType" },
        buyerCompanyDetails: { $first: "$buyer.companyDetails" },
        getPassExpiryDate: { $first: "$getPass.gatePassExpired" },
        getPassParkingDays: { $first: "$getPass.parkingDays" },
        getPassParkedDays: { $first: "$getPass.parkedDays" },
        receiptDate: { $first: "$receipts.transDate" },
        auctionDate: { $first: "$auction.auctionDate" },
        // * Sale
        sale_order_no: {
          $max: {
            $cond: [{ $eq: ["$serviceType", "sold"] }, "$saleOrderNo", null],
          },
        },
        sale_amount: {
          $max: {
            $cond: [{ $eq: ["$serviceType", "sold"] }, "$saleAmount", 0],
          },
        },
        sale_vat_amount: {
          $max: {
            $cond: [{ $eq: ["$serviceType", "sold"] }, "$vatAmount", 0],
          },
        },
        sale_total_amount: {
          $max: {
            $add: [
              {
                $cond: [{ $eq: ["$serviceType", "sold"] }, "$saleAmount", 0],
              },
              {
                $cond: [{ $eq: ["$serviceType", "sold"] }, "$vatAmount", 0],
              },
            ],
          },
        },
        // * Auction
        auction_order_no: {
          $max: {
            $cond: [
              { $eq: ["$sellerservices.serviceType", "auction"] },
              "$sellerservices.saleOrderNo",
              null,
            ],
          },
        },
        auction_fee: {
          $max: {
            $cond: [
              { $eq: ["$sellerservices.serviceType", "auction"] },
              "$sellerservices.auctionFee",
              0,
            ],
          },
        },
        listing_fee: {
          $max: {
            $cond: [
              { $eq: ["$sellerservices.serviceType", "auction"] },
              "$sellerservices.listingFee",
              0,
            ],
          },
        },
        auction_discount: {
          $max: {
            $cond: [
              { $eq: ["$sellerservices.serviceType", "auction"] },
              "$sellerservices.auctionDiscount",
              0,
            ],
          },
        },
        listing_discount: {
          $max: {
            $cond: [
              { $eq: ["$sellerservices.serviceType", "auction"] },
              "$sellerservices.listingDiscount",
              0,
            ],
          },
        },
        total_discount: {
          $max: {
            $cond: [
              { $eq: ["$sellerservices.serviceType", "auction"] },
              "$sellerservices.totalDiscount",
              0,
            ],
          },
        },
        vat_fee: {
          $max: {
            $cond: [
              { $eq: ["$sellerservices.serviceType", "auction"] },
              "$sellerservices.vatAmount",
              0,
            ],
          },
        },
        serviceStatus: {
          $max: {
            $cond: {
              if: { $eq: ["$sellerservices.serviceType", "auction"] },
              then: "$sellerservices.serviceStatus",
              else: {
                $cond: {
                  if: { $eq: ["$sellerservices.serviceType", "storage"] },
                  then: "$sellerservices.serviceStatus",
                  else: null,
                },
              },
            },
          },
        },
        // * Storage
        storage_order_no: {
          $max: {
            $cond: [
              { $eq: ["$sellerservices.serviceType", "storage"] },
              "$sellerservices.saleOrderNo",
              null,
            ],
          },
        },
        storage_amount: {
          $max: {
            $cond: [
              { $eq: ["$sellerservices.serviceType", "storage"] },
              "$sellerservices.serviceCharge",
              0,
            ],
          },
        },
        storage_vat_amount: {
          $max: {
            $cond: [
              { $eq: ["$sellerservices.serviceType", "storage"] },
              "$sellerservices.vatAmount",
              0,
            ],
          },
        },
        storage_total_amount: {
          $max: {
            $cond: [
              { $eq: ["$sellerservices.serviceType", "storage"] },
              "$sellerservices.totalPayment",
              0,
            ],
          },
        },
        storage_discount: {
          $max: {
            $cond: [
              { $eq: ["$sellerservices.serviceType", "storage"] },
              "$sellerservices.storageDiscount",
              0,
            ],
          },
        },
      },
    });

    // * addFields
    query.push({
      $addFields: {
        auction_total_without_vat: {
          $add: ["$auction_fee", "$listing_fee"],
        },
        auction_grand_total_with_vat: {
          $add: ["$auction_fee", "$listing_fee", "$vat_fee"],
        },
      },
    });

    // * project
    query.push({
      $project: {
        sale_order_no: 1,
        auction_order_no: 1,
        storage_order_no: 1,
        salesCharges: {
          amount: "$sale_amount",
          vat: "$sale_vat_amount",
          total: "$sale_total_amount",
        },
        auctionCharges: {
          auctionFee: "$auction_fee",
          listingFee: "$listing_fee",
          auctionDiscount: "$auction_discount",
          listingDiscount: "$listing_discount",
          totalDiscount: "$total_discount",
          total: "$auction_total_without_vat",
          vat: "$vat_fee",
          grandTotal: "$auction_grand_total_with_vat",
        },
        storageCharges: {
          amount: "$storage_amount",
          storageDiscount: "$storage_discount",
          total: "$storage_amount",
          vat: "$storage_vat_amount",
          grandTotal: "$storage_total_amount",
        },
        branchId: "$branchs._id",
        branchName: "$branchs.branchName",
        date: 1,
        salerId: 1,
        vinNo: "$inventorys.vin",
        lotNo: "$inventorys.lotNo",
        inventoryId: 1,
        serviceStatus: 1,
        sellerName: 1,
        sellerUserType: 1,
        sellerCompanyDetails: 1,
        buyerName: 1,
        buyerUserType: 1,
        buyerCompanyDetails: 1,
        getPassExpiryDate: { $arrayElemAt: ["$getPassExpiryDate", 0] },
        getPassParkingDays: { $arrayElemAt: ["$getPassParkingDays", 0] },
        saleDate: {
          $cond: {
            if: { $eq: ["$receiptDate", null] },
            then: "$auctionDate",
            else: "$receiptDate",
          },
        },
      },
    });

    query.push({ $sort: { date: -1 } });

    salerecieptDao
      .findServicechargelistAggregation(query)
      .then(function (data) {
        res.status(200).json({
          status: true,
          result: data,
          message: "",
          hasMore: false,
          totalCount: 0,
        });
      })
      .catch((err) => {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      });
  }
);
router.post(
  "/addpaybale",
  [
    midleware.validateFieldValue(
      ["sellerId", "branchId", "inventoryId"],
      ["sellerId", "branchId", "inventoryId"]
    ),
  ],
  async (req, res) => {
    const { body, headers } = req;
    const lang = headers.lang || config.lang;

    const { inventoryId } = body;

    try {
      if (inventoryId.length > 1) {
        return cmethod.returnSreverError(
          res,
          message[lang].singleInventoryPaymentAllowed
        );
      }

      const payable = await addSellerPayable(body);

      cmethod.returnSuccess(res, payable, false, "Payable Added Successfully!");
    } catch (error) {
      logger.error(error.message);
      cmethod.returnSreverError(res, message[lang]?.technicalError, error);
    }
  }
);

router.post("/sellerpaybalelist", async (req, res) => {
  const { body, headers } = req;
  const lang = headers.lang || config.lang;

  const query = [];

  try {
    // * createdAt
    if (body.fromDate && body.toDate) {
      DateMatch(query, "createdAt", body.fromDate, body.toDate);
    }

    // * sellerUsers
    query.push({
      $lookup: {
        from: "users",
        localField: "sellerId",
        foreignField: "_id",
        as: "sellerUsers",
      },
    });
    query.push({
      $unwind: { path: "$sellerUsers", preserveNullAndEmptyArrays: true },
    });

    // * inventorys
    query.push({
      $lookup: {
        from: "inventorys",
        localField: "inventoryId",
        foreignField: "_id",
        as: "inventorys",
      },
    });
    query.push({
      $unwind: { path: "$inventorys", preserveNullAndEmptyArrays: true },
    });

    // * makes
    query.push({
      $lookup: {
        from: "makes",
        localField: "inventorys.make",
        foreignField: "_id",
        as: "makes",
      },
    });
    query.push({
      $unwind: { path: "$makes", preserveNullAndEmptyArrays: true },
    });

    // * models
    query.push({
      $lookup: {
        from: "models",
        localField: "inventorys.model",
        foreignField: "_id",
        as: "models",
      },
    });
    query.push({
      $unwind: { path: "$models", preserveNullAndEmptyArrays: true },
    });

    // * sellerservices
    query.push({
      $lookup: {
        from: "sellerservices",
        let: {
          inventoryId: "$inventorys._id",
        },
        pipeline: [
          {
            $match: {
              $expr: {
                $and: [{ $eq: ["$inventoryId", "$$inventoryId"] }],
              },
            },
          },
        ],
        as: "sellerservices",
      },
    });
    query.push({
      $unwind: { path: "$sellerservices", preserveNullAndEmptyArrays: true },
    });

    // * receipts
    query.push({
      $lookup: {
        from: "reciepts",
        localField: "inventorys._id",
        foreignField: "inventoryId",
        as: "receipts",
      },
    });
    query.push({
      $unwind: { path: "$receipts", preserveNullAndEmptyArrays: true },
    });

    // * buyerUsers
    query.push({
      $lookup: {
        from: "users",
        localField: "sellerservices.buyerId",
        foreignField: "_id",
        as: "buyerUsers",
      },
    });
    query.push({
      $unwind: { path: "$buyerUsers", preserveNullAndEmptyArrays: true },
    });

    // * accountmasters
    query.push({
      $lookup: {
        from: "accountmasters",
        localField: "glAccountId",
        foreignField: "_id",
        as: "accountmasters",
      },
    });
    query.push({
      $unwind: { path: "$accountmasters", preserveNullAndEmptyArrays: true },
    });

    // * branchs
    query.push({
      $lookup: {
        from: "branchs",
        localField: "branchId",
        foreignField: "_id",
        as: "branchs",
      },
    });
    query.push({
      $unwind: { path: "$branchs", preserveNullAndEmptyArrays: true },
    });

    // * gatePass
    query.push({
      $lookup: {
        from: "getpasses",
        let: {
          inventoryId: "$inventorys._id",
          direction: "out",
          referenceType: "inventory",
        },
        pipeline: [
          {
            $match: {
              $expr: {
                $and: [
                  { $eq: ["$inventoryId", "$$inventoryId"] },
                  { $eq: ["$direction", "$$direction"] },
                  { $eq: ["$referenceType", "$$referenceType"] },
                ],
              },
            },
          },
        ],
        as: "gatePass",
      },
    });
    query.push({
      $unwind: { path: "$gatePass", preserveNullAndEmptyArrays: true },
    });

    // * warehouses
    query.push({
      $lookup: {
        from: "warehouses",
        localField: "inventorys.warehosId",
        foreignField: "_id",
        as: "warehouses",
      },
    });
    query.push({
      $unwind: { path: "$warehouses", preserveNullAndEmptyArrays: true },
    });

    // * drivetypes
    query.push({
      $lookup: {
        from: "drivetypes",
        localField: "inventorys.drivetypeId",
        foreignField: "_id",
        as: "drivetypes",
      },
    });
    query.push({
      $unwind: { path: "$drivetypes", preserveNullAndEmptyArrays: true },
    });

    // * fueltypes
    query.push({
      $lookup: {
        from: "fueltypes",
        localField: "inventorys.fueltypeId",
        foreignField: "_id",
        as: "fueltypes",
      },
    });
    query.push({
      $unwind: { path: "$fueltypes", preserveNullAndEmptyArrays: true },
    });

    // * engines
    query.push({
      $lookup: {
        from: "engines",
        localField: "inventorys.engineId",
        foreignField: "_id",
        as: "engines",
      },
    });
    query.push({
      $unwind: { path: "$engines", preserveNullAndEmptyArrays: true },
    });

    // * interiorcolors
    query.push({
      $lookup: {
        from: "interiorcolors",
        localField: "inventorys.interiorcolorId",
        foreignField: "_id",
        as: "interiorcolors",
      },
    });
    query.push({
      $unwind: { path: "$interiorcolors", preserveNullAndEmptyArrays: true },
    });

    // * exteriorcolors
    query.push({
      $lookup: {
        from: "exteriorcolors",
        localField: "inventorys.exteriorcolorId",
        foreignField: "_id",
        as: "exteriorcolors",
      },
    });
    query.push({
      $unwind: { path: "$exteriorcolors", preserveNullAndEmptyArrays: true },
    });

    // * singlevinimages
    query.push({
      $lookup: {
        from: "vinimages",
        let: {
          inventoryId: "$inventorys._id",
          imageType: "inventory",
          type: "carimage",
        },
        pipeline: [
          {
            $match: {
              $expr: {
                $and: [
                  { $eq: ["$imageType", "$$imageType"] },
                  { $eq: ["$type", "$$type"] },
                  { $eq: ["$referenceId", "$$inventoryId"] },
                ],
              },
            },
          },
        ],
        as: "singlevinimages",
      },
    });

    // * auction
    Lookup(query, "auctions", "sellerservices.auctionId", "_id", "auction");
    Unwind(query, "$auction");

    if (body.sellerpaybaleId) {
      query.push({
        $match: {
          $and: [{ _id: mongoose.Types.ObjectId(body.sellerpaybaleId) }],
        },
      });
    }

    if (body.sellerId) {
      query.push({
        $match: {
          $and: [{ sellerId: mongoose.Types.ObjectId(body.sellerId) }],
        },
      });
    }

    if (body.branchId) {
      query.push({
        $match: {
          $and: [{ branchId: mongoose.Types.ObjectId(body.branchId) }],
        },
      });
    }

    if (body.vinNo) {
      query.push({
        $match: {
          $and: [{ "inventorys.vin": regexSearch(body.vinNo) }],
        },
      });
    }

    if (body.balanceType) {
      query.push({
        $match: {
          $and: [{ balanceType: body.balanceType }],
        },
      });
    }

    if (body.status) {
      query.push({
        $match: {
          $and: [{ status: body.status }],
        },
      });
    }

    if (body.payableNo) {
      query.push({
        $match: {
          $and: [{ payableNo: body.payableNo }],
        },
      });
    }

    if (body.serviceStatus) {
      query.push({
        $match: {
          "sellerservices.serviceStatus": body.serviceStatus,
        },
      });
    }

    if (body.serviceType) {
      query.push({
        $match: {
          "sellerservices.serviceType": body.serviceType,
        },
      });
    }

    if (body.paymentMethod) {
      query.push({
        $match: {
          paymentMethod: body.paymentMethod,
        },
      });
    }

    if (checkBoolean(body.groupByInventory)) {
      query.push({
        $group: {
          _id: "$inventorys._id",
          inventorys: { $first: "$inventorys" },
          buyerUsers: { $first: "$buyerUsers" },
          branchs: { $first: "$branchs" },
          accountmasters: { $first: "$accountmasters" },
          makes: { $first: "$makes" },
          models: { $first: "$models" },
          payableNo: { $first: "$payableNo" },
          totalPayable: { $first: "$totalPayable" },
          totalReceivable: { $first: "$totalReceivable" },
          netPayBalance: { $first: "$netPayBalance" },
          status: { $first: "$status" },
          balanceType: { $first: "$balanceType" },
          checkNo: { $first: "$checkNo" },
          checkDate: { $first: "$checkDate" },
          checkImg: { $first: "$checkImg" },
          paymentMethod: { $first: "$paymentMethod" },
          transactionDate: { $first: "$transactionDate" },
          createdAt: { $first: "$createdAt" },
          sellerUsers: { $first: "$sellerUsers" },
          sellerservices: { $first: "$sellerservices" },
          receipts: { $first: "$receipts" },
          auctionDate: { $first: "$auction.auctionDate" },
        },
      });
    } else {
      query.push({
        $group: {
          _id: "$_id",
          makes: { $first: "$makes" },
          models: { $first: "$models" },
          inventorys: { $first: "$inventorys" },
          drivetypes: { $first: "$drivetypes" },
          fueltypes: { $first: "$fueltypes" },
          engines: { $first: "$engines" },
          interiorcolors: { $first: "$interiorcolors" },
          exteriorcolors: { $first: "$exteriorcolors" },
          sellerServices: { $push: "$sellerservices" },
          gatePass: { $first: "$gatePass" },
          warehouses: { $first: "$warehouses" },
          payableNo: { $first: "$payableNo" },
          branchs: { $first: "$branchs" },
          totalPayable: { $first: "$totalPayable" },
          totalReceivable: { $first: "$totalReceivable" },
          netPayBalance: { $first: "$netPayBalance" },
          status: { $first: "$status" },
          balanceType: { $first: "$balanceType" },
          paymentMethod: { $first: "$paymentMethod" },
          sellerUsers: { $first: "$sellerUsers" },
          buyerUsers: { $first: "$buyerUsers" },
          sellerservices: { $first: "$sellerservices" },
          createdAt: { $first: "$createdAt" },
          receipts: { $first: "$receipts" },
          auctionDate: { $first: "$auction.auctionDate" },
          singlevinimages: { $first: "$singlevinimages" },
        },
      });
    }

    if (checkBoolean(body.groupByInventory)) {
      query.push({
        $project: {
          payableNo: 1,
          inventoryDetails: {
            inventoryId: "$inventorys._id",
            carDescription: {
              $concat: [
                "$inventorys.year",
                " ",
                "$makes.makeName",
                " ",
                "$models.modelName",
              ],
            },
            lotNo: "$inventorys.lotNo",
            vinNo: "$inventorys.vin",
            keyNo: "$inventorys.keyNo",
          },
          accountName: "$accountmasters.accountName",
          accountNo: "$accountmasters.accountNo",
          refno: "$sellerservices.saleOrderNo",
          buyerID: "$buyerUsers._id",
          buyerId: "$buyerUsers.uniqueIdentifier",
          buyerName: "$buyerUsers.name",
          sellerID: "$sellerUsers._id",
          sellerId: "$sellerUsers.uniqueIdentifier",
          sellerName: "$sellerUsers.name",
          branchId: "$branchs._id",
          branchName: "$branchs.branchName",
          receiptId: "$receipts._id",
          receiptDate: {
            $cond: {
              if: { $eq: ["$receipts", null] },
              then: "$auctionDate",
              else: "$receipts.transDate",
            },
          },
          serviceType: "$sellerservices.serviceType",
          serviceStatus: "$sellerservices.serviceStatus",
          checkNo: 1,
          checkDate: 1,
          checkImg: 1,
          totalPayable: 1,
          totalReceivable: 1,
          netPayBalance: 1,
          status: 1,
          balanceType: 1,
          paymentMethod: 1,
          transactionDate: 1,
          description: "$status",
          invoiceDate: "$createdAt",
        },
      });
    } else {
      query.push({
        $project: {
          payableNo: 1,
          inventoryId: "$inventorys._id",
          makes: "$makes.makeName",
          models: "$models.modelName",
          year: "$inventorys.year",
          lotNo: "$inventorys.lotNo",
          vinNo: "$inventorys.vin",
          keyNo: "$inventorys.keyNo",
          engineName: "$engines.engineName",
          warehouseName: "$warehouses.warehouseName",
          interiorColor: "$interiorcolors.colorName",
          exteriorColor: "$exteriorcolors.colorName",
          fuelTypeName: "$fueltypes.fueltypeName",
          driveTypeName: "$drivetypes.drivetypeName",
          carDescription: {
            $concat: [
              "$inventorys.year",
              " ",
              "$makes.makeName",
              " ",
              "$models.modelName",
            ],
          },
          sellerServices: {
            $filter: {
              input: "$sellerServices",
              as: "sellerServices",
              cond: { $eq: ["$$sellerServices.serviceType", "sold"] },
            },
          },
          gatePass: 1,
          accountName: "$accountmasters.accountName",
          accountNo: "$accountmasters.accountNo",
          refno: "$sellerservices.saleOrderNo",
          buyerID: "$buyerUsers._id",
          buyerId: "$buyerUsers.uniqueIdentifier",
          buyerName: "$buyerUsers.name",
          buyerUserType: "$buyerUsers.userType",
          buyerCompanyDetails: "$buyerUsers.companyDetails",
          sellerId: "$sellerUsers.uniqueIdentifier",
          sellerID: "$sellerUsers._id",
          sellerName: "$sellerUsers.name",
          sellerEID: "$sellerUsers.eid",
          sellerTRN: "$sellerUsers.companyDetails.trn",
          sellerAddress: "$sellerUsers.address",
          sellerUserType: "$sellerUsers.userType",
          sellerCompanyDetails: "$sellerUsers.companyDetails",
          branchId: "$branchs._id",
          branchName: "$branchs.branchName",
          receiptId: "$receipts._id",
          receiptDate: {
            $cond: {
              if: { $eq: ["$receipts", null] },
              then: "$auctionDate",
              else: "$receipts.transDate",
            },
          },
          serviceType: "$sellerservices.serviceType",
          serviceStatus: "$sellerservices.serviceStatus",
          checkNo: 1,
          checkDate: 1,
          checkImg: 1,
          totalPayable: 1,
          totalReceivable: 1,
          netPayBalance: 1,
          status: 1,
          balanceType: 1,
          paymentMethod: 1,
          transactionDate: 1,
          createdAt: 1,
          description: "$status",
          invoiceDate: "$createdAt",
          singleImages: {
            $cond: {
              if: { $eq: ["$singlevinimages", []] },
              then: config.defaultInventoryImage,
              else: { $arrayElemAt: ["$singlevinimages.image", 0] },
            },
          },
        },
      });
    }

    query.push({ $sort: { createdAt: -1 } });
    const sQuery = [...query];

    sQuery.push({ $count: "totalCount" });

    if (body.page) {
      query.push({
        $skip: cmethod.pageOffset(body.page, body.pageLimit),
      });
      query.push({ $limit: cmethod.pageLimit(body.pageLimit) });
    }

    // * results
    const [result, [{ totalCount } = {}] = []] = await Promise.all([
      saleRecieptModal.SellerPayable.aggregate(query),
      saleRecieptModal.SellerPayable.aggregate(sQuery),
    ]);

    res.status(200).json({
      status: true,
      result,
      message: "",
      hasMore: cmethod.hasMoreCount(totalCount, body.page, body.pageLimit),
      totalCount,
    });
  } catch (error) {
    logger.error(error);
    cmethod.returnSreverError(res, message[lang].technicalError, error);
  }
});

router.post(
  "/seller-payable-history",
  [midleware.validateFieldValue(["payableId"], ["payableId"])],
  async (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;

    const query = [];

    // * match
    query.push({
      $match: {
        $and: [{ _id: mongoose.Types.ObjectId(postData.payableId) }],
      },
    });

    // * inventorys
    query.push({
      $lookup: {
        from: "inventorys",
        localField: "inventoryId",
        foreignField: "_id",
        as: "inventorys",
      },
    });
    query.push({
      $unwind: { path: "$inventorys", preserveNullAndEmptyArrays: true },
    });

    // * inventories by vin
    query.push({
      $lookup: {
        from: "inventorys",
        localField: "inventorys.vin",
        foreignField: "vin",
        as: "inventories",
      },
    });
    query.push({
      $unwind: { path: "$inventories", preserveNullAndEmptyArrays: true },
    });

    // * makes
    query.push({
      $lookup: {
        from: "makes",
        localField: "inventories.make",
        foreignField: "_id",
        as: "makes",
      },
    });
    query.push({
      $unwind: { path: "$makes", preserveNullAndEmptyArrays: true },
    });

    // * models
    query.push({
      $lookup: {
        from: "models",
        localField: "inventories.model",
        foreignField: "_id",
        as: "models",
      },
    });
    query.push({
      $unwind: { path: "$models", preserveNullAndEmptyArrays: true },
    });

    // * sellerPayable
    query.push({
      $lookup: {
        from: "sellerpayables",
        localField: "inventories._id",
        foreignField: "inventoryId",
        as: "sellerPayable",
      },
    });
    query.push({
      $unwind: { path: "$sellerPayable", preserveNullAndEmptyArrays: true },
    });

    // * sellerUsers
    query.push({
      $lookup: {
        from: "users",
        localField: "sellerPayable.sellerId",
        foreignField: "_id",
        as: "sellerUsers",
      },
    });
    query.push({
      $unwind: { path: "$sellerUsers", preserveNullAndEmptyArrays: true },
    });

    // * sellerServices
    query.push({
      $lookup: {
        from: "sellerservices",
        let: {
          inventoryId: "$inventories._id",
        },
        pipeline: [
          {
            $match: {
              $expr: {
                $and: [
                  { $eq: ["$inventoryId", "$$inventoryId"] },
                  {
                    $or: [
                      {
                        $and: [
                          { $eq: ["$serviceType", "sold"] },
                          { $eq: ["$serviceStatus", "sold"] },
                        ],
                      },
                      {
                        $and: [
                          { $eq: ["$serviceType", "auction"] },
                          { $in: ["$serviceStatus", ["unsold", "selfBid"]] },
                        ],
                      },
                    ],
                  },
                ],
              },
            },
          },
        ],
        as: "sellerServices",
      },
    });
    query.push({
      $unwind: {
        path: "$sellerServices",
        preserveNullAndEmptyArrays: true,
      },
    });

    // * receipts
    query.push({
      $lookup: {
        from: "reciepts",
        localField: "inventories._id",
        foreignField: "inventoryId",
        as: "receipts",
      },
    });
    query.push({
      $unwind: { path: "$receipts", preserveNullAndEmptyArrays: true },
    });

    // * buyerUsers
    query.push({
      $lookup: {
        from: "users",
        localField: "sellerServices.buyerId",
        foreignField: "_id",
        as: "buyerUsers",
      },
    });
    query.push({
      $unwind: { path: "$buyerUsers", preserveNullAndEmptyArrays: true },
    });

    // * auctionVehicles
    query.push({
      $lookup: {
        from: "auctionvehicles",
        localField: "inventories._id",
        foreignField: "inventoryId",
        as: "auctionVehicles",
      },
    });
    query.push({
      $unwind: { path: "$auctionVehicles", preserveNullAndEmptyArrays: true },
    });

    // * group
    query.push({
      $group: {
        _id: "$auctionVehicles._id",
        inventorys: { $first: "$inventories" },
        latestBid: { $first: "$auctionVehicles.bidAmount" },
        receiptDate: { $first: "$receipts.transDate" },
        sellerPayable: { $first: "$sellerPayable" },
        makes: { $first: "$makes" },
        models: { $first: "$models" },
        payableNo: { $first: "$sellerPayable.payableNo" },
        totalPayable: { $first: "$sellerPayable.totalPayable" },
        totalReceivable: { $first: "$sellerPayable.totalReceivable" },
        netPayBalance: { $first: "$sellerPayable.netPayBalance" },
        status: { $first: "$sellerPayable.status" },
        balanceType: { $first: "$sellerPayable.balanceType" },
        checkNo: { $first: "$sellerPayable.checkNo" },
        checkDate: { $first: "$sellerPayable.checkDate" },
        checkImg: { $first: "$sellerPayable.checkImg" },
        paymentMethod: { $first: "$sellerPayable.paymentMethod" },
        transactionDate: { $first: "$sellerPayable.transactionDate" },
        createdAt: { $first: "$sellerPayable.createdAt" },
        sellerUsers: { $first: "$sellerUsers" },
        buyerUsers: { $first: "$buyerUsers" },
        sellerServices: { $first: "$sellerServices" },
        receipts: { $first: "$receipts" },
      },
    });

    // * project
    query.push({
      $project: {
        payableId: "$sellerPayable._id",
        payableNo: 1,
        inventoryDetails: {
          inventoryId: "$inventorys._id",
          carDescription: {
            $concat: [
              "$inventorys.year",
              " ",
              "$makes.makeName",
              " ",
              "$models.modelName",
            ],
          },
          lotNo: "$inventorys.lotNo",
          vinNo: "$inventorys.vin",
        },
        refno: "$sellerServices.saleOrderNo",
        buyerID: "$buyerUsers._id",
        buyerId: "$buyerUsers.uniqueIdentifier",
        buyerName: "$buyerUsers.name",
        buyerUserType: "$buyerUsers.userType",
        buyerCompanyDetails: "$buyerUsers.companyDetails",
        sellerID: "$sellerUsers._id",
        sellerId: "$sellerUsers.uniqueIdentifier",
        sellerName: "$sellerUsers.name",
        sellerUserType: "$sellerUsers.userType",
        sellerCompanyDetails: "$sellerUsers.companyDetails",
        receiptId: "$receipts._id",
        serviceType: "$sellerServices.serviceType",
        serviceStatus: "$sellerServices.serviceStatus",
        checkNo: 1,
        checkDate: 1,
        checkImg: 1,
        totalPayable: 1,
        totalReceivable: 1,
        netPayBalance: 1,
        status: 1,
        balanceType: 1,
        paymentMethod: 1,
        transactionDate: 1,
        description: "$status",
        invoiceDate: "$createdAt",
        latestBid: 1,
        receiptDate: 1,
      },
    });

    query.push({ $sort: { createdAt: -1 } });

    salerecieptDao
      .findSellerpaybaleAggregation(query)
      .then(async function (data) {
        res.status(200).json({
          status: true,
          result: data,
          message: "",
          hasMore: cmethod.hasMoreCount(
            data.length,
            postData.page,
            postData.pageLimit
          ),
          totalCount: data.length,
        });
      })
      .catch((err) => {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      });
  }
);

router.patch(
  "/sellerpaybaleupdate",
  [midleware.validateFieldValue(["sellerpaybaleId"], ["sellerpaybaleId"])],
  async (req, res) => {
    const { body, headers } = req;
    const lang = headers.lang || config.lang;

    try {
      const payable = await updateSellerPayable(body);

      cmethod.returnSuccess(res, payable, false, message[lang].Updated);
    } catch (error) {
      logger.error(error.message);
      cmethod.returnSreverError(res, message[lang]?.technicalError, error);
    }
  }
);

router.delete(
  "/delete",
  [midleware.validateFieldValue(["deleteId"], ["deleteId"])],
  async (req, res) => {
    let postData = req.body;
    let allInventoryId = [];
    let cond = { _id: mongoose.Types.ObjectId(postData.deleteId) };
    let lang = req.headers["lang"] || config.lang;

    let paybleData = await saleRecieptModal.SellerPayable.findOne(
      { _id: mongoose.Types.ObjectId(postData.deleteId) },
      { inventoryId: 1, sellerId: 1, sellerServiceOrderNumbers: 1 }
    ).sort({ createdAt: -1 });
    if (paybleData) {
      for (i of paybleData?.inventoryId) {
        allInventoryId.push(mongoose.Types.ObjectId(i));
      }
    }
    saleRecieptModal.SellerPayable.deleteOne(cond, postData)
      .then(async (data) => {
        await saleRecieptModal.Salereciept.updateMany(
          { inventoryId: { $in: allInventoryId } },
          { $set: { status: "pending" } }
        );
        await saleRecieptModal.Sellerservice.updateMany(
          { inventoryId: { $in: allInventoryId } },
          { $set: { status: "pending" } }
        );

        const [inventoryId] = allInventoryId;
        const { sellerId, sellerServiceOrderNumbers } = paybleData;

        await reverseCalculateAuctionServiceCharges(
          inventoryId,
          sellerId,
          sellerServiceOrderNumbers
        );

        await reverseCalculateStorageServiceCharges(
          inventoryId,
          sellerId,
          sellerServiceOrderNumbers
        );

        cmethod.returnSuccess(res, [], false, message[lang].Deleteed);
      })
      .catch((err) => {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      });
  }
);

router.post(
  "/get-invoice",
  [midleware.validateFieldValue(["payableId"], ["payableId"])],
  async (req, res) => {
    const postData = req.body;
    let query = [];

    try {
      const filter = { _id: mongoose.Types.ObjectId(postData.payableId) };

      query.push({
        $match: filter,
      });

      if (postData.balanceType) {
        query.push({
          $match: {
            $and: [{ balanceType: postData.balanceType }],
          },
        });
      }

      // * inventories
      query.push({
        $lookup: {
          from: "inventorys",
          localField: "inventoryId",
          foreignField: "_id",
          as: "inventorys",
        },
      });
      query.push({
        $unwind: { path: "$inventorys", preserveNullAndEmptyArrays: true },
      });

      // * branchs
      query.push({
        $lookup: {
          from: "branchs",
          localField: "inventorys.branchId",
          foreignField: "_id",
          as: "branchs",
        },
      });
      query.push({
        $unwind: { path: "$branchs", preserveNullAndEmptyArrays: true },
      });

      // * makes
      query.push({
        $lookup: {
          from: "makes",
          localField: "inventorys.make",
          foreignField: "_id",
          as: "makes",
        },
      });
      query.push({
        $unwind: { path: "$makes", preserveNullAndEmptyArrays: true },
      });

      // * models
      query.push({
        $lookup: {
          from: "models",
          localField: "inventorys.model",
          foreignField: "_id",
          as: "models",
        },
      });
      query.push({
        $unwind: { path: "$models", preserveNullAndEmptyArrays: true },
      });

      // * exteriorcolors
      query.push({
        $lookup: {
          from: "exteriorcolors",
          localField: "inventorys.exteriorcolorId",
          foreignField: "_id",
          as: "exteriorcolors",
        },
      });
      query.push({
        $unwind: { path: "$exteriorcolors", preserveNullAndEmptyArrays: true },
      });

      // * users
      query.push({
        $lookup: {
          from: "users",
          localField: "sellerId",
          foreignField: "_id",
          as: "users",
        },
      });
      query.push({
        $unwind: { path: "$users", preserveNullAndEmptyArrays: true },
      });

      // * accountledgertemps
      query.push({
        $lookup: {
          from: "accountledgertemps",
          let: {
            payableNo: "$payableNo",
            balanceType: "$balanceType",
            payableStatus: "$payableStatus",
          },
          pipeline: [
            {
              $match: {
                $expr: {
                  $and: [
                    { $eq: ["$referenceNo", "$$payableNo"] },
                    { $eq: ["$payableStatus", "$$payableStatus"] },
                    {
                      $or: [
                        {
                          $and: [
                            { $eq: ["$transactionType", "cr"] },
                            { $eq: ["$payableType", "AP"] },
                          ],
                        },
                        {
                          $and: [
                            { $eq: ["$transactionType", "dr"] },
                            { $eq: ["$payableType", "AR"] },
                          ],
                        },
                      ],
                    },
                  ],
                },
              },
            },
          ],
          as: "accountLedgerTemp",
        },
      });
      query.push({
        $unwind: {
          path: "$accountLedgerTemp",
          preserveNullAndEmptyArrays: true,
        },
      });

      // * project
      query.push({
        $project: {
          carDetails: {
            name: "$makes.makeName",
            model: "$models.modelName",
            color: "$exteriorcolors.colorName",
            vinNo: "$inventorys.vin",
            year: "$inventorys.year",
            invoiceDate: "$createdAt",
          },
          inventoryId: "$inventoryId",
          sellerId: "$sellerId",
          sellerServiceOrderNumbers: 1,
          users: {
            userType: "$users.userType",
            name: "$users.name",
            address: "$users.address",
            phone: "$users.phone",
            TRN: "$users.companyDetails.trn",
            EID: "$users.eid",
            companyDetails: "$users.companyDetails",
          },
          branchs: {
            fullBranchName: "$branchs.fullbranchName",
            branchName: "$branchs.branchName",
            branchAddress: "$branchs.branchAddress",
            branchDesc: "$branchs.branchDesc",
            branchEmail: "$branchs.branchEmail",
            branchMobile: "$branchs.branchMobile",
            branchTRN: "$branchs.Trnno",
          },
          allCalculation: {
            totalPayable: "$totalPayable",
            totalReceivable: "$totalReceivable",
            status: "$status",
            paymentStatus: "$accountLedgerTemp.status",
            netPayable: "$netPayBalance",
          },
          invoice: {
            payableNo: "$payableNo",
            invoiceDate: "$createdAt",
            paymentMethod: "$paymentMethod",
          },
          glTempListId: "$accountLedgerTemp._id",
        },
      });

      const sQuery = [...query];
      query.push({ $sort: { createdAt: -1 } });
      sQuery.push({ $count: "recordCount" });

      if (postData.page) {
        query.push({
          $skip: cmethod.pageOffset(postData.page, postData.pageLimit),
        });
        query.push({ $limit: cmethod.pageLimit(postData.pageLimit) });
      }

      salerecieptDao.findSellerpaybaleAggregation(query).then(function (data) {
        salerecieptDao
          .findSellerpaybaleAggregation(sQuery)
          .then(async function (dcount) {
            let tptCnt = 0;
            if (dcount.length > 0) {
              tptCnt = dcount[0].recordCount;
            }

            try {
              const [
                {
                  inventoryId: [inventoryId],
                  sellerId,
                  sellerServiceOrderNumbers,
                },
              ] = data;

              const saleData = await processSellerData(
                inventoryId,
                sellerId,
                sellerServiceOrderNumbers
              );

              [data] = data;
              data.saleData = await saleData;

              res.status(200).json({
                status: true,
                result: data,
                message: "",
                hasMore: cmethod.hasMoreCount(
                  tptCnt,
                  postData.page,
                  postData.pageLimit
                ),
                totalCount: tptCnt,
              });
            } catch (error) {
              cmethod.returnSreverError(res, "No data found!", error);
            }
          })
          .catch((err) => {
            cmethod.returnSreverError(res, "Some technical issue", err);
          });
      });
    } catch (error) {
      logger.error(error);
    }
  }
);

router.post(
  "/accountpayableageingreport",
  [midleware.validateFieldValue([], [])],
  async (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;

    let query = [];

    // * sellerUsers
    query.push({
      $lookup: {
        from: "users",
        localField: "sellerId",
        foreignField: "_id",
        as: "sellerUsers",
      },
    });
    query.push({
      $unwind: { path: "$sellerUsers", preserveNullAndEmptyArrays: true },
    });

    // * inventory
    query.push({
      $lookup: {
        from: "inventorys",
        localField: "inventoryId",
        foreignField: "_id",
        as: "inventorys",
      },
    });
    query.push({
      $unwind: { path: "$inventorys", preserveNullAndEmptyArrays: true },
    });

    // * make
    query.push({
      $lookup: {
        from: "makes",
        localField: "inventorys.make",
        foreignField: "_id",
        as: "makes",
      },
    });
    query.push({
      $unwind: { path: "$makes", preserveNullAndEmptyArrays: true },
    });

    // * model
    query.push({
      $lookup: {
        from: "models",
        localField: "inventorys.model",
        foreignField: "_id",
        as: "models",
      },
    });
    query.push({
      $unwind: { path: "$models", preserveNullAndEmptyArrays: true },
    });

    // * seller services
    query.push({
      $lookup: {
        from: "sellerservices",
        let: {
          inventoryId: "$inventorys._id",
        },
        pipeline: [
          {
            $match: {
              $expr: {
                $and: [
                  { $eq: ["$inventoryId", "$$inventoryId"] },
                  { $eq: ["$serviceType", "sold"] },
                ],
              },
            },
          },
        ],
        as: "sellerservices",
      },
    });
    query.push({
      $unwind: { path: "$sellerservices", preserveNullAndEmptyArrays: true },
    });

    // * receipt
    query.push({
      $lookup: {
        from: "reciepts",
        localField: "inventorys._id",
        foreignField: "inventoryId",
        as: "receipts",
      },
    });
    query.push({
      $unwind: { path: "$receipts", preserveNullAndEmptyArrays: true },
    });

    // * buyerUsers
    query.push({
      $lookup: {
        from: "users",
        localField: "sellerservices.buyerId",
        foreignField: "_id",
        as: "buyerUsers",
      },
    });
    query.push({
      $unwind: { path: "$buyerUsers", preserveNullAndEmptyArrays: true },
    });

    // * account master
    query.push({
      $lookup: {
        from: "accountmasters",
        localField: "glAccountId",
        foreignField: "_id",
        as: "accountmasters",
      },
    });
    query.push({
      $unwind: { path: "$accountmasters", preserveNullAndEmptyArrays: true },
    });

    // * branch
    query.push({
      $lookup: {
        from: "branchs",
        localField: "branchId",
        foreignField: "_id",
        as: "branchs",
      },
    });
    query.push({
      $unwind: { path: "$branchs", preserveNullAndEmptyArrays: true },
    });

    // * interiorcolors
    query.push({
      $lookup: {
        from: "interiorcolors",
        localField: "inventorys.interiorcolorId",
        foreignField: "_id",
        as: "interiorcolors",
      },
    });
    query.push({
      $unwind: { path: "$interiorcolors", preserveNullAndEmptyArrays: true },
    });

    // * exteriorcolors
    query.push({
      $lookup: {
        from: "exteriorcolors",
        localField: "inventorys.exteriorcolorId",
        foreignField: "_id",
        as: "exteriorcolors",
      },
    });
    query.push({
      $unwind: { path: "$exteriorcolors", preserveNullAndEmptyArrays: true },
    });

    query.push({
      $project: {
        // payableNo: 1,
        // inventoryId: "$inventorys._id",
        makes: "$makes.makeName",
        models: "$models.modelName",
        year: "$inventorys.year",
        // lotNo: "$inventorys.lotNo",
        vinNo: "$inventorys.vin",
        // engineName: "$engines.engineName",
        // warehouseName: "$warehouses.warehouseName",
        interiorColor: "$interiorcolors.colorName",
        exteriorColor: "$exteriorcolors.colorName",
        // fuelTypeName: "$fueltypes.fueltypeName",
        // driveTypeName: "$drivetypes.drivetypeName",
        carDescription: {
          $concat: [
            "$inventorys.year",
            " ",
            "$makes.makeName",
            " ",
            "$models.modelName",
          ],
        },
        // sellerServices: {
        //   $filter: {
        //     input: "$sellerServices",
        //     as: "sellerServices",
        //     cond: { $eq: ["$$sellerServices.serviceType", "sold"] },
        //   },
        // },
        // gatePass: 1,
        // accountName: "$accountmasters.accountName",
        // accountNo: "$accountmasters.accountNo",
        refno: "$sellerservices.saleOrderNo",
        // buyerID: "$buyerUsers._id",
        // buyerId: "$buyerUsers.uniqueIdentifier",
        // buyerName: "$buyerUsers.name",
        sellerId: "$sellerUsers.uniqueIdentifier",
        sellerID: "$sellerUsers._id",
        sellerName: "$sellerUsers.name",
        // sellerEID: "$sellerUsers.eid",
        // sellerTRN: "$sellerUsers.companyDetails.trn",
        // sellerAddress: "$sellerUsers.address",
        branchId: "$branchs._id",
        branchName: "$branchs.branchName",
        receiptId: "$receipts._id",
        saleAmount: "$receipts.saleAmount",
        //paidAmount: "$receipts.paidAmount",
        dueBalance: "$receipts.dueBalance",
        // checkNo: 1,
        // checkDate: 1,
        // checkImg: 1,
        // totalPayable: 1,
        // totalReceivable: 1,
        // netPayBalance: 1,
        // status: 1,
        // serviceType: "$sellerservices.serviceType",
        // serviceStatus: "$sellerservices.serviceStatus",
        // balanceType: 1,
        // paymentMethod: 1,
        // transactionDate: 1,
        // createdAt: 1,
        // description: "$status",
        // invoiceDate: "$createdAt",
      },
    });

    query.push({ $sort: { createdAt: -1 } });
    const sQuery = [...query];

    sQuery.push({ $count: "recordCount" });

    if (postData.page) {
      query.push({
        $skip: cmethod.pageOffset(postData.page, postData.pageLimit),
      });
      query.push({ $limit: cmethod.pageLimit(postData.pageLimit) });
    }

    salerecieptDao
      .findSellerpaybaleAggregation(query)
      .then(function (data) {
        salerecieptDao
          .findSellerpaybaleAggregation(sQuery)
          .then(async function (dcount) {
            let tptCnt = 0;
            if (dcount.length > 0) {
              tptCnt = dcount[0].recordCount;
            }
            res.status(200).json({
              status: true,
              result: data,
              message: "",
              hasMore: cmethod.hasMoreCount(
                tptCnt,
                postData.page,
                postData.pageLimit
              ),
              totalCount: tptCnt,
            });
          })
          .catch((err) => {
            cmethod.returnSreverError(res, message[lang].technicalError, err);
          });
      })
      .catch((err) => {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      });
  }
);
router.post(
  "/accountreceivableageingreport",
  [midleware.validateFieldValue([], [])],
  async (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;

    let query = [];

    // * sellerUsers
    query.push({
      $lookup: {
        from: "users",
        localField: "sellerId",
        foreignField: "_id",
        as: "sellerUsers",
      },
    });
    query.push({
      $unwind: { path: "$sellerUsers", preserveNullAndEmptyArrays: true },
    });

    // * inventory
    query.push({
      $lookup: {
        from: "inventorys",
        localField: "inventoryId",
        foreignField: "_id",
        as: "inventorys",
      },
    });
    query.push({
      $unwind: { path: "$inventorys", preserveNullAndEmptyArrays: true },
    });

    // * make
    query.push({
      $lookup: {
        from: "makes",
        localField: "inventorys.make",
        foreignField: "_id",
        as: "makes",
      },
    });
    query.push({
      $unwind: { path: "$makes", preserveNullAndEmptyArrays: true },
    });

    // * model
    query.push({
      $lookup: {
        from: "models",
        localField: "inventorys.model",
        foreignField: "_id",
        as: "models",
      },
    });
    query.push({
      $unwind: { path: "$models", preserveNullAndEmptyArrays: true },
    });

    // * seller services
    query.push({
      $lookup: {
        from: "sellerservices",
        let: {
          inventoryId: "$inventorys._id",
        },
        pipeline: [
          {
            $match: {
              $expr: {
                $and: [
                  { $eq: ["$inventoryId", "$$inventoryId"] },
                  { $eq: ["$serviceType", "sold"] },
                ],
              },
            },
          },
        ],
        as: "sellerservices",
      },
    });
    query.push({
      $unwind: { path: "$sellerservices", preserveNullAndEmptyArrays: true },
    });

    // * receipt
    query.push({
      $lookup: {
        from: "reciepts",
        localField: "inventorys._id",
        foreignField: "inventoryId",
        as: "receipts",
      },
    });
    query.push({
      $unwind: { path: "$receipts", preserveNullAndEmptyArrays: true },
    });

    // * buyerUsers
    query.push({
      $lookup: {
        from: "users",
        localField: "sellerservices.buyerId",
        foreignField: "_id",
        as: "buyerUsers",
      },
    });
    query.push({
      $unwind: { path: "$buyerUsers", preserveNullAndEmptyArrays: true },
    });

    // * account master
    query.push({
      $lookup: {
        from: "accountmasters",
        localField: "glAccountId",
        foreignField: "_id",
        as: "accountmasters",
      },
    });
    query.push({
      $unwind: { path: "$accountmasters", preserveNullAndEmptyArrays: true },
    });

    // * branch
    query.push({
      $lookup: {
        from: "branchs",
        localField: "branchId",
        foreignField: "_id",
        as: "branchs",
      },
    });
    query.push({
      $unwind: { path: "$branchs", preserveNullAndEmptyArrays: true },
    });

    // * interiorcolors
    query.push({
      $lookup: {
        from: "interiorcolors",
        localField: "inventorys.interiorcolorId",
        foreignField: "_id",
        as: "interiorcolors",
      },
    });
    query.push({
      $unwind: { path: "$interiorcolors", preserveNullAndEmptyArrays: true },
    });

    // * exteriorcolors
    query.push({
      $lookup: {
        from: "exteriorcolors",
        localField: "inventorys.exteriorcolorId",
        foreignField: "_id",
        as: "exteriorcolors",
      },
    });
    query.push({
      $unwind: { path: "$exteriorcolors", preserveNullAndEmptyArrays: true },
    });

    query.push({
      $project: {
        makes: "$makes.makeName",
        models: "$models.modelName",
        year: "$inventorys.year",
        vinNo: "$inventorys.vin",
        interiorColor: "$interiorcolors.colorName",
        exteriorColor: "$exteriorcolors.colorName",
        carDescription: {
          $concat: [
            "$inventorys.year",
            " ",
            "$makes.makeName",
            " ",
            "$models.modelName",
          ],
        },
        refno: "$sellerservices.saleOrderNo",
        buyerID: "$buyerUsers._id",
        buyerId: "$buyerUsers.uniqueIdentifier",
        buyerName: "$buyerUsers.name",
        branchId: "$branchs._id",
        branchName: "$branchs.branchName",
        receiptId: "$receipts._id",
        saleAmount: "$receipts.saleAmount",
        dueBalance: "$receipts.dueBalance",
        netPayBalance: 1,
        invoiceDate: "$createdAt",
      },
    });

    query.push({ $sort: { createdAt: -1 } });
    const sQuery = [...query];

    sQuery.push({ $count: "recordCount" });

    if (postData.page) {
      query.push({
        $skip: cmethod.pageOffset(postData.page, postData.pageLimit),
      });
      query.push({ $limit: cmethod.pageLimit(postData.pageLimit) });
    }

    salerecieptDao
      .findSellerpaybaleAggregation(query)
      .then(function (data) {
        salerecieptDao
          .findSellerpaybaleAggregation(sQuery)
          .then(async function (dcount) {
            let tptCnt = 0;
            if (dcount.length > 0) {
              tptCnt = dcount[0].recordCount;
            }
            res.status(200).json({
              status: true,
              result: data,
              message: "",
              hasMore: cmethod.hasMoreCount(
                tptCnt,
                postData.page,
                postData.pageLimit
              ),
              totalCount: tptCnt,
            });
          })
          .catch((err) => {
            cmethod.returnSreverError(res, message[lang].technicalError, err);
          });
      })
      .catch((err) => {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      });
  }
);

// * get-seller-cheque
router.post(
  "/get-seller-cheque",
  [midleware.validateFieldValue([], [])],
  async (req, res) => {
    const {
      body,
      headers: { lang = config.lang },
    } = req;

    const query = [];

    try {
      ExactMatch(query, "paymentMethod", "cheque");

      if (body.chequeClearStatus) {
        ExactMatch(query, "chequeClearStatus", body.chequeClearStatus);
      }

      if (body.chequeApprovedBy) {
        ExactMatch(query, "chequeApprovedBy", body.chequeApprovedBy);
      }

      if (body.chequeRejectedBy) {
        ExactMatch(query, "chequeRejectedBy", body.chequeRejectedBy);
      }

      if (body.payableNo) {
        ExactMatch(query, "payableNo", body.payableNo);
      }

      if (body.checkNo) {
        ExactMatch(query, "checkNo", Number(body.checkNo));
      }

      if (body.status) {
        ExactMatch(query, "status", body.status);
      }

      if (body.balanceType) {
        ExactMatch(query, "balanceType", body.balanceType);
      }

      if (body.payableStatus) {
        ExactMatch(query, "payableStatus", body.payableStatus);
      }

      if (body.createdBy) {
        ExactMatch(query, "createdBy", body.createdBy);
      }

      if (body.sellerId) {
        IDMatch(query, "sellerId", body.sellerId);
      }

      if (body.branchId) {
        IDMatch(query, "branchId", body.branchId);
      }

      if (body.inventoryId) {
        IDMatch(query, "inventoryId", body.inventoryId);
      }

      if (checkBoolean(body.checkDate) && body.startDate && body.endDate) {
        DateMatch(query, "checkDate", body.startDate, body.endDate);
      }

      if (
        checkBoolean(body.transactionDate) &&
        body.startDate &&
        body.endDate
      ) {
        DateMatch(query, "transactionDate", body.startDate, body.endDate);
      }

      if (
        checkBoolean(body.chequeApprovedDate) &&
        body.startDate &&
        body.endDate
      ) {
        DateMatch(query, "chequeApprovedDate", body.startDate, body.endDate);
      }

      if (
        checkBoolean(body.chequeRejectedDate) &&
        body.startDate &&
        body.endDate
      ) {
        DateMatch(query, "chequeRejectedDate", body.startDate, body.endDate);
      }

      // * project
      query.push({
        $project: {
          _id: 1,
          payableNo: 1,
          paymentMethod: 1,
          transactionDate: 1,
          checkNo: 1,
          checkImg: 1,
          checkDate: 1,
          netPayBalance: 1,
          createdBy: 1,
          status: 1,
          payableRemarks: 1,
          createdAt: 1,
          chequeClearStatus: 1,
          chequeApprovedBy: 1,
          chequeRejectedBy: 1,
          chequeApprovedRemarks: 1,
          chequeRejectedRemarks: 1,
          chequeApprovedDate: 1,
          chequeRejectedDate: 1,
        },
      });

      // * sort
      query.push({ $sort: config.defaultSort });

      // * count
      const sQuery = [...query];
      sQuery.push({ $count: "totalCount" });

      // * pagination
      if (body.page) {
        query.push({
          $skip: cmethod.pageOffset(body.page, body.pageLimit),
        });
        query.push({ $limit: cmethod.pageLimit(body.pageLimit) });
      }

      // * results
      const results = saleRecieptModal.SellerPayable.aggregate(query);
      const count = saleRecieptModal.SellerPayable.aggregate(sQuery);

      const [result, [{ totalCount } = {}] = []] = await Promise.all([
        results,
        count,
      ]);

      res.status(200).json({
        status: true,
        result,
        message: "",
        hasMore: cmethod.hasMoreCount(totalCount, body.page, body.pageLimit),
        totalCount,
      });
    } catch (error) {
      logger.error(error);
      cmethod.returnSreverError(res, message[lang].technicalError, error);
    }
  }
);

module.exports = router;

/**
 * @swagger
 * /api/salereciept/add:
 *   post:
 *     tags: [Saler Reciept]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: salerId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: buyerId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: inventoryId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: recieptId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: saleAmount
 *         in: formData
 *         type: number
 *         required: true
 *         description:
 *       - name: paybleAmount
 *         in: formData
 *         type: number
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: Reciepts.
 *
 */
/**
 * @swagger
 * /api/salereciept/update:
 *   patch:
 *     tags: [Saler Reciept]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: salerecieptId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: updateType
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *          update type=status else blank
 *       - name: paidAmount
 *         in: formData
 *         type: number
 *         required: false
 *         description:
 *       - name: paymentMethod
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: checkNo
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: checkImg
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: status
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *     responses:
 *       200:
 *         description: Reciepts.
 *
 */

/**
 * @swagger
 * /api/salereciept/list:
 *   post:
 *     tags: [Saler Reciept]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: salerecieptId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: search
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *            ex-vin,saleRecieptNo
 *       - name: status
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *          ex- 1,2,3,4
 *       - name: pageLimit
 *         in: formData
 *         type: number
 *         required: true
 *         description:
 *       - name: page
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: Reciepts.
 *
 */
/**
 * @swagger
 * /api/salereciept/servicechargelist:
 *   post:
 *     tags: [Saler Reciept]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: servicechargeId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: serviceType[]
 *         in: formData
 *         type: array
 *         items:
 *           type: string
 *         collectionFormat: multi
 *         required: false
 *         description:
 *       - name: sellerId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: serviceStatus
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: saleOrderNo
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: vinNo
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: inventoryCreatedBy
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: fromDate
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: toDate
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: pageLimit
 *         in: formData
 *         type: number
 *         required: false
 *         description:
 *       - name: page
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *     responses:
 *       200:
 *         description: servicechargelist.
 *
 */
/**
 * @swagger
 * /api/salereciept/servicechargeupdate:
 *   patch:
 *     tags: [Saler Reciept]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: servicechargeId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: status
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *     responses:
 *       200:
 *         description: servicechargeupdate.
 *
 */
/**
 * @swagger
 * /api/salereciept/addpaybale:
 *   post:
 *     tags: [Saler Reciept]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: sellerId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: branchId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: inventoryId[]
 *         in: formData
 *         type: array
 *         items:
 *           type: string
 *         required: true
 *         description:
 *       - name: totalPayable
 *         in: formData
 *         type: number
 *         required: true
 *         description:
 *       - name: totalReceivable
 *         in: formData
 *         type: number
 *         required: true
 *         description:
 *       - name: netPayBalance
 *         in: formData
 *         type: number
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: addpaybale.
 *
 */
/**
 * @swagger
 * /api/salereciept/getsellerpayablelist:
 *   post:
 *     tags: [Saler Reciept]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: sellerpayableId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: vinNo
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: branchId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: pageLimit
 *         in: formData
 *         type: number
 *         required: true
 *         description:
 *       - name: page
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: getsellerpayablelist.
 *
 */
/**
 * @swagger
 * /api/salereciept/sellerpaybalelist:
 *   post:
 *     tags: [Saler Reciept]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: sellerpaybaleId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: sellerId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: branchId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: vinNo
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: balanceType
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: status
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: serviceStatus
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: payableNo
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: groupByInventory
 *         in: formData
 *         type: boolean
 *         required: false
 *         description:
 *       - name: paymentMethod
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: pageLimit
 *         in: formData
 *         type: number
 *         required: false
 *         description:
 *       - name: page
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *     responses:
 *       200:
 *         description: sellerpaybalelist.
 *
 */
/**
 * @swagger
 * /api/salereciept/sellerpaybaleupdate:
 *   patch:
 *     tags: [Saler Reciept]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: sellerpaybaleId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: glAccountId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: transactionDate
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: paidAmount
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: paymentMethod
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: chequeClearStatus
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: status
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *     responses:
 *       200:
 *         description: sellerpaybaleupdate.
 *
 */

/**
 * @swagger
 * /api/salereciept/delete:
 *   delete:
 *     tags: [Saler Reciept]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: deleteId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: salerpayble delete.
 *
 */

/**
 * @swagger
 * /api/salereciept/get-invoice:
 *   post:
 *     tags: [Saler Reciept]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: payableId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: balanceType
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *     responses:
 *       200:
 *         description: Invoices.
 *
 */

/**
 * @swagger
 * /api/salereciept/seller-payable-history:
 *   post:
 *     tags: [Saler Reciept]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: payableId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: pretty
 *         in: formData
 *         type: boolean
 *         required: false
 *         description:
 *     responses:
 *       200:
 *         description: Seller Payable Inventory History
 *
 */
/**
 * @swagger
 * /api/salereciept/accountpayableageingreport:
 *   post:
 *     tags: [Saler Reciept]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: pageLimit
 *         in: formData
 *         type: number
 *         required: false
 *         description:
 *       - name: page
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *     responses:
 *       200:
 *         description: accountpayableageingreport.
 *
 */

/**
 * @swagger
 * /api/salereciept/get-seller-cheque:
 *   post:
 *     tags: [Saler Reciept]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: checkNo
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: payableNo
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: status
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: balanceType
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: payableStatus
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: createdBy
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: sellerId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: branchId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: checkDate
 *         in: formData
 *         type: boolean
 *         required: false
 *         description:
 *       - name: startDate
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: endDate
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: pageLimit
 *         in: formData
 *         type: number
 *         required: false
 *         description:
 *       - name: page
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *     responses:
 *       200:
 *         description: Seller Receipt - Cheque
 *
 */
