const carModal = require("../car/carModal");
const vinModal = require("../vin/vinModal");
const message  =   require("../../config/message");
const cmethod   =   require("../../middleware/common-fun");


const carAdd = async function (res, postData) {
    const newCar = new carModal.Car(postData);    
        
    newCar.save(postData, async function (err, data) {
      if (err) { 
        cmethod.returnSreverError(res, message.technicalError, err);
      } else {      
        
          let allImages   = postData.images;
          if(allImages.length>0){
            let insertImages=[];
            allImages.forEach((value,index) => {
              insertImages.push({
                imageType:"car",
                referenceId:data._id,
                image:value
              })
            });

            await vinModal.Vinimage.insertMany(insertImages);
          }
        cmethod.returnSuccess(res, data, false, message.signupsuccess); 
      }
    });
    };
    
    const findCarWithFiled = async function (query) { 
        return new Promise(function (resolve, reject) {
          carModal.Car.find({ _id: { '$exists': true } },{vin:1},function (err, data) {
            if (err) { 
              reject(err);
            } else {
              resolve(data);
            }
          });
        });
      };
      const findCarAggregation = function (query) {
        return new Promise(function (resolve, reject) {
          carModal.Car.aggregate(query, function (err, data) {
            if (err) {
              reject(err);
            } else {
              resolve(data);
            }
          });
        });
      };

      module.exports={
        carAdd,
        findCarWithFiled,
        findCarAggregation
      }