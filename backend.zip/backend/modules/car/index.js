const express = require("express");
const router = express.Router();
const carModal = require("../car/carModal");
const message = require("../../config/message");
const config = require("../../config");
const midleware = require("../../middleware/validation");
const cmethod = require("../../middleware/common-fun");
 const carDao = require("./carDao");
var mongoose = require("mongoose");


router.post("/add",
[
    midleware.validateFieldValue(
        ["salesUserId","salerId","vin","make","model","specification","year","color","mileage","vccDoc","purchaseDoc"],
        ["salesUserId","salerId","vin","make","model","specification","year","color","mileage","vccDoc","purchaseDoc"],
    )
],
(req,res)=>{
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;

    // console.log("washi");
    carDao.carAdd(res,postData);
});

// update User

router.patch(
    "/update",
    [midleware.validateFieldValue(["carId"], ["carId"])],
    (req, res) => {
      let postData = req.body;
      let lang = req.headers["lang"] || config.lang;
      let xtoken = req.headers["x-access-token"];
      //{ token: xtoken },
      let queryCond = {
        $and: [
          { _id: mongoose.Types.ObjectId(postData.carId) },        
        ],
      };
      delete postData.carId;
      //console.log("=======================>",req.body)
      carModal.Car.findOneAndUpdate(
        queryCond,
        { $set: postData },
        { new: true },
        async function (err, data) {
        //   console.log("user->", data);
          if (err) {
            cmethod.returnSreverError(res, message[lang].technicalError, err);
          } else {
  
            cmethod.returnSuccess(
              res,
              data,
              false,
              message[lang].profileUpdate
            );
          }
        }
      );
    }
  );
  router.post("/list",
  [
      midleware.validateFieldValue(
          ["pageLimit", "page","search","carId"],
          ["page"]
      )
  ],
  (req,res)=>{
      let postData = req.body;
      let lang = req.headers["lang"] || config.lang;
      let query = [];

          query.push({
            $lookup: {
              from: "users",
              localField: "salerId",
              foreignField: "_id",
              as: "sellers",
            },
          });
          query.push({
            $unwind: { path: "$sellers", preserveNullAndEmptyArrays: true },
          });
          query.push({
            $lookup: {
              from: "users",
              localField: "salesUserId",
              foreignField: "_id",
              as: "salesPersons",
            },
          });
          query.push({
            $unwind: { path: "$salesPersons", preserveNullAndEmptyArrays: true },
          });
          if(postData.search){  
              query.push(              
                { 
                  $match: {
                    $and: [
                      {
                        $or: [
                          { make: { $regex: postData.search, $options: "i" } },
                          { model: { $regex: postData.search, $options: "i" } },
                          { vin: { $regex: postData.search, $options: "i" } },
                        ],
                      },
                    ],
                  }, 
                });
          }
          if(postData.carId){
              query.push({
                  $match:{
                      $and:[
                          {'_id':mongoose.Types.ObjectId(postData.carId)},
                      ]
                  }
              });

              query.push({
                $lookup: {
                  from: "vinimages",
                  // localField: "salesUserId",
                  // foreignField: "_id",
                  let :{
                    carId:"$_id",
                    imageType:"car"
                  },
                  pipeline: [
                    {
                      $match: {
                        $expr: {
                          $and: [
                            { $eq: ["$imageType", "$$imageType"] },
                            { $eq: ["$referenceId", "$$carId"] },
                          ],
                        },
                      },
                    },
                  ],
                  as: "vinimages",
                },
              }); 
          } 
          const sQuery = [...query];
          query.push({
              $project: {
                salesPersons:1,
                sellers:1,
                vinimages:1,
                vin:1,
                make:1,
                model:1,
                specification:1,
                year:1,
                color:1,
                mileage:1,
                vccDoc:1,
                purchaseDoc:1,
                planPrice:1,
                reservePrice:1,
                rejectedMsg:1,
                status:1,
                createdAt:1      
              },   
            }); 
       
            query.push({ $sort: { createdAt: -1 } });
            sQuery.push({ $count: "recordCount" });
      
            if (postData.page) {
              query.push({
                $skip: cmethod.pageOffset(postData.page, postData.pageLimit),
              });
              query.push({ $limit: cmethod.pageLimit(postData.pageLimit) });
            }
            
            carDao.findCarAggregation(query)
              .then(function(data){
                  carDao.findCarAggregation(sQuery)
                  .then(async function(dcount){
                      let tptCnt = 0;
                      if(dcount.length>0){
                          tptCnt=dcount[0].recordCount;
                      }
                      res.status(200).json({
                          status: true,
                          result: data,
                          message: "",
                          hasMore: cmethod.hasMoreCount(
                            tptCnt,
                            postData.page,
                            postData.pageLimit
                          ),
                          totalCount: tptCnt
                        });
                  })
                  .catch((err) => { 
                      cmethod.returnSreverError(res, message[lang].technicalError, err);
                    });
              })
              .catch((err) => { 
                  cmethod.returnSreverError(res, message[lang].technicalError, err);
                });  
  }); 
module.exports=router;