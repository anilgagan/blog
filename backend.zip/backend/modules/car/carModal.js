const { number } = require('@hapi/joi');
const mongoose = require("mongoose");
const Schema    =   mongoose.Schema;
const { connWrite } = require("../../config/database");

const carSchema =   new Schema(
    {
        salesUserId:
        {
            type:mongoose.Types.ObjectId,
            default:mongoose.Types.ObjectId(),
            index:true
        },
        salerId:
        {
            type:mongoose.Types.ObjectId,
            default:mongoose.Types.ObjectId(),
            index:true
        },
        vin:String,
        make:String,
        model:String,
        specification:String,
        year:String,
        color:String,
        mileage:String,
        planPrice:Number,
        reservePrice:Number,
        rejectedMsg:String,
        vccDoc:String,
        purchaseDoc:String,
        status: { type: Number, default: 0 },


    },
    {
        timestamps: {
          createdAt: "createdAt", 
          updatedAt: "updatedAt",
        },
    }
);

const Car = connWrite.model("cars",carSchema);


module.exports={
    Car
}