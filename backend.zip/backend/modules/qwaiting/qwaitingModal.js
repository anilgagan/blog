const { number } = require("@hapi/joi");
const mongoose = require("mongoose");
const Schema = mongoose.Schema;
const { connWrite } = require("../../config/database");

const departmentSchema = new Schema(
    {
      parentId: {
        type: mongoose.Types.ObjectId,
        default: null,
        index: true,
      },
      branchId: {
        type: mongoose.Types.ObjectId,
        default: null,
        index: true,
      },
      department: String,
      prefix:String,
      status: { type: Number, default: 0 },
    },
    {
      timestamps: {
        createdAt: "createdAt",
        updatedAt: "updatedAt",
      },
    }
  );

  const counterSchema = new Schema(
    {
      counterName: String,
      status: { type: Number, default: 0 },
    },
    {
      timestamps: {
        createdAt: "createdAt",
        updatedAt: "updatedAt",
      },
    }
  );
  const departCounterMappSchema = new Schema(
    {
      departmentId: 
      {
        type: mongoose.Types.ObjectId,
        default: null,
        index: true,
      },
      branchId: 
      {
        type: mongoose.Types.ObjectId,
        default: null,
        index: true,
      },
      counterId: 
      {
        type: mongoose.Types.ObjectId,
        default: null,
        index: true,
      },
      status: { type: Number, default: 0 },
    },
    {
      timestamps: {
        createdAt: "createdAt",
        updatedAt: "updatedAt",
      },
    }
  );

  const counterTokenSchema = new Schema(
    {
      departmentId: 
      {
        type: mongoose.Types.ObjectId,
        default: null,
        index: true,
      },
      branchId: 
      {
        type: mongoose.Types.ObjectId,
        default: null,
        index: true,
      },
      tokenNo: 
      {
        type: String,
        default: '',
        index: true,
      },
      mappingCounterId: 
      {
        type: mongoose.Types.ObjectId,
        default: null,
        index: true,
      },
      queueStatus:{ type: Number, default: 0 }, //0=default,1=in counter,2=done
      status: { type: Number, default: 0 }, 
      call: { type: Number, default: 0 },//0=default,1=voice run
      startTime: { type: Date },
      endTime: { type: Date },
      serveTime:{ type: Number, default: 0 },
      tokenTime:{type:Date,default:Date.now()}
    },
    {
      timestamps: {
        createdAt: "createdAt",
        updatedAt: "updatedAt",
      },
    }
  );
  const Department = connWrite.model("departments", departmentSchema);
  const Counter = connWrite.model("counters", counterSchema);
  const Departcountermapp = connWrite.model("departcountermapps", departCounterMappSchema);
  const Countertoken = connWrite.model("countertokens", counterTokenSchema);

module.exports = {
    Department,
    Counter,
    Departcountermapp,
    Countertoken
};