const express = require("express");
const router = express.Router();
const qwaitingModal = require("../qwaiting/qwaitingModal");
const message = require("../../config/message");
const config = require("../../config");
const midleware = require("../../middleware/validation");
const cmethod = require("../../middleware/common-fun");
const qwaitingDao = require("./qwaitingDao");
var mongoose = require("mongoose");


router.post(
  "/departmentAdd",
  [
    midleware.validateFieldValue(
      ["department", "status"],
      ["department", "status"]
    ),
  ],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;

    let chkDepartmentName = {
      $and: [{ department: postData.department.toLowerCase() }],
    };
    qwaitingDao.checkDepartmentName(chkDepartmentName).then(function (status) {
      if (status == true) {
        cmethod.returnSreverError(res, message[lang].docExist);
      } else {
        qwaitingDao.departmentAdd(res, postData);
      }
    })

  }
);

// update User

router.patch(
  "/departmentUpdate",
  [midleware.validateFieldValue(["departmentId"], ["departmentId"])],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let xtoken = req.headers["x-access-token"];
    //{ token: xtoken },
    let queryCond = {
      $and: [{ _id: mongoose.Types.ObjectId(postData.departmentId) }],
    };
    delete postData.departmentId;
    //console.log("=======================>", req.body);
    qwaitingModal.Department.findOneAndUpdate(
      queryCond,
      { $set: postData },
      { new: true },
      async function (err, data) {
        if (err) {
          cmethod.returnSreverError(res, message[lang].technicalError, err);
        } else {
          cmethod.returnSuccess(res, data, false, message[lang].profileUpdate);
        }
      }
    );
  }
);
router.post(
  "/departmentList",
  [midleware.validateFieldValue(["pageLimit", "page"], ["page"])],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let query = [];

    if (postData.branchId) {
      query.push({
        $match: {
          branchId: mongoose.Types.ObjectId(postData.branchId),
        },
      });
    }
    query.push({
      $lookup: {
        from: "branchs",
        localField: "branchId",
        foreignField: "_id",
        as: "branchs",
      },
    });
    query.push({
      $unwind: { path: "$branchs", preserveNullAndEmptyArrays: true },
    });
    query.push({
      $lookup: {
        from: "departments",
        localField: "parentId",
        foreignField: "_id",
        as: "parents",
      },
    });
    query.push({
      $unwind: { path: "$parents", preserveNullAndEmptyArrays: true },
    });

    if (postData?.parentId) {
      query.push({
        $match: {
          $and: [{ parentId: mongoose.Types.ObjectId(postData?.parentId) }]
        }
      })
    }
    if (postData?.type) {
      if (postData.type == 'child') {
        query.push({
          $match: {
            $and: [{ parentId: { $ne: null } }]
          }
        });
      } else {
        query.push({
          $match: {
            $and: [{ parentId: null }]
          }
        });
      }

    }
    query.push({
      $project: {
        branchId: "$branchs._id",
        branchName: "$branchs.branchName",
        department: 1,
        prefix: 1,
        status: 1,
        parentId: 1,
        parentName: "$parents.department",
        createdAt: 1
      },
    });
    const sQuery = [...query];
    query.push({ $sort: { createdAt: -1 } });
    sQuery.push({ $count: "recordCount" });

    if (postData.page) {
      query.push({
        $skip: cmethod.pageOffset(postData.page, postData.pageLimit),
      });
      query.push({ $limit: cmethod.pageLimit(postData.pageLimit) });
    }

    qwaitingDao
      .findDepartmentAggregation(query)
      .then(function (data) {
        qwaitingDao
          .findDepartmentAggregation(sQuery)
          .then(async function (dcount) {
            let tptCnt = 0;
            if (dcount.length > 0) {
              tptCnt = dcount[0].recordCount;
            }
            res.status(200).json({
              status: true,
              result: data,
              message: "",
              hasMore: cmethod.hasMoreCount(
                tptCnt,
                postData.page,
                postData.pageLimit
              ),
              totalCount: tptCnt,
            });
          })
          .catch((err) => {
            cmethod.returnSreverError(res, message[lang].technicalError, err);
          });
      })
      .catch((err) => {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      });
  }
);

router.delete(
  "/departmentDelete",
  [midleware.validateFieldValue(["deleteId"], ["deleteId"])],
  async (req, res) => {
    let postData = req.body;
    let cond = { _id: mongoose.Types.ObjectId(postData.deleteId) };
    let lang = req.headers["lang"] || config.lang;

    qwaitingModal.Department.deleteOne(cond, postData)
      .then(async (data) => {
        //delete sub menu access
        let cond2 = { parentId: mongoose.Types.ObjectId(postData.deleteId) };
        qwaitingModal.Department.deleteOne(cond2, postData);

        cmethod.returnSuccess(res, [], false, message[lang].Deleteed);
      })
      .catch((err) => {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      });
  }
);

//conter task
router.post(
  "/counterAdd",
  [
    midleware.validateFieldValue(
      ["counterName", "status"],
      ["counterName", "status"]
    ),
  ],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;

    let chkCounterName = {
      $and: [{ counterName: postData.counterName.toLowerCase() }, { counterName: postData.counterName.toUpperCase() }],
    };
    qwaitingDao.checkCounterName(chkCounterName).then(function (status) {
      if (status == true) {
        cmethod.returnSreverError(res, message[lang].docExist);
      } else {
        qwaitingDao.counterAdd(res, postData);
      }
    })

  }
);

// update User

router.patch(
  "/counterUpdate",
  [midleware.validateFieldValue(["counterId"], ["counterId"])],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let xtoken = req.headers["x-access-token"];
    //{ token: xtoken },
    let queryCond = {
      $and: [{ _id: mongoose.Types.ObjectId(postData.counterId) }],
    };
    delete postData.counterId;
    //console.log("=======================>", req.body);
    qwaitingModal.Counter.findOneAndUpdate(
      queryCond,
      { $set: postData },
      { new: true },
      async function (err, data) {
        if (err) {
          cmethod.returnSreverError(res, message[lang].technicalError, err);
        } else {
          cmethod.returnSuccess(res, data, false, message[lang].profileUpdate);
        }
      }
    );
  }
);
router.post(
  "/counterList",
  [midleware.validateFieldValue(["pageLimit", "page"], ["page"])],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let query = [];

    if (postData?.counterName) {
      query.push({
        $match: {
          $and: [{ counterName: postData?.counterName }]
        }
      })
    }
    query.push({
      $project: {
        counterName: 1,
        status: 1,
        createdAt: 1
      },
    });
    const sQuery = [...query];
    query.push({ $sort: { createdAt: -1 } });
    sQuery.push({ $count: "recordCount" });

    if (postData.page) {
      query.push({
        $skip: cmethod.pageOffset(postData.page, postData.pageLimit),
      });
      query.push({ $limit: cmethod.pageLimit(postData.pageLimit) });
    }

    qwaitingDao
      .findCounterAggregation(query)
      .then(function (data) {
        qwaitingDao
          .findCounterAggregation(sQuery)
          .then(async function (dcount) {
            let tptCnt = 0;
            if (dcount.length > 0) {
              tptCnt = dcount[0].recordCount;
            }
            res.status(200).json({
              status: true,
              result: data,
              message: "",
              hasMore: cmethod.hasMoreCount(
                tptCnt,
                postData.page,
                postData.pageLimit
              ),
              totalCount: tptCnt,
            });
          })
          .catch((err) => {
            cmethod.returnSreverError(res, message[lang].technicalError, err);
          });
      })
      .catch((err) => {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      });
  }
);
router.delete(
  "/counterDelete",
  [midleware.validateFieldValue(["deleteId"], ["deleteId"])],
  async (req, res) => {
    let postData = req.body;
    let cond = { _id: mongoose.Types.ObjectId(postData.deleteId) };
    let lang = req.headers["lang"] || config.lang;

    qwaitingModal.Counter.deleteOne(cond, postData)
      .then(async (data) => {
        //delete sub menu access
        let cond2 = { parentId: mongoose.Types.ObjectId(postData.deleteId) };
        qwaitingModal.Counter.deleteOne(cond2, postData);

        cmethod.returnSuccess(res, [], false, message[lang].Deleteed);
      })
      .catch((err) => {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      });
  }
);
//department conter mapping task
router.post(
  "/counterMappingAdd",
  [
    midleware.validateFieldValue(
      ["departmentId", "counterId", "status"],
      ["departmentId", "counterId", "status"]
    ),
  ],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;

    let chkCounterMapp = {
      $and: [{ departmentId: postData.departmentId }, { counterId: postData.counterId }],
    };
    qwaitingDao.checkDepartcounterMapp(chkCounterMapp).then(function (status) {
      if (status == true) {
        cmethod.returnSreverError(res, message[lang].docExist);
      } else {
        qwaitingDao.deptCounterMappAdd(res, postData);
      }
    })

  }
);

router.patch(
  "/counterMappUpdate",
  [midleware.validateFieldValue(["mappingId"], ["mappingId"])],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let xtoken = req.headers["x-access-token"];
    //{ token: xtoken },
    let queryCond = {
      $and: [{ _id: mongoose.Types.ObjectId(postData.mappingId) }],
    };
    delete postData.mappingId;
    //console.log("=======================>", req.body);
    qwaitingModal.Departcountermapp.findOneAndUpdate(
      queryCond,
      { $set: postData },
      { new: true },
      async function (err, data) {
        if (err) {
          cmethod.returnSreverError(res, message[lang].technicalError, err);
        } else {
          cmethod.returnSuccess(res, data, false, message[lang].profileUpdate);
        }
      }
    );
  }
);
router.post(
  "/mappingList",
  [midleware.validateFieldValue(["pageLimit", "page"], ["page"])],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let query = [];
    query.push({
      $lookup: {
        from: "departments",
        localField: "departmentId",
        foreignField: "_id",
        as: "departments",
      },
    });
    query.push({
      $unwind: { path: "$departments", preserveNullAndEmptyArrays: true },
    });

    query.push({
      $lookup: {
        from: "counters",
        localField: "counterId",
        foreignField: "_id",
        as: "counters",
      },
    });
    query.push({
      $unwind: { path: "$counters", preserveNullAndEmptyArrays: true },
    });

    if (postData?.departmentId) {
      query.push({
        $match: {
          $and: [{ departmentId: mongoose.Types.ObjectId(postData?.departmentId) }]
        }
      })
    }
    if (postData?.counterId) {
      query.push({
        $match: {
          $and: [{ counterId: mongoose.Types.ObjectId(postData?.counterId) }]
        }
      })
    }
    query.push({
      $project: {
        departmentId: 1,
        counterId: 1,
        department: "$departments.department",
        counterName: "$counters.counterName",
        status: 1,
        createdAt: 1
      },
    });
    const sQuery = [...query];
    query.push({ $sort: { createdAt: -1 } });
    sQuery.push({ $count: "recordCount" });

    if (postData.page) {
      query.push({
        $skip: cmethod.pageOffset(postData.page, postData.pageLimit),
      });
      query.push({ $limit: cmethod.pageLimit(postData.pageLimit) });
    }

    qwaitingDao
      .findDepartcounterMappAggregation(query)
      .then(function (data) {
        qwaitingDao
          .findDepartcounterMappAggregation(sQuery)
          .then(async function (dcount) {
            let tptCnt = 0;
            if (dcount.length > 0) {
              tptCnt = dcount[0].recordCount;
            }
            res.status(200).json({
              status: true,
              result: data,
              message: "",
              hasMore: cmethod.hasMoreCount(
                tptCnt,
                postData.page,
                postData.pageLimit
              ),
              totalCount: tptCnt,
            });
          })
          .catch((err) => {
            cmethod.returnSreverError(res, message[lang].technicalError, err);
          });
      })
      .catch((err) => {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      });
  }
);

//department conter token task
router.post(
  "/generateToken",
  [
    midleware.validateFieldValue(
      ["departmentId"],
      ["departmentId"]
    ),
  ],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    console.log("was", postData?.departmentId);
    qwaitingDao.generateToken(postData?.departmentId,postData?.branchId).then(function (data) {
      if (data) {
        cmethod.returnSuccess(res, data, false, message[lang].careerReg);
      } else {
        cmethod.returnSreverError(res, message[lang].technicalError);
      }
    })

  }
);

router.post(
  "/tokenList",
  [midleware.validateFieldValue(["pageLimit", "page"], ["page"])],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let query = [];
    query.push({
      $lookup: {
        from: "departcountermapps",
        localField: "mappingCounterId",
        foreignField: "_id",
        as: "departcountermapps"
      }
    })
    query.push({
      $unwind: { path: "$departcountermapps", preserveNullAndEmptyArrays: true }
    })
    query.push({
      $lookup: {
        from: "departments",
        localField: "departmentId",
        foreignField: "_id",
        as: "departments",
      },
    });
    query.push({
      $unwind: { path: "$departments", preserveNullAndEmptyArrays: true },
    });
    
    query.push({
      $lookup: {
        from: "branchs",
        localField: "branchId",
        foreignField: "_id",
        as: "branchs",
      },
    });
    query.push({
      $unwind: { path: "$branchs", preserveNullAndEmptyArrays: true },
    });
    query.push({
      $lookup: {
        from: "counters",
        localField: "departcountermapps.counterId",
        foreignField: "_id",
        as: "counters",
      },
    });
    query.push({
      $unwind: { path: "$counters", preserveNullAndEmptyArrays: true },
    });
    if (postData.branchId) {
      query.push({
        $match: {
          branchId: mongoose.Types.ObjectId(postData?.branchId),
        },
      });
    }
    if (postData?.departmentId) {
      query.push({
        $match: {
          $and: [{ departmentId: mongoose.Types.ObjectId(postData?.departmentId) }]
        }
      })
    }
    if (postData?.branchId) {
      query.push({
        $match: {
          $and: [{ branchId: mongoose.Types.ObjectId(postData?.branchId) }]
        }
      })
    }
    if (postData?.counterId) {
      query.push({
        $match: {
          $and: [{ counterId: mongoose.Types.ObjectId(postData?.counterId) }]
        }
      })
    }
    if (postData?.queueStatus) {
      query.push({
        $match: {
          $and: [{ queueStatus: Number(postData?.queueStatus) }]
        }
      })
    }
    query.push({
      $project: {
        departmentId: 1,
        counterId: "$counters._id",
        branchName: "$branchs.branchName",
        department: "$departments.department",
        counterName: "$counters.counterName",
        tokenNo: 1,
        status: 1,
        queueStatus: 1,
        startTime: 1,
        endTime: 1,
        createdAt: 1,
        serveTime: 1,
        call: 1
      },
    });
    const sQuery = [...query];
    if (postData?.orderBy) {
      query.push({ $sort: { tokenTime: Number(postData?.orderBy) } });
    } else {
      query.push({ $sort: { createdAt: -1 } });
    }

    sQuery.push({ $count: "recordCount" });

    if (postData.page) {
      query.push({
        $skip: cmethod.pageOffset(postData.page, postData.pageLimit),
      });
      query.push({ $limit: cmethod.pageLimit(postData.pageLimit) });
    }

    qwaitingDao
      .findTokenAggregation(query)
      .then(function (data) {
        qwaitingDao
          .findTokenAggregation(sQuery)
          .then(async function (dcount) {
            let tptCnt = 0;
            if (dcount.length > 0) {
              tptCnt = dcount[0].recordCount;
            }
            res.status(200).json({
              status: true,
              result: data,
              message: "",
              hasMore: cmethod.hasMoreCount(
                tptCnt,
                postData.page,
                postData.pageLimit
              ),
              totalCount: tptCnt,
            });
          })
          .catch((err) => {
            cmethod.returnSreverError(res, message[lang].technicalError, err);
          });
      })
      .catch((err) => {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      });
  }
);
router.post(
  "/tokenAction",
  [
    midleware.validateFieldValue(
      ["action", "departmentId"],
      ["action", "departmentId"]
    )
  ],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    qwaitingDao.tokenAction(postData.action, postData.departmentId, postData.uniqueCounter, postData?.tokenNo)
      .then((data) => {
        cmethod.returnSuccess(res, data, false, message[lang].successfully);
      })
      .catch((err) => {
        cmethod.returnSreverError(res, err, err);
      });
  }
)

router.patch(
  "/tokenUpdate",
  [midleware.validateFieldValue(["tokenId"], ["tokenId"])],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let xtoken = req.headers["x-access-token"];
    //{ token: xtoken },
    let queryCond = {
      $and: [{ _id: mongoose.Types.ObjectId(postData.tokenId) }],
    };
    delete postData.tokenId;
    //console.log("=======================>", req.body);
    if (postData?.departmentId != '' && postData?.queueStatus == 0) {
      postData.tokenTime = new Date();
    }
    qwaitingModal.Countertoken.findOneAndUpdate(
      queryCond,
      { $set: postData },
      { new: true },
      async function (err, data) {
        if (err) {
          cmethod.returnSreverError(res, message[lang].technicalError, err);
        } else {
          cmethod.returnSuccess(res, data, false, message[lang].profileUpdate);
        }
      }
    );
  }
);
module.exports = router;


/**
 * @swagger
 * /api/qwaiting/departmentAdd:
 *   post:
 *     tags: [Qwaiting]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: branchId
 *         in: formData
 *         type: string
 *         required: false
 *       - name: parentId
 *         in: formData
 *         type: string
 *         required: false
 *       - name: department
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: prefix
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: status
 *         in: formData
 *         type: number
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: Add department.
 *
 */

/**
 * @swagger
 * /api/qwaiting/departmentList:
 *   post:
 *     tags: [Qwaiting]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: type
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *          ex- child, parent
 *       - name: branchId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: parentId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: pageLimit
 *         in: formData
 *         type: number
 *         required: true
 *         description:
 *       - name: page
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: department List.
 *
 */

/**
 * @swagger
 * /api/qwaiting/departmentUpdate:
 *   patch:
 *     tags: [Qwaiting]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: departmentId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: department
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: status
 *         in: formData
 *         type: number
 *         required: false
 *         description:
 *     responses:
 *       200:
 *         description: Department update.
 *
 */

/**
 * @swagger
 * /api/qwaiting/departmentDelete:
 *   delete:
 *     tags: [Qwaiting]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: deleteId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: department delete.
 *
 */

/**
 * @swagger
 * /api/qwaiting/counterAdd:
 *   post:
 *     tags: [Qwaiting]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: counterName
 *         in: formData
 *         type: string
 *         required: true
 *       - name: status
 *         in: formData
 *         type: number
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: Add department.
 *
 */

/**
 * @swagger
 * /api/qwaiting/counterList:
 *   post:
 *     tags: [Qwaiting]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: counterName
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: pageLimit
 *         in: formData
 *         type: number
 *         required: true
 *         description:
 *       - name: page
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: counter List.
 *
 */

/**
 * @swagger
 * /api/qwaiting/counterUpdate:
 *   patch:
 *     tags: [Qwaiting]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: counterId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: counterName
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: status
 *         in: formData
 *         type: number
 *         required: false
 *         description:
 *     responses:
 *       200:
 *         description: counter update.
 *
 */

/**
 * @swagger
 * /api/qwaiting/counterDelete:
 *   delete:
 *     tags: [Qwaiting]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: deleteId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: counter delete.
 *
 */
/**
 * @swagger
 * /api/qwaiting/counterMappingAdd:
 *   post:
 *     tags: [Qwaiting]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: departmentId
 *         in: formData
 *         type: string
 *         required: true
 *       - name: counterId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: status
 *         in: formData
 *         type: number
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: Add mapping.
 *
 */

/**
 * @swagger
 * /api/qwaiting/mappingList:
 *   post:
 *     tags: [Qwaiting]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: departmentId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: counterId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: pageLimit
 *         in: formData
 *         type: number
 *         required: true
 *         description:
 *       - name: page
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: mapping List.
 *
 */

/**
 * @swagger
 * /api/qwaiting/counterMappUpdate:
 *   patch:
 *     tags: [Qwaiting]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: mappingId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: departmentId
 *         in: formData
 *         type: string
 *         required: false
 *       - name: counterId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: status
 *         in: formData
 *         type: number
 *         required: false
 *         description:
 *     responses:
 *       200:
 *         description: Department update.
 *
 */

/**
 * @swagger
 * /api/qwaiting/generateToken:
 *   post:
 *     tags: [Qwaiting]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: departmentId
 *         in: formData
 *         type: string
 *         required: true
 *       - name: branchId
 *         in: formData
 *         type: string
 *         required: true
 *     responses:
 *       200:
 *         description: Add token.
 *
 */

/**
 * @swagger
 * /api/qwaiting/tokenList:
 *   post:
 *     tags: [Qwaiting]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: branchId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: departmentId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: counterId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: queueStatus
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *            ex- 0=default,1=in counter,2=done
 *       - name: orderBy
 *         in: formData
 *         type: number
 *         required: false
 *         description:
 *       - name: pageLimit
 *         in: formData
 *         type: number
 *         required: true
 *         description:
 *       - name: page
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: token List.
 *
 */

/**
 * @swagger
 * /api/qwaiting/tokenAction:
 *   post:
 *     tags: [Qwaiting]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: action
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *           ex- next,init,close,bypass
 *       - name: departmentId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: uniqueCounter
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: tokenNo
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *     responses:
 *       200:
 *         description: Token Action.
 *
 */

/**
 * @swagger
 * /api/qwaiting/tokenUpdate:
 *   patch:
 *     tags: [Qwaiting]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: tokenId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: departmentId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: queueStatus
 *         in: formData
 *         type: number
 *         required: false
 *         description:
 *           ex- 0=waiting,1=in counter,2=done
 *       - name: serveTime
 *         in: formData
 *         type: number
 *         required: false
 *         description:
 *       - name: call
 *         in: formData
 *         type: number
 *         required: false
 *         description:
 *            ex- 0=default,1=voice call
 *     responses:
 *       200:
 *         description: Token update.
 *
 */