const qwaitingModal = require("../qwaiting/qwaitingModal");
const message = require("../../config/message");
const cmethod = require("../../middleware/common-fun");
const mongoose = require("mongoose");


const departmentAdd = async function (res, postData) {
  const newDepartment = new qwaitingModal.Department(postData);

  newDepartment.save(postData, async function (err, data) {
    if (err) {
      cmethod.returnSreverError(res, message.technicalError, err);
    } else {
      cmethod.returnSuccess(res, data, false, message.signupsuccess);
    }
  });
};

const findDepartmentWithFiled = async function (query) {
  return new Promise(function (resolve, reject) {
    qwaitingModal.Department.find(
      { _id: { $exists: true } },
      { department: 1 },
      function (err, data) {
        if (err) {
          reject(err);
        } else {
          resolve(data);
        }
      }
    );
  });
};
const findDepartmentAggregation = function (query) {
  return new Promise(function (resolve, reject) {
    qwaitingModal.Department.aggregate(query, function (err, data) {
      if (err) {
        reject(err);
      } else {
        resolve(data);
      }
    });
  });
};
const checkDepartmentName = async function (query) {
  return new Promise(function (resolve, reject) {
    qwaitingModal.Department.find(query, function (err, data) {
      if (data.length > 0) {
        resolve(true);
      } else {
        resolve(false);
      }
    });
  });
};

const counterAdd = async function (res, postData) {
  const newCounter = new qwaitingModal.Counter(postData);

  newCounter.save(postData, async function (err, data) {
    if (err) {
      cmethod.returnSreverError(res, message.technicalError, err);
    } else {
      cmethod.returnSuccess(res, data, false, message.signupsuccess);
    }
  });
};

const findCounterWithFiled = async function (query) {
  return new Promise(function (resolve, reject) {
    qwaitingModal.Counter.find(
      { _id: { $exists: true } },
      { counterName: 1 },
      function (err, data) {
        if (err) {
          reject(err);
        } else {
          resolve(data);
        }
      }
    );
  });
};
const findCounterAggregation = function (query) {
  return new Promise(function (resolve, reject) {
    qwaitingModal.Counter.aggregate(query, function (err, data) {
      if (err) {
        reject(err);
      } else {
        resolve(data);
      }
    });
  });
};
const checkCounterName = async function (query) {
  return new Promise(function (resolve, reject) {
    qwaitingModal.Counter.find(query, function (err, data) {
      if (data.length > 0) {
        resolve(true);
      } else {
        resolve(false);
      }
    });
  });
};

//department and counter mapp
const deptCounterMappAdd = async function (res, postData) {
  const newDepatcounterMapp = new qwaitingModal.Departcountermapp(postData);

  newDepatcounterMapp.save(postData, async function (err, data) {
    if (err) {
      cmethod.returnSreverError(res, message.technicalError, err);
    } else {
      cmethod.returnSuccess(res, data, false, message.signupsuccess);
    }
  });
};

const findDepartcounterMappWithFiled = async function (query) {
  return new Promise(function (resolve, reject) {
    qwaitingModal.Departcountermapp.find(
      { _id: { $exists: true } },
      { departmentId: 1 },
      function (err, data) {
        if (err) {
          reject(err);
        } else {
          resolve(data);
        }
      }
    );
  });
};
const findDepartcounterMappAggregation = function (query) {
  return new Promise(function (resolve, reject) {
    qwaitingModal.Departcountermapp.aggregate(query, function (err, data) {
      if (err) {
        reject(err);
      } else {
        resolve(data);
      }
    });
  });
};
const checkDepartcounterMapp = async function (query) {
  return new Promise(function (resolve, reject) {
    qwaitingModal.Departcountermapp.find(query, function (err, data) {
      if (data.length > 0) {
        resolve(true);
      } else {
        resolve(false);
      }
    });
  });
};
//department and counter token generation
const deptCounterTokenAdd = async function (res, postData) {
  const newDepartcounterToken = new qwaitingModal.Countertoken(postData);

  newDepartcounterToken.save(postData, async function (err, data) {
    if (err) {
      cmethod.returnSreverError(res, message.technicalError, err);
    } else {
      cmethod.returnSuccess(res, data, false, message.signupsuccess);
    }
  });
};

const findDepartcounterTokenAggregation = function (query) {
  return new Promise(function (resolve, reject) {
    qwaitingModal.Countertoken.aggregate(query, function (err, data) {
      if (err) {
        reject(err);
      } else {
        resolve(data);
      }
    });
  });
};
const generateToken = async function (departmentId,branchId) {
  return new Promise(async function (resolve, reject) {
    //get department prefix
    const departmentData = await qwaitingModal.Department.findOne(
      {
        _id: mongoose.Types.ObjectId(departmentId),
        branchId: mongoose.Types.ObjectId(branchId),
      }, {
      prefix: 1,
    }).sort({ createdAt: -1 });

    let prefix = departmentData?.prefix;
    let tokenQry = {
      $and: [
        { departmentId: mongoose.Types.ObjectId(departmentId) },
        { branchId: mongoose.Types.ObjectId(branchId) },
        { tokenNo: { $nin: [null, ""] } }
      ],
    };
    const lastTokenData = await qwaitingModal.Countertoken.findOne(tokenQry, {
      tokenNo: 1,
    }).sort({ createdAt: -1 });
    let newTokenNo;
    if (lastTokenData) {
      let lastToken = lastTokenData?.tokenNo;
      let lastTokenNo = lastToken.substring(prefix.length, lastToken.length);

      newTokenNo = Number(lastTokenNo) + 1;
      newTokenNo = prefix + newTokenNo;
    } else {
      newTokenNo = prefix + "101";
    }

    //save new token no
    let insertToken = {
      departmentId: mongoose.Types.ObjectId(departmentId),
      branchId: mongoose.Types.ObjectId(branchId),
      tokenNo: newTokenNo,
      status: 1
    }
    const newTokenData = new qwaitingModal.Countertoken(insertToken);
    const addTokenData = newTokenData.save(insertToken);
    if (addTokenData) {
      resolve(addTokenData)
    } else {
      resolve(false)
    }
  })
}
const findTokenAggregation = function (query) {
  return new Promise(function (resolve, reject) {
    qwaitingModal.Countertoken.aggregate(query, function (err, data) {
      if (err) {
        reject(err);
      } else {
        resolve(data);
      }
    });
  });
};
//token concept
const getCounter = function (departmentId) {
  let query = [];

  query.push({
    $lookup: {
      from: "counters",
      localField: "counterId",
      foreignField: "_id",
      as: "counters",
    },
  });
  query.push({
    $unwind: { path: "$counters", preserveNullAndEmptyArrays: true },
  });

  if (departmentId) {
    query.push({
      $match: {
        $and: [{ departmentId: mongoose.Types.ObjectId(departmentId) }]
      }
    })
  }
  query.push({
    $project: {
      departmentId: 1,
      counterName: "$counters.counterName",
      status: 1,
      createdAt: 1
    },
  });
  query.push({ $sort: { createdAt: 1 } });
  return new Promise(function (resolve, reject) {
    qwaitingModal.Departcountermapp.aggregate(query, function (err, data) {
      if (err) {
        reject(err);
      } else {
        resolve(data);
      }
    })
  })
}
const enqueueToken = async function (departmentId, mappCounterId, tokenNo = '') {
  return new Promise(async function (resolve, reject) {
    let query;
    if (tokenNo) {
      query = { tokenNo: tokenNo }
    } else {
      query = { departmentId: departmentId, queueStatus: 0 }
    }
    const tokenData = await qwaitingModal.Countertoken.findOne(query, {
      mappingCounterId: 1,
    }).sort({ tokenTime: 1 }).limit({ $limit: 1 });
    if (tokenData) {
      let currentCounterToken = await qwaitingModal.Countertoken.updateOne(
        { _id: mongoose.Types.ObjectId(tokenData._id) },
        {
          $set: {
            mappingCounterId: mappCounterId,
            queueStatus: 1,
            startTime: new Date(),
          },
        }
      );
      currentCounterToken = await qwaitingModal.Countertoken.findOne({ _id: mongoose.Types.ObjectId(tokenData._id) }).sort({ tokenTime: 1 }).limit({ $limit: 1 });;
      resolve(currentCounterToken);
    } else {
      resolve(false);
    }
  })
}
const dequeueToken = async function (tokenNo, mappCounterId) {
  return new Promise(async function (resolve, reject) {
    // const tokenData = await qwaitingModal.Countertoken.findOne({mappCounterId:mappCounterId,queueStatus:1}, {
    //     mappingCounterId: 1,
    //   }).sort({ tokenTime: 1 }).limit({$limit:1});
    let query;
    if (tokenNo) {
      query = { tokenNo: tokenNo, queueStatus: 1 }
    } else {
      query = { mappCounterId: mongoose.Types.ObjectId(mappCounterId), queueStatus: 1 }
    }
    const tokenData = await qwaitingModal.Countertoken.findOne(query, {
      mappingCounterId: 1,
    }).sort({ tokenTime: 1 }).limit({ $limit: 1 });

    if (tokenData) {
      let removeCounterToken = await qwaitingModal.Countertoken.updateMany(
        query,
        {
          $set: {
            queueStatus: 2,
            endTime: new Date(),
          },
        }
      );
      resolve(removeCounterToken);
    } else {
      resolve(false);
    }
  })
}
const tokenAction = function (action, departmentId, mappCounterId, tokenNo = '') {
  let data;
  return new Promise(async function (resolve, reject) {
    switch (action) {
      case 'next':
        // console.log('next'+departmentId+"|||"+mappCounterId);
        await dequeueToken(tokenNo);
        data = await enqueueToken(departmentId, mappCounterId);
        // data="next"
        break;
      case 'bypass':
        await dequeueToken('', mappCounterId);
        data = await enqueueToken(departmentId, mappCounterId, tokenNo);
        break;
      case 'init':
        // console.log('init');
        data = await enqueueToken(departmentId, mappCounterId);
        // data="init"
        break;
      case 'close':
        await dequeueToken(tokenNo);
        data = true;
        break;
      default:
        // console.log("default action run here");
        data = await enqueueToken(departmentId, mappCounterId);
        data = "default"
    }
    if (data) {
      resolve(data);
    } else {
      reject("No new Token Available");
    }
  });

}


module.exports = {
  departmentAdd,
  findDepartmentWithFiled,
  findDepartmentAggregation,
  checkDepartmentName,
  counterAdd,
  findCounterWithFiled,
  findCounterAggregation,
  checkCounterName,
  deptCounterMappAdd,
  findDepartcounterMappWithFiled,
  findDepartcounterMappAggregation,
  checkDepartcounterMapp,
  deptCounterTokenAdd,
  findDepartcounterTokenAggregation,
  generateToken,
  findTokenAggregation,
  tokenAction
}