const auction = require("../auction/auctionModal");
const inventory = require("../inventory/inventoryModal");
const message = require("../../config/message");
const jwt = require("jsonwebtoken");
const config = require("../../config");
const midleware = require("../../middleware/validation");
const moment = require("moment");
// const Promise = require("bluebird");
const cmethod = require("../../middleware/common-fun");
// const moment = require("moment");
// var axios = require('axios');
// const { sendThirdPartyOtp } = require("../import/thirdParty");
// const {
//   storeHash,
//   getHash,
//   encrypt,
//   deleteHash,
//   customDelete,
//   deleteUser,
// } = require("../../middleware/redisConnection");
var mongoose = require("mongoose");
const { connWrite } = require("./../../config/database");
const { makeObjectId } = require("../../functions/global.functions");

const auctionAddmore = async function (res, postData) {
  let displayData = await auction.Auctionvehicle.findOne(
    { auctionId: postData?.auctionId },
    { displayNo: 1 }
  )
    .sort({ displayNo: -1 })
    .limit(1);
  if (displayData) {
    postData.displayNo = parseInt(displayData?.displayNo) + 1;
  }
  const auctionListInsert = new auction.Auctionvehicle(postData);

  auctionListInsert.save(postData, async function (err, data) {
    if (err) {
      cmethod.returnSreverError(res, message.technicalError, err);
    } else {
      await inventory.Inventory.updateOne(
        { _id: mongoose.Types.ObjectId(data?.inventoryId) },
        { $set: { inventoryStatus: 2 } }
      );
      cmethod.returnSuccess(res, data, false, message.signupsuccess);
    }
  });
};
const auctionAdd = async function (res, postData) {
  auctionNoUnique = await cmethod.getauctionNo();
  postData.auctionNo = auctionNoUnique;
  const newAuction = new auction.Auction(postData);

  console.log("postData@========>.>>>", postData);
  newAuction.save(postData, async function (err, data) {
    if (err) {
      console.log(err);
      cmethod.returnSreverError(res, message.technicalError, err);
    } else {
      console.log("data@========>.>>>", data);
      let auctionListInsert = [];
      let allInventoryId = [];
      for (var i = 0; i < postData.inventoryId.length; i++) {
        allInventoryId.push(mongoose.Types.ObjectId(postData.inventoryId[i]));

        auctionListInsert.push({
          auctionId: mongoose.Types.ObjectId(data?._id),
          inventoryId: mongoose.Types.ObjectId(postData.inventoryId[i]),
          status: "pending",
          displayNo: 1,
        });
      }
      await inventory.Inventory.updateMany(
        { _id: { $in: allInventoryId } },
        { $set: { inventoryStatus: 2 } }
      );
      //insert auction vehicle list
      await auction.Auctionvehicle.insertMany(auctionListInsert);
      //end insert auction vehicle list
      cmethod.returnSuccess(res, data, false, message.auctionAdd);
    }
  });
};

const findAuctionWithFiled = async function (query, fields) {
  return new Promise(function (resolve, reject) {
    auction.Auction.find(query, fields, function (err, data) {
      if (err) {
        console.log(err);
        reject(err);
      } else {
        resolve(data);
      }
    });
  });
};

const findAuctionAggregation = function (query) {
  return new Promise(function (resolve, reject) {
    auction.Auction.aggregate(query, function (err, data) {
      if (err) {
        reject(err);
      } else {
        resolve(data);
      }
    });
  });
};
const findAuctionvehicleAggregation = function (query) {
  return new Promise(function (resolve, reject) {
    auction.Auctionvehicle.aggregate(query, function (err, data) {
      if (err) {
        reject(err);
      } else {
        resolve(data);
      }
    });
  });
};
const updateAuctionvehicle = function (query, data) {
  return new Promise(function (resolve, reject) {
    auction.Auctionvehicle.updateOne(query, data, function (err, data) {
      if (err) {
        reject(err);
      } else {
        resolve(data);
      }
    });
  });
};
const checkInventorywithauctionNo = async function (query) {
  return new Promise(function (resolve, reject) {
    auction.Auctionvehicle.find(query, function (err, data) {
      if (data.length > 0) {
        resolve("exist");
      } else {
        resolve("notexist");
      }
    });
  });
};

const isAuctionEnded = async ({ auctionId }) => {
  try {
    const filter = {
      _id: makeObjectId(auctionId),
      isAuctionEnded: { $eq: true },
    };

    const isAuctionEnded = await auction.Auction.find(filter);

    return isAuctionEnded.length > 0;
  } catch (error) {
    console.error(error);
  }
};

module.exports = {
  auctionAdd,
  checkInventorywithauctionNo,
  auctionAddmore,
  findAuctionWithFiled,
  findAuctionAggregation,
  findAuctionvehicleAggregation,
  updateAuctionvehicle,
  isAuctionEnded,
};
