const { array, boolean } = require("@hapi/joi");
const mongoose = require("mongoose");
const Schema = mongoose.Schema;
const { connWrite } = require("./../../config/database");

const auctionSchema = new Schema(
  {
    title: String,
    auctionNo: String,
    image: String,
    pdfimgPath: String,
    auctionDate: { type: Date, default: "0000-00-00" },
    auctionTime: { type: String, default: "00:00" },
    auctionClose: { type: Number, default: 0 },
    isAuctionEnded: { type: Boolean, default: false },
    duration: { type: Number, default: 20 },
    auctionType: { type: String, default: "online" },
    auctionStart: { type: Boolean, default: false },
    auctionHighlight: { type: Boolean, default: false },    
    branchId: {
      type: mongoose.Types.ObjectId,
      default: null,
      index: true,
    },
    inventoryId: [
      {
        type: mongoose.Types.ObjectId,
        default: [mongoose.Types.ObjectId()],
        index: true,
      },
    ],
  },
  {
    timestamps: {
      createdAt: "createdAt",
      updatedAt: "updatedAt",
    },
  }
);
auctionSchema.index(
  { auctionTime: 1 },
  { collation: { locale: "en", strength: 2 } }
);

const auctionVehicleSchema = new Schema(
  {
    auctionId: {
      type: mongoose.Types.ObjectId,
      default: null,
      index: true,
    },
    inventoryId: {
      type: mongoose.Types.ObjectId,
      default: null,
      index: true,
    },
    runNumber: { type: Number, default: 0 },
    status: { type: String, index: true }, //sold,unsold,prebid/UnderApproval // salesReturn // selfBid
    displayNo: { type: Number, default: 0 },
    bidAmount: { type: Number, default: 0 },
    verifyStatus: { type: String, default: "pending" },
    export: { type: Boolean, default: false },
    exportCountry: String,
  },
  {
    timestamps: {
      createdAt: "createdAt",
      updatedAt: "updatedAt",
    },
  }
);
const Auction = connWrite.model("auction", auctionSchema);

const Auctionvehicle = connWrite.model("auctionvehicles", auctionVehicleSchema);

module.exports = {
  Auction,
  Auctionvehicle,
};
