const express = require("express");
const router = express.Router();
const auctionDao = require("./auctionDao");
const bidDao = require("../bid/bidDao");
const auctionModal = require("../auction/auctionModal");
const inventoryModal = require("../inventory/inventoryModal");
const accountModal = require("../account/accountModal");
const message = require("../../config/message");
//const jwt = require("jsonwebtoken");
const config = require("../../config");
const midleware = require("../../middleware/validation");
//const Promise = require("bluebird");
const cmethod = require("../../middleware/common-fun");
//const moment = require("moment");
//const axios = require("axios");
var mongoose = require("mongoose");
const http = require("http");
const { dirname } = require("path");
const path = require("path");
const { middleware } = require("json2xls");
const { number } = require("@hapi/joi");
const {
  makeObjectId,
  regexSearch,
} = require("../../functions/global.functions");
const {
  FindOne,
  FindByIdAndUpdate,
  MultiAggregate,
} = require("../../models/factory");
const {
  LookupWithPipeline,
  Lookup,
  Unwind,
} = require("../../functions/mongoose.functions");
const logger = require("../../config/logger");
const { bidHistoryLog } = require("../bid/bidModal");

router.post(
  "/addmore",
  [
    midleware.validateFieldValue(
      ["auctionId", "inventoryId"],
      ["auctionId", "inventoryId"]
    ),
  ],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let query = {
      auctionId: mongoose.Types.ObjectId(postData.auctionId),
      inventoryId: mongoose.Types.ObjectId(postData.inventoryId),
      status: "pending",
    };
    //console.log(postData);
    //console.log(query);
    auctionDao.checkInventorywithauctionNo(query).then(async function (doc) {
      if (doc == "exist") {
        //console.log(doc);
        cmethod.returnSreverError(res, message[lang].docExist);
      } else {
        const filter = {
          auctionId: mongoose.Types.ObjectId(postData.auctionId),
          inventoryId: mongoose.Types.ObjectId(postData.inventoryId),
          status: { $in: ["unsold", "skip"] },
        };

        const unsoldAuctionVehicle = await auctionModal.Auctionvehicle.findOne(
          filter
        );

        if (unsoldAuctionVehicle) {
          const lastAuctionVehicleFilter = {
            auctionId: mongoose.Types.ObjectId(postData.auctionId),
          };

          const lastAuctionVehicleProjection = { _id: 0, displayNo: 1 };
          const lastAuctionVehicleSort = { displayNo: -1 };
          const lastAuctionVehicleByAuction = await FindOne(
            auctionModal.Auctionvehicle,
            lastAuctionVehicleFilter,
            lastAuctionVehicleProjection,
            lastAuctionVehicleSort
          );

          const uUpdate = {
            $set: {
              status: "pending",
            },
            ...(lastAuctionVehicleByAuction && {
              displayNo: ++lastAuctionVehicleByAuction.displayNo,
            }),
          };

          const uNew = { new: true };
          const auctionVehicleDoc =
            await auctionModal.Auctionvehicle.findByIdAndUpdate(
              unsoldAuctionVehicle._id,
              uUpdate,
              uNew
            );

          await inventoryModal.Inventory.updateOne(
            { _id: mongoose.Types.ObjectId(postData.inventoryId) },
            { $set: { inventoryStatus: 2 } }
          );

          cmethod.returnSuccess(
            res,
            auctionVehicleDoc,
            false,
            message.signupsuccess
          );
        } else {
          auctionDao.auctionAddmore(res, postData);
        }

        //console.log('cmethod'); return false;
      }
    });
  }
);
router.post(
  "/add",
  [
    midleware.validateFieldValue(
      ["title", "auctionDate", "branchId", "inventoryId"],
      ["title", "auctionDate", "branchId", "inventoryId"]
    ),
  ],
  (req, res) => {
    const postData = req.body;

    // let auctionListInsert=[];
    // auctionModal.Auction.find({ title: { $exists: true } }, {inventoryId:1}, async function (err, data) {
    //   if (err) { console.log(err)
    //     reject(err);
    //   } else {
    //     for (var i = 0; i < data.length; i++) {
    //       if(data[i]?.inventoryId.length>0){
    //       auctionListInsert.push({
    //           auctionId:mongoose.Types.ObjectId(data[i]?._id),
    //           inventoryId:mongoose.Types.ObjectId(data[i]?.inventoryId[i]),
    //           status:"pending"

    //         });
    //       }
    //     }
    //     // console.log(auctionListInsert);
    //     await auctionModal.Auctionvehicle.insertMany(auctionListInsert);
    //   }
    // });
    auctionDao.auctionAdd(res, postData);
  }
);
// * update auction
router.patch(
  "/update",
  [
    midleware.validateFieldValue(
      ["auctionId", "title", "auctionDate", "inventoryId", "updateType"],
      ["auctionId", "title", "auctionDate", "inventoryId"]
    ),
  ],
  async (req, res) => {
    let lang = req.headers["lang"] || config.lang;
    const postData = req.body;
    let updateType = postData?.updateType;
    let orderChange = postData?.orderChange;
    const { startingBid, costPrice, invoicePrice } = postData;
    //console.log('else---===========>1',postData);
    //return false;
    let inventoryStatus = 2;
    let auctionId = postData.auctionId;
    let bidAmount = postData.bidAmount;
    let queryCond = {
      $and: [{ _id: mongoose.Types.ObjectId(postData.auctionId) }],
    };
    delete postData.updateType;
    delete postData.auctionId;
    let allInventoryId = [];
    for (var i = 0; i < postData.inventoryId.length; i++) {
      //console.log('debug-1-------------->');
      allInventoryId.push(mongoose.Types.ObjectId(postData.inventoryId[i]));
    }
    if (updateType == "unsold") {
      let queryCond1 = {
        $and: [
          { auctionId: mongoose.Types.ObjectId(auctionId) },
          { inventoryId: { $in: allInventoryId } },
        ],
      };
      //console.log('debug-2-------------->',queryCond1);
      delete postData.inventoryId;
      inventoryStatus = 1;
      auctionModal.Auctionvehicle.updateMany(
        queryCond1,
        {
          $set: { status: "unsold", bidAmount: postData?.bidAmount },
        },
        { new: true },
        async function (err, data) {
          if (err) {
            //console.log('debug-3---------------------------->',err);
            cmethod.returnSreverError(res, message[lang].technicalError, err);
          } else {
            //console.log('debug-4-------------->',queryCond1);

            await inventoryModal.Inventory.updateMany(
              { _id: { $in: allInventoryId } },
              { $set: { inventoryStatus: inventoryStatus } }
            );
            //-------------------
            await cmethod.checkVehicleUnsold(auctionId, allInventoryId);
            cmethod.returnSuccess(res, data, false, message[lang].Updated);
          }
        }
      );
    } else {
      auctionModal.Auction.findOneAndUpdate(
        queryCond,
        {
          $set: postData,
        },
        { new: true },
        async function (err, data) {
          if (err) {
            //console.log(err);
            cmethod.returnSreverError(res, message[lang].technicalError, err);
          } else {
            await inventoryModal.Inventory.updateMany(
              { _id: { $in: allInventoryId } },
              { $set: { inventoryStatus: inventoryStatus } }
            );
            //Note : chnage orderNo
            if (orderChange) {
              //console.log('else--->0', postData); //return false;
              for (let i = 0; i < orderChange.length; i++) {
                await auctionModal.Auctionvehicle.updateOne(
                  {
                    inventoryId: mongoose.Types.ObjectId(
                      orderChange[i]?.inventoryId
                    ),
                    auctionId: mongoose.Types.ObjectId(auctionId),
                  },
                  { $set: { displayNo: orderChange[i]?.displayNo } }
                );

                //console.log('==============>', i + 1);
              }
            }
            if (startingBid) {
              for (const inventory of startingBid) {
                const update = { startingBid: Number(inventory.startingBid) };
                await FindByIdAndUpdate(
                  inventoryModal.Inventory,
                  inventory.inventoryId,
                  update
                );
              }
            }
            if (costPrice) {
              for (const inventory of costPrice) {
                const update = { costPrice: Number(inventory.costPrice) };
                await FindByIdAndUpdate(
                  inventoryModal.Inventory,
                  inventory.inventoryId,
                  update
                );
              }
            }
            if (invoicePrice) {
              for (const inventory of invoicePrice) {
                const update = { invoicePrice: Number(inventory.invoicePrice) };
                await FindByIdAndUpdate(
                  inventoryModal.Inventory,
                  inventory.inventoryId,
                  update
                );
              }
            }
            cmethod.returnSuccess(res, data, false, message[lang].Updated);
          }
        }
      );
    }
  }
);
router.patch(
  "/allMarkUnsold",
  [
    midleware.validateFieldValue(
      ["auctionId", "title", "auctionDate", "inventoryIds", "updateType"],
      ["auctionId", "title", "auctionDate", "inventoryIds"]
    ),
  ],
  async (req, res) => {
    let lang = req.headers["lang"] || config.lang;
    const postData = req.body;
    console.log("=========>result-0", postData); //return false;
    // let updateType = postData?.updateType;
    // let orderChange = postData?.orderChange;
    // postData.auctionId = "64c3c80543ad49153eb4890e";
    // postData.inventoryId = ["64c3d7233f958766f7da09d9", "64c3c7d343ad49153eb48871"]
    // postData.bidAmount = ["220", "250"]
    let result;
    //console.log("=========>result-0", postData);

    for (let i = 0; i < postData.inventoryIds.length; i++) {
      let queryCond1 = {
        $and: [
          { auctionId: mongoose.Types.ObjectId(postData.auctionId) },
          { inventoryId: mongoose.Types.ObjectId(postData.inventoryIds[i]) },
        ],
      };

      result = await auctionModal.Auctionvehicle.updateMany(queryCond1, {
        $set: { status: "unsold", bidAmount: postData?.bidAmounts[i] },
      });

      //console.log("=========>result-1", result); return false;
      if (result) {
        await inventoryModal.Inventory.updateMany(
          { _id: mongoose.Types.ObjectId(postData.inventoryIds[i]) },
          { $set: { inventoryStatus: 1 } }
        );
        let getInventoryId = mongoose.Types.ObjectId(postData.inventoryIds[i]);
        let getauctionId = mongoose.Types.ObjectId(postData.auctionId);
        await cmethod.checkVehicleUnsold(getauctionId, getInventoryId);
      }
    }
    cmethod.returnSuccess(res, message[lang].Updated);
    //console.log('else---===========>1', postData);
  }
);
router.patch(
  "/auctionVehicleUpdate",
  [midleware.validateFieldValue([], [])],
  (req, res) => {
    let postData = req.body;
    //console.log("auctionVehicleUpdate==========>>>>>>",postData);
    //return false;
    const {
      query: { fromBid, inventoryId, auctionId },
    } = req;
    let lang = req.headers["lang"] || config.lang;
    let xtoken = req.headers["x-access-token"];
    //{ token: xtoken },
    let queryCond = "";
    let update = "";

    if (fromBid === "true") {
      queryCond = {
        inventoryId: makeObjectId(inventoryId),
        auctionId: makeObjectId(auctionId),
      };
      update = postData;
    } else if (postData.verifyStatus == "approve") {
      queryCond = { _id: mongoose.Types.ObjectId(postData.auctionVehicleId) };
      update = { verifyStatus: "approved" };
    } else {
      queryCond = { _id: mongoose.Types.ObjectId(postData.inventoryId) };
      update = { displayNo: postData.displayNo };
      delete postData.auctionVehicleId;
    }

    auctionModal.Auctionvehicle.findOneAndUpdate(
      queryCond,
      { $set: update },
      { new: true },
      async function (err, data) {
        if (err) {
          cmethod.returnSreverError(res, message[lang].technicalError, err);
        } else {
          /*add inventory images */
          cmethod.returnSuccess(res, data, false, message[lang].Updated);
        }
      }
    );
  }
);
router.delete(
  "/removeAuctionVehicle",
  [
    midleware.validateFieldValue(
      ["auctionstockId", "inventoryId"],
      ["auctionstockId", "inventoryId"]
    ),
  ],
  (req, res) => {
    let lang = req.headers["lang"] || config.lang;
    let postData = req.body;
    let cond = { _id: mongoose.Types.ObjectId(postData.auctionstockId) };
    let orderChange = postData?.orderChange;
    auctionModal.Auctionvehicle.deleteOne(cond, postData)
      .then(async (data) => {
        await inventoryModal.Inventory.updateOne(
          { _id: mongoose.Types.ObjectId(postData.inventoryId) },
          { $set: { inventoryStatus: 1 } }
        );
        await auctionModal.Auctionvehicle.deleteOne({
          auctionId: mongoose.Types.ObjectId(postData.auctionstockId),
          inventoryId: mongoose.Types.ObjectId(postData.inventoryId),
        });
        //order update if any
        if (orderChange) {
          for (let i = 0; i < orderChange.length; i++) {
            await auctionModal.Auctionvehicle.updateOne(
              {
                inventoryId: mongoose.Types.ObjectId(
                  orderChange[i]?.inventoryId
                ),
                auctionId: mongoose.Types.ObjectId(postData.auctionstockId),
              },
              { $set: { displayNo: orderChange[i]?.displayNo } }
            );

            //console.log('==============>', i + 1);
          }
        }
        cmethod.returnSuccess(res, [], false, message[lang].Deleteed);
      })
      .catch((err) => {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      });
  }
);
router.post(
  "/list",
  [midleware.validateFieldValue(["pageLimit", "page"], ["pageLimit", "page"])],
  (req, res) => {
    // console.log("washi first routing")
    let lang = req.headers["lang"] || config.lang;
    let postData = req.body;
    let query = [];

    query.push({
      $lookup: {
        from: "auctionvehicles",
        localField: "_id",
        foreignField: "auctionId",
        as: "auctionvehicles",
      },
    });
    query.push({
      $unwind: { path: "$auctionvehicles", preserveNullAndEmptyArrays: true },
    });
    //add branch lookup
    query.push({
      $lookup: {
        from: "branchs",
        localField: "branchId",
        foreignField: "_id",
        as: "branchs",
      },
    });
    query.push({
      $unwind: { path: "$branchs", preserveNullAndEmptyArrays: true },
    });

    if (postData.status) {
      query.push({
        $match: {
          $and: [{ "auctionvehicles.status": postData.status }],
        },
      });
    }

    query.push({
      $lookup: {
        from: "inventorys",
        localField: "auctionvehicles.inventoryId",
        foreignField: "_id",
        as: "inventorys",
      },
    });
    query.push({
      $unwind: { path: "$inventorys", preserveNullAndEmptyArrays: true },
    });
    query.push({
      $lookup: {
        from: "makes",
        localField: "inventorys.make",
        foreignField: "_id",
        as: "makes",
      },
    });
    query.push({
      $unwind: { path: "$makes", preserveNullAndEmptyArrays: true },
    });
    query.push({
      $lookup: {
        from: "models",
        localField: "inventorys.model",
        foreignField: "_id",
        as: "models",
      },
    });
    query.push({
      $unwind: { path: "$models", preserveNullAndEmptyArrays: true },
    });
    query.push({
      $lookup: {
        from: "warehouses",
        localField: "inventorys.warehosId",
        foreignField: "_id",
        as: "warehouses",
      },
    });
    query.push({
      $unwind: { path: "$warehouses", preserveNullAndEmptyArrays: true },
    });
    query.push({
      $lookup: {
        from: "bodys",
        localField: "inventorys.bodyId",
        foreignField: "_id",
        as: "bodys",
      },
    });
    query.push({
      $unwind: { path: "$bodys", preserveNullAndEmptyArrays: true },
    });
    query.push({
      $lookup: {
        from: "series",
        localField: "inventorys.seriesId",
        foreignField: "_id",
        as: "series",
      },
    });
    query.push({
      $unwind: { path: "$series", preserveNullAndEmptyArrays: true },
    });
    query.push({
      $lookup: {
        from: "fueltypes",
        localField: "inventorys.fueltypeId",
        foreignField: "_id",
        as: "fueltypes",
      },
    });
    query.push({
      $unwind: { path: "$fueltypes", preserveNullAndEmptyArrays: true },
    });
    query.push({
      $lookup: {
        from: "drivetypes",
        localField: "inventorys.drivetypeId",
        foreignField: "_id",
        as: "drivetypes",
      },
    });
    query.push({
      $unwind: { path: "$drivetypes", preserveNullAndEmptyArrays: true },
    });
    query.push({
      $lookup: {
        from: "engines",
        localField: "inventorys.engineId",
        foreignField: "_id",
        as: "engines",
      },
    });
    query.push({
      $unwind: { path: "$engines", preserveNullAndEmptyArrays: true },
    });
    query.push({
      $lookup: {
        from: "interiorcolors",
        localField: "inventorys.interiorcolorId",
        foreignField: "_id",
        as: "interiorcolors",
      },
    });
    query.push({
      $unwind: { path: "$interiorcolors", preserveNullAndEmptyArrays: true },
    });
    query.push({
      $lookup: {
        from: "exteriorcolors",
        localField: "inventorys.exteriorcolorId",
        foreignField: "_id",
        as: "exteriorcolors",
      },
    });
    query.push({
      $unwind: { path: "$exteriorcolors", preserveNullAndEmptyArrays: true },
    });
    query.push({
      $lookup: {
        from: "vinimages",
        // localField: "salesUserId",
        // foreignField: "_id",
        let: {
          inventoryId: "$inventoryId",
          imageType: "inventory",
          type: "carimage",
        },
        pipeline: [
          {
            $match: {
              $expr: {
                $and: [
                  { $eq: ["$imageType", "$$imageType"] },
                  { $eq: ["$type", "$$type"] },
                  { $eq: ["$referenceId", "$$inventoryId"] },
                ],
              },
            },
          },
        ],
        as: "singlevinimages",
      },
    });
    query.push({
      $lookup: {
        from: "auctionvehicles",
        let: {
          auctionId: "$auctionId",
          status: "pending",
        },
        pipeline: [
          {
            $match: {
              $expr: {
                $and: [
                  { $eq: ["$$auctionId", "$_id"] },
                  { $eq: ["$status", "pending"] },
                ],
              },
            },
          },
        ],
        as: "auctionPendingCar",
      },
    });
    if (postData.closeauctionDate) {
      query.push({
        $match: {
          $and: [
            {
              auctionDate: {
                $gt: new Date(
                  cmethod.startTimeString(new Date(postData.closeauctionDate))
                ),
              },
            },
          ],
        },
      });
    }

    if (postData.search) {
      query.push({
        $match: {
          $and: [
            {
              $or: [
                { auctionDate: { $regex: postData.search, $options: "i" } },
              ],
            },
          ],
        },
      });
    } else if (postData.auctionId) {
      query.push({
        $match: {
          _id: mongoose.Types.ObjectId(postData.auctionId),
        },
      });
    } else {
      query.push({
        $match: {
          $and: [{ title: { $exists: true } }],
        },
      });
    }
    // query.push({
    //   $match: {
    //     $and: [{ inventoryId:{$exists:true,$ne:'[]'} }],
    //   },
    // });
    //get only that inventory which is auction not done
    if (postData.inventoryStatus) {
      query.push({
        $match: {
          $and: [
            { "inventorys.inventoryStatus": { $eq: postData.inventoryStatus } },
          ],
        },
      });
    }
    if (postData.vin) {
      query.push({
        $match: {
          $and: [{ "inventorys.vin": regexSearch(postData.vin) }],
        },
      });
    }
    if (postData.auctionClose) {
      query.push({
        $match: {
          $and: [
            {
              auctionClose: Number(postData.auctionClose),
            },
          ],
        },
      });
    }
    if (postData?.branchId?.length > 0) {
      let branchData = [];
      let pdata = postData.branchId;
      for (let i in pdata) {
        branchData.push(mongoose.Types.ObjectId(pdata[i]));
      }

      query.push({
        $match: {
          $and: [
            {
              branchId: {
                $in: branchData,
              },
            },
          ],
        },
      });
    } else {
    }
    //console.log('=========>>>>',postData);

    if (!postData.auctionId) {
      query.push({
        $group: {
          _id: "$_id",
          title: { $first: "$title" },
          auctionDate: { $first: "$auctionDate" },
          auctionClose: { $first: "$auctionClose" },
          auctionNo: { $first: "$auctionNo" },
          auctionTime: { $first: "$auctionTime" },
          createdAt: { $first: "$createdAt" },
          inventorys: { $push: "$inventorys" },
          auctionvehicles: { $push: "$auctionvehicles" },
          branchs: { $first: "$branchs" },
          makes: { $first: "$makes" },
          models: { $first: "$models" },
          bodys: { $first: "$bodys" },
          series: { $first: "$series" },
          fueltypes: { $first: "$fueltypes" },
          drivetypes: { $first: "$drivetypes" },
          engines: { $first: "$engines" },
          exteriorcolors: { $first: "$exteriorcolors" },
          interiorcolors: { $first: "$interiorcolors" },
          warehouses: { $first: "$warehouses" },
          //displayNo: { $first: "$auctionvehicles" },
          singlevinimages: { $first: "$singlevinimages" },
          auctionPendingCar: { $push: "$auctionPendingCar" },
          duration: { $first: "$duration" },
          auctionType: { $first: "$auctionType" },
        },
      });
    }

    query.push({
      $project: {
        title: 1,
        branchName: "$branchs.branchName",
        branchId: "$branchs._id",
        bodys: "$bodys.bodyName",
        bodyId: "$bodys._id",
        drivetypes: "$drivetypes.drivetypeName",
        drivetypeId: "$drivetypes._id",
        fueltypes: "$fueltypes.fueltypeName",
        fueltypeId: "$fueltypes._id",
        series: "$series.seriesName",
        seriesId: "$series._id",
        engines: "$engines.engineName",
        engineId: "$engines._id",
        exteriorcolorId: "$exteriorcolors._id",
        excolorCode: "$exteriorcolors.colorCode",
        color: "$exteriorcolors.colorName",
        interiorcolorId: "$interiorcolors._id",
        incolorCode: "$interiorcolors.colorCode",
        interiorcolors: "$interiorcolors.colorName",
        makeName: "$makes.makeName",
        makeId: "$makes._id",
        modelName: "$models.modelName",
        modelId: "$models._id",
        warehouses: "$warehouses.warehouseName",
        warehosId: "$warehouses._id",
        inventoryId: "$inventorys._id",
        //branchId: 1,
        //branchName: "$branchs.branchName",
        vin: "$inventorys.vin",
        year: "$inventorys.year",
        //makeName: "$makes.makeName",
        //modelName: "$models.modelName",
        milage: "$inventorys.milage",
        costPrice: "$inventorys.costPrice",
        reservePrice: "$inventorys.reservePrice",
        startingBid: "$inventorys.startingBid",
        auctionDate: 1,
        auctionClose: 1,
        auctionNo: 1,
        auctionTime: 1,
        inventorys: 1,
        duration: 1,
        auctionType: 1,
        auctionvehiclesId: "$auctionvehicles._id",
        createdAt: 1,
        displayNo: "$auctionvehicles.displayNo",
        singleImages: {
          $cond: {
            if: { $eq: ["$singlevinimages", []] },
            then: config.defaultInventoryImage,
            else: { $arrayElemAt: ["$singlevinimages.image", 0] },
          },
        },
        totalUnsoldCar: {
          $size: "$auctionPendingCar",
        },
      },
    });

    if (postData?.sortbydisplayNo) {
      query.push({ $sort: { displayNo: 1 } });
    } else {
      query.push({ $sort: { auctionDate: -1 } });
    }

    if (postData.page) {
      query.push({
        $skip: cmethod.pageOffset(postData.page, postData.pageLimit),
      });
      query.push({ $limit: cmethod.pageLimit(postData.pageLimit) });
    }

    auctionDao
      .findAuctionAggregation(query)
      .then(function (data) {
        const totalCount = (data && data.length) || 0;

        res.status(200).json({
          status: true,
          result: data,
          message: "",
          hasMore: cmethod.hasMoreCount(
            totalCount,
            postData.page,
            postData.pageLimit
          ),
          totalCount,
        });
      })
      .catch((err) => {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      });
  }
);
router.post(
  "/auctionlist",
  [midleware.validateFieldValue(["pageLimit", "page"], ["pageLimit", "page"])],
  (req, res) => {
    // console.log("washi first routing")
    let lang = req.headers["lang"] || config.lang;
    let postData = req.body;
    let query = [];

    //add branch lookup
    query.push({
      $lookup: {
        from: "branchs",
        localField: "branchId",
        foreignField: "_id",
        as: "branchs",
      },
    });
    query.push({
      $unwind: { path: "$branchs", preserveNullAndEmptyArrays: true },
    });
    query.push({
      $lookup: {
        from: "auctionvehicles",
        let: {
          auctionId: "$_id",
          status: "pending",
        },
        pipeline: [
          {
            $match: {
              $expr: {
                $and: [
                  { $eq: ["$$auctionId", "$auctionId"] },
                  { $eq: ["$status", "$$status"] },
                ],
              },
            },
          },
        ],
        as: "auctionPendingCar",
      },
    });
    if (postData.closeauctionDate) {
      query.push({
        $match: {
          $and: [
            {
              auctionDate: {
                $gt: new Date(
                  cmethod.startTimeString(new Date(postData.closeauctionDate))
                ),
              },
            },
          ],
        },
      });
    }
    if (postData.fromData && postData.toData) {
      query.push({
        $match: {
          $and: [
            {
              auctionDate: {
                $gte: new Date(
                  cmethod.startTimeString(new Date(postData.fromData))
                ),
              },
            },
            {
              auctionDate: {
                $lte: new Date(
                  cmethod.endTimeString(new Date(postData.toData))
                ),
              },
            },
          ],
        },
      });
    }
    if (postData.search) {
      query.push({
        $match: {
          $and: [
            {
              $or: [
                { auctionDate: { $regex: postData.search, $options: "i" } },
              ],
            },
          ],
        },
      });
    } else if (postData.auctionId) {
      query.push({
        $match: {
          _id: mongoose.Types.ObjectId(postData.auctionId),
        },
      });
    } else if (postData.searchAuction) {
      query.push({
        $match: {
          $and: [
            {
              $or: [
                { title: { $regex: postData.searchAuction, $options: "i" } },
                {
                  auctionNo: { $regex: postData.searchAuction, $options: "i" },
                },
                {
                  auctionDate: {
                    $regex: postData.searchAuction,
                    $options: "i",
                  },
                },
              ],
            },
          ],
        },
      });
      // }
    }
    // query.push({
    //   $match: {
    //     $and: [{ inventoryId:{$exists:true,$ne:'[]'} }],
    //   },
    // });
    //get only that inventory which is auction not done

    if (postData.auctionClose) {
      query.push({
        $match: {
          $and: [
            {
              auctionClose: Number(postData.auctionClose),
            },
          ],
        },
      });
    }
    if (postData?.pendingcar) {
      query.push({
        $match: {
          $expr: {
            $gt: [{ $size: "$auctionPendingCar" }, 0],
          },
        },
      });
    }
    if (postData?.branchId?.length > 0) {
      let branchData = [];
      let pdata = postData.branchId;
      for (let i in pdata) {
        branchData.push(mongoose.Types.ObjectId(pdata[i]));
      }

      query.push({
        $match: {
          $and: [
            {
              branchId: {
                $in: branchData,
              },
            },
          ],
        },
      });
    }

    query.push({
      $project: {
        title: 1,
        branchName: "$branchs.branchName",
        branchId: "$branchs._id",
        auctionDate: 1,
        auctionClose: 1,
        auctionNo: 1,
        auctionTime: 1,
        duration: 1,
        auctionType: 1,
        image: {
          $cond: {
            if: { $eq: ["$image", ""] },
            then: config.defaultAuctionImage,
            else: "$image",
          },
        },
        createdAt: 1,
        totalUnsoldCar: { $size: "$auctionPendingCar" },
      },
    });

    if (postData?.orderBy) {
      query.push({ $sort: { auctionDate: 1 } });
    } else {
      query.push({ $sort: { auctionDate: -1 } });
    }

    if (postData.page) {
      query.push({
        $skip: cmethod.pageOffset(postData.page, postData.pageLimit),
      });
      query.push({ $limit: cmethod.pageLimit(postData.pageLimit) });
    }

    auctionDao
      .findAuctionAggregation(query)
      .then(function (data) {
        const totalCount = (data && data.length) || 0;

        res.status(200).json({
          status: true,
          result: data,
          message: "",
          hasMore: cmethod.hasMoreCount(
            totalCount,
            postData.page,
            postData.pageLimit
          ),
          totalCount,
        });
      })
      .catch((err) => {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      });
  }
);
router.post(
  "/searchVinAuction",
  [
    midleware.validateFieldValue(
      ["pageLimit", "page"], //, "search", "auctionId"
      ["page"]
    ),
  ],
  (req, res) => {
    // console.log("washi first routing")
    let lang = req.headers["lang"] || config.lang;
    let postData = req.body;
    let query = [];
    console.log("===>", postData.auctionId.length);
    if (postData.auctionId) {
      let allAuctionId = [];
      for (var i = 0; i < postData.auctionId.length; i++) {
        allAuctionId.push(mongoose.Types.ObjectId(postData.auctionId[i]));
      }
      query.push({
        $match: {
          _id: { $in: allAuctionId },
        },
      });
      query.push({
        $lookup: {
          from: "auctionvehicles",
          localField: "_id",
          foreignField: "auctionId",
          as: "auctionvehicles",
        },
      });
      query.push({
        $unwind: { path: "$auctionvehicles", preserveNullAndEmptyArrays: true },
      });
      query.push({
        $lookup: {
          from: "inventorys",
          localField: "auctionvehicles.inventoryId",
          foreignField: "_id",
          as: "inventorys",
        },
      });

      query.push({
        $unwind: { path: "$inventorys", preserveNullAndEmptyArrays: true },
      });
      query.push({
        $lookup: {
          from: "makes",
          localField: "inventorys.make",
          foreignField: "_id",
          as: "makes",
        },
      });
      query.push({
        $unwind: { path: "$makes", preserveNullAndEmptyArrays: true },
      });
      query.push({
        $lookup: {
          from: "models",
          localField: "inventorys.model",
          foreignField: "_id",
          as: "models",
        },
      });
      query.push({
        $unwind: { path: "$models", preserveNullAndEmptyArrays: true },
      });
      query.push({
        $lookup: {
          from: "series",
          localField: "inventorys.seriesId",
          foreignField: "_id",
          as: "series",
        },
      });
      query.push({
        $unwind: { path: "$series", preserveNullAndEmptyArrays: true },
      });
      //for search vin no
      if (postData.search) {
        query.push({
          $match: {
            $and: [
              { "inventorys.vin": { $regex: postData.search, $options: "i" } },
            ],
          },
        });
      }
      if (postData.inventoryStatus) {
        query.push({
          $match: {
            $and: [{ "inventorys.inventoryStatus": postData.inventoryStatus }],
          },
        });
      }
      query.push({
        $lookup: {
          from: "users",
          localField: "inventorys.sellerId",
          foreignField: "_id",
          as: "users",
        },
      });
      query.push({
        $unwind: { path: "$users", preserveNullAndEmptyArrays: true },
      });
    } else {
      query.push({
        $match: {
          $and: [{ inventoryId: { $exists: true } }],
        },
      });
    }

    const sQuery = [...query];
    query.push({
      $project: {
        title: 1,
        auctionDate: 1,
        auctionTime: 1,
        inventorys: 1,
        users: 1,
        make: "$makes",
        model: "$models",
        series: "$series",
        year: "$inventorys.year",
        auctionVehicleId: "$auctionvehicles._id",
      },
    });

    query.push({ $sort: { createdAt: -1 } });
    sQuery.push({ $count: "recordCount" });

    if (postData.page) {
      query.push({
        $skip: cmethod.pageOffset(postData.page, postData.pageLimit),
      });
      query.push({ $limit: cmethod.pageLimit(postData.pageLimit) });
    }

    auctionDao
      .findAuctionAggregation(query)
      .then(function (data) {
        auctionDao
          .findAuctionAggregation(sQuery)
          .then(async function (dcount) {
            let tptCnt = 0;
            if (dcount.length > 0) {
              tptCnt = dcount[0].recordCount;
            }
            res.status(200).json({
              status: true,
              result: data,
              message: "",
              hasMore: cmethod.hasMoreCount(
                tptCnt,
                postData.page,
                postData.pageLimit
              ),
              totalCount: tptCnt,
            });
          })
          .catch((err) => {
            cmethod.returnSreverError(res, message[lang].technicalError, err);
          });
      })
      .catch((err) => {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      });
  }
);
router.post(
  "/auctionvehicleslist",
  [midleware.validateFieldValue(["pageLimit", "page"], ["pageLimit", "page"])],
  (req, res) => {
    // console.log("washi first routing")
    let lang = req.headers["lang"] || config.lang;
    let postData = req.body;
    let query = [];
    const userId = makeObjectId(postData?.userId);

    query.push({
      $lookup: {
        from: "inventorys",
        localField: "inventoryId",
        foreignField: "_id",
        as: "inventorys",
      },
    });
    query.push({
      $unwind: { path: "$inventorys", preserveNullAndEmptyArrays: true },
    });

    // * watchlist
    query.push({
      $lookup: {
        from: "watchlists",
        let: {
          inventoryId: "$inventoryId",
        },
        pipeline: [
          {
            $match: {
              $expr: {
                $and: [
                  { $eq: ["$inventoryId", "$$inventoryId"] },
                  { $eq: ["$buyerId", userId] },
                ],
              },
            },
          },
        ],
        as: "watchlists",
      },
    });

    query.push({
      $lookup: {
        from: "branchs",
        localField: "branchId",
        foreignField: "_id",
        as: "branchs",
      },
    });
    query.push({
      $unwind: { path: "$branchs", preserveNullAndEmptyArrays: true },
    });
    query.push({
      $lookup: {
        from: "makes",
        localField: "inventorys.make",
        foreignField: "_id",
        as: "makes",
      },
    });
    query.push({
      $unwind: { path: "$makes", preserveNullAndEmptyArrays: true },
    });
    query.push({
      $lookup: {
        from: "models",
        localField: "inventorys.model",
        foreignField: "_id",
        as: "models",
      },
    });
    query.push({
      $unwind: { path: "$models", preserveNullAndEmptyArrays: true },
    });
    query.push({
      $lookup: {
        from: "warehouses",
        localField: "inventorys.warehosId",
        foreignField: "_id",
        as: "warehouses",
      },
    });
    query.push({
      $unwind: { path: "$warehouses", preserveNullAndEmptyArrays: true },
    });
    query.push({
      $lookup: {
        from: "bodys",
        localField: "inventorys.bodyId",
        foreignField: "_id",
        as: "bodys",
      },
    });
    query.push({
      $unwind: { path: "$bodys", preserveNullAndEmptyArrays: true },
    });
    query.push({
      $lookup: {
        from: "series",
        localField: "inventorys.seriesId",
        foreignField: "_id",
        as: "series",
      },
    });
    query.push({
      $unwind: { path: "$series", preserveNullAndEmptyArrays: true },
    });
    query.push({
      $lookup: {
        from: "fueltypes",
        localField: "inventorys.fueltypeId",
        foreignField: "_id",
        as: "fueltypes",
      },
    });
    query.push({
      $unwind: { path: "$fueltypes", preserveNullAndEmptyArrays: true },
    });
    query.push({
      $lookup: {
        from: "drivetypes",
        localField: "inventorys.drivetypeId",
        foreignField: "_id",
        as: "drivetypes",
      },
    });
    query.push({
      $unwind: { path: "$drivetypes", preserveNullAndEmptyArrays: true },
    });
    query.push({
      $lookup: {
        from: "engines",
        localField: "inventorys.engineId",
        foreignField: "_id",
        as: "engines",
      },
    });
    query.push({
      $unwind: { path: "$engines", preserveNullAndEmptyArrays: true },
    });
    query.push({
      $lookup: {
        from: "interiorcolors",
        localField: "inventorys.interiorcolorId",
        foreignField: "_id",
        as: "interiorcolors",
      },
    });
    query.push({
      $unwind: { path: "$interiorcolors", preserveNullAndEmptyArrays: true },
    });
    query.push({
      $lookup: {
        from: "exteriorcolors",
        localField: "inventorys.exteriorcolorId",
        foreignField: "_id",
        as: "exteriorcolors",
      },
    });
    query.push({
      $unwind: { path: "$exteriorcolors", preserveNullAndEmptyArrays: true },
    });

    query.push({
      $lookup: {
        from: "users",
        localField: "inventorys.sellerId",
        foreignField: "_id",
        as: "users",
      },
    });
    query.push({
      $unwind: { path: "$users", preserveNullAndEmptyArrays: true },
    });
    query.push({
      $lookup: {
        from: "vinimages",
        // localField: "salesUserId",
        // foreignField: "_id",
        let: {
          inventoryId: "$inventoryId",
          imageType: "inventory",
          type: "carimage",
        },
        pipeline: [
          {
            $match: {
              $expr: {
                $and: [
                  { $eq: ["$imageType", "$$imageType"] },
                  { $eq: ["$type", "$$type"] },
                  { $eq: ["$referenceId", "$$inventoryId"] },
                ],
              },
            },
          },
        ],
        as: "vinimages",
      },
    });
    query.push({
      $lookup: {
        from: "vinimages",
        // localField: "salesUserId",
        // foreignField: "_id",
        let: {
          inventoryId: "$inventoryId",
          imageType: "inventory",
          type: "carimage",
        },
        pipeline: [
          {
            $match: {
              $expr: {
                $and: [
                  { $eq: ["$imageType", "$$imageType"] },
                  { $eq: ["$type", "$$type"] },
                  { $eq: ["$referenceId", "$$inventoryId"] },
                ],
              },
            },
          },
        ],
        as: "singlevinimages",
      },
    });
    if (postData.status) {
      if (postData.status == "sold") {
        query.push({
          $match: { $or: [{ status: postData.status }, { status: "unsold" }] },
        });
      } else {
        query.push({
          $match: {
            status: postData.status,
          },
        });
      }
    }
    if (postData?.statusList) {
      query.push({
        $match: {
          $and: [{ status: { $in: postData.statusList } }],
        },
      });
    }
    if (postData.inventoryStatus) {
      query.push({
        $match: {
          "inventorys.inventoryStatus": Number(postData.inventoryStatus),
        },
      });
    }
    if (postData.sellerId) {
      query.push({
        $match: {
          $and: [
            {
              "inventorys.sellerId": mongoose.Types.ObjectId(postData.sellerId),
            },
          ],
        },
      });
    }
    if (postData.auctionvehivleId) {
      query.push({
        $match: {
          _id: mongoose.Types.ObjectId(postData.auctionvehivleId),
        },
      });
    }
    if (postData.auctionId) {
      query.push({
        $match: {
          auctionId: mongoose.Types.ObjectId(postData.auctionId),
        },
      });
    }
    const sQuery = [...query];
    query.push({
      $project: {
        auctionId: 1,
        title: 1,
        inventoryId: "$inventorys._id",
        branchId: 1,
        branchName: "$branchs.branchName",
        vin: "$inventorys.vin",
        lotNo: "$inventorys.lotNo",
        year: "$inventorys.year",
        isAddedInWatchList: {
          $cond: {
            if: { $eq: ["$watchlists", []] },
            then: false,
            else: true,
          },
        },
        watchlistId: "$watchlists._id",
        // make: "$makes.makeName",
        // makeId: "$makes._id",
        // model: "$models.modelName",
        // modelId: "$models._id",
        // warehouses: "$warehouses.warehouseName",
        // warehosId: "$warehouses._id",
        bodys: "$bodys.bodyName",
        bodyId: "$bodys._id",
        drivetypes: "$drivetypes.drivetypeName",
        drivetypeId: "$drivetypes._id",
        fueltypes: "$fueltypes.fueltypeName",
        fueltypeId: "$fueltypes._id",
        series: "$series.seriesName",
        seriesId: "$series._id",
        engines: "$engines.engineName",
        engineId: "$engines._id",
        exteriorcolorId: "$exteriorcolors._id",
        excolorCode: "$exteriorcolors.colorCode",
        color: "$exteriorcolors.colorName",
        interiorcolorId: "$interiorcolors._id",
        incolorCode: "$interiorcolors.colorCode",
        interiorcolors: "$interiorcolors.colorName",
        make: "$makes.makeName",
        makeId: "$makes._id",
        model: "$models.modelName",
        modelId: "$models._id",
        warehouses: "$warehouses.warehouseName",
        warehosId: "$warehouses._id",
        milage: "$inventorys.milage",
        costPrice: "$inventorys.costPrice",
        invoicePrice: "$inventorys.invoicePrice",
        reservePrice: "$inventorys.reservePrice",
        startingBid: "$inventorys.startingBid",
        displayNo: 1,
        status: 1,
        singleImages: {
          $cond: {
            if: { $eq: ["$singlevinimages", []] },
            then: config.defaultInventoryImage,
            else: { $arrayElemAt: ["$singlevinimages.image", 0] },
          },
        },
        vinimages: 1,
        createdAt: 1,
        sellerId: {
          $cond: {
            if: { $eq: ["$users", {}] },
            then: "",
            else: "$users._id",
          },
        },
        bidAmount: 1,
        carDescription: {
          $concat: [
            "$inventorys.year",
            " ",
            "$makes.makeName",
            " ",
            "$models.modelName",
          ],
        },
      },
    });

    query.push({ $sort: { displayNo: 1 } });
    sQuery.push({ $count: "recordCount" });

    if (postData.page) {
      query.push({
        $skip: cmethod.pageOffset(postData.page, postData.pageLimit),
      });
      query.push({ $limit: cmethod.pageLimit(postData.pageLimit) });
    }

    auctionDao
      .findAuctionvehicleAggregation(query)
      .then(function (data) {
        auctionDao
          .findAuctionvehicleAggregation(sQuery)
          .then(async function (dcount) {
            let tptCnt = 0;
            if (dcount.length > 0) {
              tptCnt = dcount[0].recordCount;
            }
            res.status(200).json({
              status: true,
              result: data,
              message: "",
              hasMore: cmethod.hasMoreCount(
                tptCnt,
                postData.page,
                postData.pageLimit
              ),
              totalCount: tptCnt,
            });
          })
          .catch((err) => {
            cmethod.returnSreverError(res, message[lang].technicalError, err);
          });
      })
      .catch((err) => {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      });
  }
);
router.post(
  "/auctionvehiclesReport",
  [
    midleware.validateFieldValue(
      ["auctionId", "pageLimit", "page"],
      ["auctionId", "pageLimit", "page"]
    ),
  ],
  async (req, res) => {
    let lang = req.headers["lang"] || config.lang;
    let postData = req.body;
    let query = [];

    if (postData.auctionId) {
      query.push({
        $match: {
          auctionId: mongoose.Types.ObjectId(postData.auctionId),
        },
      });
    }
    // * inventorys
    query.push({
      $lookup: {
        from: "inventorys",
        localField: "inventoryId",
        foreignField: "_id",
        as: "inventorys",
      },
    });
    query.push({
      $unwind: { path: "$inventorys", preserveNullAndEmptyArrays: true },
    });

    // * makes
    query.push({
      $lookup: {
        from: "makes",
        localField: "inventorys.make",
        foreignField: "_id",
        as: "makes",
      },
    });
    query.push({
      $unwind: { path: "$makes", preserveNullAndEmptyArrays: true },
    });

    // * models
    query.push({
      $lookup: {
        from: "models",
        localField: "inventorys.model",
        foreignField: "_id",
        as: "models",
      },
    });
    query.push({
      $unwind: { path: "$models", preserveNullAndEmptyArrays: true },
    });

    // * users
    query.push({
      $lookup: {
        from: "users",
        localField: "inventorys.sellerId",
        foreignField: "_id",
        as: "users",
      },
    });
    query.push({
      $unwind: { path: "$users", preserveNullAndEmptyArrays: true },
    });

    // * soldCars
    const _let = {
      inventoryId: "$inventoryId",
      auctionId: makeObjectId(postData.auctionId),
    };
    const _pipeline = [
      {
        $match: {
          $expr: {
            $and: [
              { $eq: ["$inventoryId", "$$inventoryId"] },
              { $eq: ["$auctionId", "$$auctionId"] },
            ],
          },
        },
      },
    ];
    LookupWithPipeline(query, "reciepts", _let, _pipeline, "soldCars");
    query.push({
      $unwind: { path: "$soldCars", preserveNullAndEmptyArrays: true },
    });

    // * buyer
    Lookup(query, "users", "soldCars.buyerId", "_id", "buyer");
    Unwind(query, "$buyer");

    let allMarkAccountId = await accountModal.Accountmaster.find({
      markAccountId: {
        $in: [
          "cash-in-hand",
          "cash-in-bank-sajja",
          "cash-in-bank-ind",
          "cash-in-bank-sharj",
        ],
      },
    }).sort({ createdAt: 1 });
    let glAccountId = allMarkAccountId.map((account) =>
      mongoose.Types.ObjectId(account._id)
    );

    query.push({
      $lookup: {
        from: "accountledgers",
        let: {
          recieptNo: "$soldCars.recieptNo",
          glAccountIds: glAccountId,
        },
        pipeline: [
          {
            $match: {
              $expr: {
                $and: [
                  { $eq: ["$referenceNo", "$$recieptNo"] },
                  // { $in: ["$glAccountId", "$$glAccountIds"] },
                  {
                    $gte: [
                      "$glAccountId",
                      { $arrayElemAt: ["$$glAccountIds", 0] },
                    ],
                  },
                  {
                    $lte: [
                      "$glAccountId",
                      { $arrayElemAt: ["$$glAccountIds", -1] },
                    ],
                  },
                ],
              },
            },
          },
          {
            $limit: 300,
          },
        ],
        as: "accountledgers",
      },
    });

    if (postData.status) {
      query.push({
        $match: {
          status: postData.status,
        },
      });
    }
    if (postData?.inventoryStatus) {
      query.push({
        $match: {
          "inventorys.inventoryStatus": Number(postData?.inventoryStatus),
        },
      });
    }
    if (postData.sellerId) {
      query.push({
        $match: {
          $and: [
            {
              "inventorys.sellerId": mongoose.Types.ObjectId(postData.sellerId),
            },
          ],
        },
      });
    }
    let sellerData = [];
    if (postData.sellerIds) {
      let pdata = postData.sellerIds;
      for (let i in pdata) {
        sellerData.push(mongoose.Types.ObjectId(pdata[i]));
      }
      query.push({
        $match: {
          $and: [
            {
              "inventorys.sellerId": {
                $in: sellerData,
              },
            },
          ],
        },
      });
    }

    // * project
    query.push({
      $project: {
        title: 1,
        displayOrder: 1,
        verifyStatus: 1,
        inventoryId: 1,
        vin: "$inventorys.vin",
        make: "$makes.makeName",
        model: "$models.modelName",
        year: "$inventorys.year",
        milage: "$inventorys.milage",
        costPrice: "$inventorys.costPrice",
        reservePrice: "$inventorys.reservePrice",
        startingBid: "$inventorys.startingBid",
        displayNo: 1,
        status: 1,
        bidAmount: 1,
        sellerName: {
          $cond: {
            if: { $eq: ["$users", {}] },
            then: "",
            else: "$users.name",
          },
        },
        sellerId: "$users._id",
        soldPrice: "$soldCars.saleAmount",
        downPayment: { $arrayElemAt: ["$accountledgers.payAmount", 0] },
        paymentMethod: { $arrayElemAt: ["$accountledgers.paymentType", 0] },
        recieptId: "$soldCars._id",
        receipt: {
          receiptNo: "$soldCars.recieptNo",
          securityAmount: "$soldCars.securityAmount",
          paidAmount: "$soldCars.paidAmount",
        },
        buyer: {
          name: "$buyer.name",
          phone: "$buyer.phone",
          userType: "$buyer.userType",
          companyDetails: "$buyer.companyDetails",
        },
        seller: {
          name: "$users.name",
          phone: "$users.phone",
          userType: "$users.userType",
          companyDetails: "$users.companyDetails",
        },
        export: "$soldCars.export",
        exportCountry: "$soldCars.exportCountry",
      },
    });

    query.push({ $sort: { displayNo: 1 } });

    if (postData.page) {
      query.push({
        $skip: cmethod.pageOffset(postData.page, postData.pageLimit),
      });
      // query.push({ $limit: cmethod.pageLimit(postData.pageLimit) });
      query.push({ $limit: cmethod.pageLimit(300) });
    }

    auctionDao
      .findAuctionvehicleAggregation(query)
      .then(function (data) {
        res.status(200).json({
          status: true,
          result: data,
          message: "",
          hasMore: false,
          totalCount: 0,
        });
      })
      .catch((err) => {
        console.log(err);
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      });
  }
);
router.post(
  "/auctionvehiclesHistory",
  [midleware.validateFieldValue(["inventoryId"], ["auctionId"])],
  (req, res) => {
    // console.log("washi first routing")
    let lang = req.headers["lang"] || config.lang;
    let postData = req.body;
    let query = [];

    // * inventorys
    query.push({
      $lookup: {
        from: "inventorys",
        localField: "inventoryId",
        foreignField: "_id",
        as: "inventorys",
      },
    });
    query.push({
      $unwind: { path: "$inventorys", preserveNullAndEmptyArrays: true },
    });

    // * auctions
    query.push({
      $lookup: {
        from: "auctions",
        localField: "auctionId",
        foreignField: "_id",
        as: "auctions",
      },
    });
    query.push({
      $unwind: { path: "$auctions", preserveNullAndEmptyArrays: true },
    });

    if (postData.inventoryId) {
      query.push({
        $match: {
          inventoryId: mongoose.Types.ObjectId(postData.inventoryId),
        },
      });
    }

    // * project
    query.push({
      $project: {
        title: "$auctions.title",
        auctionDate: "$auctions.auctionDate",
        //displayOrder: 1,
        lotNo: "$inventorys.lotNo",
        startingBid: "$inventorys.startingBid",
        bidAmount: 1,
        displayNo: 1,
        status: "$inventorys.status",
        inventoryStatus: "$inventorys.inventoryStatus",
        auctionVehicleStatus: "$status",
      },
    });

    // * sort
    query.push({ $sort: { auctionDate: -1 } });

    // if (postData.page) {
    //   query.push({
    //     $skip: cmethod.pageOffset(postData.page, postData.pageLimit),
    //   });
    //   query.push({ $limit: cmethod.pageLimit(postData.pageLimit) });
    // }

    auctionDao
      .findAuctionvehicleAggregation(query)
      .then(function (data) {
        res.status(200).json({
          status: true,
          result: data,
          message: "",
          hasMore: false,
          totalCount: 0,
        });
      })
      .catch((err) => {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      });
  }
);

router.post(
  "/update-order",
  [midleware.validateFieldValue([], [])],
  (req, res) => {
    let postData = req.body;
    let query = [];
    let data = postData.data;
    if (data.length > 0) {
      for (let i = i; i < data.length; i++) {
        auctionDao.updateAuctionvehicle(
          { _id: mongoose.Types.ObjectId(data[0]._id) },
          { $set: { displayNo: data[0].displayNo } }
        );
      }
    }
    cmethod.returnSuccess(res, [], false, " Order Set Successfully set");
  }
);

// * vehicle-screening
router.post(
  "/vehicle-screening",
  [midleware.validateFieldValue(["pageLimit", "page"], ["pageLimit", "page"])],
  async (req, res) => {
    const { body, headers } = req;
    const lang = headers.lang || config.lang;
    const query = [];

    try {
      const vehicleStatus = ["Sold"];

      // * match
      query.push({
        $match: { status: { $in: vehicleStatus } },
      });

      if (body.startDate && body.endDate) {
        const start = new Date(body.startDate);
        const end = new Date(body.endDate);

        query.push({
          $match: {
            createdAt: {
              $gte: start,
              $lte: end,
            },
          },
        });
      }

      if (body.auctionId) {
        query.push({
          $match: {
            auctionId: mongoose.Types.ObjectId(body.auctionId),
          },
        });
      }

      if (body.buyerId) {
        query.push({
          $match: {
            $and: [
              {
                userId: mongoose.Types.ObjectId(body.buyerId),
              },
            ],
          },
        });
      }

      if (body.status) {
        query.push({
          $match: {
            status: body.status,
          },
        });
      }

      // * inventorys
      query.push({
        $lookup: {
          from: "inventorys",
          localField: "inventoryId",
          foreignField: "_id",
          as: "inventorys",
        },
      });
      query.push({
        $unwind: { path: "$inventorys", preserveNullAndEmptyArrays: true },
      });

      // * makes
      query.push({
        $lookup: {
          from: "makes",
          localField: "inventorys.make",
          foreignField: "_id",
          as: "makes",
        },
      });
      query.push({
        $unwind: { path: "$makes", preserveNullAndEmptyArrays: true },
      });

      // * models
      query.push({
        $lookup: {
          from: "models",
          localField: "inventorys.model",
          foreignField: "_id",
          as: "models",
        },
      });
      query.push({
        $unwind: { path: "$models", preserveNullAndEmptyArrays: true },
      });

      // * buyerUser
      query.push({
        $lookup: {
          from: "users",
          localField: "userId",
          foreignField: "_id",
          as: "buyerUser",
        },
      });
      query.push({
        $unwind: { path: "$buyerUser", preserveNullAndEmptyArrays: true },
      });

      // * sellerUser
      query.push({
        $lookup: {
          from: "users",
          localField: "inventorys.sellerId",
          foreignField: "_id",
          as: "sellerUser",
        },
      });
      query.push({
        $unwind: { path: "$sellerUser", preserveNullAndEmptyArrays: true },
      });

      // * receipts
      query.push({
        $lookup: {
          from: "reciepts",
          let: {
            buyerId: "$userId",
            auctionId: "$auctionId",
            inventoryId: "$inventoryId",
          },
          pipeline: [
            {
              $match: {
                $expr: {
                  $and: [
                    { $eq: ["$buyerId", "$$buyerId"] },
                    { $eq: ["$auctionId", "$$auctionId"] },
                    { $eq: ["$inventoryId", "$$inventoryId"] },
                  ],
                },
              },
            },
          ],
          as: "receipts",
        },
      });

      // * auctionVehicle
      query.push({
        $lookup: {
          from: "auctionvehicles",
          let: { auctionId: "$auctionId", inventoryId: "$inventoryId" },
          pipeline: [
            {
              $match: {
                $expr: {
                  $and: [
                    { $eq: ["$auctionId", "$$auctionId"] },
                    { $eq: ["$inventoryId", "$$inventoryId"] },
                  ],
                },
              },
            },
          ],
          as: "auctionVehicle",
        },
      });
      query.push({
        $unwind: { path: "$auctionVehicle", preserveNullAndEmptyArrays: true },
      });

      // * auctions
      query.push({
        $lookup: {
          from: "auctions",
          localField: "auctionId",
          foreignField: "_id",
          as: "auctions",
        },
      });
      query.push({
        $unwind: { path: "$auctions", preserveNullAndEmptyArrays: true },
      });

      // * commentLogs
      const _let = {
        referenceId: "$_id",
        referenceType: "advance",
      };
      const _pipeline = [
        {
          $match: {
            $expr: {
              $and: [
                { $eq: ["$referenceId", "$$referenceId"] },
                { $eq: ["$referenceType", "$$referenceType"] },
              ],
            },
          },
        },
      ];
      LookupWithPipeline(query, "commentlogs", _let, _pipeline, "commentLogs");

      if (body.sellerId) {
        query.push({
          $match: {
            $and: [
              {
                "inventorys.sellerId": mongoose.Types.ObjectId(body.sellerId),
              },
            ],
          },
        });
      }

      if (body.vin) {
        query.push({
          $match: {
            $and: [
              {
                "inventorys.vin": regexSearch(body.vin),
              },
            ],
          },
        });
      }

      // * project
      query.push({
        $project: {
          _id: 1,
          auctionId: 1,
          inventoryId: 1,
          auctionTitle: "$auctions.title",
          branchId: "$inventorys.branchId",
          auctionVehicleId: "$auctionVehicle._id",
          createdAt: 1,
          wasAdminBid: 1,
          receiptId: { $arrayElemAt: ["$receipts._id", 0] },
          isReceiptCreated: {
            $cond: {
              if: { $eq: ["$receipts", []] },
              then: false,
              else: true,
            },
          },
          seller: {
            _id: "$sellerUser._id",
            name: "$sellerUser.name",
            email: "$sellerUser.email",
            phone: "$sellerUser.phone",
            countryCode: "$sellerUser.countryCode",
            countryIso: "$sellerUser.countryIso",
            userType: "$sellerUser.userType",
            businessType: "$sellerUser.businessType",
            creditLimit: "$sellerUser.creditLimit",
            walletAmount: "$sellerUser.walletAmount",
            companyDetails: "$sellerUser.companyDetails",
          },
          buyer: {
            _id: "$buyerUser._id",
            name: "$buyerUser.name",
            email: "$buyerUser.email",
            phone: "$buyerUser.phone",
            countryCode: "$buyerUser.countryCode",
            countryIso: "$buyerUser.countryIso",
            userType: "$buyerUser.userType",
            businessType: "$buyerUser.businessType",
            creditLimit: "$buyerUser.creditLimit",
            walletAmount: "$buyerUser.walletAmount",
            companyDetails: "$buyerUser.companyDetails",
          },
          inventory: {
            vin: "$inventorys.vin",
            make: "$makes.makeName",
            model: "$models.modelName",
            year: "$inventorys.year",
            milage: "$inventorys.milage",
            reservePrice: "$inventorys.reservePrice",
            startingBid: "$inventorys.startingBid",
            status: "$auctionVehicle.status",
            displayNo: "$auctionVehicle.displayNo",
            export: "$auctionVehicle.export",
            exportCountry: "$auctionVehicle.exportCountry",
          },
          bid: {
            currAmount: "$currAmount",
            counterOfferAmount: "$counterOfferAmount",
            calcAmount: "$calcAmount",
            biderCount: "$biderCount",
            status: "$status",
            bidType: "$bidType",
          },
          isAdvancePayment: {
            $cond: {
              if: { $eq: ["$commentLogs", []] },
              then: false,
              else: true,
            },
          },
        },
      });

      query.push({ $sort: { createdAt: -1 } });

      const sQuery = [...query];
      sQuery.push({ $count: "totalCount" });

      if (body.page) {
        query.push({
          $skip: cmethod.pageOffset(body.page, body.pageLimit),
        });
        query.push({ $limit: cmethod.pageLimit(body.pageLimit) });
      }

      const [result, [{ totalCount } = {}] = []] = await MultiAggregate(
        bidHistoryLog,
        [query, sQuery]
      );

      res.status(200).json({
        status: true,
        result,
        hasMore: cmethod.hasMoreCount(totalCount, body.page, body.pageLimit),
        totalCount,
      });
    } catch (error) {
      logger.error(error.message);
      cmethod.returnSreverError(
        res,
        message[lang]?.technicalError,
        error.message
      );
    }
  }
);

// * Get Auction By ID
router.post(
  "/get-auction",
  [midleware.validateFieldValue(["auctionId"], ["auctionId"])],
  async (req, res) => {
    const {
      body: { auctionId },
    } = req;

    const auction = await auctionModal.Auction.findById(auctionId);

    if (!auction) {
      cmethod.returrnErrorMessage(res, "auction not found!");
    } else {
      cmethod.returnSuccess(res, auction, false, message["eng"].Updated);
    }
  }
);

module.exports = router;
/**
 * @swagger
 * /api/auction/list:
 *   post:
 *     tags: [Auction]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: auctionId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: branchId
 *         in: formData
 *         type: array
 *         items:
 *           type: string
 *         required: false
 *         description:
 *       - name: closeauctionDate
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: search
 *         in: formData
 *         type: number
 *         required: false
 *         description:
 *       - name: vin
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: auctionClose
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *                1,0
 *       - name: status
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *                sold,unsold,pending
 *       - name: pageLimit
 *         in: formData
 *         type: number
 *         required: true
 *         description:
 *       - name: page
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: Auction List.
 *
 */

/**
 * @swagger
 * /api/auction/auctionlist:
 *   post:
 *     tags: [Auction]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: auctionId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: branchId
 *         in: formData
 *         type: array
 *         items:
 *           type: string
 *         required: false
 *         description:
 *       - name: closeauctionDate
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: search
 *         in: formData
 *         type: number
 *         required: false
 *         description:
 *       - name: auctionClose
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *                1,0
 *       - name: pendingcar
 *         in: formData
 *         type: boolean
 *         required: false
 *         description:
 *                1,0
 *       - name: fromData
 *         in: formData
 *         type: string
 *         required: false
 *         description: from date
 *       - name: toData
 *         in: formData
 *         type: string
 *         required: false
 *       - name: inventoryStatus
 *         in: formData
 *         type: number
 *         required: false
 *         description: to date
 *       - name: orderBy
 *         in: formData
 *         type: string
 *         required: false
 *         description: ex- auctionDate
 *       - name: pageLimit
 *         in: formData
 *         type: number
 *         required: true
 *         description:
 *       - name: page
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: Auction List.
 *
 */
/**
 * @swagger
 * /api/auction/auctionvehicleslist:
 *   post:
 *     tags: [Auction]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: auctionId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: auctionvehivleId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: sellerId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: status
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *          ex- pending,sold,unsold,cancel
 *       - name: inventoryStatus
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *          ex- 1=in stock,2=in auction,3=sold,
 *       - name: pageLimit
 *         in: formData
 *         type: number
 *         required: true
 *         description:
 *       - name: page
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: auctionvehicleslist.
 *
 */
/**
 * @swagger
 * /api/auction/auctionvehiclesReport:
 *   post:
 *     tags: [Auction]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: auctionId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: sellerId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: sellerIds[]
 *         in: formData
 *         type: array
 *         items:
 *           type: string
 *         required: false
 *         description:
 *       - name: status
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: pageLimit
 *         in: formData
 *         type: number
 *         required: true
 *         description:
 *       - name: page
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: auctionvehicleslist.
 *
 */
/**
 * @swagger
 * /api/auction/auctionvehiclesHistory:
 *   post:
 *     tags: [Auction]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: inventoryId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: auctionvehiclesHistory.
 *
 */
/**
 * @swagger
 * /api/auction/searchVinAuction:
 *   post:
 *     tags: [Auction]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: search
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: auctionId[]
 *         in: formData
 *         type: array
 *         items:
 *           type: string
 *         required: true
 *         description:
 *       - name: pageLimit
 *         in: formData
 *         type: number
 *         required: true
 *         description:
 *       - name: page
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: Auction List.
 *
 */
/**
 * @swagger
 * /api/auction/add:
 *   post:
 *     tags: [Auction]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: branchId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: title
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: auctionDate
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: auctionTime
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: inventoryId[]
 *         in: formData
 *         type: array
 *         items:
 *           type: string
 *         collectionFormat: multi
 *         required: true
 *         description:
 *       - name: auctionNo
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: status
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *     responses:
 *       200:
 *         description: Auction Add.
 *
 */
/**
 * @swagger
 * /api/auction/update:
 *   patch:
 *     tags: [Auction]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: auctionId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: branchId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: title
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: auctionDate
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: auctionTime
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: inventoryId[]
 *         in: formData
 *         type: array
 *         items:
 *           type: string
 *         required: false
 *         description:
 *       - name: auctionNo
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: updateType
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: status
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *     responses:
 *       200:
 *         description: Auction Add.
 *
 */
/**
 * @swagger
 * /api/auction/allMarkUnsold:
 *   patch:
 *     tags: [Auction]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: auctionId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: branchId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: title
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: auctionDate
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: auctionTime
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: inventoryId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: auctionNo
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: updateType
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: status
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: bidAmount
 *         in: formData
 *         type: Number
 *         required: false
 *         description:
 *     responses:
 *       200:
 *         description: Auction Add.
 *
 */
/**
 * @swagger
 * /api/auction/addmore:
 *   post:
 *     tags: [Auction]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: inventoryId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: auctionId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: status
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: Auction Add.
 *
 */
/**
 * @swagger
 * /api/auction/removeAuctionVehicle:
 *   delete:
 *     tags: [Auction]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: auctionstockId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: inventoryId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: Auction delete.
 *
 */
/**
 * @swagger
 * /api/auction/auctionVehicleUpdate:
 *   patch:
 *     tags: [Auction]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: auctionVehicleId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: displayNo
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: verifyStatus
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *     responses:
 *       200:
 *         description: auctionVehicleUpdate.
 *
 */

/**
 * @swagger
 * /api/auction/vehicle-screening:
 *   post:
 *     tags: [Auction]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: auctionId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: sellerId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: buyerId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: status
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: startDate
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: endDate
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: pageLimit
 *         in: formData
 *         type: number
 *         required: true
 *         description:
 *       - name: page
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: Auction - Vehicle Screening.
 *
 */

/**
 * @swagger
 * /api/auction/get-auction:
 *   post:
 *     tags: [Auction]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: auctionId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: Auction - Get One
 *
 */
