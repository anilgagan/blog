const { number } = require("@hapi/joi");
const mongoose = require("mongoose");
const Schema = mongoose.Schema;
const { connWrite } = require("../../config/database");

const userroleSchema = new Schema(
  {
    userRole: String,
    status: { type: Number, default: 0 },
  },
  {
    timestamps: {
      createdAt: "createdAt",
      updatedAt: "updatedAt",
    },
  }
);
const yearSchema = new Schema(
  {
    yearName: String,
    status: { type: Number, default: 0 },
  },
  {
    timestamps: {
      createdAt: "createdAt",
      updatedAt: "updatedAt",
    },
  }
);
const modelSchema = new Schema(
  {
    makeId: {
      type: mongoose.Types.ObjectId,
      default: mongoose.Types.ObjectId(),
      index: true,
    },
    modelName: String,
    status: { type: Number, default: 0 },
  },
  {
    timestamps: {
      createdAt: "createdAt",
      updatedAt: "updatedAt",
    },
  }
);
const branchSchema = new Schema(
  {
    branchName: String,
    Trnno: String,
    fullbranchName: String,
    branchAddress: String,
    branchMobile: String,
    branchEmail: String,
    contactPerson1: String,
    contactPerson2: String,
    openingDay: String,
    branchImage: String,
    branchDesc: String,
    status: { type: Number, default: 0 },
  },
  {
    timestamps: {
      createdAt: "createdAt",
      updatedAt: "updatedAt",
    },
  }
);
const branchusermappingSchema = new Schema(
  {
    userId: {
      type: mongoose.Types.ObjectId,
      default: null,
      index: true,
    },
    branchId: {
      type: mongoose.Types.ObjectId,
      default: null,
      index: true,
    },
  },
  {
    timestamps: {
      createdAt: "createdAt",
      updatedAt: "updatedAt",
    },
  }
);
const makeSchema = new Schema(
  {
    makeName: String,
    status: { type: Number, default: 0 },
  },
  {
    timestamps: {
      createdAt: "createdAt",
      updatedAt: "updatedAt",
    },
  }
);
const seriesSchema = new Schema(
  {
    modelId: {
      type: mongoose.Types.ObjectId,
      default: mongoose.Types.ObjectId(),
      index: true,
    },
    seriesName: String,
    status: { type: Number, default: 0 },
  },
  {
    timestamps: {
      createdAt: "createdAt",
      updatedAt: "updatedAt",
    },
  }
);
const warehouseSchema = new Schema(
  {
    branchId: {
      type: mongoose.Types.ObjectId,
      default: mongoose.Types.ObjectId(),
      index: true,
    },
    warehouseName: String,
    status: { type: Number, default: 0 },
  },
  {
    timestamps: {
      createdAt: "createdAt",
      updatedAt: "updatedAt",
    },
  }
);
const buyerlimitSchema = new Schema(
  {
    package: { type: String, default: "" },
    deposit: { type: Number, default: 0 },
    creditlimit: { type: Number, default: 0 },
    purchaselimit: { type: Number, default: 0 },
    status: { type: Number, default: 0 },
  },
  {
    timestamps: {
      createdAt: "createdAt",
      updatedAt: "updatedAt",
    },
  }
);
const auctionfeeSchema = new Schema(
  {
    branchId: {
      type: mongoose.Types.ObjectId,
      default: mongoose.Types.ObjectId(),
      index: true,
    },
    startamount: { type: Number, default: 0 },
    endamount: { type: Number, default: 0 },
    handlingfee: { type: Number, default: 0 },
    status: { type: Number, default: 0 },
  },
  {
    timestamps: {
      createdAt: "createdAt",
      updatedAt: "updatedAt",
    },
  }
);
const handlingfeeSchema = new Schema(
  {
    branchId: {
      type: mongoose.Types.ObjectId,
      default: mongoose.Types.ObjectId(),
      index: true,
    },
    basePlan: { type: Number, default: 0 },
    premiumPlan: { type: Number, default: 0 },
    status: { type: Number, default: 0 },
  },
  {
    timestamps: {
      createdAt: "createdAt",
      updatedAt: "updatedAt",
    },
  }
);
const interiorcolorsSchema = new Schema(
  {
    colorName: String,
    colorCode: String,
    status: { type: Number, default: 0 },
  },
  {
    timestamps: {
      createdAt: "createdAt",
      updatedAt: "updatedAt",
    },
  }
);
const exteriorcolorsSchema = new Schema(
  {
    colorName: String,
    colorCode: String,
    status: { type: Number, default: 0 },
  },
  {
    timestamps: {
      createdAt: "createdAt",
      updatedAt: "updatedAt",
    },
  }
);
const bodySchema = new Schema(
  {
    bodyName: String,
    status: { type: Number, default: 0 },
  },
  {
    timestamps: {
      createdAt: "createdAt",
      updatedAt: "updatedAt",
    },
  }
);
const engineSchema = new Schema(
  {
    engineName: String,
    status: { type: Number, default: 0 },
  },
  {
    timestamps: {
      createdAt: "createdAt",
      updatedAt: "updatedAt",
    },
  }
);
const drivetypeSchema = new Schema(
  {
    drivetypeName: String,
    status: { type: Number, default: 0 },
  },
  {
    timestamps: {
      createdAt: "createdAt",
      updatedAt: "updatedAt",
    },
  }
);
const fueltypeSchema = new Schema(
  {
    fueltypeName: String,
    status: { type: Number, default: 0 },
  },
  {
    timestamps: {
      createdAt: "createdAt",
      updatedAt: "updatedAt",
    },
  }
);
const transmissionSchema = new Schema(
  {
    transName: String,
    status: { type: Number, default: 0 },
  },
  {
    timestamps: {
      createdAt: "createdAt",
      updatedAt: "updatedAt",
    },
  }
);
const cylindersSchema = new Schema(
  {
    cylinderName: String,
    status: { type: Number, default: 0 },
  },
  {
    timestamps: {
      createdAt: "createdAt",
      updatedAt: "updatedAt",
    },
  }
);
const menuSchema = new Schema(
  {
    parentId: {
      type: mongoose.Types.ObjectId,
      default: null,
      index: true,
    },
    menu: String,
    link: String,
    displayOrder: { type: Number, default: 0 },
    icon: String,
    status: { type: Number, default: 0 },
    custombtn: String,
  },
  {
    timestamps: {
      createdAt: "createdAt",
      updatedAt: "updatedAt",
    },
  }
);

const menuAccessSchema = new Schema(
  {
    userRoleId: {
      type: mongoose.Types.ObjectId,
      default: mongoose.Types.ObjectId(),
      index: true,
    },
    menuId: {
      type: mongoose.Types.ObjectId,
      default: mongoose.Types.ObjectId(),
      index: true,
    },
    read: { type: Number, default: 0 },
    add: { type: Number, default: 0 },
    edit: { type: Number, default: 0 },
    delete: { type: Number, default: 0 },
    import: { type: Number, default: 0 },
    export: { type: Number, default: 0 },
    custombtn: String,
  },
  {
    timestamps: {
      createdAt: "createdAt",
      updatedAt: "updatedAt",
    },
  }
);
const sellerplanSchema = new Schema(
  {
    branchId: {
      type: mongoose.Types.ObjectId,
      default: mongoose.Types.ObjectId(),
      index: true,
    },
    planName: String,
    listingFee: { type: Number, default: 0 },
    runs: { type: Number, default: 0 },
    auctionTypeFee: String,
    increment: { type: Number, default: 0 },
    amountValue: { type: Number, default: 0 },
    status: { type: Number, default: 0 },
    parkingDays: { type: Number, default: 0 },
    storage: { type: Number, default: 0 },
    initialfee: { type: Number, default: 0 },
    defaultbranchplan: { type: Number, default: 0 },
  },
  {
    timestamps: {
      createdAt: "createdAt",
      updatedAt: "updatedAt",
    },
  }
);

const serviceSchema = new Schema({
  _id: false,
  description: { type: String, required: true },
  quantity: { type: Number, required: true },
  rate: { type: Number, required: true },
  taxableAmount: { type: Number, required: true },
  taxRate: { type: Number, required: true },
  tax: { type: Number, required: true },
  amount: { type: Number, required: true },
});

const customServiceSchema = new Schema(
  {
    name: { type: String, required: true, unique: true, index: true },
    glId: {
      type: mongoose.Types.ObjectId,
      ref: "accountmasters",
      required: true,
      index: true,
    },
    status: { type: Number, default: 0 },
    services: { type: [serviceSchema], required: true },
  },
  { timestamps: true }
);

const Sellerplan = connWrite.model("sellerplans", sellerplanSchema);
const Fueltypes = connWrite.model("fueltypes", fueltypeSchema);
const Cylinders = connWrite.model("cylinders", cylindersSchema);
const Transmission = connWrite.model("transmissions", transmissionSchema);
const Userrole = connWrite.model("userroles", userroleSchema);
const Engines = connWrite.model("engines", engineSchema);
const Drivetype = connWrite.model("drivetypes", drivetypeSchema);
const Bodys = connWrite.model("bodys", bodySchema);
const interiorColor = connWrite.model("interiorcolors", interiorcolorsSchema);
const exteriorColor = connWrite.model("exteriorcolors", exteriorcolorsSchema);
const Auctionfee = connWrite.model("auctionfees", auctionfeeSchema);
const Handlingfee = connWrite.model("handlingfees", handlingfeeSchema);
const Buyerlimit = connWrite.model("buyerlimits", buyerlimitSchema);
const Warehouse = connWrite.model("warehouses", warehouseSchema);
const Series = connWrite.model("series", seriesSchema);
const Make = connWrite.model("makes", makeSchema);
const Branch = connWrite.model("branchs", branchSchema);
const Branchusermapping = connWrite.model(
  "branchusermappings",
  branchusermappingSchema
);
const Model = connWrite.model("models", modelSchema);
const Year = connWrite.model("years", yearSchema);

const Menu = connWrite.model("menus", menuSchema);
const Menuaccess = connWrite.model("menuaccesses", menuAccessSchema);
const CustomService = connWrite.model("CustomService", customServiceSchema);

module.exports = {
  Userrole,
  Year,
  Model,
  Branch,
  Branchusermapping,
  Make,
  Series,
  Warehouse,
  Buyerlimit,
  Auctionfee,
  Handlingfee,
  interiorColor,
  exteriorColor,
  Bodys,
  Engines,
  Drivetype,
  Transmission,
  Cylinders,
  Fueltypes,
  Sellerplan,
  Menu,
  Menuaccess,
  CustomService,
};
