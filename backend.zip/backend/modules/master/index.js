const express = require("express");
const router = express.Router();
const masterModal = require("../master/masterModal");
const message = require("../../config/message");
const reader = require("xlsx");
const config = require("../../config");
const midleware = require("../../middleware/validation");
const cmethod = require("../../middleware/common-fun");
const masterDao = require("./masterDao");
var mongoose = require("mongoose");
const excelJS = require("exceljs");
var multer = require("multer");
const path = require("path");

var fs = require("fs");
const { setCachedData, cacheMiddleware } = require("../../config/cache");
const { ExactMatch } = require("../../functions/mongoose.functions");
const DIR = "./public/temp";

const {
  createCustomService,
  getCustomServices,
  updateCustomService,
  deleteCustomService,
  getCustomService,
} = require("../../controllers/master.controller");

const fetchFilesFromReq = (req) => {
  if (req.file) {
    return [req.file];
  } else if (req.files) {
    return req.files;
  }
};
let storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, DIR);
  },
  filename: (req, file, cb) => {
    cb(
      null,
      file.fieldname + "-" + Date.now() + path.extname(file.originalname)
    );
  },
  onError: function (err, next) {
    console.log("error", err);
    next(err);
    res.send({ status: false, message: message.filenotUpdate });
  },
});
let uploadsFile = multer({ storage: storage });

router.post("/exportdata", async (req, res) => {
  const workbook = new excelJS.Workbook();
  const worksheet = workbook.addWorksheet("My Users");
  worksheet.columns = config.makeexport;
  let counter = 1;
  let query = [];
  query.push({
    $project: {
      makeName: 1,
      status: 1,
    },
  });
  makedata = await masterDao.findMakeAggregation(query);
  makedata.forEach((makes) => {
    makes._id = counter;
    worksheet.addRow(makes);
    counter++;
  });
  try {
    const data = await workbook.xlsx.writeFile(`users.xlsx`).then(() => {
      res.send({
        status: "success",
        message: "file successfully downloaded",
        path: `users.xlsx`,
      });
    });
  } catch (err) {
    res.send({
      status: "error",
      message: "Something went wrong",
    });
  }
});
router.post(
  "/add",
  [
    midleware.validateFieldValue(
      ["makeName", "status"],
      ["makeName", "status"]
    ),
  ],
  async (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;

    let makeval = postData.makeName;
    makeval = makeval.trim();
    let chkmakeName = {
      makeName: { $regex: new RegExp(`^${makeval}$`), $options: "i" },
    };

    masterDao.checkmakeName(chkmakeName).then(function (doc) {
      if (doc == true) {
        cmethod.returrnErrorMessage(res, message[lang].docExist);
      } else {
        masterDao.makeAdd(res, postData);
      }
    });
  }
);

// update User

router.patch(
  "/update",
  [midleware.validateFieldValue(["makeId"], ["makeId"])],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let xtoken = req.headers["x-access-token"];
    //{ token: xtoken },
    let queryCond = {
      $and: [{ _id: mongoose.Types.ObjectId(postData.makeId) }],
    };
    delete postData.makeId;
    //console.log("=======================>", req.body);
    masterModal.Make.findOneAndUpdate(
      queryCond,
      { $set: postData },
      { new: true },
      async function (err, data) {
        //console.log("user->", data);
        if (err) {
          cmethod.returnSreverError(res, message[lang].technicalError, err);
        } else {
          cmethod.returnSuccess(res, data, false, message[lang].profileUpdate);
        }
      }
    );
  }
);
router.post(
  "/sellerplanlist",
  [midleware.validateFieldValue(["pageLimit", "page"], ["page"])],
  async (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let query = [];
    if (postData.planName) {
      let planval = postData.planName;
      planval = planval.trim();
      query.push({
        $match: {
          $or: [
            { planName: { $regex: new RegExp(`^${planval}$`), $options: "i" } },
          ],
        },
      });
    }
    query.push({
      $lookup: {
        from: "branchs",
        localField: "branchId",
        foreignField: "_id",
        as: "branches",
      },
    });
    query.push({
      $unwind: { path: "$branches", preserveNullAndEmptyArrays: true },
    });

    if (postData.branchId) {
      query.push({
        $match: {
          $and: [{ branchId: mongoose.Types.ObjectId(postData.branchId) }],
        },
      });
    }
    let branchData = [];
    if (postData.branchIds) {
      let pdata = postData.branchIds;
      for (let i in pdata) {
        branchData.push(mongoose.Types.ObjectId(pdata[i]));
      }
      query.push({
        $match: {
          $and: [
            {
              branchId: {
                $in: branchData,
              },
            },
          ],
        },
      });
    }
    if (postData.sellerplanId) {
      query.push({
        $match: {
          $and: [{ _id: mongoose.Types.ObjectId(postData.sellerplanId) }],
        },
      });
    }
    if (postData.search) {
      query.push({
        $match: {
          $and: [
            {
              $or: [
                {
                  planName: {
                    $regex: postData.search,
                    $options: "i",
                  },
                },
                {
                  $expr: {
                    $regexMatch: {
                      input: { $toString: "$listingFee" },
                      regex: postData.search,
                    },
                  },
                },
                {
                  $expr: {
                    $regexMatch: {
                      input: { $toString: "$increment" },
                      regex: postData.search,
                    },
                  },
                },
              ],
            },
          ],
        },
      });
    }

    if (postData.status) {
      ExactMatch(query, "status", config.boolStatus[postData.status]);
    }

    if (postData.defaultbranchplan) {
      ExactMatch(
        query,
        "defaultbranchplan",
        Number(postData.defaultbranchplan)
      );
    }

    query.push({
      $project: {
        planName: 1,
        listingFee: 1,
        runs: 1,
        auctionTypeFee: 1,
        increment: 1,
        amountValue: 1,
        status: 1,
        defaultbranchplan: 1,
        initialfee: 1,
        branchId: 1,
        branchId: "$branches._id",
        parkingDays: 1,
        storage: 1,
        branchName: "$branches.branchName",
        createdAt: 1,
      },
    });
    const sQuery = [...query];
    query.push({ $sort: { createdAt: -1 } });
    sQuery.push({ $count: "recordCount" });

    if (postData.page) {
      query.push({
        $skip: cmethod.pageOffset(postData.page, postData.pageLimit),
      });
      query.push({ $limit: cmethod.pageLimit(postData.pageLimit) });
    }

    masterDao
      .findPlanAggregation(query)
      .then(function (data) {
        masterDao
          .findPlanAggregation(sQuery)
          .then(async function (dcount) {
            let tptCnt = 0;
            if (dcount.length > 0) {
              tptCnt = dcount[0].recordCount;
            }
            res.status(200).json({
              status: true,
              result: data,
              message: "",
              hasMore: cmethod.hasMoreCount(
                tptCnt,
                postData.page,
                postData.pageLimit
              ),
              totalCount: tptCnt,
            });
          })
          .catch((err) => {
            cmethod.returnSreverError(res, message[lang].technicalError, err);
          });
      })
      .catch((err) => {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      });
  }
);
router.patch(
  "/sellerplanupdate",
  [midleware.validateFieldValue(["sellerplanId"], ["sellerplanId"])],
  async (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let xtoken = req.headers["x-access-token"];
    //{ token: xtoken },
    let queryCond = {
      $and: [{ _id: mongoose.Types.ObjectId(postData.sellerplanId) }],
    };

    if (postData?.branchId) {
      await masterModal.Sellerplan.updateMany(
        { branchId: postData?.branchId },
        { $set: { defaultbranchplan: 0 } }
      );
    }

    delete postData.sellerplanId;
    //console.log("=======================>", req.body);
    masterModal.Sellerplan.findOneAndUpdate(
      queryCond,
      { $set: postData },
      { new: true },
      async function (err, data) {
        //console.log("user->", data);
        if (err) {
          cmethod.returnSreverError(res, message[lang].technicalError, err);
        } else {
          cmethod.returnSuccess(res, data, false, message[lang].profileUpdate);
        }
      }
    );
  }
);
router.post(
  "/list",
  //[midleware.validateFieldValue(["pageLimit", "page"], ["page"])],
  async (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let query = [];
    if (postData.makeName) {
      let makeval = postData.makeName;
      makeval = makeval.trim();
      query.push({
        $match: {
          $or: [
            { makeName: { $regex: new RegExp(`^${makeval}$`), $options: "i" } },
          ],
        },
      });
    }

    if (postData.search) {
      query.push({
        $match: {
          $and: [
            {
              $or: [
                {
                  makeName: {
                    $regex: postData.search,
                    $options: "i",
                  },
                },
              ],
            },
          ],
        },
      });
    }
    query.push({
      $project: {
        makeName: 1,
        status: 1,
      },
    });
    const sQuery = [...query];
    query.push({ $sort: { createdAt: -1 } });
    sQuery.push({ $count: "recordCount" });

    if (postData.page) {
      query.push({
        $skip: cmethod.pageOffset(postData.page, postData.pageLimit),
      });
      query.push({ $limit: cmethod.pageLimit(postData.pageLimit) });
    }

    masterDao
      .findMakeAggregation(query)
      .then(function (data) {
        masterDao
          .findMakeAggregation(sQuery)
          .then(async function (dcount) {
            let tptCnt = 0;
            if (dcount.length > 0) {
              tptCnt = dcount[0].recordCount;
            }
            res.status(200).json({
              status: true,
              result: data,
              message: "",
              hasMore: cmethod.hasMoreCount(
                tptCnt,
                postData.page,
                postData.pageLimit
              ),
              totalCount: tptCnt,
            });
          })
          .catch((err) => {
            cmethod.returnSreverError(res, message[lang].technicalError, err);
          });
      })
      .catch((err) => {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      });
  }
);

router.post(
  "/addUserRole",
  [
    midleware.validateFieldValue(
      ["userRole", "status"],
      ["userRole", "status"]
    ),
  ],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;

    let userRoleval = postData.userRole;
    userRoleval = userRoleval.trim();
    let chkuserRole = {
      userRole: { $regex: new RegExp(`^${userRoleval}$`), $options: "i" },
    };

    masterDao.checkuserRole(chkuserRole).then(function (doc) {
      if (doc == true) {
        cmethod.returrnErrorMessage(res, message[lang].docExist);
      } else {
        masterDao.userRoleAdd(res, postData);
      }
    });
  }
);

// update User

router.patch(
  "/updateUserRole",
  [midleware.validateFieldValue(["userRoleId"], ["userRoleId"])],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let xtoken = req.headers["x-access-token"];
    //{ token: xtoken },
    let queryCond = {
      $and: [{ _id: mongoose.Types.ObjectId(postData.userRoleId) }],
    };
    delete postData.userRoleId;
    //console.log("=======================>", req.body);
    masterModal.Userrole.findOneAndUpdate(
      queryCond,
      { $set: postData },
      { new: true },
      async function (err, data) {
        // console.log("user->", data);
        if (err) {
          cmethod.returrnErrorMessage(res, message[lang].technicalError, err);
        } else {
          cmethod.returnSuccess(res, data, false, message[lang].profileUpdate);
        }
      }
    );
  }
);
router.post(
  "/userRoleList",
  [midleware.validateFieldValue(["pageLimit", "page"], ["page"])],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let query = [];

    query.push({
      $project: {
        userRole: 1,
        status: 1,
      },
    });
    const sQuery = [...query];
    query.push({ $sort: { createdAt: -1 } });
    sQuery.push({ $count: "recordCount" });

    if (postData.page) {
      query.push({
        $skip: cmethod.pageOffset(postData.page, postData.pageLimit),
      });
      query.push({ $limit: cmethod.pageLimit(postData.pageLimit) });
    }

    masterDao
      .findUserRoleAggregation(query)
      .then(function (data) {
        masterDao
          .findUserRoleAggregation(sQuery)
          .then(async function (dcount) {
            let tptCnt = 0;
            if (dcount.length > 0) {
              tptCnt = dcount[0].recordCount;
            }
            res.status(200).json({
              status: true,
              result: data,
              message: "",
              hasMore: cmethod.hasMoreCount(
                tptCnt,
                postData.page,
                postData.pageLimit
              ),
              totalCount: tptCnt,
            });
          })
          .catch((err) => {
            cmethod.returnSreverError(res, message[lang].technicalError, err);
          });
      })
      .catch((err) => {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      });
  }
);

//model API
router.post(
  "/modeladd",
  [
    midleware.validateFieldValue(
      ["modelName", "status"],
      ["modelName", "status"]
    ),
  ],
  async (req, res) => {
    let postData = req.body;
    //console.log("=======>", postData);
    let lang = req.headers["lang"] || config.lang;
    let modelNameval = postData.modelName;
    modelNameval = modelNameval.trim();

    let chkmodelName = {
      $and: [
        {
          makeId: mongoose.Types.ObjectId(postData.makeId),
        },
        {
          $or: [
            {
              modelName: {
                $regex: new RegExp(`^${modelNameval}$`),
                $options: "i",
              },
            },
          ],
        },
      ],
    };
    masterDao.checkmodelName(chkmodelName).then(function (doc) {
      if (doc == true) {
        cmethod.returrnErrorMessage(res, message[lang].docExist);
      } else {
        //console.log("else"); return false;
        masterDao.modelAdd(res, postData);
      }
    });
  }
);

// update User

router.patch(
  "/modelupdate",
  [midleware.validateFieldValue(["modelId"], ["modelId"])],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let xtoken = req.headers["x-access-token"];
    //{ token: xtoken },
    let queryCond = {
      $and: [{ _id: mongoose.Types.ObjectId(postData.modelId) }],
    };
    delete postData.modelId;
    //console.log("=======================>", req.body);
    masterModal.Model.findOneAndUpdate(
      queryCond,
      { $set: postData },
      { new: true },
      async function (err, data) {
        //console.log("user->", data);
        if (err) {
          cmethod.returrnErrorMessage(res, message[lang].technicalError, err);
        } else {
          cmethod.returnSuccess(res, data, false, message[lang].profileUpdate);
        }
      }
    );
  }
);
router.post(
  "/modellist",
  [midleware.validateFieldValue(["pageLimit", "page"], ["page"])],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let query = [];
    query.push({
      $lookup: {
        from: "makes",
        localField: "makeId",
        foreignField: "_id",
        as: "makes",
      },
    });
    query.push({
      $unwind: { path: "$makes", preserveNullAndEmptyArrays: true },
    });
    if (postData.modelName) {
      let modelNameval = postData.modelName;
      modelNameval = modelNameval.trim();
      query.push({
        $match: {
          $or: [
            {
              modelName: {
                $regex: new RegExp(`^${modelNameval}$`),
                $options: "i",
              },
            },
          ],
        },
      });
    }

    if (postData.search) {
      query.push({
        $match: {
          $and: [
            {
              $or: [
                {
                  modelName: {
                    $regex: postData.search,
                    $options: "i",
                  },
                },
              ],
            },
          ],
        },
      });
    }
    if (postData.makeName) {
      query.push({
        $match: {
          $and: [{ "makes.makeName": postData.makeName }],
        },
      });
    }
    if (postData.makeId) {
      query.push({
        $match: {
          $and: [{ "makes._id": mongoose.Types.ObjectId(postData.makeId) }],
        },
      });
    }
    query.push({
      $project: {
        modelName: 1,
        status: 1,
        makeId: 1,
        makeName: "$makes.makeName",
      },
    });
    const sQuery = [...query];
    query.push({ $sort: { createdAt: -1 } });
    sQuery.push({ $count: "recordCount" });

    if (postData.page) {
      query.push({
        $skip: cmethod.pageOffset(postData.page, postData.pageLimit),
      });
      query.push({ $limit: cmethod.pageLimit(postData.pageLimit) });
    }

    masterDao
      .findModelAggregation(query)
      .then(function (data) {
        masterDao
          .findModelAggregation(sQuery)
          .then(async function (dcount) {
            let tptCnt = 0;
            if (dcount.length > 0) {
              tptCnt = dcount[0].recordCount;
            }
            if (data.length > 0) {
              res.status(200).json({
                status: true,
                result: data,
                message: "",
                hasMore: cmethod.hasMoreCount(
                  tptCnt,
                  postData.page,
                  postData.pageLimit
                ),
                totalCount: tptCnt,
              });
            } else {
              let naData = await masterModal.Model.findOne(
                { modelName: "NA." },
                { modelName: 1 }
              ).sort({ createdAt: -1 });
              res.status(200).json({
                status: true,
                result: [{ modelName: naData?.modelName, _id: naData?._id }],
                message: "",
                hasMore: cmethod.hasMoreCount(
                  tptCnt,
                  postData.page,
                  postData.pageLimit
                ),
                totalCount: tptCnt,
              });
            }
          })
          .catch((err) => {
            cmethod.returnSreverError(res, message[lang].technicalError, err);
          });
      })
      .catch((err) => {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      });
  }
);
//Series API
router.post(
  "/seriesadd",
  [
    midleware.validateFieldValue(
      ["seriesName", "status"],
      ["seriesName", "status"]
    ),
  ],
  async (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let seriesNameval = postData.seriesName;
    seriesNameval = seriesNameval.trim();
    let chkseriesName = {
      $and: [
        {
          modelId: mongoose.Types.ObjectId(postData.modelId),
        },
        {
          $or: [
            {
              seriesName: {
                $regex: new RegExp(`^${seriesNameval}$`),
                $options: "i",
              },
            },
          ],
        },
      ],
    };

    masterDao.checkseriesName(chkseriesName).then(function (doc) {
      if (doc == true) {
        cmethod.returrnErrorMessage(res, message[lang].docExist);
      } else {
        //conosle.log('chkmakeName==>');return false;
        masterDao.seriesAdd(res, postData);
      }
    });
  }
);

// update User

router.patch(
  "/seriesupdate",
  [midleware.validateFieldValue(["seriesId"], ["seriesId"])],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let xtoken = req.headers["x-access-token"];
    //{ token: xtoken },
    let queryCond = {
      $and: [{ _id: mongoose.Types.ObjectId(postData.seriesId) }],
    };
    delete postData.seriesId;
    //console.log("=======================>", req.body);
    masterModal.Series.findOneAndUpdate(
      queryCond,
      { $set: postData },
      { new: true },
      async function (err, data) {
        //console.log("user->", data);
        if (err) {
          cmethod.returrnErrorMessage(res, message[lang].technicalError, err);
        } else {
          cmethod.returnSuccess(res, data, false, message[lang].profileUpdate);
        }
      }
    );
  }
);
router.post(
  "/serieslist",
  [midleware.validateFieldValue(["pageLimit", "page"], ["page"])],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let query = [];

    query.push({
      $lookup: {
        from: "models",
        localField: "modelId",
        foreignField: "_id",
        as: "modelses",
      },
    });
    query.push({
      $unwind: { path: "$modelses", preserveNullAndEmptyArrays: true },
    });
    if (postData.modelId) {
      query.push({
        $match: {
          $and: [{ modelId: mongoose.Types.ObjectId(postData.modelId) }],
        },
      });
    }

    if (postData.seriesName) {
      let seriesNameval = postData.seriesName;
      seriesNameval = seriesNameval.trim();
      query.push({
        $match: {
          $or: [
            {
              seriesName: {
                $regex: new RegExp(`^${seriesNameval}$`),
                $options: "i",
              },
            },
          ],
        },
      });
    }
    if (postData.search) {
      query.push({
        $match: {
          $and: [
            {
              $or: [
                {
                  seriesName: {
                    $regex: postData.search,
                    $options: "i",
                  },
                },
              ],
            },
          ],
        },
      });
    }
    if (postData.modelName) {
      query.push({
        $match: {
          $and: [{ "modelses.modelName": postData.modelName }],
        },
      });
    }
    query.push({
      $project: {
        seriesName: 1,
        status: 1,
        modelId: 1,
        modelName: "$modelses.modelName",
      },
    });
    const sQuery = [...query];
    query.push({ $sort: { createdAt: -1 } });
    sQuery.push({ $count: "recordCount" });

    if (postData.page) {
      query.push({
        $skip: cmethod.pageOffset(postData.page, postData.pageLimit),
      });
      query.push({ $limit: cmethod.pageLimit(postData.pageLimit) });
    }

    masterDao
      .findSeriesAggregation(query)
      .then(function (data) {
        masterDao
          .findSeriesAggregation(sQuery)
          .then(async function (dcount) {
            let tptCnt = 0;
            if (dcount.length > 0) {
              tptCnt = dcount[0].recordCount;
            }
            if (data.length > 0) {
              res.status(200).json({
                status: true,
                result: data,
                message: "",
                hasMore: cmethod.hasMoreCount(
                  tptCnt,
                  postData.page,
                  postData.pageLimit
                ),
                totalCount: tptCnt,
              });
            } else {
              let naData = await masterModal.Series.findOne(
                { seriesName: "NA." },
                { seriesName: 1 }
              ).sort({ createdAt: -1 });
              res.status(200).json({
                status: true,
                result: [{ seriesName: naData?.seriesName, _id: naData?._id }],
                message: "",
                hasMore: cmethod.hasMoreCount(
                  tptCnt,
                  postData.page,
                  postData.pageLimit
                ),
                totalCount: tptCnt,
              });
            }
          })
          .catch((err) => {
            cmethod.returnSreverError(res, message[lang].technicalError, err);
          });
      })
      .catch((err) => {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      });
  }
);

//update branch API
router.post(
  "/branchadd",
  [
    midleware.validateFieldValue(
      ["branchName", "status"],
      ["branchName", "status"]
    ),
  ],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;

    let branchNameval = postData.branchName;
    branchNameval = branchNameval.trim();

    let chkbranchName = {
      $or: [
        {
          branchName: {
            $regex: new RegExp(`^${branchNameval}$`),
            $options: "i",
          },
        },
      ],
    };

    masterDao.checkbranchName(chkbranchName).then(function (doc) {
      if (doc == true) {
        cmethod.returrnErrorMessage(res, message[lang].docExist);
      } else {
        masterDao.branchAdd(res, postData);
      }
    });
  }
);

// update User

router.patch(
  "/branchupdate",
  [midleware.validateFieldValue(["branchId"], ["branchId"])],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let xtoken = req.headers["x-access-token"];
    //{ token: xtoken },
    let queryCond = {
      $and: [{ _id: mongoose.Types.ObjectId(postData.branchId) }],
    };
    delete postData.branchId;
    //console.log("=======================>", req.body);
    masterModal.Branch.findOneAndUpdate(
      queryCond,
      { $set: postData },
      { new: true },
      async function (err, data) {
        //console.log("user->", data);
        if (err) {
          cmethod.returrnErrorMessage(res, message[lang].technicalError, err);
        } else {
          cmethod.returnSuccess(res, data, false, message[lang].profileUpdate);
        }
      }
    );
  }
);
router.post(
  "/branchlist",
  [midleware.validateFieldValue(["pageLimit", "page"], ["page"])],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let query = [];
    let branchData = [];
    const { path } = req;

    if (postData.branchName) {
      let branchNameval = postData.branchName;
      branchNameval = branchNameval.trim();
      query.push({
        $match: {
          $or: [
            {
              branchName: {
                $regex: new RegExp(`^${branchNameval}$`),
                $options: "i",
              },
            },
          ],
        },
      });
    }

    if (postData?.branchId?.length > 0) {
      let pdata = postData.branchId;
      for (let i in pdata) {
        branchData.push(mongoose.Types.ObjectId(pdata[i]));
      }

      query.push({
        $match: {
          $and: [
            {
              _id: {
                $in: branchData,
              },
            },
          ],
        },
      });
    }
    //console.log("branchData===>", query);
    query.push({
      $project: {
        branchName: 1,
        branchImage: 1,
        branchAddress: 1,
        branchMobile: 1,
        branchEmail: 1,
        contactPerson1: 1,
        contactPerson2: 1,
        openingDay: 1,
        branchDesc: 1,
        status: 1,
        createdAt: 1,
        Trnno: 1,
        fullbranchName: 1,
      },
    });
    const sQuery = [...query];
    query.push({ $sort: { createdAt: -1 } });
    sQuery.push({ $count: "recordCount" });

    if (postData.page) {
      query.push({
        $skip: cmethod.pageOffset(postData.page, postData.pageLimit),
      });
      query.push({ $limit: cmethod.pageLimit(postData.pageLimit) });
    }

    masterDao
      .findBranchAggregation(query)
      .then(function (data) {
        masterDao
          .findBranchAggregation(sQuery)
          .then(async function (dcount) {
            let tptCnt = 0;
            if (dcount.length > 0) {
              tptCnt = dcount[0].recordCount;
            }

            const resObj = {
              status: true,
              result: data,
              message: "",
              hasMore: cmethod.hasMoreCount(
                tptCnt,
                postData.page,
                postData.pageLimit
              ),
              totalCount: tptCnt,
            };

            setCachedData(path, resObj);
            res.status(200).json(resObj);
          })
          .catch((err) => {
            cmethod.returnSreverError(res, message[lang].technicalError, err);
          });
      })
      .catch((err) => {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      });
  }
);

//warehouse
router.post(
  "/warehouseadd",
  [
    midleware.validateFieldValue(
      ["warehouseName", "status"],
      ["warehouseName", "status"]
    ),
  ],
  async (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;

    let warehouseNameval = postData.warehouseName;
    warehouseNameval = warehouseNameval.trim();
    let chkwarehouseName = {
      $or: [
        {
          warehouseName: {
            $regex: new RegExp(`^${warehouseNameval}$`),
            $options: "i",
          },
        },
      ],
    };

    masterDao.checkwarehouseName(chkwarehouseName).then(function (doc) {
      if (doc == true) {
        cmethod.returrnErrorMessage(res, message[lang].docExist);
      } else {
        masterDao.warehouseAdd(res, postData);
      }
    });
  }
);

// update User

router.patch(
  "/warehouseupdate",
  [midleware.validateFieldValue(["warehosId"], ["warehosId"])],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let xtoken = req.headers["x-access-token"];
    //{ token: xtoken },
    let queryCond = {
      $and: [{ _id: mongoose.Types.ObjectId(postData.warehosId) }],
    };
    delete postData.warehosId;
    masterModal.Warehouse.findOneAndUpdate(
      queryCond,
      { $set: postData },
      { upsert: true },
      async function (err, data) {
        if (err) {
          cmethod.returrnErrorMessage(res, message[lang].technicalError, err);
        } else {
          cmethod.returnSuccess(res, data, false, message[lang].profileUpdate);
        }
      }
    );
  }
);
router.post(
  "/warehouselist",
  [midleware.validateFieldValue(["pageLimit", "page"], ["page"])],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let query = [];

    query.push({
      $lookup: {
        from: "branchs",
        localField: "branchId",
        foreignField: "_id",
        as: "branches",
      },
    });
    query.push({
      $unwind: { path: "$branches", preserveNullAndEmptyArrays: true },
    });

    if (postData.branchId) {
      query.push({
        $match: {
          $and: [{ branchId: mongoose.Types.ObjectId(postData.branchId) }],
        },
      });
    }

    let branchData = [];
    if (postData.branchIds) {
      let pdata = postData.branchIds;
      for (let i in pdata) {
        branchData.push(mongoose.Types.ObjectId(pdata[i]));
      }
      query.push({
        $match: {
          $and: [
            {
              branchId: {
                $in: branchData,
              },
            },
          ],
        },
      });
    }

    if (postData.warehouseName) {
      let warehouseNameval = postData.warehouseName;
      warehouseNameval = warehouseNameval.trim();
      query.push({
        $match: {
          $or: [
            {
              warehouseName: {
                $regex: new RegExp(`^${warehouseNameval}$`),
                $options: "i",
              },
            },
          ],
        },
      });
    }
    query.push({
      $project: {
        warehouseName: 1,
        status: 1,
        branchId: 1,
        branchName: "$branches.branchName",
        //branchIds:1,
        //branchs: "$branchs.branchName",
      },
    });
    const sQuery = [...query];
    query.push({ $sort: { createdAt: -1 } });
    sQuery.push({ $count: "recordCount" });

    if (postData.page) {
      query.push({
        $skip: cmethod.pageOffset(postData.page, postData.pageLimit),
      });
      query.push({ $limit: cmethod.pageLimit(postData.pageLimit) });
    }
    masterDao
      .findWarehouseAggregation(query)
      .then(function (data) {
        masterDao
          .findWarehouseAggregation(sQuery)
          .then(async function (dcount) {
            let tptCnt = 0;
            if (dcount.length > 0) {
              tptCnt = dcount[0].recordCount;
            }
            res.status(200).json({
              status: true,
              result: data,
              message: "",
              hasMore: cmethod.hasMoreCount(
                tptCnt,
                postData.page,
                postData.pageLimit
              ),
              totalCount: tptCnt,
            });
          })
          .catch((err) => {
            cmethod.returnSreverError(res, message[lang].technicalError, err);
          });
      })
      .catch((err) => {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      });
  }
);
//======================================================
router.post(
  "/handlingfeeadd",
  [
    midleware.validateFieldValue(
      ["basePlan", "premiumPlan", "status"],
      ["basePlan", "premiumPlan", "status"]
    ),
  ],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;

    let chkhandlingfeeName = {
      $or: [
        {
          basePlan: postData.basePlan,
          basePlan: postData.basePlan,
          premiumPlan: postData.premiumPlan,
          premiumPlan: postData.premiumPlan,
        },
      ],
    };
    masterDao.checkhandlingfeeName(chkhandlingfeeName).then(function (doc) {
      if (doc == true) {
        cmethod.returrnErrorMessage(res, message[lang].docExist);
      } else {
        masterDao.handlingfeeAdd(res, postData);
      }
    });
  }
);

// update User

router.patch(
  "/handlingfeeupdate",
  [midleware.validateFieldValue(["handlingId"], ["handlingId"])],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let xtoken = req.headers["x-access-token"];
    //{ token: xtoken },
    let queryCond = {
      $and: [{ _id: mongoose.Types.ObjectId(postData.handlingId) }],
    };
    delete postData.handlingId;
    //console.log("=======================>", req.body);
    masterModal.Handlingfee.findOneAndUpdate(
      queryCond,
      { $set: postData },
      { new: true },
      async function (err, data) {
        console.log("user->", data);
        if (err) {
          cmethod.returrnErrorMessage(res, message[lang].technicalError, err);
        } else {
          cmethod.returnSuccess(res, data, false, message[lang].profileUpdate);
        }
      }
    );
  }
);
router.post(
  "/handlingfeelist",
  [midleware.validateFieldValue(["pageLimit", "page"], ["page"])],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let query = [];

    if (postData.branchId) {
      query.push({
        $match: {
          branchId: mongoose.Types.ObjectId(postData.branchId),
        },
      });
    }

    query.push({
      $lookup: {
        from: "branchs",
        localField: "branchId",
        foreignField: "_id",
        as: "branchs",
      },
    });
    query.push({
      $unwind: { path: "$branchs", preserveNullAndEmptyArrays: true },
    });

    query.push({
      $project: {
        basePlan: 1,
        premiumPlan: 1,
        status: 1,
        branchs: 1,
        branchId: "$branchs._id",
      },
    });
    const sQuery = [...query];
    query.push({ $sort: { createdAt: -1 } });
    sQuery.push({ $count: "recordCount" });

    if (postData.page) {
      query.push({
        $skip: cmethod.pageOffset(postData.page, postData.pageLimit),
      });
      query.push({ $limit: cmethod.pageLimit(postData.pageLimit) });
    }

    masterDao
      .findHandlingfeeAggregation(query)
      .then(function (data) {
        masterDao
          .findHandlingfeeAggregation(sQuery)
          .then(async function (dcount) {
            let tptCnt = 0;
            if (dcount.length > 0) {
              tptCnt = dcount[0].recordCount;
            }
            res.status(200).json({
              status: true,
              result: data,
              message: "",
              hasMore: cmethod.hasMoreCount(
                tptCnt,
                postData.page,
                postData.pageLimit
              ),
              totalCount: tptCnt,
            });
          })
          .catch((err) => {
            cmethod.returnSreverError(res, message[lang].technicalError, err);
          });
      })
      .catch((err) => {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      });
  }
);
//======================================================
router.post(
  "/auctionfeeadd",
  [
    midleware.validateFieldValue(
      ["startamount", "endamount", "handlingfee", "status"],
      ["startamount", "endamount", "handlingfee", "status"]
    ),
  ],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;

    let chkauctionfeeName = {
      $or: [
        {
          startamount: postData.startamount,
          endamount: postData.endamount,
          handlingfee: postData.handlingfee,
        },
      ],
    };
    masterDao.checkauctionfeeName(chkauctionfeeName).then(function (doc) {
      if (doc == true) {
        cmethod.returrnErrorMessage(res, message[lang].docExist);
      } else {
        //console.log('doc=========>>>',doc); return false;
        masterDao.auctionfeeAdd(res, postData);
      }
    });
  }
);

// update User

router.patch(
  "/auctionfeeupdate",
  [midleware.validateFieldValue(["auctionId"], ["auctionId"])],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let xtoken = req.headers["x-access-token"];
    //{ token: xtoken },
    let queryCond = {
      $and: [{ _id: mongoose.Types.ObjectId(postData.auctionId) }],
    };
    delete postData.auctionId;
    //console.log("=======================>", req.body);
    masterModal.Auctionfee.findOneAndUpdate(
      queryCond,
      { $set: postData },
      { new: true },
      async function (err, data) {
        //console.log("user->", data);
        if (err) {
          cmethod.returrnErrorMessage(res, message[lang].technicalError, err);
        } else {
          cmethod.returnSuccess(res, data, false, message[lang].profileUpdate);
        }
      }
    );
  }
);
router.post(
  "/auctionfeelist",
  [midleware.validateFieldValue(["pageLimit", "page"], ["page"])],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let query = [];

    query.push({
      $lookup: {
        from: "branchs",
        localField: "branchId",
        foreignField: "_id",
        as: "branchs",
      },
    });
    query.push({
      $unwind: { path: "$branchs", preserveNullAndEmptyArrays: true },
    });
    if (postData.branchId) {
      query.push({
        $match: {
          branchId: mongoose.Types.ObjectId(postData.branchId),
        },
      });
    }
    query.push({
      $project: {
        startamount: 1,
        endamount: 1,
        handlingfee: 1,
        status: 1,
        branchs: 1,
        branchId: "$branchs._id",
      },
    });
    const sQuery = [...query];
    query.push({ $sort: { createdAt: -1 } });
    sQuery.push({ $count: "recordCount" });

    if (postData.page) {
      query.push({
        $skip: cmethod.pageOffset(postData.page, postData.pageLimit),
      });
      query.push({ $limit: cmethod.pageLimit(postData.pageLimit) });
    }

    masterDao
      .findAuctionfeeAggregation(query)
      .then(function (data) {
        masterDao
          .findAuctionfeeAggregation(sQuery)
          .then(async function (dcount) {
            let tptCnt = 0;
            if (dcount.length > 0) {
              tptCnt = dcount[0].recordCount;
            }
            res.status(200).json({
              status: true,
              result: data,
              message: "",
              hasMore: cmethod.hasMoreCount(
                tptCnt,
                postData.page,
                postData.pageLimit
              ),
              totalCount: tptCnt,
            });
          })
          .catch((err) => {
            cmethod.returnSreverError(res, message[lang].technicalError, err);
          });
      })
      .catch((err) => {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      });
  }
);
router.post(
  "/buyerlimitadd",
  [
    midleware.validateFieldValue(
      ["package", "deposit", "creditlimit", "status"],
      ["package", "deposit", "creditlimit", "status"]
    ),
  ],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;

    let chkbuyerlimitName = {
      $or: [
        {
          package: postData.package,
          deposit: postData.deposit,
          creditlimit: postData.creditlimit,
          purchaselimit: postData.purchaselimit,
        },
      ],
    };
    masterDao.checkbuyerlimitName(chkbuyerlimitName).then(function (doc) {
      if (doc == true) {
        cmethod.returrnErrorMessage(res, message[lang].docExist);
      } else {
        //console.log('doc=========>>>',doc); return false;
        masterDao.buyerlimitAdd(res, postData);
      }
    });
  }
);

// update User

router.patch(
  "/buyerlimitupdate",
  [midleware.validateFieldValue(["buyerId"], ["buyerId"])],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let xtoken = req.headers["x-access-token"];
    //{ token: xtoken },
    let queryCond = {
      $and: [{ _id: mongoose.Types.ObjectId(postData.buyerId) }],
    };
    delete postData.buyerId;
    //console.log("=======================>", req.body);
    masterModal.Buyerlimit.findOneAndUpdate(
      queryCond,
      { $set: postData },
      { new: true },
      async function (err, data) {
        console.log("user->", data);
        if (err) {
          cmethod.returnSreverError(res, message[lang].technicalError, err);
        } else {
          cmethod.returnSuccess(res, data, false, message[lang].profileUpdate);
        }
      }
    );
  }
);
router.post(
  "/buyerlimitlist",
  [midleware.validateFieldValue(["pageLimit", "page"], ["page"])],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let query = [];

    if (postData.package) {
      query.push({
        $match: {
          $and: [{ package: postData.package }],
        },
      });
    }
    query.push({
      $project: {
        package: 1,
        deposit: 1,
        creditlimit: 1,
        purchaselimit: 1,
        status: 1,
      },
    });
    const sQuery = [...query];
    query.push({ $sort: { createdAt: -1 } });
    sQuery.push({ $count: "recordCount" });

    if (postData.page) {
      query.push({
        $skip: cmethod.pageOffset(postData.page, postData.pageLimit),
      });
      query.push({ $limit: cmethod.pageLimit(postData.pageLimit) });
    }

    masterDao
      .findBuyerlimitAggregation(query)
      .then(function (data) {
        masterDao
          .findBuyerlimitAggregation(sQuery)
          .then(async function (dcount) {
            let tptCnt = 0;
            if (dcount.length > 0) {
              tptCnt = dcount[0].recordCount;
            }
            res.status(200).json({
              status: true,
              result: data,
              message: "",
              hasMore: cmethod.hasMoreCount(
                tptCnt,
                postData.page,
                postData.pageLimit
              ),
              totalCount: tptCnt,
            });
          })
          .catch((err) => {
            cmethod.returnSreverError(res, message[lang].technicalError, err);
          });
      })
      .catch((err) => {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      });
  }
);
router.post(
  "/yearadd",
  [
    midleware.validateFieldValue(
      ["yearName", "status"],
      ["yearName", "status"]
    ),
  ],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;

    let chkyearName = {
      $and: [{ yearName: postData.yearName.toLowerCase() }],
    };
    masterDao.checkyearName(chkyearName).then(function (doc) {
      if (doc == true) {
        cmethod.returnSreverError(res, message[lang].docExist);
      } else {
        //console.log("doc------------->", doc); return false;
        masterDao.yearAdd(res, postData);
      }
    });
  }
);

// update User

router.patch(
  "/yearupdate",
  [midleware.validateFieldValue(["yearId"], ["yearId"])],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let xtoken = req.headers["x-access-token"];
    //{ token: xtoken },
    let queryCond = {
      $and: [{ _id: mongoose.Types.ObjectId(postData.yearId) }],
    };
    delete postData.yearId;
    //console.log("=======================>", req.body);
    masterModal.Year.findOneAndUpdate(
      queryCond,
      { $set: postData },
      { new: true },
      async function (err, data) {
        //console.log("user->", data);
        if (err) {
          cmethod.returnSreverError(res, message[lang].technicalError, err);
        } else {
          cmethod.returnSuccess(res, data, false, message[lang].profileUpdate);
        }
      }
    );
  }
);
router.post(
  "/yearlist",
  [midleware.validateFieldValue(["pageLimit", "page"], ["page"])],
  (req, res) => {
    let postData = req.body;
    //console.log("==============>", postData);
    let lang = req.headers["lang"] || config.lang;
    let query = [];

    query.push({
      $project: {
        yearName: 1,
        status: 1,
      },
    });
    const sQuery = [...query];
    query.push({ $sort: { createdAt: -1 } });
    sQuery.push({ $count: "recordCount" });

    if (postData.page) {
      query.push({
        $skip: cmethod.pageOffset(postData.page, postData.pageLimit),
      });
      query.push({ $limit: cmethod.pageLimit(postData.pageLimit) });
    }

    masterDao
      .findYearAggregation(query)
      .then(function (data) {
        masterDao
          .findYearAggregation(sQuery)
          .then(async function (dcount) {
            let tptCnt = 0;
            if (dcount.length > 0) {
              tptCnt = dcount[0].recordCount;
            }
            res.status(200).json({
              status: true,
              result: data,
              message: "",
              hasMore: cmethod.hasMoreCount(
                tptCnt,
                postData.page,
                postData.pageLimit
              ),
              totalCount: tptCnt,
            });
          })
          .catch((err) => {
            cmethod.returnSreverError(res, message[lang].technicalError, err);
          });
      })
      .catch((err) => {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      });
  }
);
//interior color add
router.post(
  "/interiorcoloradd",
  [
    midleware.validateFieldValue(
      ["colorName", "status"],
      ["colorName", "status"]
    ),
  ],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;

    let colorNameval = postData.colorName;
    colorNameval = colorNameval.trim();
    let chkinteriorcolorName = {
      $or: [
        {
          colorName: { $regex: new RegExp(`^${colorNameval}$`), $options: "i" },
        },
      ],
    };

    masterDao.checkinteriorcolorName(chkinteriorcolorName).then(function (doc) {
      if (doc == true) {
        cmethod.returrnErrorMessage(res, message[lang].docExist);
      } else {
        masterDao.interiorcolorAdd(res, postData);
      }
    });
  }
);

// update User

router.patch(
  "/interiorcolorupdate",
  [midleware.validateFieldValue(["colorId"], ["colorId"])],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let xtoken = req.headers["x-access-token"];
    //{ token: xtoken },
    let queryCond = {
      $and: [{ _id: mongoose.Types.ObjectId(postData.colorId) }],
    };
    delete postData.colorId;
    //console.log("=======================>", req.body);
    masterModal.interiorColor.findOneAndUpdate(
      queryCond,
      { $set: postData },
      { new: true },
      async function (err, data) {
        //console.log("user->", data);
        if (err) {
          cmethod.returrnErrorMessage(res, message[lang].technicalError, err);
        } else {
          cmethod.returnSuccess(res, data, false, message[lang].profileUpdate);
        }
      }
    );
  }
);
router.post(
  "/interiorcolorlist",
  [midleware.validateFieldValue(["pageLimit", "page"], ["page"])],
  (req, res) => {
    let postData = req.body;
    //console.log("==============>", postData);
    let lang = req.headers["lang"] || config.lang;
    let query = [];

    if (postData.colorName) {
      let colorNameval = postData.colorName;
      colorNameval = colorNameval.trim();
      query.push({
        $match: {
          $or: [
            {
              colorName: {
                $regex: new RegExp(`^${colorNameval}$`),
                $options: "i",
              },
            },
          ],
        },
      });
    }
    query.push({
      $project: {
        colorName: 1,
        colorCode: 1,
        status: 1,
      },
    });
    const sQuery = [...query];
    query.push({ $sort: { createdAt: -1 } });
    sQuery.push({ $count: "recordCount" });

    if (postData.page) {
      query.push({
        $skip: cmethod.pageOffset(postData.page, postData.pageLimit),
      });
      query.push({ $limit: cmethod.pageLimit(postData.pageLimit) });
    }

    masterDao
      .findColorAggregation(query)
      .then(function (data) {
        masterDao
          .findColorAggregation(sQuery)
          .then(async function (dcount) {
            let tptCnt = 0;
            if (dcount.length > 0) {
              tptCnt = dcount[0].recordCount;
            }
            res.status(200).json({
              status: true,
              result: data,
              message: "",
              hasMore: cmethod.hasMoreCount(
                tptCnt,
                postData.page,
                postData.pageLimit
              ),
              totalCount: tptCnt,
            });
          })
          .catch((err) => {
            cmethod.returnSreverError(res, message[lang].technicalError, err);
          });
      })
      .catch((err) => {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      });
  }
);
//=======================================transmission===============
//interior color add
router.post(
  "/transmissionadd",
  [midleware.validateFieldValue(["transName", "status"])],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;

    let transNameval = postData.transName;
    transNameval = transNameval.trim();
    let chktransmissionName = {
      $or: [
        {
          transName: { $regex: new RegExp(`^${transNameval}$`), $options: "i" },
        },
      ],
    };

    masterDao.checktransmissionName(chktransmissionName).then(function (doc) {
      if (doc == true) {
        cmethod.returrnErrorMessage(res, message[lang].docExist);
      } else {
        masterDao.transmissionAdd(res, postData);
      }
    });
  }
);

// update User

router.patch(
  "/transmissionupdate",
  [midleware.validateFieldValue(["transId"], ["transId"])],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let xtoken = req.headers["x-access-token"];
    //{ token: xtoken },
    let queryCond = {
      $and: [{ _id: mongoose.Types.ObjectId(postData.transId) }],
    };
    delete postData.transId;
    //console.log("=======================>", req.body);
    masterModal.Transmission.findOneAndUpdate(
      queryCond,
      { $set: postData },
      { new: true },
      async function (err, data) {
        //console.log("user->", data);
        if (err) {
          cmethod.returrnErrorMessage(res, message[lang].technicalError, err);
        } else {
          cmethod.returnSuccess(res, data, false, message[lang].profileUpdate);
        }
      }
    );
  }
);
router.post(
  "/transmissionlist",
  [midleware.validateFieldValue(["pageLimit", "page"], ["page"])],
  (req, res) => {
    let postData = req.body;
    //console.log("==============>", postData);
    let lang = req.headers["lang"] || config.lang;
    let query = [];

    if (postData.transName) {
      let transNameval = postData.transName;
      transNameval = transNameval.trim();
      query.push({
        $match: {
          $or: [
            {
              transName: {
                $regex: new RegExp(`^${transNameval}$`),
                $options: "i",
              },
            },
          ],
        },
      });
    }
    query.push({
      $project: {
        transName: 1,
        status: 1,
      },
    });
    const sQuery = [...query];
    query.push({ $sort: { createdAt: -1 } });
    sQuery.push({ $count: "recordCount" });

    if (postData.page) {
      query.push({
        $skip: cmethod.pageOffset(postData.page, postData.pageLimit),
      });
      query.push({ $limit: cmethod.pageLimit(postData.pageLimit) });
    }

    masterDao
      .findTransAggregation(query)
      .then(function (data) {
        masterDao
          .findTransAggregation(sQuery)
          .then(async function (dcount) {
            let tptCnt = 0;
            if (dcount.length > 0) {
              tptCnt = dcount[0].recordCount;
            }
            res.status(200).json({
              status: true,
              result: data,
              message: "",
              hasMore: cmethod.hasMoreCount(
                tptCnt,
                postData.page,
                postData.pageLimit
              ),
              totalCount: tptCnt,
            });
          })
          .catch((err) => {
            cmethod.returnSreverError(res, message[lang].technicalError, err);
          });
      })
      .catch((err) => {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      });
  }
);
//exterior color add

//=========================================================
//drive type color add
router.post(
  "/drivetypeadd",
  [
    midleware.validateFieldValue(
      ["drivetypeName", "status"],
      ["drivetypeName", "status"]
    ),
  ],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;

    let drivetypeNameval = postData.drivetypeName;
    drivetypeNameval = drivetypeNameval.trim();
    let chkdrivetypeName = {
      $or: [
        {
          drivetypeName: {
            $regex: new RegExp(`^${drivetypeNameval}$`),
            $options: "i",
          },
        },
      ],
    };

    masterDao.checkdrivetypeName(chkdrivetypeName).then(function (doc) {
      if (doc == true) {
        cmethod.returrnErrorMessage(res, message[lang].docExist);
      } else {
        masterDao.driveTypeAdd(res, postData);
      }
    });
  }
);

// update User

router.patch(
  "/drivetypeupdate",
  [midleware.validateFieldValue(["drivetypeId"], ["drivetypeId"])],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let xtoken = req.headers["x-access-token"];
    //{ token: xtoken },
    let queryCond = {
      $and: [{ _id: mongoose.Types.ObjectId(postData.drivetypeId) }],
    };
    delete postData.drivetypeId;
    //console.log("=======================>", req.body);
    masterModal.Drivetype.findOneAndUpdate(
      queryCond,
      { $set: postData },
      { new: true },
      async function (err, data) {
        //console.log("user->", data);
        if (err) {
          cmethod.returnSreverError(res, message[lang].technicalError, err);
        } else {
          cmethod.returnSuccess(res, data, false, message[lang].profileUpdate);
        }
      }
    );
  }
);
router.post(
  "/drivetypelist",
  [midleware.validateFieldValue(["pageLimit", "page"], ["page"])],
  (req, res) => {
    let postData = req.body;
    //console.log("==============>", postData);
    let lang = req.headers["lang"] || config.lang;
    let query = [];

    if (postData.drivetypeName) {
      let drivetypeNameval = postData.drivetypeName;
      drivetypeNameval = drivetypeNameval.trim();
      query.push({
        $match: {
          $or: [
            {
              drivetypeName: {
                $regex: new RegExp(`^${drivetypeNameval}$`),
                $options: "i",
              },
            },
          ],
        },
      });
    }
    query.push({
      $project: {
        drivetypeName: 1,
        status: 1,
      },
    });
    const sQuery = [...query];
    query.push({ $sort: { createdAt: -1 } });
    sQuery.push({ $count: "recordCount" });

    if (postData.page) {
      query.push({
        $skip: cmethod.pageOffset(postData.page, postData.pageLimit),
      });
      query.push({ $limit: cmethod.pageLimit(postData.pageLimit) });
    }

    masterDao
      .finddriveTypeAggregation(query)
      .then(function (data) {
        masterDao
          .finddriveTypeAggregation(sQuery)
          .then(async function (dcount) {
            let tptCnt = 0;
            if (dcount.length > 0) {
              tptCnt = dcount[0].recordCount;
            }
            res.status(200).json({
              status: true,
              result: data,
              message: "",
              hasMore: cmethod.hasMoreCount(
                tptCnt,
                postData.page,
                postData.pageLimit
              ),
              totalCount: tptCnt,
            });
          })
          .catch((err) => {
            cmethod.returnSreverError(res, message[lang].technicalError, err);
          });
      })
      .catch((err) => {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      });
  }
);
//===================================================================
//Fuel type color add
router.post(
  "/fueltypeadd",
  [
    midleware.validateFieldValue(
      ["fueltypeName", "status"],
      ["fueltypeName", "status"]
    ),
  ],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;

    let fueltypeNameval = postData.fueltypeName;
    fueltypeNameval = fueltypeNameval.trim();
    let chkfueltypeName = {
      $or: [
        {
          fueltypeName: {
            $regex: new RegExp(`^${fueltypeNameval}$`),
            $options: "i",
          },
        },
      ],
    };
    masterDao.checkfueltypeName(chkfueltypeName).then(function (doc) {
      if (doc == true) {
        cmethod.returrnErrorMessage(res, message[lang].docExist);
      } else {
        masterDao.fueltypeAdd(res, postData);
      }
    });
  }
);

// update User

router.patch(
  "/fueltypeupdate",
  [midleware.validateFieldValue(["fueltypeId"], ["fueltypeId"])],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let xtoken = req.headers["x-access-token"];
    //{ token: xtoken },
    let queryCond = {
      $and: [{ _id: mongoose.Types.ObjectId(postData.fueltypeId) }],
    };
    delete postData.drivetypeId;
    //console.log("=======================>", req.body);
    masterModal.Fueltypes.findOneAndUpdate(
      queryCond,
      { $set: postData },
      { new: true },
      async function (err, data) {
        //console.log("user->", data);
        if (err) {
          cmethod.returnSreverError(res, message[lang].technicalError, err);
        } else {
          cmethod.returnSuccess(res, data, false, message[lang].profileUpdate);
        }
      }
    );
  }
);
router.post(
  "/fueltypelist",
  [midleware.validateFieldValue(["pageLimit", "page"], ["page"])],
  (req, res) => {
    let postData = req.body;
    //console.log("==============>", postData);
    let lang = req.headers["lang"] || config.lang;
    let query = [];

    if (postData.fueltypeName) {
      let fueltypeNameval = postData.fueltypeName;
      fueltypeNameval = fueltypeNameval.trim();
      query.push({
        $match: {
          $or: [
            {
              fueltypeName: {
                $regex: new RegExp(`^${fueltypeNameval}$`),
                $options: "i",
              },
            },
          ],
        },
      });
    }

    query.push({
      $lookup: {
        from: "inventorys",
        localField: "_id",
        foreignField: "fueltypeId",
        as: "inventorys",
      },
    });

    query.push({
      $project: {
        fueltypeName: 1,
        status: 1,
        inventorysCount: {
          $size: {
            $filter: {
              input: "$inventorys",
              as: "inventory",
              cond: { $eq: ["$$inventory.inventoryStatus", 2] }, // * in auction
            },
          },
        },
      },
    });

    const sQuery = [...query];
    query.push({ $sort: { createdAt: -1 } });
    sQuery.push({ $count: "recordCount" });

    if (postData.page) {
      query.push({
        $skip: cmethod.pageOffset(postData.page, postData.pageLimit),
      });
      query.push({ $limit: cmethod.pageLimit(postData.pageLimit) });
    }

    masterDao
      .findfuelTypeAggregation(query)
      .then(function (data) {
        masterDao
          .findfuelTypeAggregation(sQuery)
          .then(async function (dcount) {
            let tptCnt = 0;
            if (dcount.length > 0) {
              tptCnt = dcount[0].recordCount;
            }
            res.status(200).json({
              status: true,
              result: data,
              message: "",
              hasMore: cmethod.hasMoreCount(
                tptCnt,
                postData.page,
                postData.pageLimit
              ),
              totalCount: tptCnt,
            });
          })
          .catch((err) => {
            cmethod.returnSreverError(res, message[lang].technicalError, err);
          });
      })
      .catch((err) => {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      });
  }
);
router.post(
  "/cylinderadd",
  [
    midleware.validateFieldValue(
      ["cylinderName", "status"],
      ["cylinderName", "status"]
    ),
  ],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;

    // console.log("washi");
    masterDao.cylinderAdd(res, postData);
  }
);

// update User

router.patch(
  "/cylinderupdate",
  [midleware.validateFieldValue(["cylinderId"], ["cylinderId"])],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let xtoken = req.headers["x-access-token"];
    //{ token: xtoken },
    let queryCond = {
      $and: [{ _id: mongoose.Types.ObjectId(postData.cylinderId) }],
    };
    delete postData.cylinderId;
    //console.log("=======================>", req.body);
    masterModal.Cylinders.findOneAndUpdate(
      queryCond,
      { $set: postData },
      { new: true },
      async function (err, data) {
        //console.log("user->", data);
        if (err) {
          cmethod.returrnErrorMessage(res, message[lang].technicalError, err);
        } else {
          cmethod.returnSuccess(res, data, false, message[lang].profileUpdate);
        }
      }
    );
  }
);
router.post(
  "/cylinderlist",
  [midleware.validateFieldValue(["pageLimit", "page"], ["page"])],
  (req, res) => {
    let postData = req.body;
    //console.log("==============>", postData);
    let lang = req.headers["lang"] || config.lang;
    let query = [];

    query.push({
      $project: {
        cylinderName: 1,
        status: 1,
      },
    });
    const sQuery = [...query];
    query.push({ $sort: { createdAt: -1 } });
    sQuery.push({ $count: "recordCount" });

    if (postData.page) {
      query.push({
        $skip: cmethod.pageOffset(postData.page, postData.pageLimit),
      });
      query.push({ $limit: cmethod.pageLimit(postData.pageLimit) });
    }

    masterDao
      .findCylinderAggregation(query)
      .then(function (data) {
        masterDao
          .findCylinderAggregation(sQuery)
          .then(async function (dcount) {
            let tptCnt = 0;
            if (dcount.length > 0) {
              tptCnt = dcount[0].recordCount;
            }
            res.status(200).json({
              status: true,
              result: data,
              message: "",
              hasMore: cmethod.hasMoreCount(
                tptCnt,
                postData.page,
                postData.pageLimit
              ),
              totalCount: tptCnt,
            });
          })
          .catch((err) => {
            cmethod.returnSreverError(res, message[lang].technicalError, err);
          });
      })
      .catch((err) => {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      });
  }
);
//exterior color add
router.post(
  "/exteriorcoloradd",
  [
    midleware.validateFieldValue(
      ["colorName", "status"],
      ["colorName", "status"]
    ),
  ],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;

    let colorNameval = postData.colorName;
    colorNameval = colorNameval.trim();
    let chkexteriorcolorName = {
      $or: [
        {
          colorName: { $regex: new RegExp(`^${colorNameval}$`), $options: "i" },
        },
      ],
    };

    masterDao.checkexteriorcolorName(chkexteriorcolorName).then(function (doc) {
      if (doc == true) {
        cmethod.returrnErrorMessage(res, message[lang].docExist);
      } else {
        masterDao.exteriorcolorAdd(res, postData);
      }
    });
  }
);
// update User

router.patch(
  "/exteriorcolorupdate",
  [midleware.validateFieldValue(["colorId"], ["colorId"])],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let xtoken = req.headers["x-access-token"];
    //{ token: xtoken },
    let queryCond = {
      $and: [{ _id: mongoose.Types.ObjectId(postData.colorId) }],
    };
    delete postData.colorId;
    //console.log("=======================>", req.body);
    masterModal.exteriorColor.findOneAndUpdate(
      queryCond,
      { $set: postData },
      { new: true },
      async function (err, data) {
        //console.log("user->", data);
        if (err) {
          cmethod.returnSreverError(res, message[lang].technicalError, err);
        } else {
          cmethod.returnSuccess(res, data, false, message[lang].profileUpdate);
        }
      }
    );
  }
);
router.post(
  "/exteriorcolorlist",
  [midleware.validateFieldValue(["pageLimit", "page"], ["page"])],
  (req, res) => {
    let postData = req.body;
    //console.log("==============>", postData);
    let lang = req.headers["lang"] || config.lang;
    let query = [];

    if (postData.colorName) {
      let colorNameval = postData.colorName;
      colorNameval = colorNameval.trim();
      query.push({
        $match: {
          $or: [
            {
              colorName: {
                $regex: new RegExp(`^${colorNameval}$`),
                $options: "i",
              },
            },
          ],
        },
      });
    }
    query.push({
      $project: {
        colorName: 1,
        colorCode: 1,
        status: 1,
      },
    });
    const sQuery = [...query];
    query.push({ $sort: { createdAt: -1 } });
    sQuery.push({ $count: "recordCount" });

    if (postData.page) {
      query.push({
        $skip: cmethod.pageOffset(postData.page, postData.pageLimit),
      });
      query.push({ $limit: cmethod.pageLimit(postData.pageLimit) });
    }

    masterDao
      .findexColorAggregation(query)
      .then(function (data) {
        masterDao
          .findexColorAggregation(sQuery)
          .then(async function (dcount) {
            let tptCnt = 0;
            if (dcount.length > 0) {
              tptCnt = dcount[0].recordCount;
            }
            res.status(200).json({
              status: true,
              result: data,
              message: "",
              hasMore: cmethod.hasMoreCount(
                tptCnt,
                postData.page,
                postData.pageLimit
              ),
              totalCount: tptCnt,
            });
          })
          .catch((err) => {
            cmethod.returnSreverError(res, message[lang].technicalError, err);
          });
      })
      .catch((err) => {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      });
  }
);
//Body
router.post(
  "/bodyadd",
  [
    midleware.validateFieldValue(
      ["bodyName", "status"],
      ["bodyName", "status"]
    ),
  ],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;

    let bodyNameval = postData.bodyName;
    bodyNameval = bodyNameval.trim();
    let chkbodyName = {
      $or: [
        { bodyName: { $regex: new RegExp(`^${bodyNameval}$`), $options: "i" } },
      ],
    };

    masterDao.checkbodyName(chkbodyName).then(function (doc) {
      if (doc == true) {
        cmethod.returrnErrorMessage(res, message[lang].docExist);
      } else {
        masterDao.bodyAdd(res, postData);
      }
    });
  }
);

// update User

router.patch(
  "/bodyupdate",
  [midleware.validateFieldValue(["bodyId"], ["bodyId"])],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let xtoken = req.headers["x-access-token"];
    //{ token: xtoken },
    let queryCond = {
      $and: [{ _id: mongoose.Types.ObjectId(postData.bodyId) }],
    };
    delete postData.bodyId;
    //console.log("=======================>", req.body);
    masterModal.Bodys.findOneAndUpdate(
      queryCond,
      { $set: postData },
      { new: true },
      async function (err, data) {
        //console.log("user->", data);
        if (err) {
          cmethod.returnSreverError(res, message[lang].technicalError, err);
        } else {
          cmethod.returnSuccess(res, data, false, message[lang].profileUpdate);
        }
      }
    );
  }
);
router.post(
  "/bodylist",
  [midleware.validateFieldValue(["pageLimit", "page"], ["page"])],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let query = [];

    if (postData.bodyName) {
      let bodyNameval = postData.bodyName;
      bodyNameval = bodyNameval.trim();
      query.push({
        $match: {
          $or: [
            {
              bodyName: {
                $regex: new RegExp(`^${bodyNameval}$`),
                $options: "i",
              },
            },
          ],
        },
      });
    }

    query.push({
      $lookup: {
        from: "inventorys",
        localField: "_id",
        foreignField: "bodyId",
        as: "inventorys",
      },
    });

    query.push({
      $project: {
        bodyName: 1,
        bodyCode: 1,
        status: 1,
        inventorysCount: {
          $size: {
            $filter: {
              input: "$inventorys",
              as: "inventory",
              cond: { $eq: ["$$inventory.inventoryStatus", 2] }, // * in auction
            },
          },
        },
      },
    });

    const sQuery = [...query];
    query.push({ $sort: { createdAt: -1 } });
    sQuery.push({ $count: "recordCount" });

    if (postData.page) {
      query.push({
        $skip: cmethod.pageOffset(postData.page, postData.pageLimit),
      });
      query.push({ $limit: cmethod.pageLimit(postData.pageLimit) });
    }

    masterDao
      .findBodysAggregation(query)
      .then(function (data) {
        masterDao
          .findBodysAggregation(sQuery)
          .then(async function (dcount) {
            let tptCnt = 0;
            if (dcount.length > 0) {
              tptCnt = dcount[0].recordCount;
            }
            res.status(200).json({
              status: true,
              result: data,
              message: "",
              hasMore: cmethod.hasMoreCount(
                tptCnt,
                postData.page,
                postData.pageLimit
              ),
              totalCount: tptCnt,
            });
          })
          .catch((err) => {
            cmethod.returnSreverError(res, message[lang].technicalError, err);
          });
      })
      .catch((err) => {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      });
  }
);

//Engine
router.post(
  "/engineadd",
  [
    midleware.validateFieldValue(
      ["engineName", "status"],
      ["engineName", "status"]
    ),
  ],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;

    let engineNameval = postData.engineName;
    engineNameval = engineNameval.trim();
    let chkengineNameName = {
      $or: [
        {
          engineName: {
            $regex: new RegExp(`^${engineNameval}$`),
            $options: "i",
          },
        },
      ],
    };
    masterDao.checkengineName(chkengineNameName).then(function (doc) {
      if (doc == true) {
        cmethod.returrnErrorMessage(res, message[lang].docExist);
      } else {
        masterDao.engineAdd(res, postData);
      }
    });
  }
);

// update User

router.patch(
  "/engineupdate",
  [midleware.validateFieldValue(["engineId"], ["engineId"])],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let xtoken = req.headers["x-access-token"];
    //{ token: xtoken },
    let queryCond = {
      $and: [{ _id: mongoose.Types.ObjectId(postData.engineId) }],
    };
    delete postData.engineId;
    //console.log("=======================>", req.body);
    masterModal.Engines.findOneAndUpdate(
      queryCond,
      { $set: postData },
      { new: true },
      async function (err, data) {
        //console.log("user->", data);
        if (err) {
          cmethod.returnSreverError(res, message[lang].technicalError, err);
        } else {
          cmethod.returnSuccess(res, data, false, message[lang].profileUpdate);
        }
      }
    );
  }
);
router.post(
  "/enginelist",
  [midleware.validateFieldValue(["pageLimit", "page"], ["page"])],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let query = [];

    if (postData.engineName) {
      let engineNameval = postData.engineName;
      engineNameval = engineNameval.trim();
      query.push({
        $match: {
          $or: [
            {
              engineName: {
                $regex: new RegExp(`^${engineNameval}$`),
                $options: "i",
              },
            },
          ],
        },
      });
    }
    query.push({
      $project: {
        engineName: 1,
        status: 1,
      },
    });
    const sQuery = [...query];
    query.push({ $sort: { createdAt: -1 } });
    sQuery.push({ $count: "recordCount" });

    if (postData.page) {
      query.push({
        $skip: cmethod.pageOffset(postData.page, postData.pageLimit),
      });
      query.push({ $limit: cmethod.pageLimit(postData.pageLimit) });
    }

    masterDao
      .findEngineAggregation(query)
      .then(function (data) {
        masterDao
          .findEngineAggregation(sQuery)
          .then(async function (dcount) {
            let tptCnt = 0;
            if (dcount.length > 0) {
              tptCnt = dcount[0].recordCount;
            }
            res.status(200).json({
              status: true,
              result: data,
              message: "",
              hasMore: cmethod.hasMoreCount(
                tptCnt,
                postData.page,
                postData.pageLimit
              ),
              totalCount: tptCnt,
            });
          })
          .catch((err) => {
            cmethod.returnSreverError(res, message[lang].technicalError, err);
          });
      })
      .catch((err) => {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      });
  }
);

//menu
router.post(
  "/menuAdd",
  [
    midleware.validateFieldValue(
      ["menu", "link", "status"],
      ["menu", "link", "status"]
    ),
  ],
  (req, res) => {
    let postData = req.body;
    if (postData.custombtn) {
      let btn = postData.custombtn;
      let customBtn = btn.join(",");
      postData.custombtn = customBtn;
    }
    let lang = req.headers["lang"] || config.lang;
    masterDao.menuAdd(res, postData);
  }
);

router.patch(
  "/menuUpdate",
  [midleware.validateFieldValue(["menuId"], ["menuId"])],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let xtoken = req.headers["x-access-token"];
    //{ token: xtoken },
    // let btn = postData.custombtn = ["active", "inactive"];
    //
    if (postData.custombtn) {
      let btn = postData.custombtn;
      let customBtn = btn.join(",");
      postData.custombtn = customBtn;
    }
    let queryCond = {
      $and: [{ _id: mongoose.Types.ObjectId(postData.menuId) }],
    };
    delete postData.menuId;
    // console.log('---------------',postData); //return false;
    masterModal.Menu.findOneAndUpdate(
      queryCond,
      { $set: postData },
      { new: true },
      async function (err, data) {
        //console.log("user->", data);
        if (err) {
          cmethod.returnSreverError(res, message[lang].technicalError, err);
        } else {
          cmethod.returnSuccess(res, data, false, message[lang].profileUpdate);
        }
      }
    );
  }
);
router.post(
  "/menuList",
  [midleware.validateFieldValue(["pageLimit", "page"], ["page"])],
  (req, res) => {
    let postData = req.body;
    console.log("==============>", postData);
    let lang = req.headers["lang"] || config.lang;
    let query = [];
    if (postData.type == "tree") {
      query.push({
        $match: {
          $and: [{ parentId: null }],
        },
      });
      query.push({
        $graphLookup: {
          from: "menus",
          startWith: "$_id",
          connectFromField: "_id",
          connectToField: "parentId",
          as: "childMenu",
        },
      });
    } else {
      query.push({
        $lookup: {
          from: "menus",
          localField: "parentId",
          foreignField: "_id",
          as: "parentMenu",
        },
      });
      query.push({
        $unwind: { path: "$parentMenu", preserveNullAndEmptyArrays: true },
      });
    }

    if (postData.search) {
      query.push({
        $match: {
          $and: [
            {
              $or: [
                {
                  menu: {
                    $regex: postData.search,
                    $options: "i",
                  },
                },
              ],
            },
          ],
        },
      });
    }
    query.push({
      $project: {
        parentId: 1,
        menu: 1,
        link: 1,
        displayOrder: 1,
        icon: 1,
        status: 1,
        childMenu: 1,
        parentMenu: 1,
        custombtn: 1,
      },
    });
    const sQuery = [...query];
    query.push({ $sort: { displayOrder: 1 } });
    sQuery.push({ $count: "recordCount" });

    if (postData.page) {
      query.push({
        $skip: cmethod.pageOffset(postData.page, postData.pageLimit),
      });
      query.push({ $limit: cmethod.pageLimit(postData.pageLimit) });
    }

    masterDao
      .findMenuAggregation(query)
      .then(function (data) {
        masterDao
          .findMenuAggregation(sQuery)
          .then(async function (dcount) {
            let tptCnt = 0;
            if (dcount.length > 0) {
              tptCnt = dcount[0].recordCount;
            }
            res.status(200).json({
              status: true,
              result: data,
              message: "",
              hasMore: cmethod.hasMoreCount(
                tptCnt,
                postData.page,
                postData.pageLimit
              ),
              totalCount: tptCnt,
            });
          })
          .catch((err) => {
            cmethod.returnSreverError(res, message[lang].technicalError, err);
          });
      })
      .catch((err) => {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      });
  }
);
//menuAccess
router.post(
  "/menuAccessAdd",
  [
    midleware.validateFieldValue(
      ["userRoleId", "menuAccessArr"],
      ["userRoleId", "menuAccessArr"]
    ),
  ],
  async (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let allmenuAccessArr = postData.menuAccessArr;
    // console.log(allmenuAccessArr);
    // formate of request = {"6401c0fbb70246b04cb44438": {"read": 1, "add": 1,"edit": 1, "delete": 1,"import": 1,"export": 1}}
    await masterModal.Menuaccess.deleteMany({
      userRoleId: mongoose.Types.ObjectId(postData.userRoleId),
    });

    let insertData = [];

    for (let index in allmenuAccessArr) {
      let kkk = JSON.stringify(allmenuAccessArr[index].custombtn);
      insertData.push({
        userRoleId: mongoose.Types.ObjectId(postData.userRoleId),
        menuId: mongoose.Types.ObjectId(index),
        read: allmenuAccessArr[index].read,
        add: allmenuAccessArr[index].add,
        edit: allmenuAccessArr[index].edit,
        delete: allmenuAccessArr[index].delete,
        import: allmenuAccessArr[index].import,
        export: allmenuAccessArr[index].export,
        custombtn: kkk,
      });
    }

    // console.log(insertData); return;
    if (insertData.length > 0) {
      masterModal.Menuaccess.insertMany(insertData, (err, data) => {
        if (err) {
          cmethod.returnSreverError(res, message[lang].technicalError, err);
        } else {
          cmethod.returnSuccess(
            res,
            data,
            false,
            "Sales Return added successfully."
          );
        }
      });
    } else {
      cmethod.returnSreverError(res, "Menu Access can not be empty.", "");
    }
  }
);

// update User

router.post(
  "/menuAccessList",
  [midleware.validateFieldValue(["pageLimit", "page"], ["page"])],
  (req, res) => {
    let postData = req.body;
    //console.log("==============>", postData);
    let lang = req.headers["lang"] || config.lang;
    let query = [];

    if (postData.userRoleId) {
      query.push({
        $match: {
          $and: [{ userRoleId: mongoose.Types.ObjectId(postData.userRoleId) }],
        },
      });
    }
    query.push({
      $project: {
        userRoleId: 1,
        menuId: 1,
        read: 1,
        add: 1,
        edit: 1,
        delete: 1,
        import: 1,
        export: 1,
        custombtn: 1,
      },
    });
    const sQuery = [...query];
    query.push({ $sort: { createdAt: 1 } });
    sQuery.push({ $count: "recordCount" });

    if (postData.page) {
      query.push({
        $skip: cmethod.pageOffset(postData.page, postData.pageLimit),
      });
      query.push({ $limit: cmethod.pageLimit(postData.pageLimit) });
    }

    masterDao
      .findMenuAccessAggregation(query)
      .then(function (data) {
        masterDao
          .findMenuAccessAggregation(sQuery)
          .then(async function (dcount) {
            let tptCnt = 0;
            if (dcount.length > 0) {
              tptCnt = dcount[0].recordCount;
            }
            res.status(200).json({
              status: true,
              result: data,
              message: "",
              hasMore: cmethod.hasMoreCount(
                tptCnt,
                postData.page,
                postData.pageLimit
              ),
              totalCount: tptCnt,
            });
          })
          .catch((err) => {
            cmethod.returnSreverError(res, message[lang].technicalError, err);
          });
      })
      .catch((err) => {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      });
  }
);
router.delete(
  "/delete",
  [midleware.validateFieldValue(["deleteId"], ["deleteId"])],
  async (req, res) => {
    let postData = req.body;
    //console.log("delete---->", postData);
    let cond = { _id: mongoose.Types.ObjectId(postData.deleteId) };
    let lang = req.headers["lang"] || config.lang;

    masterModal.Menu.deleteOne(cond, postData)
      .then(async (data) => {
        //delete sub menu access
        let cond2 = { parentId: mongoose.Types.ObjectId(postData.deleteId) };
        masterModal.Menu.deleteOne(cond2, postData);
        //delete menu access
        let cond3 = { menuId: mongoose.Types.ObjectId(postData.deleteId) };
        masterModal.Menuaccess.deleteOne(cond3, postData);

        cmethod.returnSuccess(res, [], false, message[lang].Deleteed);
      })
      .catch((err) => {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      });
  }
);
router.post(
  "/sidebarMenuAcess",
  [midleware.validateFieldValue(["pageLimit", "page"], ["page"])],
  (req, res) => {
    let postData = req.body;
    //console.log("==============>", postData);
    let lang = req.headers["lang"] || config.lang;
    let query = [];

    query.push({
      $match: {
        $and: [{ read: 1 }],
      },
    });

    if (postData.userRoleId) {
      query.push({
        $match: {
          $and: [{ userRoleId: mongoose.Types.ObjectId(postData.userRoleId) }],
        },
      });
    }
    query.push({
      $lookup: {
        from: "menus",
        localField: "menuId",
        foreignField: "_id",
        as: "menus",
      },
    });
    query.push({
      $unwind: { path: "$menus", preserveNullAndEmptyArrays: true },
    });

    if (postData.menuLink) {
      query.push({
        $match: {
          $and: [
            { "menus.link": { $regex: postData.menuLink, $options: "i" } },
          ],
        },
      });
    }
    query.push({
      $project: {
        userRoleId: 1,
        menuId: 1,
        menuName: "$menus.menu",
        menuLink: "$menus.link",
        parentId: "$menus.parentId",
        displayOrder: "$menus.displayOrder",
        read: 1,
        add: 1,
        edit: 1,
        delete: 1,
        import: 1,
        export: 1,
        custombtn: 1,
      },
    });
    const sQuery = [...query];
    query.push({ $sort: { displayOrder: 1 } });
    sQuery.push({ $count: "recordCount" });

    if (postData.page) {
      query.push({
        $skip: cmethod.pageOffset(postData.page, postData.pageLimit),
      });
      query.push({ $limit: cmethod.pageLimit(postData.pageLimit) });
    }

    masterDao
      .findMenuAccessAggregation(query)
      .then(async function (data) {
        //create tree data for sidebar menu
        if (postData.listType == "sidebar") {
          let treeData = {};
          let i = 1;
          for (let item of data) {
            if (item?.parentId != null) {
              let menuData = await masterModal.Menu.findOne(
                { _id: mongoose.Types.ObjectId(item?.parentId) },
                { menu: 1 }
              ).sort({ createdAt: -1 });
              item.parentName = menuData?.menu;
              if (treeData[item?.parentId]) {
                treeData[item?.parentId].push(item);
              } else {
                treeData[item?.parentId] = [item];
              }
            } else {
              treeData[item?.menuId] = item;
            }
            i++;
          }
          data = treeData;
        }
        masterDao
          .findMenuAccessAggregation(sQuery)
          .then(async function (dcount) {
            let tptCnt = 0;
            if (dcount.length > 0) {
              tptCnt = dcount[0].recordCount;
            }
            res.status(200).json({
              status: true,
              result: data,
              message: "",
              hasMore: cmethod.hasMoreCount(
                tptCnt,
                postData.page,
                postData.pageLimit
              ),
              totalCount: tptCnt,
            });
          })
          .catch((err) => {
            cmethod.returnSreverError(res, message[lang].technicalError, err);
          });
      })
      .catch((err) => {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      });
  }
);
router.post(
  "/sellerplanadd",
  [midleware.validateFieldValue(["planName"], ["planName"])],
  async (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;

    // let planval = postData.planName;
    // planval = planval.trim();
    // let chkplanName = {
    //   planName: { $regex: new RegExp(`^${planval}$`), $options: 'i' }
    // };
    //masterDao.checkplanName(chkplanName).then(function (doc) {
    //if (doc == true) {
    //  cmethod.returrnErrorMessage(res, message[lang].docExist);
    // } else {
    masterDao.planAdd(res, postData);
  }
  //})

  // }
);
router.post("/importdata", uploadsFile.single("myFile"), async (req, res) => {
  let postData = req.body;
  let lang = req.headers["lang"] || config.lang;
  let files = fetchFilesFromReq(req);
  let filepathname = files[0].filename;
  console.log("-------------", files); //return false;

  let headerArray = [
    "vin",
    "make",
    "model",
    "series",
    "year",
    "milage",
    "reserve_price",
    "interior_color",
    "exterior_color",
    "body",
    "drive_type",
    "engine",
    "fuel_type",
    "startingBid",
    "containerNo",
    "costPrice",
  ];
  const filePath = path.resolve(DIR, filepathname);
  //console.log('filePath-------------',filePath); //return false;
  //const filePath2 = path.resolve(__dirname, filepathname);
  // console.log("10888888882=====>>>>>", filePath2);
  const workbook = new excelJS.Workbook();
  workbook.xlsx.readFile(filePath).then(async () => {
    const worksheet = workbook.getWorksheet(1);
    // console.log("102=====>>>>>", worksheet.actualRowCount);
    // return false;
    let tempRowindex = 2,
      tempRow,
      tempColumn,
      tempRowData;
    let data = [];
    while (tempRowindex <= worksheet.actualRowCount) {
      tempRow = worksheet.getRow(tempRowindex);
      tempColumn = 1;
      tempRowData = [];
      //console.log("headerArray.length=====>>>>>", headerArray.length);
      while (tempColumn <= headerArray.length) {
        let tempValue = tempRow.getCell(tempColumn).value;
        //console.log("tempValue=====>>>>>", tempValue);
        tempRowData.push(tempValue);
        tempColumn++;
      }
      tempRowindex++;
      if (tempRowData.length) {
        data.push([...tempRowData, tempRowindex]);
      }
      //console.log("100000=====>>>>>", data);
    }
    let objData = [];
    for (let i = 0; i < data.length; i++) {
      let [
        vin,
        make,
        model,
        series,
        year,
        milage,
        reservePrice,
        interior_color,
        exterior_color,
        body,
        drive_type,
        engine,
        fuel_type,
        startingBid,
        containerNo,
        costPrice,
      ] = data[i];
      let obj = {
        vin: vin,
        make: make,
        model: model,
        series: series,
        year: year,
        milage: milage,
        reservePrice: reservePrice,
        interiorcolorId: interior_color,
        exteriorcolorId: exterior_color,
        bodyId: body,
        drivetypeId: drive_type,
        engineId: engine,
        fueltypeId: fuel_type,
        startingBid: startingBid,
        containerNo: containerNo,
        costPrice: costPrice,
      };
      objData.push(obj);
    }
    console.log("1009=====>>>>>", objData);
    fs.writeFile("input.json", JSON.stringify(objData), function (err) {
      if (err) throw err;
      console.log("complete");
    });
    return false;
  });

  masterDao.planAdd(res, postData);
});
router.post("/removespace", async (req, res) => {
  let postData = req.body;
  let lang = req.headers["lang"] || config.lang;

  console.log("===========", postData);
  // return false;

  if (postData.Name == "make") {
    console.log("===========make");
    let getallData = await masterModal.Make.find(
      { status: 1 },
      { makeName: 1 }
    );
    for (var i = 0; i < getallData.length; i++) {
      let makename = getallData[i].makeName.trim();
      let cond = { _id: mongoose.Types.ObjectId(getallData[i]._id) };
      await masterModal.Make.updateMany(cond, { $set: { makeName: makename } });
    }
  } else if (postData.Name == "model") {
    console.log("===========model");
    let getallData = await masterModal.Model.find(
      { status: 1 },
      { modelName: 1 }
    );
    // console.log('===========',getallData);
    // return false;
    for (var i = 0; i < getallData.length; i++) {
      let modelname = getallData[i].modelName.trim();
      let cond = { _id: mongoose.Types.ObjectId(getallData[i]._id) };
      await masterModal.Model.updateMany(cond, {
        $set: { modelName: modelname },
      });
    }
  } else if (postData.Name == "series") {
    console.log("===========series");
    let getallData = await masterModal.Series.find(
      { status: 1 },
      { seriesName: 1 }
    );
    for (var i = 0; i < getallData.length; i++) {
      let seriesname = getallData[i].seriesName.trim();
      let cond = { _id: mongoose.Types.ObjectId(getallData[i]._id) };
      await masterModal.Series.updateMany(cond, {
        $set: { seriesName: seriesname },
      });
    }
  } else if (postData.Name == "body") {
    console.log("===========body");
    let getallData = await masterModal.Bodys.find(
      { status: 1 },
      { bodyName: 1 }
    );
    for (var i = 0; i < getallData.length; i++) {
      let bodyname = getallData[i].bodyName.trim();
      let cond = { _id: mongoose.Types.ObjectId(getallData[i]._id) };
      await masterModal.Bodys.updateMany(cond, {
        $set: { bodyName: bodyname },
      });
    }
  } else if (postData.Name == "branch") {
    console.log("===========branch");
    let getallData = await masterModal.Branch.find(
      { status: 1 },
      { branchName: 1 }
    );
    for (var i = 0; i < getallData.length; i++) {
      let branchname = getallData[i].branchName.trim();
      let cond = { _id: mongoose.Types.ObjectId(getallData[i]._id) };
      await masterModal.Branch.updateMany(cond, {
        $set: { branchName: branchname },
      });
    }
  } else if (postData.Name == "warehouse") {
    console.log("===========warehouse");
    let getallData = await masterModal.Warehouse.find(
      { status: 1 },
      { warehouseName: 1 }
    );
    for (var i = 0; i < getallData.length; i++) {
      let warehousename = getallData[i].warehouseName.trim();
      let cond = { _id: mongoose.Types.ObjectId(getallData[i]._id) };
      await masterModal.Warehouse.updateMany(cond, {
        $set: { warehouseName: warehousename },
      });
    }
  } else if (postData.Name == "engine") {
    console.log("===========engine");
    let getallData = await masterModal.Engines.find(
      { status: 1 },
      { engineName: 1 }
    );
    for (var i = 0; i < getallData.length; i++) {
      let enginename = getallData[i].engineName.trim();
      let cond = { _id: mongoose.Types.ObjectId(getallData[i]._id) };
      await masterModal.Engines.updateMany(cond, {
        $set: { engineName: enginename },
      });
    }
  } else if (postData.Name == "drivetype") {
    console.log("===========drivetype");
    let getallData = await masterModal.Drivetype.find(
      { status: 1 },
      { drivetypeName: 1 }
    );
    for (var i = 0; i < getallData.length; i++) {
      let drivetypename = getallData[i].drivetypeName.trim();
      let cond = { _id: mongoose.Types.ObjectId(getallData[i]._id) };
      await masterModal.Drivetype.updateMany(cond, {
        $set: { drivetypeName: drivetypename },
      });
    }
  } else if (postData.Name == "exteriorcolor") {
    console.log("===========exteriorcolor");
    let getallData = await masterModal.exteriorColor.find(
      { status: 1 },
      { colorName: 1 }
    );
    for (var i = 0; i < getallData.length; i++) {
      let colorname = getallData[i].colorName.trim();
      let cond = { _id: mongoose.Types.ObjectId(getallData[i]._id) };
      await masterModal.exteriorColor.updateMany(cond, {
        $set: { colorName: colorname },
      });
    }
  } else if (postData.Name == "interiorcolor") {
    console.log("===========interiorColor");
    let getallData = await masterModal.interiorColor.find(
      { status: 1 },
      { colorName: 1 }
    );
    for (var i = 0; i < getallData.length; i++) {
      let colorname = getallData[i].colorName.trim();
      let cond = { _id: mongoose.Types.ObjectId(getallData[i]._id) };
      await masterModal.interiorColor.updateMany(cond, {
        $set: { colorName: colorname },
      });
    }
  } else if (postData.Name == "role") {
    console.log("===========Userrole");
    let getallData = await masterModal.Userrole.find(
      { status: 1 },
      { userRole: 1 }
    );
    for (var i = 0; i < getallData.length; i++) {
      let userrole = getallData[i].userRole.trim();
      let cond = { _id: mongoose.Types.ObjectId(getallData[i]._id) };
      await masterModal.Userrole.updateMany(cond, {
        $set: { userRole: userrole },
      });
    }
  } else if (postData.Name == "fueltype") {
    console.log("===========fueltype");
    let getallData = await masterModal.Fueltypes.find(
      { status: 1 },
      { fueltypeName: 1 }
    );
    for (var i = 0; i < getallData.length; i++) {
      let fueltypename = getallData[i].fueltypeName.trim();
      let cond = { _id: mongoose.Types.ObjectId(getallData[i]._id) };
      await masterModal.Fueltypes.updateMany(cond, {
        $set: { fueltypeName: fueltypename },
      });
    }
  }
});

router.post("/notification", (req, res) => {
  var users = [
    {
      name: "what is loren ipsum?",
      desc: "This is test notification1",
      createAt: "14-08-2023",
    },
    {
      name: "what is loren ipsum?",
      desc: "This is test notification2",
      createAt: "14-08-2023",
    },
    {
      name: "what is loren ipsum?",
      desc: "This is test notification3",
      createAt: "14-08-2023",
    },
    {
      name: "what is loren ipsum?",
      desc: "This is test notification4",
      createAt: "14-08-2023",
    },
  ];
  res.status(200).json({
    status: true,
    result: users,
    message: "",
  });
});

router
  .route("/custom-services")
  .post(
    [
      midleware.validateFieldValue(
        ["name", "glId", "services"],
        ["name", "glId", "services"]
      ),
    ],
    createCustomService
  )
  .get(getCustomServices);

router
  .route("/custom-services/:id")
  .get(getCustomService)
  .patch(updateCustomService)
  .delete(deleteCustomService);

module.exports = router;
/**
 * @swagger
 * /api/master/importdata:
 *   post:
 *     tags: [Master]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: importId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *     responses:
 *       200:
 *         description: import data.
 *
 */
/**
 * @swagger
 * /api/master/exportdata:
 *   post:
 *     tags: [Master]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: exportdataId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *     responses:
 *       200:
 *         description: Make List.
 *
 */
/**
 * @swagger
 * /api/master/add:
 *   post:
 *     tags: [Master]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: makeName
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: status
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: Add Make.
 *
 */

/**
 * @swagger
 * /api/master/list:
 *   post:
 *     tags: [Master]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: makeName
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: search
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: pageLimit
 *         in: formData
 *         type: number
 *         required: true
 *         description:
 *       - name: page
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: Make List.
 *
 */

/**
 * @swagger
 * /api/master/update:
 *   patch:
 *     tags: [Master]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: makeId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: makeName
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: status
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *     responses:
 *       200:
 *         description: Make update.
 *
 */

/**
 * @swagger
 * /api/master/modeladd:
 *   post:
 *     tags: [Master]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: modelName
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: status
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: makeId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: Add Model.
 *
 */

/**
 * @swagger
 * /api/master/modellist:
 *   post:
 *     tags: [Master]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: makeName
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: makeId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: modelName
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: search
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: pageLimit
 *         in: formData
 *         type: number
 *         required: true
 *         description:
 *       - name: page
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: Make List.
 *
 */

/**
 * @swagger
 * /api/master/modelupdate:
 *   patch:
 *     tags: [Master]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: modelId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: modelName
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: makeId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: status
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: update all fields using above api.
 *
 */
/**
 * @swagger
 * /api/master/seriesadd:
 *   post:
 *     tags: [Master]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: seriesName
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: modelId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: status
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: Add Series.
 *
 */
/**
 * @swagger
 * /api/master/serieslist:
 *   post:
 *     tags: [Master]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: modelName
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: seriesName
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: search
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: pageLimit
 *         in: formData
 *         type: number
 *         required: true
 *         description:
 *       - name: page
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: Series List.
 *
 */
/**
 * @swagger
 * /api/master/seriesupdate:
 *   patch:
 *     tags: [Master]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: seriesId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: seriesName
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: modelId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: status
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: Series Update.
 *
 */
/**
 * @swagger
 * /api/master/branchadd:
 *   post:
 *     tags: [Master]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: branchName
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: Trnno
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: fullbranchName
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: branchAddress
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: branchMobile
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: branchEmail
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: contactPerson1
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: contactPerson2
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: openingDay
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: branchImage
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: branchDesc
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: status
 *         in: formData
 *         type: Number
 *         required: false
 *         description:
 *     responses:
 *       200:
 *         description: Add Branch.
 *
 */

/**
 * @swagger
 * /api/master/branchlist:
 *   post:
 *     tags: [Master]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: branchId[]
 *         in: formData
 *         type: array
 *         items:
 *           type: string
 *         required: false
 *         description:
 *       - name: branchName
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: pageLimit
 *         in: formData
 *         type: number
 *         required: true
 *         description:
 *       - name: page
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: Series List.
 *
 */

/**
 * @swagger
 * /api/master/branchupdate:
 *   patch:
 *     tags: [Master]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: branchId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: branchName
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: Trnno
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: fullbranchName
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: status
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *     responses:
 *       200:
 *         description: Series Update.
 *
 */
/**
 * @swagger
 * /api/master/warehouseadd:
 *   post:
 *     tags: [Master]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: warehouseName
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: branchId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: status
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: Add Warehouse.
 *
 */

/**
 * @swagger
 * /api/master/warehouselist:
 *   post:
 *     tags: [Master]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: branchId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: branchIds[]
 *         in: formData
 *         type: array
 *         items:
 *           type: string
 *         required: false
 *         description:
 *       - name: warehouseName
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: pageLimit
 *         in: formData
 *         type: number
 *         required: true
 *         description:
 *       - name: page
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: Make List.
 *
 */
/**
 * @swagger
 * /api/master/warehouseupdate:
 *   patch:
 *     tags: [Master]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: warehosId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: branchId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: warehouseName
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: status
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: warehouse update.
 *
 */
/**
 * @swagger
 * /api/master/handlingfeeadd:
 *   post:
 *     tags: [Master]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: branchId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: basePlan
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: premiumPlan
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: status
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: Add Warehouse.
 *
 */

/**
 * @swagger
 * /api/master/handlingfeelist:
 *   post:
 *     tags: [Master]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: pageLimit
 *         in: formData
 *         type: number
 *         required: true
 *         description:
 *       - name: page
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: Make List.
 *
 */
/**
 * @swagger
 * /api/master/handlingfeeupdate:
 *   patch:
 *     tags: [Master]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: handlingId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: branchId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: basePlan
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: premiumPlan
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: status
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *     responses:
 *       200:
 *         description: warehouse update.
 *
 */
/**
 * @swagger
 * /api/master/auctionfeeadd:
 *   post:
 *     tags: [Master]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: branchId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: startamount
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: endamount
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: handlingfee
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: status
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: Add Warehouse.
 *
 */

/**
 * @swagger
 * /api/master/auctionfeelist:
 *   post:
 *     tags: [Master]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: pageLimit
 *         in: formData
 *         type: number
 *         required: true
 *         description:
 *       - name: page
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: Make List.
 *
 */
/**
 * @swagger
 * /api/master/auctionfeeupdate:
 *   patch:
 *     tags: [Master]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: auctionId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: startamount
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: endamount
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: handlingfee
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: status
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *     responses:
 *       200:
 *         description: warehouse update.
 *
 */
/**
 * @swagger
 * /api/master/buyerlimitadd:
 *   post:
 *     tags: [Master]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: package
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: deposit
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: creditlimit
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: purchaselimit
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: status
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: Add Warehouse.
 *
 */

/**
 * @swagger
 * /api/master/buyerlimitlist:
 *   post:
 *     tags: [Master]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: package
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: pageLimit
 *         in: formData
 *         type: number
 *         required: true
 *         description:
 *       - name: page
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: Make List.
 *
 */
/**
 * @swagger
 * /api/master/buyerlimitupdate:
 *   patch:
 *     tags: [Master]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: buyerId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: package
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: deposit
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: creditlimit
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: status
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *     responses:
 *       200:
 *         description: warehouse update.
 *
 */
/**
 * @swagger
 * /api/master/yearadd:
 *   post:
 *     tags: [Master]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: yearName
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: status
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: Add Warehouse.
 *
 */

/**
 * @swagger
 * /api/master/yearlist:
 *   post:
 *     tags: [Master]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: pageLimit
 *         in: formData
 *         type: number
 *         required: true
 *         description:
 *       - name: page
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: Make List.
 *
 */
/**
 * @swagger
 * /api/master/yearupdate:
 *   patch:
 *     tags: [Master]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: yearId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: yearName
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: status
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *     responses:
 *       200:
 *         description: warehouse update.
 *
 */
/**
 * @swagger
 * /api/master/interiorcoloradd:
 *   post:
 *     tags: [Master]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: colorName
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: colorCode
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: status
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: Add Color.
 *
 */

/**
 * @swagger
 * /api/master/interiorcolorlist:
 *   post:
 *     tags: [Master]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: colorName
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: pageLimit
 *         in: formData
 *         type: number
 *         required: true
 *         description:
 *       - name: page
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: Color List.
 *
 */

/**
 * @swagger
 * /api/master/interiorcolorupdate:
 *   patch:
 *     tags: [Master]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: colorId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: colorName
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: colorCode
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: status
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *     responses:
 *       200:
 *         description: Color update.
 *
 */
/**
 * @swagger
 * /api/master/exteriorcoloradd:
 *   post:
 *     tags: [Master]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: colorName
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: colorCode
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: status
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: Add exterior Color.
 *
 */

/**
 * @swagger
 * /api/master/exteriorcolorlist:
 *   post:
 *     tags: [Master]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: colorName
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: pageLimit
 *         in: formData
 *         type: number
 *         required: true
 *         description:
 *       - name: page
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: exterior Color List.
 *
 */

/**
 * @swagger
 * /api/master/exteriorcolorupdate:
 *   patch:
 *     tags: [Master]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: colorId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: colorName
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: colorCode
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: status
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *     responses:
 *       200:
 *         description: exterior Color update.
 *
 */
/**
 * @swagger
 * /api/master/bodyadd:
 *   post:
 *     tags: [Master]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: bodyName
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: status
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: Add body.
 *
 */

/**
 * @swagger
 * /api/master/bodylist:
 *   post:
 *     tags: [Master]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: bodyName
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: pageLimit
 *         in: formData
 *         type: number
 *         required: true
 *         description:
 *       - name: page
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: body List.
 *
 */

/**
 * @swagger
 * /api/master/bodyupdate:
 *   patch:
 *     tags: [Master]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: bodyId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: bodyName
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: status
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *     responses:
 *       200:
 *         description: Color update.
 *
 */
/**
 * @swagger
 * /api/master/engineadd:
 *   post:
 *     tags: [Master]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: engineName
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: status
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: Add Engine.
 *
 */

/**
 * @swagger
 * /api/master/enginelist:
 *   post:
 *     tags: [Master]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: engineName
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: pageLimit
 *         in: formData
 *         type: number
 *         required: true
 *         description:
 *       - name: page
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: engine List.
 *
 */

/**
 * @swagger
 * /api/master/engineupdate:
 *   patch:
 *     tags: [Master]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: engineId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: engineName
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: status
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *     responses:
 *       200:
 *         description: Engine update.
 *
 */
/**
 * @swagger
 * /api/master/drivetypeadd:
 *   post:
 *     tags: [Master]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: drivetypeName
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: status
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: Add drivetypeName.
 *
 */

/**
 * @swagger
 * /api/master/drivetypelist:
 *   post:
 *     tags: [Master]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: drivetypeName
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: pageLimit
 *         in: formData
 *         type: number
 *         required: true
 *         description:
 *       - name: page
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: drivetypeName List.
 *
 */

/**
 * @swagger
 * /api/master/drivetypeupdate:
 *   patch:
 *     tags: [Master]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: drivetypeId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: drivetypeName
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: status
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *     responses:
 *       200:
 *         description: drivetypeName update.
 *
 */
/**
 * @swagger
 * /api/master/fueltypeadd:
 *   post:
 *     tags: [Master]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: fueltypeName
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: status
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: Add fueltypeName.
 *
 */

/**
 * @swagger
 * /api/master/fueltypelist:
 *   post:
 *     tags: [Master]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: fueltypeName
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: pageLimit
 *         in: formData
 *         type: number
 *         required: true
 *         description:
 *       - name: page
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: fueltypeName List.
 *
 */

/**
 * @swagger
 * /api/master/fueltypeupdate:
 *   patch:
 *     tags: [Master]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: fueltypeId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: fueltypeName
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: status
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *     responses:
 *       200:
 *         description: fueltypeName update.
 *
 */
/**
 * @swagger
 * /api/master/cylinderadd:
 *   post:
 *     tags: [Master]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: cylinderName
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: status
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: Add cylinderadd.
 *
 */

/**
 * @swagger
 * /api/master/cylinderlist:
 *   post:
 *     tags: [Master]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: pageLimit
 *         in: formData
 *         type: number
 *         required: true
 *         description:
 *       - name: page
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: cylinder List.
 *
 */

/**
 * @swagger
 * /api/master/cylinderupdate:
 *   patch:
 *     tags: [Master]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: cylinderId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: cylinderName
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: status
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *     responses:
 *       200:
 *         description: cylinder update.
 *
 */
/**
 * @swagger
 * /api/master/transmissionadd:
 *   post:
 *     tags: [Master]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: transName
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: status
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: Add Transmission.
 *
 */

/**
 * @swagger
 * /api/master/transmissionlist:
 *   post:
 *     tags: [Master]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: transName
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: pageLimit
 *         in: formData
 *         type: number
 *         required: true
 *         description:
 *       - name: page
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: transmission List.
 *
 */

/**
 * @swagger
 * /api/master/transmissionupdate:
 *   patch:
 *     tags: [Master]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: transId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: transName
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: status
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *     responses:
 *       200:
 *         description: transmission update.
 *
 */
/**
 * @swagger
 * /api/master/addUserRole:
 *   post:
 *     tags: [Master]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: x-access-token
 *         in: header
 *         type: string
 *         required: true
 *         description: Authorization Token
 *       - name: userRole
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: status
 *         in: formData
 *         type: number
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: Add user role.
 *
 */

/**
 * @swagger
 * /api/master/userRoleList:
 *   post:
 *     tags: [Master]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: x-access-token
 *         in: header
 *         type: string
 *         required: true
 *         description: Authorization Token
 *       - name: pageLimit
 *         in: formData
 *         type: number
 *         required: true
 *         description:
 *       - name: page
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: User Role List.
 *
 */

/**
 * @swagger
 * /api/master/updateUserRole:
 *   patch:
 *     tags: [Master]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: x-access-token
 *         in: header
 *         type: string
 *         required: true
 *         description: Authorization Token
 *       - name: userRoleId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: userRole
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: status
 *         in: formData
 *         type: number
 *         required: false
 *         description:
 *     responses:
 *       200:
 *         description: user Role update.
 *
 */

/**
 * @swagger
 * /api/master/menuAdd:
 *   post:
 *     tags: [Master]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: x-access-token
 *         in: header
 *         type: string
 *         required: true
 *         description: Authorization Token
 *       - name: parentId
 *         in: formData
 *         type: string
 *         required: false
 *       - name: displayOrder
 *         in: formData
 *         type: number
 *         required: true
 *       - name: icon
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: menu
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: link
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: status
 *         in: formData
 *         type: number
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: Add user role.
 *
 */

/**
 * @swagger
 * /api/master/menuList:
 *   post:
 *     tags: [Master]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: x-access-token
 *         in: header
 *         type: string
 *         required: true
 *         description: Authorization Token
 *       - name: search
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: type
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *            ex tree,normal
 *       - name: pageLimit
 *         in: formData
 *         type: number
 *         required: true
 *         description:
 *       - name: page
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: Menu List.
 *
 */
/**
 * @swagger
 * /api/master/delete:
 *   delete:
 *     tags: [Master]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: deleteId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: Menu delete.
 *
 */
/**
 * @swagger
 * /api/master/menuUpdate:
 *   patch:
 *     tags: [Master]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: menuId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: menu
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: status
 *         in: formData
 *         type: number
 *         required: false
 *         description:
 *     responses:
 *       200:
 *         description: Menu update.
 *
 */

/**
 * @swagger
 * /api/master/menuAccessAdd:
 *   post:
 *     tags: [Master]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: userRoleId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *            ex: 6401a9bf7b0f9312aad244d8
 *       - name: menuAccessArr
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *          object value like  index name read add edit delete inport export
 *     responses:
 *       200:
 *         description: Add user role.
 *
 */

/**
 * @swagger
 * /api/master/menuAccessList:
 *   post:
 *     tags: [Master]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: userRoleId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: pageLimit
 *         in: formData
 *         type: number
 *         required: true
 *         description:
 *       - name: page
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: Menu Access List.
 *
 */

/**
 * @swagger
 * /api/master/sidebarMenuAcess:
 *   post:
 *     tags: [Master]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: listType
 *         in: formData
 *         type: string
 *         required: required
 *         description:
 *           ex- list type like sidebar or access
 *       - name: userRoleId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: menuLink
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: pageLimit
 *         in: formData
 *         type: number
 *         required: true
 *         description:
 *       - name: page
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: Menu Access List.
 *
 */
/**
 * @swagger
 * /api/master/sellerplanadd:
 *   post:
 *     tags: [Master]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: planName
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: listingFee
 *         in: formData
 *         type: Number
 *         required: false
 *         description:
 *       - name: runs
 *         in: formData
 *         type:  Number
 *         required: false
 *         description:
 *       - name: auctionTypeFee
 *         in: formData
 *         type:  string
 *         required: false
 *         description:
 *              EX - unlimited,limited
 *       - name: increment
 *         in: formData
 *         type:  Number
 *         required: false
 *         description:
 *       - name: amountValue
 *         in: formData
 *         type:  Number
 *         required: false
 *         description:
 *       - name: branchId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: initialfee
 *         in: formData
 *         type: Number
 *         required: false
 *         description:
 *       - name: defaultbranchplan
 *         in: formData
 *         type: Number
 *         required: false
 *         description:
 *       - name: status
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *     responses:
 *       200:
 *         description: sellerplanadd.
 *
 */
/**
 * @swagger
 * /api/master/sellerplanlist:
 *   post:
 *     tags: [Master]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: planName
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: search
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: branchId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: branchIds[]
 *         in: formData
 *         type: array
 *         items:
 *           type: string
 *         required: false
 *         description:
 *       - name: sellerplanId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: parkingDays
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: storage
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: initialfee
 *         in: formData
 *         type: Number
 *         required: false
 *         description:
 *       - name: status
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: defaultbranchplan
 *         in: formData
 *         type: number
 *         required: false
 *         description:
 *       - name: pageLimit
 *         in: formData
 *         type: number
 *         required: true
 *         description:
 *       - name: page
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: seller plan list.
 *
 */
/**
 * @swagger
 * /api/master/sellerplanupdate:
 *   patch:
 *     tags: [Master]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: sellerplanId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: planName
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: listingFee
 *         in: formData
 *         type: Number
 *         required: false
 *         description:
 *       - name: runs
 *         in: formData
 *         type:  Number
 *         required: false
 *         description:
 *       - name: auctionTypeFee
 *         in: formData
 *         type:  string
 *         required: false
 *         description:
 *       - name: increment
 *         in: formData
 *         type:  Number
 *         required: false
 *         description:
 *       - name: amountValue
 *         in: formData
 *         type:  Number
 *         required: false
 *         description:
 *       - name: status
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: branchId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *     responses:
 *       200:
 *         description: sellerplanupdate.
 *
 */
/**
 * @swagger
 * /api/master/removespace:
 *   post:
 *     tags: [Master]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: Name
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *            EX - make,model,series,body,branch,warehouse,engine,drivetype,interiorcolor,exteriorcolor,role,fueltype
 *     responses:
 *       200:
 *         description: Add removespace.
 *
 */
/**
 * @swagger
 * /api/master/notification:
 *   post:
 *     tags: [Master]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: notification
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *     responses:
 *       200:
 *         description: notification.
 *
 */

/**
 * @swagger
 * /api/master/custom-services:
 *   post:
 *     tags: [Master]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: name
 *         in: formData
 *         type: string
 *         required: true
 *       - name: glId
 *         in: formData
 *         type: string
 *         required: true
 *     responses:
 *       200:
 *         description: Master - Custom Services - Create
 */

/**
 * @swagger
 * /api/master/custom-services:
 *   get:
 *     tags: [Master]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: name
 *         in: query
 *         type: string
 *         required: false
 *       - name: pageLimit
 *         in: query
 *         type: number
 *         required: true
 *         description:
 *       - name: page
 *         in: query
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: Master - Custom Services - Get
 */

/**
 * @swagger
 * /api/master/custom-services/{id}:
 *   get:
 *     tags: [Master]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: id
 *         in: path
 *         type: string
 *         required: false
 *     responses:
 *       200:
 *         description: Master - Custom Services - Get One
 */

/**
 * @swagger
 * /api/master/custom-services/{id}:
 *   patch:
 *     tags: [Master]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: id
 *         in: path
 *         type: string
 *         required: false
 *       - name: status
 *         in: formData
 *         type: number
 *         required: false
 *     responses:
 *       200:
 *         description: Master - Custom Services - Update
 */

/**
 * @swagger
 * /api/master/custom-services/{id}:
 *   delete:
 *     tags: [Master]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: id
 *         in: path
 *         type: string
 *         required: false
 *     responses:
 *       200:
 *         description: Master - Custom Services - Delete
 */
