const masterModal = require("../master/masterModal");
const message = require("../../config/message");
const cmethod = require("../../middleware/common-fun");

const makeAdd = async function (res, postData) {
  const newMaster = new masterModal.Make(postData);

  newMaster.save(postData, async function (err, data) {
    if (err) {
      cmethod.returnSreverError(res, message.technicalError, err);
    } else {
      cmethod.returnSuccess(res, data, false, message.signupsuccess);
    }
  });
};
const planAdd = async function (res, postData) {
  
  if (postData?.branchId) {
    await masterModal.Sellerplan.updateMany(
      { branchId: postData?.branchId },
      { $set: { defaultbranchplan: 0 } }
    );
  }
  
  if (postData.auctionTypeFee == "unlimited") {
    postData.increment = 0;
    postData.amountValue = 0;
  }
  //console.log('===================',postData);
  const newMaster = new masterModal.Sellerplan(postData);

  newMaster.save(postData, async function (err, data) {
    if (err) {
      cmethod.returnSreverError(res, message.technicalError, err);
    } else {
      cmethod.returnSuccess(res, data, false, message.signupsuccess);
    }
  });
};
const findMakeWithFiled = async function (query) {
  return new Promise(function (resolve, reject) {
    masterModal.Make.find(
      { _id: { $exists: true } },
      { vin: 1 },
      function (err, data) {
        if (err) {
          reject(err);
        } else {
          resolve(data);
        }
      }
    );
  });
};
const findMakeAggregation = function (query) {
  return new Promise(function (resolve, reject) {
    masterModal.Make.aggregate(query, function (err, data) {
      if (err) {
        reject(err);
      } else {
        resolve(data);
      }
    });
  });
};
const findPlanAggregation = function (query) {
  return new Promise(function (resolve, reject) {
    masterModal.Sellerplan.aggregate(query, function (err, data) {
      if (err) {
        reject(err);
      } else {
        resolve(data);
      }
    });
  });
};
//user roles api
const userRoleAdd = async function (res, postData) {
  const newUserRole = new masterModal.Userrole(postData);

  newUserRole.save(postData, async function (err, data) {
    if (err) {
      cmethod.returnSreverError(res, message.technicalError, err);
    } else {
      cmethod.returnSuccess(res, data, false, message.signupsuccess);
    }
  });
};
const findUserRoleAggregation = function (query) {
  return new Promise(function (resolve, reject) {
    masterModal.Userrole.aggregate(query, function (err, data) {
      if (err) {
        reject(err);
      } else {
        resolve(data);
      }
    });
  });
};

//Model API
const modelAdd = async function (res, postData) {
  const newModel = new masterModal.Model(postData);

  newModel.save(postData, async function (err, data) {
    if (err) {
      cmethod.returnSreverError(res, message.technicalError, err);
    } else {
      cmethod.returnSuccess(res, data, false, message.signupsuccess);
    }
  });
};

const findModelWithFiled = async function (query) {
  return new Promise(function (resolve, reject) {
    masterModal.Model.find(
      { _id: { $exists: true } },
      { vin: 1 },
      function (err, data) {
        if (err) {
          reject(err);
        } else {
          resolve(data);
        }
      }
    );
  });
};
const findModelAggregation = function (query) {
  return new Promise(function (resolve, reject) {
    masterModal.Model.aggregate(query, function (err, data) {
      if (err) {
        reject(err);
      } else {
        resolve(data);
      }
    });
  });
};

//Series API
const seriesAdd = async function (res, postData) {
  const newSeries = new masterModal.Series(postData);

  newSeries.save(postData, async function (err, data) {
    if (err) {
      cmethod.returnSreverError(res, message.technicalError, err);
    } else {
      cmethod.returnSuccess(res, data, false, message.signupsuccess);
    }
  });
};

const findSeriesWithFiled = async function (query) {
  return new Promise(function (resolve, reject) {
    masterModal.Series.find(
      { _id: { $exists: true } },
      { vin: 1 },
      function (err, data) {
        if (err) {
          reject(err);
        } else {
          resolve(data);
        }
      }
    );
  });
};
const findSeriesAggregation = function (query) {
  return new Promise(function (resolve, reject) {
    masterModal.Series.aggregate(query, function (err, data) {
      if (err) {
        reject(err);
      } else {
        resolve(data);
      }
    });
  });
};

const branchAdd = async function (res, postData) {
  const newBranch = new masterModal.Branch(postData);

  newBranch.save(postData, async function (err, data) {
    if (err) {
      cmethod.returnSreverError(res, message.technicalError, err);
    } else {
      cmethod.returnSuccess(res, data, false, message.signupsuccess);
    }
  });
};

const findBranchWithFiled = async function (query) {
  return new Promise(function (resolve, reject) {
    masterModal.Branch.find(
      { _id: { $exists: true } },
      { vin: 1 },
      function (err, data) {
        if (err) {
          reject(err);
        } else {
          resolve(data);
        }
      }
    );
  });
};
const findBranchAggregation = function (query) {
  return new Promise(function (resolve, reject) {
    masterModal.Branch.aggregate(query, function (err, data) {
      if (err) {
        reject(err);
      } else {
        resolve(data);
      }
    });
  });
};
const warehouseAdd = async function (res, postData) {
  const newWarehouse = new masterModal.Warehouse(postData);

  newWarehouse.save(postData, async function (err, data) {
    if (err) {
      cmethod.returnSreverError(res, message.technicalError, err);
    } else {
      cmethod.returnSuccess(res, data, false, message.signupsuccess);
    }
  });
};

const findWarehouseWithFiled = async function (query) {
  return new Promise(function (resolve, reject) {
    masterModal.Warehouse.find(
      { _id: { $exists: true } },
      { vin: 1 },
      function (err, data) {
        if (err) {
          reject(err);
        } else {
          resolve(data);
        }
      }
    );
  });
};
const findWarehouseAggregation = function (query) {
  return new Promise(function (resolve, reject) {
    masterModal.Warehouse.aggregate(query, function (err, data) {
      if (err) {
        reject(err);
      } else {
        resolve(data);
      }
    });
  });
};

const handlingfeeAdd = async function (res, postData) {
  const newHandlingfee = new masterModal.Handlingfee(postData);

  newHandlingfee.save(postData, async function (err, data) {
    if (err) {
      cmethod.returnSreverError(res, message.technicalError, err);
    } else {
      cmethod.returnSuccess(res, data, false, message.signupsuccess);
    }
  });
};

const findHandlingfeeWithFiled = async function (query) {
  return new Promise(function (resolve, reject) {
    masterModal.Handlingfee.find(
      { _id: { $exists: true } },
      { vin: 1 },
      function (err, data) {
        if (err) {
          reject(err);
        } else {
          resolve(data);
        }
      }
    );
  });
};
const findHandlingfeeAggregation = function (query) {
  return new Promise(function (resolve, reject) {
    masterModal.Handlingfee.aggregate(query, function (err, data) {
      if (err) {
        reject(err);
      } else {
        resolve(data);
      }
    });
  });
};
const auctionfeeAdd = async function (res, postData) {
  const newAuctionfee = new masterModal.Auctionfee(postData);

  newAuctionfee.save(postData, async function (err, data) {
    if (err) {
      cmethod.returnSreverError(res, message.technicalError, err);
    } else {
      cmethod.returnSuccess(res, data, false, message.signupsuccess);
    }
  });
};

const findAuctionfeeWithFiled = async function (query) {
  return new Promise(function (resolve, reject) {
    masterModal.Auctionfee.find(
      { _id: { $exists: true } },
      { vin: 1 },
      function (err, data) {
        if (err) {
          reject(err);
        } else {
          resolve(data);
        }
      }
    );
  });
};
const findAuctionfeeAggregation = function (query) {
  return new Promise(function (resolve, reject) {
    masterModal.Auctionfee.aggregate(query, function (err, data) {
      if (err) {
        reject(err);
      } else {
        resolve(data);
      }
    });
  });
};
const buyerlimitAdd = async function (res, postData) {
  const newBuyerlimit = new masterModal.Buyerlimit(postData);

  newBuyerlimit.save(postData, async function (err, data) {
    if (err) {
      cmethod.returnSreverError(res, message.technicalError, err);
    } else {
      cmethod.returnSuccess(res, data, false, message.signupsuccess);
    }
  });
};

const findBuyerlimitWithFiled = async function (query) {
  return new Promise(function (resolve, reject) {
    masterModal.Buyerlimit.find(
      { _id: { $exists: true } },
      { vin: 1 },
      function (err, data) {
        if (err) {
          reject(err);
        } else {
          resolve(data);
        }
      }
    );
  });
};
const findBuyerlimitAggregation = function (query) {
  return new Promise(function (resolve, reject) {
    masterModal.Buyerlimit.aggregate(query, function (err, data) {
      if (err) {
        reject(err);
      } else {
        resolve(data);
      }
    });
  });
};
const yearAdd = async function (res, postData) {
  const newYear = new masterModal.Year(postData);

  newYear.save(postData, async function (err, data) {
    if (err) {
      cmethod.returnSreverError(res, message.technicalError, err);
    } else {
      cmethod.returnSuccess(res, data, false, message.signupsuccess);
    }
  });
};

const findYearWithFiled = async function (query) {
  return new Promise(function (resolve, reject) {
    masterModal.Year.find(
      { _id: { $exists: true } },
      { vin: 1 },
      function (err, data) {
        if (err) {
          reject(err);
        } else {
          resolve(data);
        }
      }
    );
  });
};
const findYearAggregation = function (query) {
  return new Promise(function (resolve, reject) {
    masterModal.Year.aggregate(query, function (err, data) {
      if (err) {
        reject(err);
      } else {
        resolve(data);
      }
    });
  });
};
const interiorcolorAdd = async function (res, postData) {
  const newColor = new masterModal.interiorColor(postData);

  newColor.save(postData, async function (err, data) {
    if (err) {
      cmethod.returnSreverError(res, message.technicalError, err);
    } else {
      cmethod.returnSuccess(res, data, false, message.signupsuccess);
    }
  });
};

const findColorWithFiled = async function (query) {
  return new Promise(function (resolve, reject) {
    masterModal.interiorColor.find(
      { _id: { $exists: true } },
      { vin: 1 },
      function (err, data) {
        if (err) {
          reject(err);
        } else {
          resolve(data);
        }
      }
    );
  });
};
const findColorAggregation = function (query) {
  return new Promise(function (resolve, reject) {
    masterModal.interiorColor.aggregate(query, function (err, data) {
      if (err) {
        reject(err);
      } else {
        resolve(data);
      }
    });
  });
};
//exterior color
const exteriorcolorAdd = async function (res, postData) {
  const newColor = new masterModal.exteriorColor(postData);

  newColor.save(postData, async function (err, data) {
    if (err) {
      cmethod.returnSreverError(res, message.technicalError, err);
    } else {
      cmethod.returnSuccess(res, data, false, message.signupsuccess);
    }
  });
};

const findexColorWithFiled = async function (query) {
  return new Promise(function (resolve, reject) {
    masterModal.exteriorColor.find(
      { _id: { $exists: true } },
      { vin: 1 },
      function (err, data) {
        if (err) {
          reject(err);
        } else {
          resolve(data);
        }
      }
    );
  });
};
const findexColorAggregation = function (query) {
  return new Promise(function (resolve, reject) {
    masterModal.exteriorColor.aggregate(query, function (err, data) {
      if (err) {
        reject(err);
      } else {
        resolve(data);
      }
    });
  });
};
//Body
const bodyAdd = async function (res, postData) {
  const newBody = new masterModal.Bodys(postData);

  newBody.save(postData, async function (err, data) {
    if (err) {
      cmethod.returnSreverError(res, message.technicalError, err);
    } else {
      cmethod.returnSuccess(res, data, false, message.signupsuccess);
    }
  });
};

const findBodysWithFiled = async function (query) {
  return new Promise(function (resolve, reject) {
    masterModal.Bodys.find(
      { _id: { $exists: true } },
      { vin: 1 },
      function (err, data) {
        if (err) {
          reject(err);
        } else {
          resolve(data);
        }
      }
    );
  });
};
const findBodysAggregation = function (query) {
  return new Promise(function (resolve, reject) {
    masterModal.Bodys.aggregate(query, function (err, data) {
      if (err) {
        reject(err);
      } else {
        resolve(data);
      }
    });
  });
};
//Engine
//Body
const engineAdd = async function (res, postData) {
  const newEngine = new masterModal.Engines(postData);

  newEngine.save(postData, async function (err, data) {
    if (err) {
      cmethod.returnSreverError(res, message.technicalError, err);
    } else {
      cmethod.returnSuccess(res, data, false, message.signupsuccess);
    }
  });
};

const findEngineWithFiled = async function (query) {
  return new Promise(function (resolve, reject) {
    masterModal.Engines.find(
      { _id: { $exists: true } },
      { vin: 1 },
      function (err, data) {
        if (err) {
          reject(err);
        } else {
          resolve(data);
        }
      }
    );
  });
};
const findEngineAggregation = function (query) {
  return new Promise(function (resolve, reject) {
    masterModal.Engines.aggregate(query, function (err, data) {
      if (err) {
        reject(err);
      } else {
        resolve(data);
      }
    });
  });
};
//Body
const cylinderAdd = async function (res, postData) {
  const newCylinder = new masterModal.Cylinders(postData);

  newCylinder.save(postData, async function (err, data) {
    if (err) {
      cmethod.returnSreverError(res, message.technicalError, err);
    } else {
      cmethod.returnSuccess(res, data, false, message.signupsuccess);
    }
  });
};

const findCylinderWithFiled = async function (query) {
  return new Promise(function (resolve, reject) {
    masterModal.Cylinders.find(
      { _id: { $exists: true } },
      { vin: 1 },
      function (err, data) {
        if (err) {
          reject(err);
        } else {
          resolve(data);
        }
      }
    );
  });
};
const findCylinderAggregation = function (query) {
  return new Promise(function (resolve, reject) {
    masterModal.Cylinders.aggregate(query, function (err, data) {
      if (err) {
        reject(err);
      } else {
        resolve(data);
      }
    });
  });
};
//============================================
const driveTypeAdd = async function (res, postData) {
  const newEngine = new masterModal.Drivetype(postData);

  newEngine.save(postData, async function (err, data) {
    if (err) {
      cmethod.returnSreverError(res, message.technicalError, err);
    } else {
      cmethod.returnSuccess(res, data, false, message.signupsuccess);
    }
  });
};

const finddriveTypeWithFiled = async function (query) {
  return new Promise(function (resolve, reject) {
    masterModal.Drivetype.find(
      { _id: { $exists: true } },
      { vin: 1 },
      function (err, data) {
        if (err) {
          reject(err);
        } else {
          resolve(data);
        }
      }
    );
  });
};
const finddriveTypeAggregation = function (query) {
  return new Promise(function (resolve, reject) {
    masterModal.Drivetype.aggregate(query, function (err, data) {
      if (err) {
        reject(err);
      } else {
        resolve(data);
      }
    });
  });
};
//===================================================
const fueltypeAdd = async function (res, postData) {
  const newFueltype = new masterModal.Fueltypes(postData);

  newFueltype.save(postData, async function (err, data) {
    if (err) {
      cmethod.returnSreverError(res, message.technicalError, err);
    } else {
      cmethod.returnSuccess(res, data, false, message.signupsuccess);
    }
  });
};

const findfuelTypeWithFiled = async function (query) {
  return new Promise(function (resolve, reject) {
    masterModal.Fueltypes.find(
      { _id: { $exists: true } },
      { vin: 1 },
      function (err, data) {
        if (err) {
          reject(err);
        } else {
          resolve(data);
        }
      }
    );
  });
};
const findfuelTypeAggregation = function (query) {
  return new Promise(function (resolve, reject) {
    masterModal.Fueltypes.aggregate(query, function (err, data) {
      if (err) {
        reject(err);
      } else {
        resolve(data);
      }
    });
  });
};
//=====================transmission=================
//============================================
const transmissionAdd = async function (res, postData) {
  const newTrans = new masterModal.Transmission(postData);

  newTrans.save(postData, async function (err, data) {
    if (err) {
      cmethod.returnSreverError(res, message.technicalError, err);
    } else {
      cmethod.returnSuccess(res, data, false, message.signupsuccess);
    }
  });
};

const findTransWithFiled = async function (query) {
  return new Promise(function (resolve, reject) {
    masterModal.Transmission.find(
      { _id: { $exists: true } },
      { vin: 1 },
      function (err, data) {
        if (err) {
          reject(err);
        } else {
          resolve(data);
        }
      }
    );
  });
};
const findTransAggregation = function (query) {
  return new Promise(function (resolve, reject) {
    masterModal.Transmission.aggregate(query, function (err, data) {
      if (err) {
        reject(err);
      } else {
        resolve(data);
      }
    });
  });
};
//menu
const menuAdd = async function (res, postData) {
  const newMenu = new masterModal.Menu(postData);

  newMenu.save(postData, async function (err, data) {
    if (err) {
      cmethod.returnSreverError(res, message.technicalError, err);
    } else {
      cmethod.returnSuccess(res, data, false, message.signupsuccess);
    }
  });
};

const findMenuAggregation = function (query) {
  return new Promise(function (resolve, reject) {
    masterModal.Menu.aggregate(query, function (err, data) {
      if (err) {
        reject(err);
      } else {
        resolve(data);
      }
    });
  });
};

//menu access
const menuAccessAdd = async function (res, postData) {
  const newMenuaccess = new masterModal.Menuaccess(postData);

  newMenuaccess.save(postData, async function (err, data) {
    if (err) {
      cmethod.returnSreverError(res, message.technicalError, err);
    } else {
      cmethod.returnSuccess(res, data, false, message.signupsuccess);
    }
  });
};

const findMenuAccessAggregation = function (query) {
  return new Promise(function (resolve, reject) {
    masterModal.Menuaccess.aggregate(query, function (err, data) {
      if (err) {
        reject(err);
      } else {
        resolve(data);
      }
    });
  });
};
const checkmakeName = async function (query) {
  return new Promise(function (resolve, reject) {
    masterModal.Make.find(query, function (err, data) {
      if (data.length > 0) {
        resolve(true);
      } else {
        resolve(false);
      }
    });
  });
};
const checkuserRole = async function (query) {
  return new Promise(function (resolve, reject) {
    masterModal.Userrole.find(query, function (err, data) {
      if (data.length > 0) {
        resolve(true);
      } else {
        resolve(false);
      }
    });
  });
};
const checkmodelName = async function (query) {
  return new Promise(function (resolve, reject) {
    masterModal.Model.find(query, function (err, data) {
      if (data.length > 0) {
        resolve(true);
      } else {
        resolve(false);
      }
    });
  });
};
const checkseriesName = async function (query) {
  return new Promise(function (resolve, reject) {
    masterModal.Series.find(query, function (err, data) {
      if (data.length > 0) {
        resolve(true);
      } else {
        resolve(false);
      }
    });
  });
};
const checkbranchName = async function (query) {
  return new Promise(function (resolve, reject) {
    masterModal.Branch.find(query, function (err, data) {
      if (data.length > 0) {
        resolve(true);
      } else {
        resolve(false);
      }
    });
  });
};
const checkwarehouseName = async function (query) {
  return new Promise(function (resolve, reject) {
    masterModal.Warehouse.find(query, function (err, data) {
      if (data.length > 0) {
        resolve(true);
      } else {
        resolve(false);
      }
    });
  });
};
const checkhandlingfeeName = async function (query) {
  return new Promise(function (resolve, reject) {
    masterModal.Handlingfee.find(query, function (err, data) {
      if (data.length > 0) {
        resolve(true);
      } else {
        resolve(false);
      }
    });
  });
};
const checkauctionfeeName = async function (query) {
  return new Promise(function (resolve, reject) {
    masterModal.Auctionfee.find(query, function (err, data) {
      if (data.length > 0) {
        resolve(true);
      } else {
        resolve(false);
      }
    });
  });
};
const checkbuyerlimitName = async function (query) {
  return new Promise(function (resolve, reject) {
    masterModal.Buyerlimit.find(query, function (err, data) {
      if (data.length > 0) {
        resolve(true);
      } else {
        resolve(false);
      }
    });
  });
};
const checkyearName = async function (query) {
  return new Promise(function (resolve, reject) {
    masterModal.Year.find(query, function (err, data) {
      if (data.length > 0) {
        resolve(true);
      } else {
        resolve(false);
      }
    });
  });
};
const checkinteriorcolorName = async function (query) {
  return new Promise(function (resolve, reject) {
    masterModal.interiorColor.find(query, function (err, data) {
      if (data.length > 0) {
        resolve(true);
      } else {
        resolve(false);
      }
    });
  });
};
const checktransmissionName = async function (query) {
  return new Promise(function (resolve, reject) {
    masterModal.Transmission.find(query, function (err, data) {
      if (data.length > 0) {
        resolve(true);
      } else {
        resolve(false);
      }
    });
  });
};
const checkexteriorcolorName = async function (query) {
  return new Promise(function (resolve, reject) {
    masterModal.exteriorColor.find(query, function (err, data) {
      if (data.length > 0) {
        resolve(true);
      } else {
        resolve(false);
      }
    });
  });
};
const checkdrivetypeName = async function (query) {
  return new Promise(function (resolve, reject) {
    masterModal.Drivetype.find(query, function (err, data) {
      if (data.length > 0) {
        resolve(true);
      } else {
        resolve(false);
      }
    });
  });
};
const checkfueltypeName = async function (query) {
  return new Promise(function (resolve, reject) {
    masterModal.Fueltypes.find(query, function (err, data) {
      if (data.length > 0) {
        resolve(true);
      } else {
        resolve(false);
      }
    });
  });
};
const checkexteriorName = async function (query) {
  return new Promise(function (resolve, reject) {
    masterModal.exteriorColor.find(query, function (err, data) {
      if (data.length > 0) {
        resolve(true);
      } else {
        resolve(false);
      }
    });
  });
};
const checkbodyName = async function (query) {
  return new Promise(function (resolve, reject) {
    masterModal.Bodys.find(query, function (err, data) {
      if (data.length > 0) {
        resolve(true);
      } else {
        resolve(false);
      }
    });
  });
};
const checkengineName = async function (query) {
  return new Promise(function (resolve, reject) {
    masterModal.Engines.find(query, function (err, data) {
      if (data.length > 0) {
        resolve(true);
      } else {
        resolve(false);
      }
    });
  });
};

module.exports = {
  userRoleAdd,
  findUserRoleAggregation,
  checkuserRole,
  checkmodelName,
  checkseriesName,
  checkbranchName,
  checkwarehouseName,
  checkhandlingfeeName,
  checkauctionfeeName,
  checkbuyerlimitName,
  checkyearName,
  checkinteriorcolorName,
  checkexteriorcolorName,
  checktransmissionName,
  checkdrivetypeName,
  checkfueltypeName,
  checkexteriorName,
  checkbodyName,
  checkengineName,
  makeAdd,
  findMakeWithFiled,
  findMakeAggregation,
  checkmakeName,
  modelAdd,
  findModelWithFiled,
  findModelAggregation,
  seriesAdd,
  findSeriesWithFiled,
  findSeriesAggregation,
  branchAdd,
  findBranchWithFiled,
  findBranchAggregation,
  warehouseAdd,
  findWarehouseWithFiled,
  findWarehouseAggregation,
  auctionfeeAdd,
  findAuctionfeeWithFiled,
  findAuctionfeeAggregation,
  handlingfeeAdd,
  findHandlingfeeWithFiled,
  findHandlingfeeAggregation,
  buyerlimitAdd,
  findBuyerlimitWithFiled,
  findBuyerlimitAggregation,
  yearAdd,
  findYearWithFiled,
  findYearAggregation,
  interiorcolorAdd,
  findColorWithFiled,
  findColorAggregation,
  exteriorcolorAdd,
  findexColorWithFiled,
  findexColorAggregation,
  bodyAdd,
  findBodysWithFiled,
  findBodysAggregation,
  engineAdd,
  findEngineWithFiled,
  findEngineAggregation,
  driveTypeAdd,
  finddriveTypeWithFiled,
  finddriveTypeAggregation,
  transmissionAdd,
  findTransWithFiled,
  findTransAggregation,
  cylinderAdd,
  findCylinderAggregation,
  findCylinderWithFiled,
  fueltypeAdd,
  findfuelTypeAggregation,
  findfuelTypeWithFiled,

  menuAdd,
  findMenuAggregation,
  menuAccessAdd,
  findMenuAccessAggregation,
  planAdd,
  findPlanAggregation,
};
