const accountModal = require("../account/accountModal");
const auctionModal = require("../auction/auctionModal");
const message = require("../../config/message");
const cmethod = require("../../middleware/common-fun");
var mongoose = require("mongoose");
const { createCommonLog } = require("../../services/comment.service");

const expenseAdd = async function (res, postData) {
  const newOutgoingcash = new accountModal.Outgoingcash(postData);
  //console.log('postData---------->',postData);
  newOutgoingcash.save(postData, async function (err, data) {
    if (err) {
      cmethod.returnSreverError(res, message.technicalError, err);
    } else {
      //console.log('data---------->',data); //return false;
      let insertData = [];
      let postitemData = postData?.itemData;
      // let postitemData = [
      //   {
      //     expenseId: "645e6cca67aa54f409a92636",
      //     date: "17-05-2023",
      //     description: "This is first desc",
      //     invoice: "1",
      //     amount: "6000",
      //   },
      //   {
      //     expenseId: "645e6cca67aa54f409a92636",
      //     date: "21-05-2023",
      //     description: "This is second desc",
      //     invoice: "1",
      //     amount: "7000",
      //   },
      // ];
      if (postitemData.length > 0) {
        for (var i = 0; i < postitemData.length; i++) {
          if (postitemData[i].invoice != "" && postitemData.amount != "") {
            insertData.push({
              expenseId: mongoose.Types.ObjectId(data?._id),
              date: postitemData[i]?.date,
              invoice: postitemData[i]?.invoice,
              amount: postitemData[i]?.amount,
              description: postitemData[i]?.description,
            });
          }
        }

        if (insertData.length > 0) {
          await accountModal.ItemExpenses.insertMany(insertData);
          //await accountModal.ItemExpenses.insertMany(insertData, (err, data) => {});
          cmethod.returnSuccess(res, data, false, message.signupsuccess);
        }
      }
      cmethod.returnSuccess(res, data, false, message.signupsuccess);
    }
  });
};

const outgoingcashAdd = async function (res, postData) {
  const { createdBy = "system" } = postData;
  const newOutgoingcash = new accountModal.Outgoingcash(postData);

  newOutgoingcash.save(postData, async function (err, data) {
    if (err) {
      cmethod.returnSreverError(res, message.technicalError, err);
    } else {
      const { _id: referenceId, voucherNo } = data;

      await createCommonLog({
        action: "Created",
        from: "Account(Security Deposit)",
        id: referenceId,
        of: "account",
        no: voucherNo,
        by: createdBy,
      });
      cmethod.returnSuccess(res, data, false, message.signupsuccess);
    }
  });
};

const closingAccountAdd = async function (res, postData) {
  //console.log(postData); return false;
  //let calculatecrdrAmount = await calculateCrDrAmount(postData);
  //let drAmount = calculatecrdrAmount[0].totalAmount;
  //let crAmount = calculatecrdrAmount[1].totalAmount;
  //console.log('drAmount====================>', drAmount);
  //return false;
  /*set unique data only for markAccountId */
  //if (drAmount == crAmount) {
  postData.openingBalance = "Y";
  const newclosingAccount = new accountModal.ClosingAccount(postData);
  newclosingAccount.save(postData, async function (err, data) {
    if (err) {
      cmethod.returnSreverError(res, message.technicalError, err);
    } else {
      //console.log('data@123===========>',data);
      /*var today = new Date();
      var _month = today.getMonth();
      var _year = today.getFullYear();
      var _day1 = today.getDate();
      var __month1 = _month + 1;
      var _toDate = _year + "-" + __month1 + "-" + _day1;
      var fdate = new Date(_toDate);
      fdate.setDate(fdate.getDate());
      fdate.setUTCHours(0, 0, 0, 0);
      var tdate = new Date(_toDate);
      tdate.setDate(tdate.getDate());
      tdate.setUTCHours(23, 59, 59, 0);
      var matchch = { createdAt: { $gte: fdate, $lte: tdate } }
      await accountModal.Accountledger.updateMany(matchch, { $set: { closingStatus: 1 } });*/

      //Case :-1 : 3 days before update :N
      var today = new Date();
      var _month = today.getMonth();
      var _year = today.getFullYear();
      var _day1 = today.getDate();
      var __month1 = _month + 1;
      var _toDate = _year + "-" + __month1 + "-" + _day1;
      var fdate = new Date(new Date().getTime() - 15 * 24 * 60 * 60 * 1000);
      fdate.setDate(fdate.getDate());
      fdate.setUTCHours(0, 0, 0, 0);
      var tdate = new Date(_toDate);
      tdate.setDate(tdate.getDate());
      tdate.setUTCHours(47, 59, 59, 0);
      var matchch = {
        createdAt: { $gte: fdate, $lte: tdate },
        branchId: mongoose.Types.ObjectId(postData.branchId),
        markAccountId: postData.markAccountId,
      };
      //console.log('--->matchch', matchch); return false;
      await accountModal.ClosingAccount.updateMany(matchch, {
        $set: { openingBalance: "N" },
      });

      //Case : -2 CURRENT DATE set Y

      await accountModal.ClosingAccount.updateOne(
        {
          _id: data?._id,
          markAccountId: postData.markAccountId,
          branchId: mongoose.Types.ObjectId(postData.branchId),
        },
        { $set: { openingBalance: "Y" } }
      );

      //Case : -3 CURRENT DATE set Y
      //console.log('postData===========>',postData);
      let allIds = [];
      if (postData?.ledgerIds.length > 0) {
        let pdata = postData.ledgerIds;
        for (let i in pdata) {
          allIds.push(mongoose.Types.ObjectId(pdata[i]));
        }
      }
      if (allIds.length > 0) {
        await accountModal.Accountledger.updateMany(
          {
            _id: { $in: allIds },
            branchId: mongoose.Types.ObjectId(postData.branchId),
          },
          {
            $set: {
              closingStatus: 1,
              accountcloseId: mongoose.Types.ObjectId(data._id),
            },
          }
        );
      }

      //Case :4 update closingDate
      // await accountModal.Accountmaster.updateOne({ markAccountId: 'cash-in-hand' }, { $set: { closingDate: postData?.transDate } });

      //Case :5 update auctionClose
      await auctionModal.Auction.updateOne(
        {
          transDate: data?.transDate,
          branchId: mongoose.Types.ObjectId(postData.branchId),
        },
        { $set: { auctionClose: 1 } }
      );
      //notesDetails:[{notes:100,qty:5,total:500},{notes:100,qty:4,total:400}]

      // let saveClosingnotesdetail = {
      //   closingAccountId: mongoose.Types.ObjectId(data._id),
      //   Note: postData?.Note,
      //   qty: postData?.qty,
      //   Total: postData?.Total,
      // }
      // cmethod.addclosingNotesDetails(saveClosingnotesdetail);

      //let notesDetails = [{ notes: 100, qty: 5, total: 500 }, { notes: 100, qty: 4, total: 400 }]
      let notesDetails = postData?.notesDetails;
      if (notesDetails?.length > 0) {
        for (var i = 0; i < notesDetails.length; i++) {
          let saveClosingnotesdetail = {
            closingAccountId: mongoose.Types.ObjectId(data._id),
            Note: notesDetails[i]?.notes,
            qty: notesDetails[i]?.qty,
            Total: notesDetails[i]?.total,
          };
          cmethod.addclosingNotesDetails(saveClosingnotesdetail);
        }
      }
      //return false;

      /*add inventory images */
      let saveClosingAccountData = {
        referenceType: "closingAccount",
        referenceId: data?._id,
        message: "closingAccount created by ".concat(data?.createdBy),
        commentBy: data?.createdBy,
      };
      cmethod.addcommentsLog(saveClosingAccountData);
      cmethod.returnSuccess(res, data, false, message.signupsuccess);
    }
  });
  // } else {
  //   cmethod.returnSreverError(res, message.technicalError, err);
  // }
};
const findClosingDate = async function (query) {
  return new Promise(function (resolve, reject) {
    accountModal.ClosingAccount.find(
      query,
      { transDate: 1, amount: 1 },
      { sort: { transDate: -1 }, limit: 1 },
      function (err, data) {
        if (err) {
          reject(err);
        } else {
          resolve(data);
        }
      }
    );
  });
};
const dailyBasisclosingAdd = async function (postData) {
  let query = [];
  // if (postData.branchId) {
  //   postData.branchId = postData.branchId;
  // } else {
  //   postData.branchId = '640ec8a8e979987820b80f7b';
  // }

  //-----------------------------date-------------------------
  var today = new Date();
  var _month = today.getMonth();
  var _year = today.getFullYear();
  //var _day = 01;
  var _day1 = today.getDate();
  var __month1 = _month + 1;
  //var _fromDate = _year + "-" + _month + "-" + _day;
  var _toDate = _year + "-" + __month1 + "-" + _day1;
  var fdate = new Date(_toDate);
  fdate.setDate(fdate.getDate());
  fdate.setUTCHours(0, 0, 0, 0);

  var tdate = new Date(_toDate);
  tdate.setDate(tdate.getDate());
  tdate.setUTCHours(23, 59, 59, 0);
  query.push({
    $lookup: {
      from: "accountmasters",
      localField: "glAccountId",
      foreignField: "_id",
      as: "accountmasters",
    },
  });
  query.push({
    $unwind: { path: "$accountmasters", preserveNullAndEmptyArrays: true },
  });
  query.push({
    $lookup: {
      from: "branchs",
      localField: "branchId",
      foreignField: "_id",
      as: "branchs",
    },
  });
  query.push({
    $unwind: { path: "$branchs", preserveNullAndEmptyArrays: true },
  });
  query.push({
    $lookup: {
      from: "reciepts",
      localField: "referenceId",
      foreignField: "_id",
      as: "reciepts",
    },
  });
  query.push({
    $unwind: { path: "$reciepts", preserveNullAndEmptyArrays: true },
  });

  query.push({
    $match: {
      $and: [
        {
          "accountmasters.markAccountId": { $in: ["cash-in-hand"] },
        },
      ],
    },
  });
  if (postData.branchId) {
    query.push({
      $match: {
        $and: [{ branchId: mongoose.Types.ObjectId(postData.branchId) }],
      },
    });
  }
  query.push({
    $match: {
      $and: [{ createdAt: { $gte: fdate, $lte: tdate } }],
    },
  });
  query.push({
    $group: {
      _id: "$transactionType",
      totalAmount: { $sum: "$payAmount" },
    },
  });

  query.push({
    $project: {
      transactionType: 1,
      paymentType: 1,
      payAmount: 1,
      referenceType: 1,
      referenceId: 1,
      referenceNo: "$reciepts.recieptNo",
      description: 1,
      createdBy: 1,
      createdAt: 1,
      totalAmount: 1,
    },
  });
  const sQuery = [...query];
  query.push({ $sort: { createdAt: -1 } });
  let datadata = await findAccountledgerAggregation(query);
  return datadata;
};
const calculateCrDrAmount = async function (postData) {
  let query = [];
  if (postData.branchId) {
    postData.branchId = postData.branchId;
  } else {
    postData.branchId = "640ec8a8e979987820b80f7b";
  }

  //-----------------------------date-------------------------
  var today = new Date();
  var _month = today.getMonth();
  var _year = today.getFullYear();
  //var _day = 01;
  var _day1 = today.getDate();
  var __month1 = _month + 1;
  //var _fromDate = _year + "-" + _month + "-" + _day;
  var _toDate = _year + "-" + __month1 + "-" + _day1;
  var fdate = new Date(_toDate);
  fdate.setDate(fdate.getDate());
  fdate.setUTCHours(0, 0, 0, 0);

  var tdate = new Date(_toDate);
  tdate.setDate(tdate.getDate());
  tdate.setUTCHours(23, 59, 59, 0);
  query.push({
    $lookup: {
      from: "accountmasters",
      localField: "glAccountId",
      foreignField: "_id",
      as: "accountmasters",
    },
  });
  query.push({
    $unwind: { path: "$accountmasters", preserveNullAndEmptyArrays: true },
  });
  query.push({
    $lookup: {
      from: "branchs",
      localField: "branchId",
      foreignField: "_id",
      as: "branchs",
    },
  });
  query.push({
    $unwind: { path: "$branchs", preserveNullAndEmptyArrays: true },
  });
  query.push({
    $lookup: {
      from: "reciepts",
      localField: "referenceId",
      foreignField: "_id",
      as: "reciepts",
    },
  });
  query.push({
    $unwind: { path: "$reciepts", preserveNullAndEmptyArrays: true },
  });

  query.push({
    $match: {
      $and: [
        {
          "accountmasters.markAccountId": { $in: ["cash-in-hand"] },
        },
      ],
    },
  });
  if (postData.branchId) {
    query.push({
      $match: {
        $and: [{ branchId: mongoose.Types.ObjectId(postData.branchId) }],
      },
    });
  }
  query.push({
    $match: {
      $and: [{ createdAt: { $gte: fdate, $lte: tdate } }],
    },
  });
  query.push({
    $group: {
      _id: "$transactionType",
      totalAmount: { $sum: "$payAmount" },
    },
  });

  query.push({
    $project: {
      transactionType: 1,
      paymentType: 1,
      payAmount: 1,
      referenceType: 1,
      referenceId: 1,
      referenceNo: "$reciepts.recieptNo",
      description: 1,
      createdBy: 1,
      createdAt: 1,
      totalAmount: 1,
    },
  });
  query.push({ $sort: { createdAt: -1 } });
  let datadata = await findAccountledgerAggregation(query);
  return datadata;
};
const findclosingAccountAggregation = function (query) {
  return new Promise(function (resolve, reject) {
    accountModal.ClosingAccount.aggregate(query, function (err, data) {
      if (err) {
        reject(err);
      } else {
        resolve(data);
      }
    });
  });
};
//-------------------------------------------------
const accountAdd = async function (res, postData) {
  /*set unique data only for markAccountId */
  if (postData?.markAccountId) {
    await accountModal.Accountmaster.updateMany(
      { markAccountId: postData?.markAccountId },
      { $set: { markAccountId: "" } }
    );
  }
  /*set unique data only for markAccountId */
  const newAccount = new accountModal.Accountmaster(postData);

  newAccount.save(postData, async function (err, data) {
    if (err) {
      cmethod.returnSreverError(res, message.technicalError, err);
    } else {
      cmethod.returnSuccess(res, data, false, message.signupsuccess);
    }
  });
};

const findAccountWithFiled = async function (query) {
  return new Promise(function (resolve, reject) {
    accountModal.Accountmaster.find(
      { _id: { $exists: true } },
      function (err, data) {
        if (err) {
          reject(err);
        } else {
          resolve(data);
        }
      }
    );
  });
};
const findAccountAggregation = function (query) {
  return new Promise(function (resolve, reject) {
    accountModal.Accountmaster.aggregate(query, function (err, data) {
      if (err) {
        reject(err);
      } else {
        resolve(data);
      }
    });
  });
};
const accountLedgerAdd = async function (res, postData) {
  const newAccountledger = new accountModal.Accountledger(postData);

  newAccountledger.save(postData, async function (err, data) {
    if (err) {
      cmethod.returnSreverError(res, message.technicalError, err);
    } else {
      cmethod.returnSuccess(res, data, false, message.successfully);
    }
  });
};

const findAccountledgerAggregation = function (query) {
  return new Promise(function (resolve, reject) {
    accountModal.Accountledger.aggregate(query, function (err, data) {
      if (err) {
        reject(err);
      } else {
        resolve(data);
      }
    });
  });
};
const findAccountledgertempAggregation = function (query) {
  return new Promise(function (resolve, reject) {
    accountModal.Accountledgertemp.aggregate(query, function (err, data) {
      if (err) {
        reject(err);
      } else {
        resolve(data);
      }
    });
  });
};
const findOutgoingcashAggregation = function (query) {
  return new Promise(function (resolve, reject) {
    accountModal.Outgoingcash.aggregate(query, function (err, data) {
      if (err) {
        reject(err);
      } else {
        resolve(data);
      }
    });
  });
};
const findAccountMasterAggregation = function (query) {
  return new Promise(function (resolve, reject) {
    accountModal.Accountmaster.aggregate(query, function (err, data) {
      if (err) {
        reject(err);
      } else {
        resolve(data);
      }
    });
  });
};
const findclosingnotesdetailAggregation = function (query) {
  return new Promise(function (resolve, reject) {
    accountModal.Closingnotesdetail.aggregate(query, function (err, data) {
      if (err) {
        reject(err);
      } else {
        resolve(data);
      }
    });
  });
};
const findExpenseggregation = function (query) {
  return new Promise(function (resolve, reject) {
    accountModal.ItemExpenses.aggregate(query, function (err, data) {
      if (err) {
        reject(err);
      } else {
        resolve(data);
      }
    });
  });
};
const accountPayable = async function (res, postData) {
  let accountPayableNo = await cmethod.accountPayable();
  postData.refno = accountPayableNo;
  const newaccountPayable = new accountModal.AccountPayable(postData);

  newaccountPayable.save(postData, async function (err, data) {
    if (err) {
      cmethod.returnSreverError(res, message.technicalError, err);
    } else {
      cmethod.returnSuccess(res, data, false, message.signupsuccess);
    }
  });
};
const findAccountpayableAggregation = function (query) {
  return new Promise(function (resolve, reject) {
    accountModal.AccountPayable.aggregate(query, function (err, data) {
      if (err) {
        reject(err);
      } else {
        resolve(data);
      }
    });
  });
};
module.exports = {
  accountAdd,
  findAccountWithFiled,
  findAccountAggregation,
  accountLedgerAdd,
  findAccountledgerAggregation,
  closingAccountAdd,
  findClosingDate,
  findclosingAccountAggregation,
  dailyBasisclosingAdd,
  outgoingcashAdd,
  expenseAdd,
  findOutgoingcashAggregation,
  findAccountMasterAggregation,
  findclosingnotesdetailAggregation,
  findExpenseggregation,
  findAccountledgertempAggregation,
  accountPayable,
  findAccountpayableAggregation,
};
