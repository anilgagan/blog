const express = require("express");
const router = express.Router();
const accountModal = require("../account/accountModal");
const message = require("../../config/message");
const config = require("../../config");
const midleware = require("../../middleware/validation");
const cmethod = require("../../middleware/common-fun");
const accountDao = require("./accountDao");
var mongoose = require("mongoose");
const {
  makeObjectId,
  makeObjectIds,
} = require("../../functions/global.functions");
const {
  getEntityBalance,
  approveSecurityDeposit,
  rejectSecurityDeposit,
  approveZeroRatedSecurityDeposit,
  rejectZeroRatedSecurityDeposit,
  updateIncomingOutgoingPayment,
} = require("../../services/account.service");
const logger = require("../../config/logger");
const {
  Lookup,
  Unwind,
  ExactMatch,
  IDMatch,
  LookupWithPipeline,
  InMatch,
  Sort,
  Limit,
  Project,
} = require("../../functions/mongoose.functions");
const {
  updateCommonLog,
  createCommonLog,
} = require("../../services/comment.service");
const { FindByIdAndUpdate } = require("../../models/factory");
const { addPaymentStorage } = require("../../controllers/account.controller");

router.post(
  "/expenseadd",
  [
    midleware.validateFieldValue(
      ["referenecType", "status"],
      ["referenecType", "status"]
    ),
  ],
  async (req, res) => {
    let postData = req.body;
    let voucherNo = await cmethod.getDocNo(postData.referenecType);
    postData.voucherNo = voucherNo;
    accountDao.expenseAdd(res, postData);
  }
);
router.post(
  "/expenselist",
  [midleware.validateFieldValue(["pageLimit", "page"], ["page"])],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let query = [];

    query.push({
      $lookup: {
        from: "branchs",
        localField: "branchId",
        foreignField: "_id",
        as: "branchs",
      },
    });
    query.push({
      $unwind: { path: "$branchs", preserveNullAndEmptyArrays: true },
    });
    query.push({
      $match: {
        $and: [{ referenecType: "expense" }],
      },
    });
    if (postData.expenseId) {
      query.push({
        $match: {
          $and: [{ _id: mongoose.Types.ObjectId(postData.expenseId) }],
        },
      });
    }
    query.push({
      $lookup: {
        from: "itemexpensesses",
        let: {
          outgoingId: "$_id",
          expenseId: "$expenseId",
        },
        pipeline: [
          {
            $match: {
              $expr: {
                $and: [{ $eq: ["$expenseId", "$$outgoingId"] }],
              },
            },
          },
        ],
        as: "itemexpensess",
      },
    });
    query.push({
      $project: {
        voucherNo: 1,
        referenceId: 1,
        referenecType: 1,
        paymentMethod: 1,
        amount: 1,
        file: 1,
        status: 1,
        referenceNo: 1,
        branchId: "$branchs._id",
        branchName: "$branchs.branchName",
        createdAt: 1,
        employeenameId: 1,
        departmenthead: 1,
        businessPurpose: 1,
        itemData: "$itemexpensess",
      },
    });
    const sQuery = [...query];
    query.push({ $sort: { createdAt: -1 } });
    sQuery.push({ $count: "recordCount" });

    if (postData.page) {
      query.push({
        $skip: cmethod.pageOffset(postData.page, postData.pageLimit),
      });
      query.push({ $limit: cmethod.pageLimit(postData.pageLimit) });
    }

    accountDao
      .findOutgoingcashAggregation(query)
      .then(function (data) {
        accountDao
          .findOutgoingcashAggregation(sQuery)
          .then(async function (dcount) {
            var element = {};
            // console.log('element1------------->', data);
            // for (var i = 0; i < data.length; i++) {
            //   let exData = await accountModal.ItemExpenses.find({ expenseId: mongoose.Types.ObjectId(data[i]._id) }, { date: 1, invoice: 1, amount: 1, description: 1, })
            //   element.referenecType = data[0].referenecType;
            //   element.paymentMethod = data[0].paymentMethod;
            //   element.branchId = data[0].branchId;
            //   element.employeenameId = data[0].employeenameId;
            //   element.departmenthead = data[0].departmenthead;
            //   element.businessPurpose = data[0].businessPurpose;
            //   element.itemData = exData;
            //   //console.log('element------------->', element);
            // }
            let tptCnt = 0;
            if (dcount.length > 0) {
              tptCnt = dcount[0].recordCount;
            }
            res.status(200).json({
              status: true,
              result: data,
              message: "",
              hasMore: cmethod.hasMoreCount(
                tptCnt,
                postData.page,
                postData.pageLimit
              ),
              totalCount: tptCnt,
            });
          })
          .catch((err) => {
            cmethod.returnSreverError(res, message[lang].technicalError, err);
          });
      })
      .catch((err) => {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      });
  }
);
router.patch(
  "/expenseupdate",
  [midleware.validateFieldValue(["expId"], ["expId"])],
  async (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let xtoken = req.headers["x-access-token"];
    //{ token: xtoken },
    let queryCond = {
      $and: [{ _id: mongoose.Types.ObjectId(postData.expId) }],
    };
    delete postData.expId;
    /*set unique data only for markAccountId */
    accountModal.Outgoingcash.findOneAndUpdate(
      queryCond,
      { $set: postData },
      { new: true },
      async function (err, data) {
        if (err) {
          cmethod.returnSreverError(res, message[lang].technicalError, err);
        } else {
          let insertData = [];
          let postitemData = postData?.itemData;
          /*let postitemData = [
            {
              id: "646520463a05a738cbd9aed5",
              date: "17-05-2023",
              description: "Monu1231",
              invoice: "1",
              amount: "9000",
            },
            {  
              id:"",
              date: "21-05-2023",
              description: "This is second dec insert451",
              invoice: "1",
              amount: "7000",
            },
          ];*/
          if (postitemData?.length > 0) {
            for (var i = 0; i < postitemData.length; i++) {
              //insert
              if (postitemData[i]?.id != "") {
                const itemData = await accountModal.ItemExpenses.findOne(
                  { _id: mongoose.Types.ObjectId(postitemData[i]?.id) },
                  { amount: 1 }
                );
                if (itemData) {
                  await accountModal.ItemExpenses.updateMany(
                    { _id: mongoose.Types.ObjectId(postitemData[i]?.id) },
                    {
                      $set: {
                        date: postitemData[i]?.date,
                        invoice: postitemData[i]?.invoice,
                        amount: postitemData[i]?.amount,
                        description: postitemData[i]?.description,
                      },
                    }
                  );
                }
              } else {
                insertData.push({
                  expenseId: mongoose.Types.ObjectId(data?.id),
                  date: postitemData[i]?.date,
                  invoice: postitemData[i]?.invoice,
                  amount: postitemData[i]?.amount,
                  description: postitemData[i]?.description,
                });
                await accountModal.ItemExpenses.insertMany(insertData);
              }
            }
          }
          cmethod.returnSuccess(res, data, false, message[lang].profileUpdate);
          /*if (data?.status == 'paid') {
            await recieptModal.Reciept.updateOne({ _id: mongoose.Types.ObjectId(data.referenceId) }, { $set: { securityClaim: 1 } });
            let ledgerData = [];
            const accountPettyData = await accountModal.Accountmaster.findOne({ markAccountId: 'petty-cash' }, {
              markAccountId: 1,
            }).sort({ createdAt: -1 });
            let pettyAccountId = accountPettyData?._id;
            let voucherNoUnique = await cmethod.getVoucherNo();           
            ledgerData.push({
              branchId: mongoose.Types.ObjectId(data.branchId),
              glAccountId: mongoose.Types.ObjectId(pettyAccountId),
              voucherNo: voucherNoUnique,
              transactionType: "cr",
              paymentType: data.paymentMethod,
              payAmount: Number(data?.amount),
              referenceType: "security claim",
              referenceId: mongoose.Types.ObjectId(data._id),
              referenceNo: data?.referenceNo,
              createdBy: "system",
              transDate: postData?.transDate,
            });
            const accountSecurityData = await accountModal.Accountmaster.findOne({ markAccountId: 'security' }, {
              markAccountId: 1,
            }).sort({ createdAt: -1 });
            let securityAccountId = accountSecurityData?._id;           
            ledgerData.push({
              branchId: mongoose.Types.ObjectId(data.branchId),
              glAccountId: mongoose.Types.ObjectId(securityAccountId),
              voucherNo: voucherNoUnique,
              transactionType: "dr",
              paymentType: data.paymentMethod,
              payAmount: Number(data?.amount),
              referenceType: "security claim",
              referenceId: mongoose.Types.ObjectId(data._id),
              referenceNo: data?.referenceNo,
              createdBy: "system",
              transDate: postData?.transDate,
            });
            await accountModal.Accountledger.insertMany(ledgerData);
          }
          cmethod.returnSuccess(res, data, false, message[lang].profileUpdate);*/
        }
      }
    );
  }
);
router.delete(
  "/expenseitemdelete",
  [midleware.validateFieldValue(["expId"], ["expId"])],
  async (req, res) => {
    let postData = req.body;
    let cond = {
      $and: [{ _id: mongoose.Types.ObjectId(postData.expId) }],
    };
    let lang = req.headers["lang"] || config.lang;

    accountModal.ItemExpenses.deleteOne(cond, postData)
      .then(async (data) => {
        cmethod.returnSuccess(res, [], false, message[lang].Deleteed);
      })
      .catch((err) => {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      });
  }
);
//-------------------outgoing cash add ----------------------
router.post(
  "/outgoingcashadd",
  [
    midleware.validateFieldValue(
      ["referenecType", "status"],
      ["referenecType", "status"]
    ),
  ],
  async (req, res) => {
    let postData = req.body;
    let voucherNo = await cmethod.getDocNo(postData.referenecType);
    postData.voucherNo = voucherNo;
    accountDao.outgoingcashAdd(res, postData);
  }
);
router.post(
  "/outgoingcashlist",
  [midleware.validateFieldValue(["pageLimit", "page"], ["page"])],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let query = [];

    query.push({
      $lookup: {
        from: "reciepts",
        localField: "referenceId",
        foreignField: "_id",
        as: "reciepts",
      },
    });
    query.push({
      $unwind: { path: "$reciepts", preserveNullAndEmptyArrays: true },
    });
    query.push({
      $lookup: {
        from: "branchs",
        localField: "branchId",
        foreignField: "_id",
        as: "branchs",
      },
    });
    query.push({
      $unwind: { path: "$branchs", preserveNullAndEmptyArrays: true },
    });

    // * inventories
    Lookup(query, "inventorys", "reciepts.inventoryId", "_id", "inventories");
    Unwind(query, "$inventories");

    // * makes
    Lookup(query, "makes", "inventories.make", "_id", "makes");
    Unwind(query, "$makes");

    // * models
    Lookup(query, "models", "inventories.model", "_id", "models");
    Unwind(query, "$models");

    // * exteriorcolors
    Lookup(
      query,
      "exteriorcolors",
      "inventories.exteriorcolorId",
      "_id",
      "exteriorcolors"
    );
    Unwind(query, "$exteriorcolors");

    // * match
    if (postData.voucherNo) {
      ExactMatch(query, "voucherNo", postData.voucherNo);
    }
    if (postData.referenecType) {
      ExactMatch(query, "referenecType", postData.referenecType);
    }
    if (postData.referenceNo) {
      ExactMatch(query, "referenceNo", postData.referenceNo);
    }
    if (postData.vin) {
      ExactMatch(query, "inventories.vin", postData.vin);
    }
    if (postData.branchId) {
      IDMatch(query, "branchs._id", postData.branchId);
    }
    if (postData.paymentMethod) {
      ExactMatch(query, "paymentMethod", postData.paymentMethod);
    }
    if (postData.status) {
      ExactMatch(query, "status", postData.status);
    }

    if (postData.outgoingcashId) {
      query.push({
        $match: {
          $and: [{ _id: mongoose.Types.ObjectId(postData.outgoingcashId) }],
        },
      });
    }
    let statusData = [];
    if (Array.isArray(postData?.status) && postData?.status?.length > 0) {
      let sdata = postData.status;
      for (let i in sdata) {
        statusData.push(mongoose.Types.ObjectId(sdata[i]));
      }
      query.push({
        $match: {
          $and: [
            {
              status: {
                $in: statusData,
              },
            },
          ],
        },
      });
    }
    query.push({
      $project: {
        voucherNo: 1,
        referenceId: 1,
        referenecType: 1,
        paymentMethod: 1,
        amount: 1,
        file: 1,
        status: 1,
        isZeroRatedReceipt: "$reciepts.isZeroRated",
        referenceNo: 1,
        branchId: "$branchs._id",
        branchName: "$branchs.branchName",
        createdAt: 1,
        vin: "$inventories.vin",
        carDescription: {
          $concat: [
            { $ifNull: ["$inventories.year", ""] },
            " ",
            { $ifNull: ["$makes.makeName", ""] },
            " ",
            { $ifNull: ["$models.modelName", ""] },
            //" ",
            //{ $ifNull: ["$exteriorcolors.colorName", ""] },
          ],
        },
      },
    });
    const sQuery = [...query];
    query.push({ $sort: { createdAt: -1 } });
    sQuery.push({ $count: "recordCount" });

    if (postData.page) {
      query.push({
        $skip: cmethod.pageOffset(postData.page, postData.pageLimit),
      });
      query.push({ $limit: cmethod.pageLimit(postData.pageLimit) });
    }

    accountDao
      .findOutgoingcashAggregation(query)
      .then(function (data) {
        accountDao
          .findOutgoingcashAggregation(sQuery)
          .then(async function (dcount) {
            let tptCnt = 0;
            if (dcount.length > 0) {
              tptCnt = dcount[0].recordCount;
            }
            res.status(200).json({
              status: true,
              result: data,
              message: "",
              hasMore: cmethod.hasMoreCount(
                tptCnt,
                postData.page,
                postData.pageLimit
              ),
              totalCount: tptCnt,
            });
          })
          .catch((err) => {
            cmethod.returnSreverError(res, message[lang].technicalError, err);
          });
      })
      .catch((err) => {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      });
  }
);
router.delete(
  "/outgoingcashdelete",
  [midleware.validateFieldValue(["outId"], ["outId"])],
  async (req, res) => {
    let postData = req.body;
    let cond = {
      $and: [{ _id: mongoose.Types.ObjectId(postData.outId) }],
    };
    let lang = req.headers["lang"] || config.lang;

    accountModal.Outgoingcash.deleteOne(cond, postData)
      .then(async (data) => {
        cmethod.returnSuccess(res, [], false, message[lang].Deleteed);
      })
      .catch((err) => {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      });
  }
);
router.patch(
  "/outgoingcashupdate",
  [midleware.validateFieldValue(["outgotId"], ["outgotId"])],
  async (req, res) => {
    const { body, headers } = req;
    const lang = headers.lang || config.lang;

    const {
      outgotId: outgoingCashId,
      isZeroRatedReceipt,
      createdBy = "system",
      ...rest
    } = body;

    try {
      const projection = { new: true };
      const outgoingCash = await FindByIdAndUpdate(
        accountModal.Outgoingcash,
        outgoingCashId,
        rest,
        projection
      );

      if (!outgoingCash) {
        return cmethod.returrnErrorMessage(res, "outgoing doc not found!");
      }

      const { status, referenceId, referenceNo } = outgoingCash;
      outgoingCash.createdBy = createdBy;

      if (status === "approved") {
        if (isZeroRatedReceipt) {
          await updateCommonLog({
            action: "Approved",
            from: "Account(Security Deposit)",
            id: referenceId,
            no: referenceNo,
            by: createdBy,
          });
          await approveZeroRatedSecurityDeposit(outgoingCash, cmethod);
        } else {
          await approveSecurityDeposit(outgoingCash, cmethod);
        }
      }
      if (status === "rejected") {
        if (isZeroRatedReceipt) {
          await rejectZeroRatedSecurityDeposit(outgoingCash, cmethod);
        } else {
          await rejectSecurityDeposit(outgoingCash, cmethod);
        }
      }
      cmethod.returnSuccess(
        res,
        outgoingCash,
        false,
        message[lang].profileUpdate
      );
    } catch (error) {
      logger.error(error.message);
      common.returnSreverError(res, message[lang]?.technicalError, error);
    }
  }
);
//add account
router.post(
  "/add",
  [
    midleware.validateFieldValue(
      ["accountName", "status"],
      ["accountName", "status"]
    ),
  ],
  async (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;

    let queryUnique = {
      $and: [{ accountNo: { $exists: true } }, { accountNo: { $gt: 0 } }],
    };
    let accountNoUnique = 0;
    const accountData = await accountModal.Accountmaster.findOne(queryUnique, {
      accountNo: 1,
    }).sort({ createdAt: -1 });

    if (accountData) {
      if (accountData.accountNo == 0 || !accountData.accountNo) {
        accountNoUnique = 100;
      } else {
        accountNoUnique = accountData.accountNo + 1;
      }
    } else {
      accountNoUnique = 100;
    }
    postData.accountNo = accountNoUnique;
    accountDao.accountAdd(res, postData);
  }
);

router.patch(
  "/update",
  [midleware.validateFieldValue(["accountId"], ["accountId"])],
  async (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let xtoken = req.headers["x-access-token"];
    //{ token: xtoken },
    let queryCond = {
      $and: [{ _id: mongoose.Types.ObjectId(postData.accountId) }],
    };
    delete postData.accountId;
    /*set unique data only for markAccountId */
    if (postData?.markAccountId) {
      await accountModal.Accountmaster.updateMany(
        { markAccountId: postData?.markAccountId },
        { $set: { markAccountId: "" } }
      );
    }
    /*set unique data only for markAccountId */
    accountModal.Accountmaster.findOneAndUpdate(
      queryCond,
      { $set: postData },
      { new: true },
      async function (err, data) {
        if (err) {
          cmethod.returnSreverError(res, message[lang].technicalError, err);
        } else {
          cmethod.returnSuccess(res, data, false, message[lang].profileUpdate);
        }
      }
    );
  }
);
router.post("/list", [midleware.validateFieldValue([], [])], (req, res) => {
  let postData = req.body;
  let lang = req.headers["lang"] || config.lang;
  let query = [];
  if (postData.type == "tree") {
    // query.push({
    //   $match: {
    //     $and: [{ parentId: null }],
    //   },
    // });
    // query.push({
    //   $graphLookup: {
    //     from: "accountmasters",
    //     startWith: "$_id",
    //     connectFromField: "_id",
    //     connectToField: "parentId",
    //     as: "childAccount",
    //   },
    // });
  } else {
    query.push({
      $lookup: {
        from: "accountmasters",
        localField: "parentId",
        foreignField: "_id",
        as: "parentAccount",
      },
    });
    query.push({
      $unwind: { path: "$parentAccount", preserveNullAndEmptyArrays: true },
    });
  }

  query.push({
    $lookup: {
      from: "branchs",
      localField: "branchId",
      foreignField: "_id",
      as: "branchs",
    },
  });
  query.push({
    $unwind: { path: "$branchs", preserveNullAndEmptyArrays: true },
  });

  if (postData.groupType) {
    query.push({
      $match: {
        $and: [{ type: postData.groupType }],
      },
    });
  }
  if (postData?.fixedGl) {
    query.push({
      $match: {
        $and: [{ fixedGl: Number(postData?.fixedGl) }],
      },
    });
  }
  if (postData?.fixedGlNot) {
    query.push({
      $match: {
        $and: [{ fixedGl: { $nin: [Number(postData?.fixedGlNot)] } }],
      },
    });
  }
  //postData.filteraccountNo=[126,127];
  if (postData.filteraccountNo) {
    query.push({
      $match: {
        $and: [{ accountNo: { $nin: postData.filteraccountNo } }],
      },
    });
  }
  if (postData.accountNo) {
    query.push({
      $match: {
        $and: [{ accountNo: Number(postData.accountNo) }],
      },
    });
  }
  if (postData.accountName) {
    query.push({
      $match: {
        $and: [
          {
            $or: [
              {
                accountName: {
                  $regex: postData.accountName,
                  $options: "i",
                },
              },
            ],
          },
        ],
      },
    });
  }
  if (postData.accountMasterId) {
    IDMatch(query, "_id", postData.accountMasterId);
  }

  if (postData.search) {
    query.push(
      {
        $addFields: {
          r_s: { $convert: { input: "$accountNo", to: "string" } },
        },
      },
      {
        $match: {
          $and: [
            {
              $or: [
                { accountName: { $regex: postData.search, $options: "i" } },
                { r_s: { $regex: postData.search, $options: "i" } },
              ],
            },
          ],
        },
      }
    );
  }
  query.push({
    $project: {
      accountNo: 1,
      accountName: 1,
      markAccountId: 1,
      nature: 1,
      parentId: 1,
      category: 1,
      type: 1,
      paymentType: 1,
      lock: 1,
      fixedGl: 1,
      status: 1,
      childAccount: 1,
      closingDate: 1,
      parentAccount: 1,
      createdAt: 1,
      branchId: "$branchs._id",
      branchName: "$branchs.branchName",
    },
  });
  const sQuery = [...query];
  query.push({ $sort: { createdAt: -1 } });
  sQuery.push({ $count: "recordCount" });

  if (postData.page) {
    query.push({
      $skip: cmethod.pageOffset(postData.page, postData.pageLimit),
    });
    query.push({ $limit: cmethod.pageLimit(postData.pageLimit) });
  }

  accountDao
    .findAccountAggregation(query)
    .then(function (data) {
      accountDao
        .findAccountAggregation(sQuery)
        .then(async function (dcount) {
          let tptCnt = 0;
          if (dcount.length > 0) {
            tptCnt = dcount[0].recordCount;
          }
          //for tree data
          if (postData.type == "tree") {
            data = await cmethod.buildTree(data);
          }
          res.status(200).json({
            status: true,
            result: data,
            message: "",
            hasMore: cmethod.hasMoreCount(
              tptCnt,
              postData.page,
              postData.pageLimit
            ),
            totalCount: tptCnt,
          });
        })
        .catch((err) => {
          cmethod.returnSreverError(res, message[lang].technicalError, err);
        });
    })
    .catch((err) => {
      cmethod.returnSreverError(res, message[lang].technicalError, err);
    });
});
router.delete(
  "/delete",
  [midleware.validateFieldValue(["accountId"], ["accountId"])],
  async (req, res) => {
    let postData = req.body;
    let cond = {
      $or: [
        { _id: mongoose.Types.ObjectId(postData.accountId) },
        { parentId: mongoose.Types.ObjectId(postData.accountId) },
      ],
    };
    let lang = req.headers["lang"] || config.lang;

    accountModal.Accountmaster.deleteMany(cond, postData)
      .then(async (data) => {
        cmethod.returnSuccess(res, [], false, message[lang].Deleteed);
      })
      .catch((err) => {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      });
  }
);

router.post(
  "/glList",
  // [
  //   midleware.validateFieldValue(
  //     ["pageLimit", "page"],
  //     ["pageLimit", "page"]
  //   )
  // ],
  (req, res) => {
    let postData = req.body;
    let query = [];
    query.push({
      $lookup: {
        from: "accountmasters",
        localField: "glAccountId",
        foreignField: "_id",
        as: "accountmasters",
      },
    });
    query.push({
      $unwind: { path: "$accountmasters", preserveNullAndEmptyArrays: true },
    });
    query.push({
      $lookup: {
        from: "branchs",
        localField: "branchId",
        foreignField: "_id",
        as: "branchs",
      },
    });
    query.push({
      $unwind: { path: "$branchs", preserveNullAndEmptyArrays: true },
    });
    /*query.push({
      $lookup: {
        from: "reciepts",
        localField: "referenceId",
        foreignField: "_id",
        as: "reciepts",
      },
    });
    query.push({
      $unwind: { path: "$reciepts", preserveNullAndEmptyArrays: true },
    });*/

    if (postData.accountNo) {
      query.push({
        $match: {
          $and: [{ "accountmasters.accountNo": Number(postData.accountNo) }],
        },
      });
    }
    if (postData.accountName) {
      query.push({
        $match: {
          $and: [
            {
              $or: [
                {
                  "accountmasters.accountName": {
                    $regex: postData.accountName,
                    $options: "i",
                  },
                },
              ],
            },
          ],
        },
      });
    }
    if (postData.addedFrom) {
      query.push({
        $match: {
          $and: [{ addedFrom: postData.addedFrom }],
        },
      });
    }
    if (postData.transactionType) {
      query.push({
        $match: {
          $and: [{ transactionType: postData.transactionType }],
        },
      });
    }
    if (postData.voucherNo) {
      query.push({
        $match: {
          $and: [{ voucherNo: postData.voucherNo }],
        },
      });
    }

    //----------------------------------------------------------
    let branchData = [];
    if (postData?.branchId?.length > 0) {
      let pdata = postData.branchId;
      for (let i in pdata) {
        branchData.push(mongoose.Types.ObjectId(pdata[i]));
      }
      query.push({
        $match: {
          $and: [
            {
              branchId: {
                $in: branchData,
              },
            },
          ],
        },
      });
    }
    if (postData.fromDate && postData.toDate) {
      query.push({
        $match: {
          $and: [
            {
              transDate: {
                $gte: new Date(
                  cmethod.startTimeString(new Date(postData.fromDate))
                ),
              },
            },
            {
              transDate: {
                $lte: new Date(
                  cmethod.endTimeString(new Date(postData.toDate))
                ),
              },
            },
          ],
        },
      });
    }
    if (postData.search) {
      query.push({
        $match: {
          $and: [
            {
              $or: [
                {
                  referenceNo: {
                    $regex: postData.search,
                    $options: "i",
                  },
                },
                {
                  referenceNo2: {
                    $regex: postData.search,
                    $options: "i",
                  },
                },
                {
                  voucherNo: {
                    $regex: postData.search,
                    $options: "i",
                  },
                },
                {
                  description: {
                    $regex: postData.search,
                    $options: "i",
                  },
                },
                {
                  transactionType: {
                    $regex: postData.search,
                    $options: "i",
                  },
                },
              ],
            },
          ],
        },
      });
    }
    //-----------------------------------------------------------------------
    query.push({
      $project: {
        voucherNo: 1,
        branchId: "$branchs._id",
        branchName: "$branchs.branchName",
        accountNo: "$accountmasters.accountNo",
        accountName: "$accountmasters.accountName",
        closingStatus: 1,
        transactionType: 1,
        paymentType: 1,
        payAmount: 1,
        referenceType: 1,
        referenceId: 1,
        referenceNo: 1, //"$reciepts.recieptNo",
        referenceNo2: 1,
        description: 1,
        createdBy: 1,
        createdAt: 1,
        transDate: 1,
      },
    });
    const sQuery = [...query];
    query.push({ $sort: { createdAt: 1 } });
    sQuery.push({ $count: "recordCount" });

    if (postData.page) {
      query.push({
        $skip: cmethod.pageOffset(postData.page, postData.pageLimit),
      });
      query.push({ $limit: cmethod.pageLimit(postData.pageLimit) });
    }

    accountDao
      .findAccountledgerAggregation(query)
      .then(function (data) {
        accountDao
          .findAccountledgerAggregation(sQuery)
          .then(async function (dcount) {
            let tptCnt = 0;
            if (dcount.length > 0) {
              tptCnt = dcount[0].recordCount;
            }
            res.status(200).json({
              status: true,
              result: data,
              message: "",
              hasMore: cmethod.hasMoreCount(
                tptCnt,
                postData.page,
                postData.pageLimit
              ),
              totalCount: tptCnt,
            });
          })
          .catch((err) => {
            cmethod.returnSreverError(res, message[lang].technicalError, err);
          });
      })
      .catch((err) => {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      });
  }
);
router.post(
  "/glListReport",
  // [
  //   midleware.validateFieldValue(
  //     [],
  //     []
  //   )
  // ],
  (req, res) => {
    let postData = req.body;
    let query = [];

    // * accountmasters
    query.push({
      $lookup: {
        from: "accountmasters",
        localField: "glAccountId",
        foreignField: "_id",
        as: "accountmasters",
      },
    });
    query.push({
      $unwind: { path: "$accountmasters", preserveNullAndEmptyArrays: true },
    });

    // * branchs
    query.push({
      $lookup: {
        from: "branchs",
        localField: "branchId",
        foreignField: "_id",
        as: "branchs",
      },
    });
    query.push({
      $unwind: { path: "$branchs", preserveNullAndEmptyArrays: true },
    });

    // * reciepts
    query.push({
      $lookup: {
        from: "reciepts",
        localField: "referenceId",
        foreignField: "_id",
        as: "reciepts",
      },
    });
    query.push({
      $unwind: { path: "$reciepts", preserveNullAndEmptyArrays: true },
    });

    if (postData.accountNo) {
      query.push({
        $match: {
          $and: [{ "accountmasters.accountNo": Number(postData.accountNo) }],
        },
      });
    }
    if (postData.accountName) {
      query.push({
        $match: {
          $and: [
            {
              $or: [
                {
                  "accountmasters.accountName": {
                    $regex: postData.accountName,
                    $options: "i",
                  },
                },
              ],
            },
          ],
        },
      });
    }
    if (postData.markAccountId) {
      query.push({
        $match: {
          $and: [
            {
              "accountmasters.markAccountId": postData.markAccountId,
            },
          ],
        },
      });
    }
    if (postData.voucherNo) {
      query.push({
        $match: {
          $and: [{ voucherNo: postData.voucherNo }],
        },
      });
    }
    if (postData.accountCloseId) {
      query.push({
        $match: {
          $and: [
            {
              accountCloseId: mongoose.Types.ObjectId(postData.accountCloseId),
            },
          ],
        },
      });
    }
    let branchData = [];
    if (postData?.branchId?.length > 0) {
      let pdata = postData.branchId;
      for (let i in pdata) {
        branchData.push(mongoose.Types.ObjectId(pdata[i]));
      }
      //console.log("reciept====>", branchData);
      query.push({
        $match: {
          $and: [
            {
              branchId: {
                $in: branchData,
              },
            },
          ],
        },
      });
    }
    if (postData.fromData && postData.toData) {
      query.push({
        $match: {
          $and: [
            {
              transDate: {
                $gte: new Date(
                  cmethod.startTimeString(new Date(postData.fromData))
                ),
              },
            },
            {
              transDate: {
                $lte: new Date(
                  cmethod.endTimeString(new Date(postData.toData))
                ),
              },
            },
          ],
        },
      });
    }
    if (postData.search) {
      query.push({
        $match: {
          $and: [
            {
              $or: [
                {
                  referenceNo: {
                    $regex: postData.search,
                    $options: "i",
                  },
                },
                {
                  referenceNo2: {
                    $regex: postData.search,
                    $options: "i",
                  },
                },
              ],
            },
          ],
        },
      });
    }
    if (postData.buyerNo) {
      query.push({
        $match: {
          $and: [{ buyerNo: postData.buyerNo }],
        },
      });
    }
    if (postData.sellerNo) {
      query.push({
        $match: {
          $and: [{ sellerNo: postData.sellerNo }],
        },
      });
    }
    if (postData.transactionOf) {
      query.push({
        $match: {
          $and: [{ transactionOf: postData.transactionOf }],
        },
      });
    }

    query.push({
      $project: {
        voucherNo: 1,
        branchId: 1,
        branchName: "$branchs.branchName",
        accountNo: "$accountmasters.accountNo",
        accountName: "$accountmasters.accountName",
        transactionType: 1,
        paymentType: 1,
        payAmount: 1,
        referenceType: 1,
        referenceId: 1,
        referenceNo: 1, //"$reciepts.recieptNo",
        referenceNo2: 1,
        description: 1,
        createdBy: 1,
        createdAt: 1,
        transDate: 1,
        closingStatus: 1,
        buyerNo: 1,
        sellerNo: 1,
        transactionOf: 1,
      },
    });
    const sQuery = [...query];
    if (postData?.orderBy) {
      query.push({ $sort: { transDate: -1 } });
    } else {
      query.push({ $sort: { transDate: 1 } });
    }
    sQuery.push({ $count: "recordCount" });

    if (postData.page) {
      query.push({
        $skip: cmethod.pageOffset(postData.page, postData.pageLimit),
      });
      query.push({ $limit: cmethod.pageLimit(postData.pageLimit) });
    }

    accountDao
      .findAccountledgerAggregation(query)
      .then(function (data) {
        accountDao
          .findAccountledgerAggregation(sQuery)
          .then(async function (dcount) {
            let tptCnt = 0;
            let openingBalance = 0;
            let closingBalance = 0;

            if (dcount.length > 0) {
              tptCnt = dcount[0].recordCount;
            }

            if (
              postData.transactionOf &&
              (postData?.sellerNo || postData?.buyerNo)
            ) {
              const { transactionOf, sellerNo, buyerNo } = postData;
              const type = sellerNo ? sellerNo : buyerNo;
              const getBalance = await getEntityBalance(transactionOf, type);
              openingBalance = getBalance?.openingBalance;
              closingBalance = getBalance?.closingBalance;
            }

            res.status(200).json({
              status: true,
              result: data,
              openingBalance,
              closingBalance,
              message: "",
              hasMore: cmethod.hasMoreCount(
                tptCnt,
                postData.page,
                postData.pageLimit
              ),
              totalCount: tptCnt,
            });
          })
          .catch((err) => {
            cmethod.returnSreverError(res, message[lang].technicalError, err);
          });
      })
      .catch((err) => {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      });
  }
);

// * comments
/*query.push({
     $lookup: {
       from: "users",
       let: {
         userbuyerNo: "$buyerNo",
         uniqueIdentifierId: "$uniqueIdentifier"
       },
       pipeline: [
         {
           $match: {
             $expr: {
               $and: [
                 { $eq: ["$uniqueIdentifierId", "$$userbuyerNo"] },
               ],
             },
           },
         },
       ],
       as: "users",
     },
   });
   //-----------------------------date-------------------------
  var today = new Date();
    var _month = today.getMonth();
    var _year = today.getFullYear();
    //var _day = 01;
    var _day1 = today.getDate();
    var __month1 = _month + 1;
    //var _fromDate = _year + "-" + _month + "-" + _day;
    var _toDate = _year + "-" + __month1 + "-" + _day1;
    var fdate = new Date(_toDate);
    fdate.setDate(fdate.getDate());
    fdate.setUTCHours(0, 0, 0, 0);
 
    var tdate = new Date(_toDate);
    tdate.setDate(tdate.getDate());
    tdate.setUTCHours(23, 59, 59, 0);
 
 
 
    console.log('to date-------->', tdate);
    console.log('from date-------->', fdate);
    //match = { createdAt: { $gte: fdate, $lte: tdate } }*/

// query.push({
//   $lookup: {
//     from: "reciepts",
//     localField: "referenceId",
//     foreignField: "_id",
//     as: "reciepts",
//   },
// });
// query.push({
//   $unwind: { path: "$reciepts", preserveNullAndEmptyArrays: true },
// });

// query.push({
//   $match: {
//     $and: [
//       {
//         "accountmasters.markAccountId": { $in: ['cash-in-hand'] }
//       },
//     ],
//   },
// });

/*
    query.push({
      $match: {
        $and: [{ createdAt: { $gte: fdate, $lte: tdate } }],
      },
    });

    if (postData.fromData && postData.toData) {
      query.push({
        $match: {
          $and: [
            {
              createdAt: {
                $gte: new Date(
                  cmethod.startTimeString(new Date(postData.fromData))
                ),
              },
            },
            {
              createdAt: {
                $lte: new Date(
                  cmethod.endTimeString(new Date(postData.toData))
                ),
              },
            },
          ],
        },
      });
    }*/
// query.push({
//   $group: {
//     _id: "$transactionType",
//     totalAmount: { $sum: "$payAmount" }
//   },
// });

/* query.push({
       $lookup: {
         from: "users",
         localField: "buyerNo",
         foreignField: "uniqueIdentifier",
         as: "buyersdata",
       },
     });
     query.push({
       $unwind: { path: "$buyersdata", preserveNullAndEmptyArrays: true },
     });
     query.push({
       $lookup: {
         from: "users",
         localField: "sellerNo",
         foreignField: "uniqueIdentifier",
         as: "sellersdata",
       },
     });
     query.push({
       $unwind: { path: "$sellersdata", preserveNullAndEmptyArrays: true },
     });*/
// * comments
router.post(
  "/closingDataList",
  [midleware.validateFieldValue(["pageLimit", "page"], ["pageLimit", "page"])],
  async (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let query = [];

    // * accountmasters
    query.push({
      $lookup: {
        from: "accountmasters",
        localField: "glAccountId",
        foreignField: "_id",
        as: "accountmasters",
      },
    });
    query.push({
      $unwind: { path: "$accountmasters", preserveNullAndEmptyArrays: true },
    });

    // * branchs
    query.push({
      $lookup: {
        from: "branchs",
        localField: "branchId",
        foreignField: "_id",
        as: "branchs",
      },
    });
    query.push({
      $unwind: { path: "$branchs", preserveNullAndEmptyArrays: true },
    });

    // * markAccountId
    if (postData.markAccountId) {
      query.push({
        $match: {
          $and: [
            {
              "accountmasters.markAccountId": postData.markAccountId,
            },
          ],
        },
      });
    }

    // * branchId
    let branchData = [];
    if (postData?.branchId?.length > 0) {
      let pdata = postData.branchId;
      for (let i in pdata) {
        branchData.push(mongoose.Types.ObjectId(pdata[i]));
      }
      query.push({
        $match: {
          $and: [
            {
              branchId: {
                $in: branchData,
              },
            },
          ],
        },
      });
    }

    // * accountcloseId
    if (postData.accountcloseId) {
      query.push({
        $match: {
          $and: [
            {
              accountcloseId: mongoose.Types.ObjectId(postData.accountcloseId),
            },
          ],
        },
      });
    }

    // * closingstatusval
    query.push({
      $match: {
        $and: [
          {
            closingStatus: Number(
              postData.closingstatusval ? postData.closingstatusval : 0
            ),
          },
        ],
      },
    });

    // * transDate
    if (postData.transDate) {
      query.push({
        $match: {
          $and: [
            {
              transDate: {
                $gte: new Date(
                  cmethod.startTimeString(new Date(postData.transDate))
                ),
              },
            },
            {
              transDate: {
                $lte: new Date(
                  cmethod.endTimeString(new Date(postData.transDate))
                ),
              },
            },
          ],
        },
      });
    }

    // * search
    if (postData.search) {
      query.push({
        $match: {
          $and: [
            {
              $or: [
                {
                  referenceNo: {
                    $regex: postData.search,
                    $options: "i",
                  },
                },
                {
                  referenceNo2: {
                    $regex: postData.search,
                    $options: "i",
                  },
                },
              ],
            },
          ],
        },
      });
    }

    // * buyer users
    query.push({
      $lookup: {
        from: "users",
        let: {
          buyerNo: "$buyerNo",
        },
        pipeline: [
          {
            $match: {
              $and: [
                {
                  $expr: {
                    $and: [
                      { $eq: ["$uniqueIdentifier", "$$buyerNo"] },
                      { $in: ["$userType", [4, 5]] },
                    ],
                  },
                },
                { buyerNo: { $ne: "" } },
              ],
            },
          },
        ],
        as: "buyersdata",
      },
    });

    // * seller users
    query.push({
      $lookup: {
        from: "users",
        let: {
          sellerNo: "$sellerNo",
        },
        pipeline: [
          {
            $match: {
              $and: [
                {
                  $expr: {
                    $and: [
                      { $eq: ["$uniqueIdentifier", "$$sellerNo"] },
                      { $in: ["$userType", [2, 3]] },
                    ],
                  },
                },
                { sellerNo: { $ne: "" } },
              ],
            },
          },
        ],
        as: "sellersdata",
      },
    });

    // * project
    query.push({
      $project: {
        voucherNo: 1,
        branchId: 1,
        branchName: "$branchs.branchName",
        accountNo: "$accountmasters.accountNo",
        accountName: "$accountmasters.accountName",
        closingStatus: 1,
        transactionType: 1,
        paymentType: 1,
        payAmount: 1,
        referenceType: 1,
        referenceId: 1,
        referenceNo: 1,
        referenceNo2: 1,
        description: 1,
        createdBy: 1,
        createdAt: 1,
        openingBalance: 1,
        accountcloseId: 1,
        transDate: 1,
        buyerName: {
          $cond: {
            if: {
              $eq: [
                {
                  $ifNull: ["$buyerNo", ""],
                },
                "",
              ],
            },
            then: "",
            else: { $arrayElemAt: ["$buyersdata.name", 0] },
          },
        },
        buyerNo: 1,
        sellerName: {
          $cond: {
            if: {
              $eq: [
                {
                  $ifNull: ["$sellerNo", ""],
                },
                "",
              ],
            },
            then: "",
            else: { $arrayElemAt: ["$sellersdata.name", 0] },
          },
        },
        sellerNo: 1,
      },
    });

    const sQuery = [...query];
    query.push({ $sort: { transDate: -1 } });
    sQuery.push({ $count: "recordCount" });

    if (postData.page) {
      query.push({
        $skip: cmethod.pageOffset(postData.page, postData.pageLimit),
      });
      query.push({ $limit: cmethod.pageLimit(postData.pageLimit) });
    }

    accountDao
      .findAccountledgerAggregation(query)
      .then(function (data) {
        accountDao
          .findAccountledgerAggregation(sQuery)
          .then(async function (dcount) {
            //------------------------------------------------
            let closingBalanceAmount = 0;
            /*this function run only when search data by date and branch. */
            if (!postData.accountcloseId) {
              let queryAccount = {
                $and: [
                  { openingBalance: { $eq: "Y" } },
                  { branchId: { $in: branchData } },
                  { markAccountId: postData?.markAccountId },
                ],
              };

              const getopeningBalance =
                await accountModal.ClosingAccount.findOne(queryAccount, {
                  amount: 1,
                }).sort({ createdAt: -1 });
              if (getopeningBalance?.amount) {
                closingBalanceAmount = getopeningBalance?.amount;
              }
            } else {
              let queryAccount = {
                $and: [
                  { openingBalance: { $eq: "N" } },
                  { branchId: { $in: branchData } },
                  { markAccountId: postData?.markAccountId },
                  { transDate: { $lt: postData?.transDate } },
                ],
              };
              const getopeningBalance =
                await accountModal.ClosingAccount.findOne(queryAccount, {
                  amount: 1,
                })
                  .sort({ createdAt: -1 })
                  .limit(1);
              if (getopeningBalance?.amount) {
                closingBalanceAmount = getopeningBalance?.amount;
              }
            }

            //-------------------------------------------------
            let tptCnt = 0;
            if (dcount.length > 0) {
              tptCnt = dcount[0].recordCount;
            }
            res.status(200).json({
              status: true,
              result: data,
              closingBalance: closingBalanceAmount,
              message: "",
              hasMore: cmethod.hasMoreCount(
                tptCnt,
                postData.page,
                postData.pageLimit
              ),
              totalCount: tptCnt,
            });
          })
          .catch((err) => {
            cmethod.returnSreverError(res, message[lang].technicalError, err);
          });
      })
      .catch((err) => {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      });
  }
);
router.post("/addGl", async (req, res) => {
  let postData = req.body.glData;
  //console.log(postData);
  /*let postData = [
    {
      branchId: "640e235b00b462b7e05a006a",
      glAccountId: "641b3877c79c779a26b805b6",
      transactionType: "cr",
      paymentType: "cash",
      payAmount: "1000",
      description: "This is first desc",
      referenceType: "",
      referenceId: "",
      voucherNo: "120124",
      closingStatus:0
    },
  ];*/
  let lang = req.headers["lang"] || config.lang;
  let errorData = [];
  /*
  let queryUnique = {
    $and: [{ voucherNo: { $exists: true } }, { voucherNo: { $gt: 0 } }],
  };
  let voucherNoUnique = 0;
  const voucherData = await accountModal.Accountledger.findOne(queryUnique, {
    voucherNo: 1,
  }).sort({ createdAt: -1 });
  //console.log('voucherData=>',voucherData);
  if (voucherData) {
    if (voucherData.voucherNo == 0 || !voucherData.voucherNo) {
      voucherNoUnique = 100101;
    } else { //console.log('voucherData=>11111111');
      voucherNoUnique = voucherData.voucherNo + 1;
    }
  } else {
    voucherNoUnique = 100101;
  }*/

  let voucherNoUnique = await cmethod.getVoucherNo();
  if (postData.length > 0) {
    var insaccountData = [];
    for (var i = 0; i < postData.length; i++) {
      if (postData[i]?.glAccountId != "" && postData[i]?.branchId != "") {
        /*let referenceId;
        if (postData[i]?.referenceId != "") {
          referenceId = mongoose.Types.ObjectId(postData[i]?.referenceId);
        } else {
          referenceId = null;
        }*/
        insaccountData.push({
          voucherNo: voucherNoUnique,
          branchId: postData[i]?.branchId,
          glAccountId: mongoose.Types.ObjectId(postData[i].glAccountId),
          transactionType: postData[i]?.transactionType,
          paymentType: postData[i]?.paymentType,
          payAmount: postData[i]?.payAmount,
          description: postData[i]?.description,
          referenceType: postData[i]?.referenceType
            ? postData[i]?.referenceType
            : "",
          //referenceId: referenceId,
          referenceNo: postData[i]?.referenceNo,
          transDate: postData[i]?.transDate,
          createdBy: postData[i]?.createdBy,
          closingStatus: postData[i]?.closingStatus,
          addedFrom: postData[i]?.addedFrom,
        });
      } else {
        let error =
          "row " +
          index +
          " glAccountId or branchId data not correct or invalid";
        errorData.push({
          error: error,
        });
      }
    }
    //console.log("data==>2", insaccountData);
    //return false;
  }
  //console.log("data==>3", insaccountData);
  // return false;
  if (insaccountData.length > 0) {
    accountModal.Accountledger.insertMany(insaccountData, (err, data) => {
      if (err) {
        console.log(err);
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      } else {
        cmethod.returnSuccess(
          res,
          data,
          false,
          "Accountledger Data has been import successfully."
        );
      }
    });
  } else {
    cmethod.returnSreverError(res, message[lang].technicalError, ["ll"]);
  }
});
router.patch(
  "/updateGl",
  [midleware.validateFieldValue(["glId"], ["glId"])],
  async (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let xtoken = req.headers["x-access-token"];
    //{ token: xtoken },
    let queryCond = {
      $and: [{ _id: mongoose.Types.ObjectId(postData.glId) }],
    };
    delete postData.glId;

    /*set unique data only for markAccountId */
    accountModal.Accountledger.findOneAndUpdate(
      queryCond,
      { $set: postData },
      { new: true },
      async function (err, data) {
        if (err) {
          cmethod.returnSreverError(res, message[lang].technicalError, err);
        } else {
          cmethod.returnSuccess(res, data, false, message[lang].profileUpdate);
        }
      }
    );
  }
);
//----------------------------------cash-in-hand----------------------------
router.post(
  "/cashInHandSummary",
  [midleware.validateFieldValue(["pageLimit", "page"], ["pageLimit", "page"])],
  (req, res) => {
    let postData = req.body;
    let query = [];

    query.push({
      $lookup: {
        from: "accountmasters",
        localField: "glAccountId",
        foreignField: "_id",
        as: "accountmasters",
      },
    });
    query.push({
      $unwind: { path: "$accountmasters", preserveNullAndEmptyArrays: true },
    });
    query.push({
      $lookup: {
        from: "branchs",
        localField: "branchId",
        foreignField: "_id",
        as: "branchs",
      },
    });
    query.push({
      $unwind: { path: "$branchs", preserveNullAndEmptyArrays: true },
    });
    query.push({
      $lookup: {
        from: "reciepts",
        localField: "referenceId",
        foreignField: "_id",
        as: "reciepts",
      },
    });
    query.push({
      $unwind: { path: "$reciepts", preserveNullAndEmptyArrays: true },
    });

    if (postData.accountNo) {
      query.push({
        $match: {
          $and: [{ "accountmasters.accountNo": Number(postData.accountNo) }],
        },
      });
    }
    if (postData.accountName) {
      query.push({
        $match: {
          $and: [
            {
              $or: [
                {
                  "accountmasters.accountName": {
                    $regex: postData.accountName,
                    $options: "i",
                  },
                },
              ],
            },
          ],
        },
      });
    }

    query.push({
      $match: {
        $and: [
          {
            "accountmasters.markAccountId": {
              $in: ["cash-in-bank", "cash-in-hand"],
            },
          },
        ],
      },
    });
    let branchData = [];
    if (postData?.branchId?.length > 0) {
      let pdata = postData.branchId;
      for (let i in pdata) {
        branchData.push(mongoose.Types.ObjectId(pdata[i]));
      }
      query.push({
        $match: {
          $and: [
            {
              branchId: {
                $in: branchData,
              },
            },
          ],
        },
      });
    }
    if (postData.fromData && postData.toData) {
      query.push({
        $match: {
          $and: [
            {
              transDate: {
                $gte: new Date(
                  cmethod.startTimeString(new Date(postData.fromData))
                ),
              },
            },
            {
              transDate: {
                $lte: new Date(
                  cmethod.endTimeString(new Date(postData.toData))
                ),
              },
            },
          ],
        },
      });
    }

    query.push({
      $group: {
        _id: "$accountmasters.markAccountId",
        totalAmount: { $sum: "$payAmount" },
      },
    });

    query.push({
      $project: {
        branchId: 1,
        payAmount: 1,
        createdAt: 1,
        totalAmount: 1,
        transDate: 1,
      },
    });
    const sQuery = [...query];
    query.push({ $sort: { transDate: -1 } });
    sQuery.push({ $count: "recordCount" });

    if (postData.page) {
      query.push({
        $skip: cmethod.pageOffset(postData.page, postData.pageLimit),
      });
      query.push({ $limit: cmethod.pageLimit(postData.pageLimit) });
    }

    accountDao
      .findAccountledgerAggregation(query)
      .then(function (data) {
        accountDao
          .findAccountledgerAggregation(sQuery)
          .then(async function (dcount) {
            let tptCnt = 0;
            if (dcount.length > 0) {
              tptCnt = dcount[0].recordCount;
            }
            res.status(200).json({
              status: true,
              result: data,
              message: "",
              hasMore: cmethod.hasMoreCount(
                tptCnt,
                postData.page,
                postData.pageLimit
              ),
              totalCount: tptCnt,
            });
          })
          .catch((err) => {
            cmethod.returnSreverError(res, message[lang].technicalError, err);
          });
      })
      .catch((err) => {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      });
  }
);

router.post(
  "/closingAccountadd",
  [midleware.validateFieldValue(["amount"], ["amount"])],
  async (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    //console.log('=====>>>>>>',postData);
    accountDao
      .closingAccountAdd(res, postData)
      .then(async function () {})
      .catch((err) => {
        cmethod.returnSreverError(res, message[lang].drcrError, err);
      });
  }
);
// router.post(
//   "/dailyBasisclosing",
//   [
//     midleware.validateFieldValue(
//       ["pageLimit", "page"],
//       ["pageLimit", "page"]
//     ),
//   ],
//   async (req, res) =>  {

//   }
// );

router.post(
  "/dailyBasisclosing",
  [midleware.validateFieldValue([], [])],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let query = [];

    // * branchs
    query.push({
      $lookup: {
        from: "branchs",
        localField: "branchId",
        foreignField: "_id",
        as: "branchs",
      },
    });
    query.push({
      $unwind: { path: "$branchs", preserveNullAndEmptyArrays: true },
    });

    if (postData.branchId) {
      query.push({
        $match: {
          branchId: mongoose.Types.ObjectId(postData.branchId),
        },
      });
    }

    // * project
    query.push({
      $project: {
        branchId: 1,
        branchName: "$branchs.branchName",
        amount: 1,
        createdAt: 1,
        createdBy: 1,
        openingBalance: 1,
        transDate: 1,
        markAccountId: 1,
      },
    });

    const sQuery = [...query];
    query.push({ $sort: { transDate: -1 } });
    sQuery.push({ $count: "recordCount" });

    if (postData.page) {
      query.push({
        $skip: cmethod.pageOffset(postData.page, postData.pageLimit),
      });
      query.push({ $limit: cmethod.pageLimit(postData.pageLimit) });
    }

    accountDao
      .findclosingAccountAggregation(query)
      .then(function (data) {
        accountDao
          .findclosingAccountAggregation(sQuery)
          .then(async function (dcount) {
            let tptCnt = 0;
            if (dcount.length > 0) {
              tptCnt = dcount[0].recordCount;
            }
            res.status(200).json({
              status: true,
              result: data,
              message: "",
              hasMore: cmethod.hasMoreCount(
                tptCnt,
                postData.page,
                postData.pageLimit
              ),
              totalCount: tptCnt,
            });
          })
          .catch((err) => {
            cmethod.returnSreverError(res, message[lang].technicalError, err);
          });
      })
      .catch((err) => {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      });
  }
);

router.post(
  "/getclosingDate",
  [midleware.validateFieldValue(["branchId"], ["branchId"])],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let query = "";

    if (postData.branchId && postData.markAccountId) {
      query = {
        $and: [
          {
            branchId: mongoose.Types.ObjectId(postData.branchId),
          },
          {
            markAccountId: postData.markAccountId,
          },
          {
            openingBalance: "Y",
          },
        ],
      };
    }
    accountDao
      .findClosingDate(query)
      .then(async (result) => {
        if (result == null || result.length == 0) {
          var beforeonedaydata = new Date(
            new Date().getTime() - 1 * 24 * 60 * 60 * 1000
          );
          beforeonedaydata.setDate(beforeonedaydata.getDate());
          beforeonedaydata.setUTCHours(0, 0, 0, 0);
          res.status(200).json({
            status: true,
            result: [{ closingDate: beforeonedaydata }],
            message: "",
            hasMore: 0,
            totalCount: 0,
          });

          //cmethod.returrnErrorMessage(res, "Data not found.");
        } else {
          res.status(200).json({
            status: true,
            result: [{ closingDate: result[0]?.transDate }],
            message: "",
            hasMore: 0,
            totalCount: 0,
          });
        }
      })
      .catch((err) => {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      });
  }
);
router.post(
  "/getclosingBalance",
  [midleware.validateFieldValue(["branchId"], ["branchId"])],
  async (req, res) => {
    const { body, headers } = req;
    const lang = headers.lang || config.lang;

    const query = [];

    try {
      if (body.branchId) {
        IDMatch(query, "branchId", body.branchId);
      }

      if (body.markAccountId) {
        InMatch(query, "markAccountId", [body.markAccountId]);
      }

      if (body.closingDate) {
        query.push({
          $match: {
            $and: [{ transDate: { $lt: new Date(body.closingDate) } }],
          },
        });
      }

      Sort(query, config.defaultSort);
      Limit(query, 1);

      const closing = await accountModal.ClosingAccount.aggregate(query);

      res.status(200).json({
        status: true,
        result: [{ openingBalance: closing[0]?.amount }],
        message: "",
        hasMore: 0,
        totalCount: 0,
      });
    } catch (error) {
      logger.error(error.message);
      cmethod.returnSreverError(res, message[lang]?.technicalError, error);
    }
  }
);
router.post(
  "/closingnotesdetaillist",
  [midleware.validateFieldValue(["pageLimit", "page"], ["page"])],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let query = [];
    // query.push({
    //   $lookup: {
    //     from: "branchs",
    //     localField: "branchId",
    //     foreignField: "_id",
    //     as: "branchs",
    //   },
    // });
    // query.push({
    //   $unwind: { path: "$branchs", preserveNullAndEmptyArrays: true },
    // });
    if (postData.closingAccountId) {
      query.push({
        $match: {
          closingAccountId: mongoose.Types.ObjectId(postData.closingAccountId),
        },
      });
    }
    query.push({
      $project: {
        closingAccountId: 1,
        //branchName: "$branchs.branchName",
        Note: 1,
        qty: 1,
        Total: 1,
        createdAt: 1,
      },
    });
    const sQuery = [...query];
    query.push({ $sort: { createdAt: -1 } });
    sQuery.push({ $count: "recordCount" });

    if (postData.page) {
      query.push({
        $skip: cmethod.pageOffset(postData.page, postData.pageLimit),
      });
      query.push({ $limit: cmethod.pageLimit(postData.pageLimit) });
    }

    accountDao
      .findclosingnotesdetailAggregation(query)
      .then(function (data) {
        accountDao
          .findclosingnotesdetailAggregation(sQuery)
          .then(async function (dcount) {
            let tptCnt = 0;
            if (dcount.length > 0) {
              tptCnt = dcount[0].recordCount;
            }
            res.status(200).json({
              status: true,
              result: data,
              message: "",
              hasMore: cmethod.hasMoreCount(
                tptCnt,
                postData.page,
                postData.pageLimit
              ),
              totalCount: tptCnt,
            });
          })
          .catch((err) => {
            cmethod.returnSreverError(res, message[lang].technicalError, err);
          });
      })
      .catch((err) => {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      });
  }
);
router.post("/addtempGl", async (req, res) => {
  let postData = req.body.glData;
  let lang = req.headers["lang"] || config.lang;
  let errorData = [];

  let voucherNoUnique = await cmethod.getempGlNo();
  if (postData.length > 0) {
    var insaccountData = [];
    for (var i = 0; i < postData.length; i++) {
      if (postData[i]?.glAccountId != "" && postData[i]?.branchId != "") {
        insaccountData.push({
          voucherNo: voucherNoUnique,
          branchId: postData[i]?.branchId,
          glAccountId: mongoose.Types.ObjectId(postData[i].glAccountId),
          transactionType: postData[i]?.transactionType,
          paymentType: postData[i]?.paymentType,
          payAmount: postData[i]?.payAmount,
          description: postData[i]?.description,
          referenceType: postData[i]?.referenceType
            ? postData[i]?.referenceType
            : "",
          //referenceId: referenceId,
          referenceNo: postData[i]?.referenceNo,
          transDate: postData[i]?.transDate,
          createdBy: postData[i]?.createdBy,
          closingStatus: postData[i]?.closingStatus,
          addedFrom: postData[i]?.addedFrom,
          status: postData[i]?.status,
          createdFrom: postData[i]?.createdFrom,
        });
      } else {
        let error =
          "row " +
          index +
          " glAccountId or branchId data not correct or invalid";
        errorData.push({
          error: error,
        });
      }
    }
    //console.log("data==>2", insaccountData);
    //return false;
  }
  //console.log("data==>3", insaccountData);
  // return false;
  if (insaccountData.length > 0) {
    accountModal.Accountledgertemp.insertMany(
      insaccountData,
      async (err, data) => {
        if (err) {
          console.log(err);
          cmethod.returnSreverError(res, message[lang].technicalError, err);
        } else {
          let referenceId = "";
          let referenceNo = "";
          let createdBy = "";

          for (const item of data) {
            if (item.addedFrom === "ip" && item.transactionType === "dr") {
              referenceId = item._id;
              referenceNo = item.voucherNo;
              createdBy = item.createdBy;
            } else if (
              item.addedFrom === "op" &&
              item.transactionType === "cr"
            ) {
              referenceId = item._id;
              referenceNo = item.voucherNo;
              createdBy = item.createdBy;
            }
          }

          await createCommonLog({
            action: "Created",
            from: "Payment",
            id: referenceId,
            of: "payment",
            no: referenceNo,
            by: createdBy,
          });

          cmethod.returnSuccess(
            res,
            data,
            false,
            "Accountledger Data has been import successfully."
          );
        }
      }
    );
  } else {
    cmethod.returnSreverError(res, message[lang].technicalError, ["ll"]);
  }
});
router.post(
  "/gltempList",
  [midleware.validateFieldValue([], [])],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let query = [];

    // * match
    if (postData.fromDate && postData.toDate) {
      query.push({
        $match: {
          $and: [
            {
              createdAt: {
                $gte: new Date(
                  cmethod.startTimeString(new Date(postData.fromDate))
                ),
              },
            },
            {
              createdAt: {
                $lte: new Date(
                  cmethod.endTimeString(new Date(postData.toDate))
                ),
              },
            },
          ],
        },
      });
    }
    if (postData.fromTransDate && postData.toTransDate) {
      query.push({
        $match: {
          $and: [
            {
              transDate: {
                $gte: new Date(
                  cmethod.startTimeString(new Date(postData.fromTransDate))
                ),
              },
            },
            {
              transDate: {
                $lte: new Date(
                  cmethod.endTimeString(new Date(postData.toTransDate))
                ),
              },
            },
          ],
        },
      });
    }
    if (postData.status) {
      ExactMatch(query, "status", postData.status);
    }
    if (Array.isArray(postData.statusArr)) {
      InMatch(query, "status", postData.statusArr);
    }

    // * accountmasters
    query.push({
      $lookup: {
        from: "accountmasters",
        localField: "glAccountId",
        foreignField: "_id",
        as: "accountmasters",
      },
    });
    query.push({
      $unwind: { path: "$accountmasters", preserveNullAndEmptyArrays: true },
    });

    // * branchs
    query.push({
      $lookup: {
        from: "branchs",
        localField: "branchId",
        foreignField: "_id",
        as: "branchs",
      },
    });
    query.push({
      $unwind: { path: "$branchs", preserveNullAndEmptyArrays: true },
    });

    // * sellerPayables
    query.push({
      $lookup: {
        from: "sellerpayables",
        localField: "referenceNo",
        foreignField: "payableNo",
        as: "sellerPayables",
      },
    });
    query.push({
      $unwind: { path: "$sellerPayables", preserveNullAndEmptyArrays: true },
    });

    // * sellerPayables.inventoryId
    query.push({
      $unwind: {
        path: "$sellerPayables.inventoryId",
        preserveNullAndEmptyArrays: true,
      },
    });

    // * inventories
    Lookup(
      query,
      "inventorys",
      "sellerPayables.inventoryId",
      "_id",
      "inventories"
    );
    Unwind(query, "$inventories");

    // * makes
    Lookup(query, "makes", "inventorys.make", "_id", "makes");
    Unwind(query, "$makes");

    // * models
    Lookup(query, "models", "inventorys.model", "_id", "models");
    Unwind(query, "$models");

    // * exteriorcolors
    Lookup(
      query,
      "exteriorcolors",
      "inventorys.exteriorcolorId",
      "_id",
      "exteriorcolors"
    );
    Unwind(query, "$exteriorcolors");

    // * sellerUsers
    Lookup(query, "users", "sellerPayables.sellerId", "_id", "sellerUsers");
    Unwind(query, "$sellerUsers");

    // * sellerServices
    LookupWithPipeline(
      query,
      "sellerservices",
      {
        saleOrderNo: "$sellerPayables.sellerServiceOrderNumbers",
      },
      [
        {
          $match: {
            $expr: {
              $in: ["$saleOrderNo", { $ifNull: ["$$saleOrderNo", []] }],
            },
          },
        },
      ],
      "sellerServices"
    );

    // * sellerService
    const sellerServiceLet = {
      inventoryId: "$sellerPayables.inventoryId",
      status: "pending",
    };

    const sellerServicePipeline = [
      {
        $match: {
          $expr: {
            $and: [
              { $eq: ["$inventoryId", "$$inventoryId"] },
              { $eq: ["$status", "$$status"] },
            ],
          },
        },
      },
    ];

    LookupWithPipeline(
      query,
      "sellerservices",
      sellerServiceLet,
      sellerServicePipeline,
      "sellerService"
    );

    // * gate pass
    query.push({
      $lookup: {
        from: "getpasses",
        let: {
          inventoryId: "$sellerPayables.inventoryId",
          direction: "out",
          referenceType: "inventory",
          status: "in warehouse",
        },
        pipeline: [
          {
            $match: {
              $expr: {
                $and: [
                  { $eq: ["$inventoryId", "$$inventoryId"] },
                  { $eq: ["$direction", "$$direction"] },
                  { $eq: ["$referenceType", "$$referenceType"] },
                  { $eq: ["$status", "$$status"] },
                ],
              },
            },
          },
        ],
        as: "gatePass",
      },
    });

    // * outgoingCash
    Lookup(query, "outgoingcashs", "referenceNo", "voucherNo", "outgoingCash");
    Unwind(query, "$outgoingCash");

    const buyerLet = {
      buyerNo: "$buyerNo",
    };
    const buyerPipeline = [
      {
        $match: {
          $and: [
            {
              $expr: {
                $and: [
                  {
                    $eq: ["$uniqueIdentifier", "$$buyerNo"],
                  },
                  { $in: ["$userType", [4, 5]] },
                ],
              },
            },
          ],
        },
      },
    ];

    LookupWithPipeline(query, "users", buyerLet, buyerPipeline, "buyer");
    Unwind(query, "$buyer");

    if (postData.accountNo) {
      query.push({
        $match: {
          $and: [{ "accountmasters.accountNo": Number(postData.accountNo) }],
        },
      });
    }
    if (postData.accountName) {
      query.push({
        $match: {
          $and: [
            {
              $or: [
                {
                  "accountmasters.accountName": {
                    $regex: postData.accountName,
                    $options: "i",
                  },
                },
              ],
            },
          ],
        },
      });
    }
    if (postData.addedFrom) {
      query.push({
        $match: {
          $and: [{ addedFrom: postData.addedFrom }],
        },
      });
    }
    if (postData.transactionType) {
      query.push({
        $match: {
          $and: [{ transactionType: postData.transactionType }],
        },
      });
    }
    if (postData.voucherNo) {
      query.push({
        $match: {
          $and: [{ voucherNo: postData.voucherNo }],
        },
      });
    }
    if (postData.accountLedgerTempId) {
      query.push({
        $match: {
          $and: [{ _id: makeObjectId(postData.accountLedgerTempId) }],
        },
      });
    }

    //----------------------------------------------------------
    let branchData = [];
    if (postData?.branchId?.length > 0) {
      let pdata = postData.branchId;
      for (let i in pdata) {
        branchData.push(mongoose.Types.ObjectId(pdata[i]));
      }
      query.push({
        $match: {
          $and: [
            {
              branchId: {
                $in: branchData,
              },
            },
          ],
        },
      });
    }
    if (postData.search) {
      query.push({
        $match: {
          $and: [
            {
              $or: [
                {
                  referenceNo: {
                    $regex: postData.search,
                    $options: "i",
                  },
                },
                {
                  referenceNo2: {
                    $regex: postData.search,
                    $options: "i",
                  },
                },
                {
                  voucherNo: {
                    $regex: postData.search,
                    $options: "i",
                  },
                },
                {
                  description: {
                    $regex: postData.search,
                    $options: "i",
                  },
                },
                {
                  transactionType: {
                    $regex: postData.search,
                    $options: "i",
                  },
                },
              ],
            },
          ],
        },
      });
    }
    //-----------------------------------------------------------------------
    query.push({
      $project: {
        isGatePassAvailable: {
          $cond: {
            if: { $eq: ["$gatePass", []] },
            then: false,
            else: true,
          },
        },
        isPaymentDue: {
          $cond: {
            if: { $eq: ["$sellerService", []] },
            then: false,
            else: true,
          },
        },
        voucherNo: 1,
        branchId: "$branchs._id",
        fullBranchName: "$branchs.fullbranchName",
        branchName: "$branchs.branchName",
        branchTRN: "$branchs.Trnno",
        branchAddress: "$branchs.branchAddress",
        branchEmail: "$branchs.branchEmail",
        branchMobile: "$branchs.branchMobile",
        accountNo: "$accountmasters.accountNo",
        accountName: "$accountmasters.accountName",
        sellerPayableId: "$sellerPayables._id",
        closingStatus: 1,
        transactionType: 1,
        paymentType: 1,
        payAmount: 1,
        referenceType: 1,
        referenceId: 1,
        referenceNo: 1, //"$reciepts.recieptNo",
        referenceNo2: 1,
        description: 1,
        createdBy: 1,
        createdAt: 1,
        transDate: 1,
        createdFrom: 1,
        status: 1,
        payableType: 1,
        payableStatus: 1,
        glAccountId: 1,
        signaturePath: 1,
        paidDate: 1,
        users: {
          name: "$sellerUsers.name",
          address: "$sellerUsers.address",
          phone: "$sellerUsers.phone",
          TRN: "$sellerUsers.companyDetails.trn",
          EID: "$sellerUsers.eid",
        },
        carDetails: {
          name: "$makes.makeName",
          model: "$models.modelName",
          color: "$exteriorcolors.colorName",
          vinNo: "$inventories.vin",
          year: "$inventories.year",
          invoiceDate: "$createdAt",
        },
        isSecurityDeposit: { $ifNull: ["$outgoingCash", false] },
        checkImg: "$sellerPayables.checkImg",
        buyer: {
          name: "$buyer.name",
          address: "$buyer.address",
          phone: "$buyer.phone",
          TRN: "$buyer.companyDetails.trn",
          EID: "$buyer.eid",
        },
        isStorageDue: {
          $cond: {
            if: {
              $eq: [
                { $arrayElemAt: ["$sellerServices.serviceType", 0] },
                "storage",
              ],
            },
            then: false,
            else: true,
          },
        },
      },
    });
    const sQuery = [...query];
    query.push({ $sort: { createdAt: -1 } });
    sQuery.push({ $count: "recordCount" });

    if (postData.page) {
      query.push({
        $skip: cmethod.pageOffset(postData.page, postData.pageLimit),
      });
      query.push({ $limit: cmethod.pageLimit(postData.pageLimit) });
    }

    accountDao
      .findAccountledgertempAggregation(query)
      .then(function (data) {
        accountDao
          .findAccountledgertempAggregation(sQuery)
          .then(async function (dcount) {
            let tptCnt = 0;
            if (dcount.length > 0) {
              tptCnt = dcount[0].recordCount;
            }
            res.status(200).json({
              status: true,
              result: data,
              message: "",
              hasMore: cmethod.hasMoreCount(
                tptCnt,
                postData.page,
                postData.pageLimit
              ),
              totalCount: tptCnt,
            });
          })
          .catch((err) => {
            cmethod.returnSreverError(res, message[lang].technicalError, err);
          });
      })
      .catch((err) => {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      });
  }
);
router.patch(
  "/updatetempGl",
  [midleware.validateFieldValue(["glId"], ["glId"])],
  async (req, res) => {
    const { body, headers } = req;
    const lang = headers.lang || config.lang;

    try {
      const payment = await updateIncomingOutgoingPayment(body);

      cmethod.returnSuccess(res, payment, false, message[lang].profileUpdate);
    } catch (error) {
      logger.error(error.message);
      cmethod.returnSreverError(res, message[lang]?.technicalError, error);
    }
  }
);
router.post(
  "/accountpayable",
  [midleware.validateFieldValue(["referenceId"], ["referenceId"])],
  async (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    accountDao.accountPayable(res, postData);
  }
);
router.post(
  "/accountpayablelist",
  [midleware.validateFieldValue(["pageLimit", "page"], ["page"])],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let query = [];

    if (postData.fromData && postData.toData) {
      query.push({
        $match: {
          $and: [
            {
              invoiceDate: {
                $gte: new Date(
                  cmethod.startTimeString(new Date(postData.fromData))
                ),
              },
            },
            {
              invoiceDate: {
                $lte: new Date(
                  cmethod.endTimeString(new Date(postData.toData))
                ),
              },
            },
          ],
        },
      });
    }
    query.push({
      $project: {
        refno: 1,
        appType: 1,
        referenceId: 1,
        invoiceDate: 1,
        description: 1,
        totalPayment: 1,
        totalPaid: 1,
        dueAmount: 1,
        paymentMethod: 1,
        status: 1,
        createdAt: 1,
      },
    });
    const sQuery = [...query];
    query.push({ $sort: { createdAt: -1 } });
    sQuery.push({ $count: "recordCount" });

    if (postData.page) {
      query.push({
        $skip: cmethod.pageOffset(postData.page, postData.pageLimit),
      });
      query.push({ $limit: cmethod.pageLimit(postData.pageLimit) });
    }

    accountDao
      .findAccountpayableAggregation(query)
      .then(function (data) {
        accountDao
          .findAccountpayableAggregation(sQuery)
          .then(async function (dcount) {
            let tptCnt = 0;
            if (dcount.length > 0) {
              tptCnt = dcount[0].recordCount;
            }
            //for tree data
            if (postData.type == "tree") {
              data = await cmethod.buildTree(data);
            }
            res.status(200).json({
              status: true,
              result: data,
              message: "",
              hasMore: cmethod.hasMoreCount(
                tptCnt,
                postData.page,
                postData.pageLimit
              ),
              totalCount: tptCnt,
            });
          })
          .catch((err) => {
            cmethod.returnSreverError(res, message[lang].technicalError, err);
          });
      })
      .catch((err) => {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      });
  }
);

router.post(
  "/statement",
  [
    midleware.validateFieldValue(
      ["fromDate", "toDate"],
      ["fromDate", "toDate"]
    ),
  ],
  async (req, res) => {
    const { body, headers } = req;
    const lang = headers.lang || config.lang;

    const pipeline = [];
    const opening = [];
    const closing = [];

    const { fromDate, toDate, branchId, glAccountId, pageLimit, page } = body;

    try {
      const filter = {};

      if (fromDate && toDate) {
        const start = new Date(fromDate);
        const end = new Date(toDate);
        end.setDate(end.getDate() + 1);

        filter.transDate = {
          $gte: start,
          $lt: end,
        };
      }

      if (branchId) {
        filter.branchId = { $in: makeObjectIds(branchId) };
      }

      if (glAccountId) {
        filter.glAccountId = { $in: makeObjectIds(glAccountId) };
      }

      const {
        transDate: { $gte },
        ...rest
      } = filter;

      const openingFilter = {
        transDate: { $lt: $gte },
        ...rest,
      };

      opening.push(
        {
          $match: openingFilter,
        },
        {
          $group: {
            _id: "$glAccountId",
            crTotal: {
              $sum: {
                $cond: [
                  {
                    $eq: ["$transactionType", "cr"],
                  },
                  "$payAmount",
                  0,
                ],
              },
            },
            drTotal: {
              $sum: {
                $cond: [
                  {
                    $eq: ["$transactionType", "dr"],
                  },
                  "$payAmount",
                  0,
                ],
              },
            },
          },
        },
        {
          $project: {
            opening: {
              $subtract: ["$drTotal", "$crTotal"],
            },
          },
        }
      );

      closing.push(
        {
          $match: filter,
        },
        {
          $lookup: {
            from: "accountmasters",
            localField: "glAccountId",
            foreignField: "_id",
            as: "accountMaster",
          },
        },
        {
          $unwind: {
            path: "$accountMaster",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "branchs",
            localField: "branchId",
            foreignField: "_id",
            as: "branch",
          },
        },
        {
          $unwind: {
            path: "$branch",
            preserveNullAndEmptyArrays: true,
          },
        }
      );

      if (page) {
        closing.push({
          $skip: cmethod.pageOffset(page, pageLimit),
        });
        closing.push({ $limit: cmethod.pageLimit(pageLimit) });
      }

      closing.push({
        $group: {
          _id: "$glAccountId",
          transactions: {
            $push: {
              _id: "$_id",
              voucherNo: "$voucherNo",
              transactionType: "$transactionType",
              payAmount: "$payAmount",
              transDate: "$transDate",
              createdAt: "$createdAt",
              createdBy: "$createdBy",
              description: "$description",
              paymentType: "$paymentType",
              referenceId: "$referenceId",
              referenceNo: "$referenceNo",
              referenceType: "$referenceType",
              branchId: "$branchId",
              branchName: "$branch.branchName",
              accountNo: "$accountMaster.accountNo",
              accountName: "$accountMaster.accountName",
            },
          },
          crTotal: {
            $sum: {
              $cond: [
                {
                  $eq: ["$transactionType", "cr"],
                },
                "$payAmount",
                0,
              ],
            },
          },
          drTotal: {
            $sum: {
              $cond: [
                {
                  $eq: ["$transactionType", "dr"],
                },
                "$payAmount",
                0,
              ],
            },
          },
        },
      });

      pipeline.push({
        $facet: {
          openingBalance: opening,
          closingBalance: closing,
        },
      });

      const fields = {
        openingBalance: {
          $ifNull: [
            {
              $round: {
                $first: "$openingBalance.opening",
              },
            },
            0,
          ],
        },
        closingBalance: {
          $ifNull: [
            {
              $round: {
                $subtract: [
                  {
                    $add: [
                      {
                        $ifNull: [
                          {
                            $round: {
                              $first: "$openingBalance.opening",
                            },
                          },
                          0,
                        ],
                      },
                      {
                        $ifNull: [
                          {
                            $round: {
                              $first: "$closingBalance.drTotal",
                            },
                          },
                          0,
                        ],
                      },
                    ],
                  },
                  {
                    $first: "$closingBalance.crTotal",
                  },
                ],
              },
            },
            0,
          ],
        },
        crTotal: {
          $ifNull: [
            {
              $round: {
                $first: "$closingBalance.crTotal",
              },
            },
            0,
          ],
        },
        drTotal: {
          $ifNull: [
            {
              $round: {
                $add: [
                  {
                    $ifNull: [
                      {
                        $round: {
                          $first: "$openingBalance.opening",
                        },
                      },
                      0,
                    ],
                  },
                  {
                    $ifNull: [
                      {
                        $round: {
                          $first: "$closingBalance.drTotal",
                        },
                      },
                      0,
                    ],
                  },
                ],
              },
            },
            0,
          ],
        },
        statement: {
          $first: "$closingBalance.transactions",
        },
      };

      Project(pipeline, fields);

      const results = await accountModal.Accountledger.aggregate(pipeline);

      const [
        {
          openingBalance = 0,
          closingBalance = 0,
          crTotal = 0,
          drTotal = 0,
          statement = [],
        } = {},
      ] = results;

      const sorted = statement.sort((a, b) => a.transDate - b.transDate);

      let runningBalance = openingBalance;

      const runningDocs = sorted.map((item) => {
        const transactionAmount =
          item.transactionType === "dr" ? item.payAmount : -item.payAmount;
        runningBalance += transactionAmount;

        return {
          ...item,
          runningBalance,
        };
      });

      const result = {
        openingBalance,
        closingBalance,
        crTotal,
        drTotal,
        statement: runningDocs,
      };

      cmethod.returnSuccess(res, result);
    } catch (error) {
      logger.error(error.message);
      cmethod.returnSreverError(res, message[lang]?.technicalError, error);
    }
  }
);

router.patch(
  "/add-payment-storage",
  [
    midleware.validateFieldValue(
      ["sellerId", "branchId", "inventoryId"],
      ["sellerId", "branchId", "inventoryId"]
    ),
  ],
  addPaymentStorage
);

module.exports = router;

/**
 * @swagger
 * /api/account/add:
 *   post:
 *     tags: [Account]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: accountName
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: nature
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *             ex- dr or cr
 *       - name: paymentType
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *             ex- cash or bank
 *       - name: parentId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: category
 *         in: formData
 *         type: string
 *         required: true
 *       - name: type
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *          ex - dropdown of MGR,GR,GL
 *       - name: lock
 *         in: formData
 *         type: number
 *         required: true
 *         description:
 *           ex- 0,1
 *       - name: fixedGl
 *         in: formData
 *         type: number
 *         required: false
 *         description:
 *           ex- 0,1
 *       - name: branchId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: status
 *         in: formData
 *         type: number
 *         required: true
 *         description:
 *            ex- 0,1
 *     responses:
 *       200:
 *         description: Add Make.
 *
 */

/**
 * @swagger
 * /api/account/getclosingDate:
 *   post:
 *     tags: [Account]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: branchId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: markAccountId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *     responses:
 *       200:
 *         description: getclosingDate.
 *
 */
/**
 * @swagger
 * /api/account/getclosingBalance:
 *   post:
 *     tags: [Account]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: branchId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: markAccountId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: closingDate
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *     responses:
 *       200:
 *         description: getclosingBalance.
 *
 */
/**
 * @swagger
 * /api/account/list:
 *   post:
 *     tags: [Account]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: search
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *          ex- accountNo or accountName
 *       - name: type
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *          ex- tree or normal
 *       - name: groupType
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *          ex- MGR, GR,GL
 *       - name: accountNo
 *         in: formData
 *         type: number
 *         required: false
 *         description:
 *       - name: accountName
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: filteraccountNo
 *         in: formData
 *         type: array
 *         items:
 *           type: string
 *         required: false
 *         description:
 *       - name: fixedGl
 *         in: formData
 *         type: number
 *         required: false
 *         description:
 *           ex- 0,1
 *       - name: fixedGlNot
 *         in: formData
 *         type: number
 *         required: false
 *         description:
 *           ex- 1
 *       - name: branchId
 *         in: formData
 *         type: string
 *         required: false
 *       - name: pageLimit
 *         in: formData
 *         type: number
 *         required: false
 *         description:
 *       - name: page
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *     responses:
 *       200:
 *         description: Account List.
 *
 */

/**
 * @swagger
 * /api/account/update:
 *   patch:
 *     tags: [Account]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: accountId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: accountName
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: status
 *         in: formData
 *         type: number
 *         required: false
 *         description:
 *     responses:
 *       200:
 *         description: Make update.
 *
 */

/**
 * @swagger
 * /api/account/delete:
 *   delete:
 *     tags: [Account]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: accountId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: Reciepts.
 *
 */

/**
 * @swagger
 * /api/account/addGl:
 *   post:
 *     tags: [Account]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: branchId[]
 *         in: formData
 *         type: array
 *         items:
 *           type: string
 *         required: true
 *         description:
 *       - name: glAccountId[]
 *         in: formData
 *         type: array
 *         items:
 *           type: string
 *         required: true
 *         description:
 *       - name: transactionType[]
 *         in: formData
 *         type: array
 *         items:
 *           type: string
 *         required: true
 *         description:
 *            like cr or dr
 *       - name: paymentType[]
 *         in: formData
 *         type: array
 *         items:
 *           type: string
 *         required: true
 *         description:
 *       - name: payAmount[]
 *         in: formData
 *         type: array
 *         items:
 *           type: string
 *         required: true
 *         description:
 *       - name: referenceType[]
 *         in: formData
 *         type: array
 *         items:
 *           type: string
 *         required: false
 *         description:
 *       - name: referenceId[]
 *         in: formData
 *         type: array
 *         items:
 *           type: string
 *         required: false
 *         description:
 *       - name: addedFrom[]
 *         in: formData
 *         type: array
 *         items:
 *           type: string
 *         required: false
 *         description:
 *       - name: createdBy[]
 *         in: formData
 *         type: array
 *         items:
 *           type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: Reciepts.
 *
 */
/**
 * @swagger
 * /api/account/updateGl:
 *   patch:
 *     tags: [Account]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: glId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: closingStatus
 *         in: formData
 *         type: number
 *         required: false
 *         description:
 *     responses:
 *       200:
 *         description: Make update.
 *
 */
/**
 * @swagger
 * /api/account/glList:
 *   post:
 *     tags: [Account]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: branchId[]
 *         in: formData
 *         type: array
 *         items:
 *           type: string
 *         required: true
 *         description:
 *       - name: fromDate
 *         in: formData
 *         type: string
 *         required: true
 *         description: transaction date
 *       - name: toDate
 *         in: formData
 *         type: string
 *         required: true
 *         description: transaction date
 *       - name: search
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *              ex - vin,recieptNo,voucherNo,description,referenceNo,referenceNo2,transactionType
 *       - name: voucherNo
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: accountNo
 *         in: formData
 *         type: number
 *         required: false
 *         description:
 *       - name: accountName
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: transactionType
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *          ex - dr or cr
 *       - name: addedFrom
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *          ex - ip=incoming payment,op=outgoing payment
 *       - name: pageLimit
 *         in: formData
 *         type: number
 *         required: false
 *         description:
 *       - name: page
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *     responses:
 *       200:
 *         description: Reciepts.
 *
 */

/**
 * @swagger
 * /api/account/glListReport:
 *   post:
 *     tags: [Account]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: markAccountId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *              like cash-in-bank,cash-in-bank-sajja, cash-in-bank-ind, cash-in-bank-sharj, cash-in-hand, sales, vat, security, storage, storage-vat, discount, receivable, transaction-fee, sale-return,petty-cash
 *       - name: accountCloseId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: branchId[]
 *         in: formData
 *         type: array
 *         items:
 *           type: string
 *         required: false
 *         description:
 *       - name: fromData
 *         in: formData
 *         type: string
 *         required: false
 *         description: transaction date
 *       - name: toData
 *         in: formData
 *         type: string
 *         required: false
 *         description: transaction date
 *       - name: voucherNo
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: accountNo
 *         in: formData
 *         type: number
 *         required: false
 *         description:
 *       - name: accountName
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: sellerNo
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: buyerNo
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: transactionOf
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *              ex - seller | buyer | ""
 *       - name: search
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *              ex - vin,recieptNo
 *       - name: orderBy
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *              ex - desc
 *       - name: pageLimit
 *         in: formData
 *         type: number
 *         required: false
 *         description:
 *       - name: page
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *     responses:
 *       200:
 *         description: Reciepts.
 *
 */
/**
 * @swagger
 * /api/account/cashInHandSummary:
 *   post:
 *     tags: [Account]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: branchId[]
 *         in: formData
 *         type: array
 *         items:
 *           type: string
 *         required: false
 *         description:
 *       - name: fromData
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: toData
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: pageLimit
 *         in: formData
 *         type: number
 *         required: true
 *         description:
 *       - name: page
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: Reciepts.
 *
 */

/**
 * @swagger
 * /api/account/closingDataList:
 *   post:
 *     tags: [Account]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: accountcloseId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: markAccountId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: closingstatusval
 *         in: formData
 *         type: Number
 *         required: false
 *         description:
 *       - name: branchId[]
 *         in: formData
 *         type: array
 *         items:
 *           type: string
 *         required: false
 *         description:
 *       - name: transDate
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: search
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *              ex - vin,recieptNo
 *       - name: pageLimit
 *         in: formData
 *         type: number
 *         required: true
 *         description:
 *       - name: page
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: closingDataList.
 *
 */

/**
 * @swagger
 * /api/account/closingAccountadd:
 *   post:
 *     tags: [Account]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: branchId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: ledgerIds[]
 *         in: formData
 *         type: array
 *         items:
 *           type: string
 *         required: true
 *         description:
 *       - name: closingNotesDetails[]
 *         in: formData
 *         type: array
 *         items:
 *           type: string
 *         required: false
 *         description:
 *              ex - [{notes:100,qty:5,total:500},{notes:100,qty:4,total:400}]
 *       - name: amount
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: createdBy
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: closing Account add.
 *
 */

/**
 * @swagger
 * /api/account/dailyBasisclosing:
 *   post:
 *     tags: [Account]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: branchId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: pageLimit
 *         in: formData
 *         type: number
 *         required: false
 *         description:
 *       - name: page
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *     responses:
 *       200:
 *         description: closing Account add.
 *
 */

/**
 * @swagger
 * /api/account/outgoingcashadd:
 *   post:
 *     tags: [Account]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: branchId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: referenecType
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *          ex - security , expense
 *       - name: referenceId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: paymentMethod
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: amount
 *         in: formData
 *         type: Number
 *         required: false
 *         description:
 *       - name: file
 *         in: formData
 *         type: string
 *         required: true
 *       - name: status
 *         in: formData
 *         type: String
 *         required: false
 *         description:
 *          ex - pending, approved, paid
 *     responses:
 *       200:
 *         description: Add Make.
 *
 */

/**
 * @swagger
 * /api/account/outgoingcashlist:
 *   post:
 *     tags: [Account]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: status[]
 *         in: formData
 *         type: array
 *         items:
 *           type: string
 *         required: false
 *         description:
 *       - name: outgoingcashId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: referenceNo
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: pageLimit
 *         in: formData
 *         type: number
 *         required: true
 *         description:
 *       - name: page
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: Make List.
 *
 */
/**
 * @swagger
 * /api/account/outgoingcashdelete:
 *   delete:
 *     tags: [Account]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: outId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: Reciepts.
 *
 */
/**
 * @swagger
 * /api/account/outgoingcashupdate:
 *   patch:
 *     tags: [Account]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: outgotId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: referenecType
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: referenceId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: paymentMethod
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: amount
 *         in: formData
 *         type: Number
 *         required: false
 *         description:
 *       - name: file
 *         in: formData
 *         type: string
 *         required: false
 *       - name: transDate
 *         in: formData
 *         type: Number
 *         required: false
 *       - name: status
 *         in: formData
 *         type: Number
 *         required: false
 *         description:
 *     responses:
 *       200:
 *         description: Add Make.
 *
 */

/**
 * @swagger
 * /api/account/expenseadd:
 *   post:
 *     tags: [Account]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: branchId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: referenecType
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *          ex - security , expense
 *       - name: paymentMethod
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: amount
 *         in: formData
 *         type: Number
 *         required: false
 *         description:
 *       - name: file
 *         in: formData
 *         type: string
 *         required: false
 *       - name: employeenameId
 *         in: formData
 *         type: String
 *         required: false
 *         description:
 *       - name: departmenthead
 *         in: formData
 *         type: String
 *         required: false
 *         description:
 *       - name: businessPurpose
 *         in: formData
 *         type: String
 *         required: false
 *         description:
 *       - name: itemData[]
 *         in: formData
 *         type: array
 *         items:
 *           type: string
 *         required: false
 *       - name: status
 *         in: formData
 *         type: String
 *         required: false
 *         description:
 *          ex - pending, approved, paid
 *     responses:
 *       200:
 *         description: Add Make.
 *
 */
/**
 * @swagger
 * /api/account/expenseupdate:
 *   patch:
 *     tags: [Account]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: expId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: branchId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: referenecType
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *          ex - security , expense
 *       - name: paymentMethod
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: amount
 *         in: formData
 *         type: Number
 *         required: false
 *         description:
 *       - name: file
 *         in: formData
 *         type: string
 *         required: false
 *       - name: employeenameId
 *         in: formData
 *         type: String
 *         required: false
 *         description:
 *       - name: departmenthead
 *         in: formData
 *         type: String
 *         required: false
 *         description:
 *       - name: businessPurpose
 *         in: formData
 *         type: String
 *         required: false
 *         description:
 *       - name: itemData[]
 *         in: formData
 *         type: array
 *         items:
 *           type: string
 *         required: false
 *       - name: status
 *         in: formData
 *         type: String
 *         required: false
 *         description:
 *          ex - pending, approved, paid
 *     responses:
 *       200:
 *         description: expenseupdate.
 *
 */
/**
 * @swagger
 * /api/account/expenselist:
 *   post:
 *     tags: [Account]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: expenseId
 *         in: formData
 *         type: String
 *         required: false
 *         description:
 *       - name: pageLimit
 *         in: formData
 *         type: number
 *         required: true
 *         description:
 *       - name: page
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: itemizeexpenselist.
 *
 */
/**
 * @swagger
 * /api/account/expenseitemdelete:
 *   delete:
 *     tags: [Account]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: expId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: expenseitemdelete.
 *
 */
/**
 * @swagger
 * /api/account/closingnotesdetaillist:
 *   post:
 *     tags: [Account]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: closingAccountId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: pageLimit
 *         in: formData
 *         type: number
 *         required: true
 *         description:
 *       - name: page
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: closing Account add.
 *
 */
/**
 * @swagger
 * /api/account/addtempGl:
 *   post:
 *     tags: [Account]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: branchId[]
 *         in: formData
 *         type: array
 *         items:
 *           type: string
 *         required: true
 *         description:
 *       - name: glAccountId[]
 *         in: formData
 *         type: array
 *         items:
 *           type: string
 *         required: true
 *         description:
 *       - name: transactionType[]
 *         in: formData
 *         type: array
 *         items:
 *           type: string
 *         required: true
 *         description:
 *            like cr or dr
 *       - name: paymentType[]
 *         in: formData
 *         type: array
 *         items:
 *           type: string
 *         required: true
 *         description:
 *       - name: payAmount[]
 *         in: formData
 *         type: array
 *         items:
 *           type: string
 *         required: true
 *         description:
 *       - name: referenceType[]
 *         in: formData
 *         type: array
 *         items:
 *           type: string
 *         required: false
 *         description:
 *       - name: referenceId[]
 *         in: formData
 *         type: array
 *         items:
 *           type: string
 *         required: false
 *         description:
 *       - name: addedFrom[]
 *         in: formData
 *         type: array
 *         items:
 *           type: string
 *         required: false
 *         description:
 *       - name: createdBy[]
 *         in: formData
 *         type: array
 *         items:
 *           type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: Reciepts.
 *
 */
/**
 * @swagger
 * /api/account/gltempList:
 *   post:
 *     tags: [Account]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: branchId[]
 *         in: formData
 *         type: array
 *         items:
 *           type: string
 *         required: false
 *         description:
 *       - name: search
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *              ex - vin,recieptNo,voucherNo,description,referenceNo,referenceNo2,transactionType
 *       - name: accountLedgerTempId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: voucherNo
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: accountNo
 *         in: formData
 *         type: number
 *         required: false
 *         description:
 *       - name: accountName
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: transactionType
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *          ex - dr or cr
 *       - name: addedFrom
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *          ex - ip=incoming payment,op=outgoing payment
 *       - name: pageLimit
 *         in: formData
 *         type: number
 *         required: false
 *         description:
 *       - name: page
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *     responses:
 *       200:
 *         description: Reciepts.
 *
 */
/**
 * @swagger
 * /api/account/updatetempGl:
 *   patch:
 *     tags: [Account]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: glId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: status
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: isAR
 *         in: formData
 *         type: boolean
 *         required: false
 *         description:
 *       - name: paymentType
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: transDate
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: voucherNo
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *     responses:
 *       200:
 *         description: Make update.
 *
 */
/**
 * @swagger
 * /api/account/accountpayable:
 *   post:
 *     tags: [Account]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: appType
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: referenceId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: invoiceDate
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: description
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: totalPaid
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: dueAmount
 *         in: formData
 *         type: number
 *         required: true
 *         description:
 *       - name: status
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: paymentMethod
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: accountPayable.
 *
 */
/**
 * @swagger
 * /api/account/accountpayablelist:
 *   post:
 *     tags: [Account]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: fromData
 *         in: formData
 *         type: string
 *         required: false
 *         description: from date
 *       - name: toData
 *         in: formData
 *         type: string
 *         required: false
 *         description: to date
 *       - name: pageLimit
 *         in: formData
 *         type: number
 *         required: true
 *         description:
 *       - name: page
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: Account List.
 *
 */

/**
 * @swagger
 * /api/account/statement:
 *   post:
 *     tags: [Account]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: fromDate
 *         in: formData
 *         type: string
 *         required: true
 *       - name: toDate
 *         in: formData
 *         type: string
 *         required: true
 *       - name: branchId[]
 *         in: formData
 *         type: array
 *         items:
 *           type: string
 *         collectionFormat: multi
 *         required: false
 *       - name: glAccountId[]
 *         in: formData
 *         type: array
 *         items:
 *           type: string
 *         collectionFormat: multi
 *         required: false
 *       - name: pageLimit
 *         in: formData
 *         type: number
 *         required: true
 *       - name: page
 *         in: formData
 *         type: string
 *         required: true
 *     responses:
 *       200:
 *         description: Account - Statement
 *
 */

/**
 * @swagger
 * /api/account/add-payment-storage:
 *   patch:
 *     tags: [Account]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: sellerId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: branchId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: inventoryId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: Account - Storage Payment
 *
 */
