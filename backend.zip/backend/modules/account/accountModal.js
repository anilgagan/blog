const { number } = require("@hapi/joi");
const mongoose = require("mongoose");
const Schema = mongoose.Schema;
const { connWrite } = require("../../config/database");

const accountMasterSchema = new Schema(
  {
    accountNo: Number,
    accountName: String,
    nature: String, //dr=positive,cr=negative
    parentId: {
      type: mongoose.Types.ObjectId,
      default: null,
      index: true,
    },
    branchId: {
      type: mongoose.Types.ObjectId,
      default: null,
      index: true,
    },
    category: String,
    type: String, //MGR, GR,GL
    paymentType: {
      type: String,
      enum: ["cash", "bank"],
      default: "cash",
    },
    markAccountId: String,
    fixedGl: { type: Number, default: 0 }, //1 means fixed for specific screen
    lock: { type: Number, default: 0 },
    status: { type: Number, default: 0 },
    isDelete: { type: Number, default: 0 }, //1 means delete
    closingDate: { type: Date },
  },
  {
    timestamps: {
      createdAt: "createdAt",
      updatedAt: "updatedAt",
    },
  }
);
const accountLedgerSchema = new Schema(
  {
    branchId: {
      type: mongoose.Types.ObjectId,
      default: null,
      index: true,
    },
    voucherNo: String, //{ type: Number, default: 0 },
    glAccountId: {
      type: mongoose.Types.ObjectId,
      default: null,
      index: true,
    },
    transactionType: { type: String, default: "cr" } /*like cr or dr*/,
    paymentType: { type: String, default: "cash" } /*like cash or online*/,
    payAmount: Number,
    description: String,
    referenceType: String /*reciept,inventory,sales etc. */,
    referenceId: {
      type: mongoose.Types.ObjectId,
      default: null,
      index: true,
    },
    referenceNo: String,
    referenceNo2: String,
    balanceAmount: { type: Number, default: 0 },
    createdBy: String,
    closingStatus: { type: Number, default: 0 },
    transDate: { type: Date, index: true },
    buyerNo: String,
    sellerNo: String,
    accountcloseId: {
      type: mongoose.Types.ObjectId,
      default: null,
      index: true,
    },
    sapId: { type: Number, default: 0, index: true },
    addedFrom: String, //for specific screen value should come ip=incoming payment,op=outgoing payment
    transactionOf: { type: String, default: "", index: true },
    accountMasterType: String, // * sales|storage|receivable - account masters reference
  },
  {
    timestamps: {
      createdAt: "createdAt",
      updatedAt: "updatedAt",
    },
  }
);

const closingAccountSchema = new Schema(
  {
    branchId: {
      type: mongoose.Types.ObjectId,
      default: mongoose.Types.ObjectId(),
      index: true,
    },
    amount: { type: Number, default: 0 },
    createdBy: String,
    openingBalance: String,
    transDate: { type: Date },
    markAccountId: String,
  },
  {
    timestamps: {
      createdAt: "createdAt",
      updatedAt: "updatedAt",
    },
  }
);
const outgoingcashschema = new Schema(
  {
    voucherNo: String,
    referenceId: {
      type: mongoose.Types.ObjectId,
      default: mongoose.Types.ObjectId(),
      index: true,
    },
    branchId: {
      type: mongoose.Types.ObjectId,
      default: mongoose.Types.ObjectId(),
      index: true,
    },
    referenecType: String, //security , expense
    paymentMethod: String,
    //recieptNo: String,
    referenceNo: String,
    amount: { type: Number, default: 0 },
    file: String,
    //------------expense----------------
    employeenameId: String,
    departmenthead: String,
    businessPurpose: String,
    status: { type: String, default: "pending" }, // pending|approved|paid|rejected
    transDate: { type: Date },
    comments: { type: String, default: "" },
  },
  {
    timestamps: {
      createdAt: "createdAt",
      updatedAt: "updatedAt",
    },
  }
);
const closingNotesDetails = new Schema(
  {
    closingAccountId: {
      type: mongoose.Types.ObjectId,
      default: mongoose.Types.ObjectId(),
      index: true,
    },
    Note: { type: Number, default: 0 },
    qty: { type: Number, default: 0 },
    Total: { type: Number, default: 0 },
  },
  {
    timestamps: {
      createdAt: "createdAt",
      updatedAt: "updatedAt",
    },
  }
);
const itemExpenses = new Schema(
  {
    expenseId: {
      type: mongoose.Types.ObjectId,
      default: mongoose.Types.ObjectId(),
      index: true,
    },
    date: String,
    description: String,
    invoice: String,
    amount: { type: Number, default: 0 },
  },
  {
    timestamps: {
      createdAt: "createdAt",
      updatedAt: "updatedAt",
    },
  }
);
const accountLedgertempSchema = new Schema(
  {
    branchId: {
      type: mongoose.Types.ObjectId,
      default: null,
      index: true,
    },
    voucherNo: String, //{ type: Number, default: 0 },
    glAccountId: {
      type: mongoose.Types.ObjectId,
      default: null,
      index: true,
    },
    transactionType: { type: String, default: "cr" } /*like cr or dr*/,
    paymentType: { type: String, default: "cash" } /*like cash or online*/,
    payAmount: Number,
    description: String,
    referenceType: String /*reciept,inventory,sales etc. */,
    referenceId: {
      type: mongoose.Types.ObjectId,
      default: null,
      index: true,
    },
    referenceNo: String,
    referenceNo2: String,
    balanceAmount: { type: Number, default: 0 },
    createdBy: String,
    closingStatus: { type: Number, default: 0 },
    transDate: { type: Date },
    buyerNo: String,
    sellerNo: String,
    accountcloseId: {
      type: mongoose.Types.ObjectId,
      default: null,
      index: true,
    },
    addedFrom: String, //for specific screen value should come ip=incoming payment,op=outgoing payment
    createdFrom: String,
    status: { type: String, default: "pending" }, // pending|approved|paid|rejected
    signaturePath: { type: String, default: "" },
    transactionOf: { type: String, default: "" }, // seller, buyer, ""
    payableType: { type: String, default: "" },
    payableStatus: { type: String, default: "" },
    paidDate: { type: Date, default: null },
    comments: { type: String, default: "" },
  },
  {
    timestamps: {
      createdAt: "createdAt",
      updatedAt: "updatedAt",
    },
  }
);
const accountpayableSchema = new Schema(
  {
    refno: String,
    appType: String,
    referenceId: {
      type: mongoose.Types.ObjectId,
      default: null,
      index: true,
    },
    invoiceDate: { type: Date },
    description: String,
    totalPayment: { type: Number, default: 0 },
    totalPaid: { type: Number, default: 0 },
    dueAmount: { type: Number, default: 0 },
    paymentMethod: String,
    status: { type: String, default: "pending" },
  },
  {
    timestamps: {
      createdAt: "createdAt",
      updatedAt: "updatedAt",
    },
  }
);
const Closingnotesdetail = connWrite.model(
  "closingnotesdetails",
  closingNotesDetails
);
const Outgoingcash = connWrite.model("outgoingcashs", outgoingcashschema);
const Accountmaster = connWrite.model("accountmasters", accountMasterSchema);
const Accountledger = connWrite.model("accountledgers", accountLedgerSchema);
const ClosingAccount = connWrite.model("closingaccounts", closingAccountSchema);
const ItemExpenses = connWrite.model("itemexpensess", itemExpenses);
const Accountledgertemp = connWrite.model(
  "accountledgertemps",
  accountLedgertempSchema
);
const AccountPayable = connWrite.model("accountpayables", accountpayableSchema);

module.exports = {
  Accountmaster,
  Accountledger,
  ClosingAccount,
  Outgoingcash,
  Closingnotesdetail,
  ItemExpenses,
  Accountledgertemp,
  AccountPayable,
};
