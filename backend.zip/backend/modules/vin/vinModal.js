const mongoose = require("mongoose");
const Schema = mongoose.Schema;
const { connWrite } = require("../../config/database");

const vinSchema = new Schema(
  {
    vin: String,
  },
  {
    timestamps: {
      createdAt: "createdAt",
      updatedAt: "updatedAt",
    },
  }
);

const Vin = connWrite.model("vins", vinSchema);

const VinImagesSchema = new Schema(
  {
    vinId: {
      type: mongoose.Types.ObjectId,
      default: null,
      index: true,
    },
    imageType: { type: String, index: true },
    type: { type: String, index: true },
    referenceId: {
      type: mongoose.Types.ObjectId,
      default: null,
      index: true,
    },
    image: String,
    defaultimage: { type: Number, default: 0, index: true },
  },
  {
    timestamps: {
      createdAt: "createdAt",
      updatedAt: "updatedAt",
    },
  }
);
const folderSchema = new Schema(
  {
    parentId: {
      type: mongoose.Types.ObjectId,
      default: null,
      index: true,
    },
    folderName: String,
  },
  {
    timestamps: {
      createdAt: "createdAt",
      updatedAt: "updatedAt",
    },
  }
);

const Vinimage = connWrite.model("vinimages", VinImagesSchema);
const Folder = connWrite.model("folders", folderSchema);

module.exports = {
  Vin,
  Vinimage,
  Folder,
};
