const vinModal = require("../vin/vinModal");
const message = require("../../config/message");
const cmethod = require("../../middleware/common-fun");


const vinAdd = async function (res, postData) {
const newVin = new vinModal.Vin(postData);    
    
newVin.save(postData, async function (err, data) {
  if (err) { 
    cmethod.returnSreverError(res, message.technicalError, err);
  } else {         
    cmethod.returnSuccess(res, data, false, message.signupsuccess); 
  }
});
};

const findVinWithFiled = async function (query) { 
    return new Promise(function (resolve, reject) {
      vinModal.Vin.find({ costPrice: { '$exists': true } },{vin:1},function (err, data) {
        if (err) { 
          reject(err);
        } else {
          resolve(data);
        }
      });
    });
  };
  const findVinAggregation = function (query) {
    return new Promise(function (resolve, reject) {
      vinModal.Vin.aggregate(query, function (err, data) {
        if (err) {
          reject(err);
        } else {
          resolve(data);
        }
      });
    });
  };
  const findVinimagesAggregation = function (query) {
    return new Promise(function (resolve, reject) {
      vinModal.Vinimage.aggregate(query, function (err, data) {
        if (err) {
          reject(err);
        } else {
          resolve(data);
        }
      });
    });
  };
//folder master code
//menu
const folderAdd = async function (res, postData) {
  const newFolder = new vinModal.Folder(postData);

  newFolder.save(postData, async function (err, data) {
    if (err) {
      cmethod.returnSreverError(res, message.technicalError, err);
    } else {
      cmethod.returnSuccess(res, data, false, message.signupsuccess);
    }
  });
};

const findFolderAggregation = function (query) {
  return new Promise(function (resolve, reject) {
    vinModal.Folder.aggregate(query, function (err, data) {
      if (err) {
        reject(err);
      } else {
        resolve(data);
      }
    });
  });
};
  module.exports={
    vinAdd,
    findVinWithFiled,
    findVinAggregation,
    findVinimagesAggregation,
    folderAdd,
    findFolderAggregation
  }