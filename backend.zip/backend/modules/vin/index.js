const express = require("express");
const router = express.Router();
const vinModal = require("../vin/vinModal");
const message = require("../../config/message");
const config = require("../../config");
const midleware = require("../../middleware/validation");
const cmethod = require("../../middleware/common-fun");
const vinDao = require("./vinDao");
var mongoose = require("mongoose");
const { route } = require("../reciept");
const fs = require('fs')
const s3Zip = require('s3-zip')
const aws = require('aws-sdk')
const archiver = require('archiver');
const path = require('path');
const { split } = require("lodash");


router.post("/add",
  [
    midleware.validateFieldValue(
      ["images"],
      ["images"]
    )
  ],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;

    let imagesData = [];
    let allImages = postData.images;
    if (allImages.length > 0) {
      allImages.forEach((value, index) => {
        imagesData.push(
          {
            "imageType": "documents",
            "image": value
          }
        )
      });
    }

    vinModal.Vinimage.insertMany(imagesData, async (err, data) => {
      if (err) {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      } else {

        cmethod.returnSuccess(res, data, false, "images added successfully.");
      }
    })


  });

router.post("/list",
  [
    midleware.validateFieldValue(
      ["pageLimit", "page"],
      ["page"]
    )
  ],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let query = [];


    if (postData.referenceId) {
      query.push({
        $match: {
          referenceId: mongoose.Types.ObjectId(postData.referenceId),
        },
      });
    }
    if (postData.search) {
      query.push(
        {
          $match: {
            $and: [
              {
                $or: [
                  { 'image': { $regex: postData.search, $options: "i" } },
                  // { 'buyerUsers.name': { $regex: postData.search, $options: "i" } },
                ],
              },
            ],
          },
        });
    }
    const sQuery = [...query];
    query.push({
      $project: {
        vinId: 1,
        imageType: 1,
        image: 1,
        createdAt: 1,
        referenceId: 1,
        type: 1
      },
    });

    query.push({ $sort: { createdAt: -1 } });
    sQuery.push({ $count: "recordCount" });

    if (postData.page) {
      query.push({
        $skip: cmethod.pageOffset(postData.page, postData.pageLimit),
      });
      query.push({ $limit: cmethod.pageLimit(postData.pageLimit) });
    }

    vinDao.findVinimagesAggregation(query)
      .then(function (data) {
        vinDao.findVinimagesAggregation(sQuery)
          .then(async function (dcount) {
            let tptCnt = 0;
            if (dcount.length > 0) {
              tptCnt = dcount[0].recordCount;
            }
            res.status(200).json({
              status: true,
              result: data,
              message: "",
              hasMore: cmethod.hasMoreCount(
                tptCnt,
                postData.page,
                postData.pageLimit
              ),
              totalCount: tptCnt
            });
          })
          .catch((err) => {
            cmethod.returnSreverError(res, message[lang].technicalError, err);
          });
      })
      .catch((err) => {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      });
  });
router.post("/imagelist",
  [
    midleware.validateFieldValue(
      ["referenceId"],
      ["referenceId"]
    )
  ],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let query = [];


    if (postData.referenceId) {
      query.push({
        $match: {
          referenceId: mongoose.Types.ObjectId(postData.referenceId),
        },
      });
    }
    if (postData.imageType) {
      query.push({
        $match: {
          imageType: postData?.imageType,
        },
      });
    }
    if (postData.type) {
      query.push({
        $match: {
          type: postData?.type,
        },
      });
    }
    if (postData.search) {
      query.push(
        {
          $match: {
            $and: [
              {
                $or: [
                  { 'image': { $regex: postData.search, $options: "i" } },
                  // { 'buyerUsers.name': { $regex: postData.search, $options: "i" } },
                ],
              },
            ],
          },
        });
    }
    const sQuery = [...query];
    query.push({
      $project: {
        vinId: 1,
        imageType: 1,
        image: 1,
        createdAt: 1,
        referenceId: 1,
        type: 1
      },
    });

    query.push({ $sort: { createdAt: -1 } });
    sQuery.push({ $count: "recordCount" });

    if (postData.page) {
      query.push({
        $skip: cmethod.pageOffset(postData.page, postData.pageLimit),
      });
      query.push({ $limit: cmethod.pageLimit(postData.pageLimit) });
    }

    vinDao.findVinimagesAggregation(query)
      .then(function (data) {
        res.status(200).json({
          status: true,
          result: data,
          message: "",
          hasMore: false,
          totalCount: 0
        });
      })
      .catch((err) => {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      });
  });
router.patch(
  "/vinImageUpdate",
  [midleware.validateFieldValue(
    ["documentId", "image"],
    ["documentId", "image"])],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let xtoken = req.headers["x-access-token"];
    //{ token: xtoken },
    let queryCond = {
      $and: [
        { _id: mongoose.Types.ObjectId(postData.documentId) },
      ],
    };
    delete postData.documentId;
    //console.log("=======================>",req.body)
    vinModal.Vinimage.findOneAndUpdate(
      queryCond,
      { $set: postData },
      { new: true },
      async function (err, data) {
        //   console.log("user->", data);
        if (err) {
          cmethod.returnSreverError(res, message[lang].technicalError, err);
        } else {
          /* await deleteHash(req)
          let index = await uModal.User.find({"_id": { "$lte" : mongoose.Types.ObjectId(data._id)}}).count()
          await deleteUser(index) */
          //console.log(data)   
          // let tempObj = {
          //   ...data.result,
          // };

          // delete tempObj.token;
          // delete tempObj.password;

          cmethod.returnSuccess(
            res,
            data,
            false,
            message[lang].profileUpdate
          );
        }
      }
    );
  }
);

router.post("/filezip",
  [
    midleware.validateFieldValue(
      ["referenceId"],
      ["referenceId"]
    )
  ],
  async (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let query = [];


    if (postData.referenceId) {
      query.push({
        $match: {
          referenceId: mongoose.Types.ObjectId(postData.referenceId),
        },
      });
    }
    if (postData.imageType) {
      query.push({
        $match: {
          imageType: postData?.imageType,
        },
      });
    }
    if (postData.type) {
      query.push({
        $match: {
          type: postData?.type,
        },
      });
    }
    if (postData.search) {
      query.push(
        {
          $match: {
            $and: [
              {
                $or: [
                  { 'image': { $regex: postData.search, $options: "i" } },
                  // { 'buyerUsers.name': { $regex: postData.search, $options: "i" } },
                ],
              },
            ],
          },
        });
    }
    const sQuery = [...query];
    query.push({ $sort: { createdAt: 1 } });
    sQuery.push({ $count: "recordCount" });

    if (postData.page) {
      query.push({
        $skip: cmethod.pageOffset(postData.page, postData.pageLimit),
      });
      query.push({ $limit: cmethod.pageLimit(postData.pageLimit) });
    }
    query.push({
      $project: {
        vinId: 1,
        imageType: 1,
        image: 1,
        createdAt: 1,
        referenceId: 1,
        type: 1
      },
    });
    aws.config.update({
      accessKeyId: process.env.AWS_ACCESSKEYID,
      secretAccessKey: process.env.AWS_SECRETACCESSKEY,
      region: 'us-east-2', // Set your AWS region
    });

    vinDao.findVinimagesAggregation(query)
      .then(async function (data) {
        // Create an S3 instance
        const s3 = new aws.S3();

        const bucketName = process.env.AWS_BUCKET;
        const fileKeys = data;
        const tempDirectory = process.cwd() + '/public/www/';
        fs.mkdirSync(tempDirectory, { recursive: true });

        // Download S3 files to the temporary directory
        var i = 0;
        for (const fileKey of fileKeys) {
          if(!fileKey?.image){
            continue;
          }

          let fileData = fileKey?.image;
          let filepath = fileData.split("assets/");
          filepath = "assets/" + filepath[1];
          const params = {
            Bucket: bucketName,
            Key: filepath,
          };
          i++;
          let ext = path.extname(filepath)
          // const outputFile = `${tempDirectory}${fileKey}`;
          const outputFile = tempDirectory + i + ext;
          const fileStream = await fs.createWriteStream(outputFile);
          // console.log("kkkk",fileStream);
          const s3Stream = await s3.getObject(params).createReadStream();
          // console.log("jjjjj======",s3Stream);
          s3Stream.pipe(fileStream);

          await new Promise((resolve, reject) => {
            s3Stream.on('end', resolve);
            s3Stream.on('error', reject);
          });
        }

        // Create a zip archive from the downloaded files
        const archive = archiver('zip');
        archive.directory(tempDirectory, false);
        archive.pipe(res);

        // Set the HTTP response headers for downloading the zip file
        res.setHeader('Content-Type', 'application/zip');
        res.setHeader('Content-Disposition', 'attachment; filename=downloaded-files.zip');
        res.attachment('downloaded-files.zip');

        // Start sending the zip file to the client
        await archive.finalize();

        // Clean up the temporary directory
        fs.rmdirSync(tempDirectory, { recursive: true });

        // cmethod.returnSuccess(res, [], false, message[lang].profileUpdate);
      })
      .catch((err) => { console.log(err);
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      });
  });
//menu
router.post(
  "/folderAdd",
  [
    midleware.validateFieldValue(
      ["folderName"],
      ["folderName"]
    ),
  ],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;

    // console.log("washi");
    vinDao.folderAdd(res, postData);
  }
);

router.patch(
  "/folderUpdate",
  [midleware.validateFieldValue(["folderId"], ["folderId"])],
  (req, res) => {
    let postData = req.body;
    let lang = req.headers["lang"] || config.lang;
    let xtoken = req.headers["x-access-token"];
    //{ token: xtoken },
    let queryCond = {
      $and: [{ _id: mongoose.Types.ObjectId(postData.folderId) }],
    };
    delete postData.folderId;
    //console.log("=======================>", req.body);
    vinModal.Folder.findOneAndUpdate(
      queryCond,
      { $set: postData },
      { new: true },
      async function (err, data) {
        //console.log("user->", data);
        if (err) {
          cmethod.returnSreverError(res, message[lang].technicalError, err);
        } else {
          cmethod.returnSuccess(res, data, false, message[lang].profileUpdate);
        }
      }
    );
  }
);

router.post(
  "/folderList",
  [midleware.validateFieldValue(["pageLimit", "page"], ["page"])],
  (req, res) => {
    let postData = req.body;
    //console.log("==============>", postData);
    let lang = req.headers["lang"] || config.lang;
    let query = [];
    if (postData.type == "tree") {
      // query.push({
      //   $match: {
      //     $and: [{ parentId: null }],
      //   },
      // });
      // query.push({
      //   $graphLookup: {
      //     from: "folders",
      //     startWith: "$_id",
      //     connectFromField: "_id",
      //     connectToField: "parentId",
      //     as: "childFolder",
      //   },
      // });
    } else {
      query.push({
        $lookup: {
          from: "folders",
          localField: "parentId",
          foreignField: "_id",
          as: "parentFolder",
        },
      });
      query.push({
        $unwind: { path: "$parentFolder", preserveNullAndEmptyArrays: true },
      });
    }

    query.push({
      $project: {
        parentId: 1,
        folderName: 1,
        parentFolder: 1,
      },
    });
    const sQuery = [...query];
    query.push({ $sort: { createdAt: 1 } });
    sQuery.push({ $count: "recordCount" });

    if (postData.page) {
      query.push({
        $skip: cmethod.pageOffset(postData.page, postData.pageLimit),
      });
      query.push({ $limit: cmethod.pageLimit(postData.pageLimit) });
    }

    vinDao
      .findFolderAggregation(query)
      .then(function (data) {
        vinDao
          .findFolderAggregation(sQuery)
          .then(async function (dcount) {
            let tptCnt = 0;
            if (dcount.length > 0) {
              tptCnt = dcount[0].recordCount;
            }
            if (postData.type == "tree") {
              data = await cmethod.buildTree(data);
            }
            res.status(200).json({
              status: true,
              result: data,
              message: "",
              hasMore: cmethod.hasMoreCount(
                tptCnt,
                postData.page,
                postData.pageLimit
              ),
              totalCount: tptCnt,
            });
          })
          .catch((err) => {
            cmethod.returnSreverError(res, message[lang].technicalError, err);
          });
      })
      .catch((err) => {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      });
  }
);

router.delete(
  "/delete",
  [midleware.validateFieldValue(["vinId"], ["vinId"])],
  async (req, res) => {
    let postData = req.body;
    let cond = {
      $or: [
        { _id: mongoose.Types.ObjectId(postData.vinId) }
      ]
    };
    let lang = req.headers["lang"] || config.lang;

    vinModal.Vinimage.deleteMany(cond, postData)
      .then(async (data) => {
        cmethod.returnSuccess(res, [], false, message[lang].Deleteed);
      })
      .catch((err) => {
        cmethod.returnSreverError(res, message[lang].technicalError, err);
      });
  }
);
module.exports = router;

/**
 * @swagger
 * /api/vin/add:
 *   post:
 *     tags: [Documents]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: images[]
 *         in: formData
 *         type: array
 *         items:
 *           type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: Add images.
 *
 */

/**
 * @swagger
 * /api/vin/list:
 *   post:
 *     tags: [Documents]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: referenceId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: folderName
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: pageLimit
 *         in: formData
 *         type: number
 *         required: true
 *         description:
 *       - name: page
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: Folder List.
 *
 */
/**
 * @swagger
 * /api/vin/imagelist:
 *   post:
 *     tags: [Documents]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: referenceId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: imageType
 *         in: formData
 *         type: string
 *         required: false
 *         description: inventory
 *       - name: type
 *         in: formData
 *         type: string
 *         required: false
 *         description: carimage,
 *     responses:
 *       200:
 *         description: Folder List.
 *
 */

/**
 * @swagger
 * /api/vin/filezip:
 *   post:
 *     tags: [Documents]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: referenceId
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *       - name: imageType
 *         in: formData
 *         type: string
 *         required: false
 *         description: inventory
 *       - name: type
 *         in: formData
 *         type: string
 *         required: false
 *         description: carimage,
 *     responses:
 *       200:
 *         description: Folder List.
 *
 */

/**
 * @swagger
 * /api/vin/vinImageUpdate:
 *   patch:
 *     tags: [Documents]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: documentId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: image
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *     responses:
 *       200:
 *         description: image update.
 *
 */

/**
 * @swagger
 * /api/vin/folderAdd:
 *   post:
 *     tags: [Documents]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: parentId
 *         in: formData
 *         type: string
 *         required: false
 *       - name: folderName
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: Add folder.
 *
 */

/**
 * @swagger
 * /api/vin/folderList:
 *   post:
 *     tags: [Documents]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: type
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *            ex tree,normal
 *       - name: pageLimit
 *         in: formData
 *         type: number
 *         required: true
 *         description:
 *       - name: page
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: Folder List.
 *
 */
/**
 * @swagger
 * /api/vin/folderUpdate:
 *   patch:
 *     tags: [Documents]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: folderId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *       - name: folderName
 *         in: formData
 *         type: string
 *         required: false
 *         description:
 *     responses:
 *       200:
 *         description: folder name update.
 *
 */
/**
 * @swagger
 * /api/vin/delete:
 *   delete:
 *     tags: [Documents]
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: vinId
 *         in: formData
 *         type: string
 *         required: true
 *         description:
 *     responses:
 *       200:
 *         description: Reciepts.
 *
 */