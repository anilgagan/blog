//set Global config
const dotenv = require("dotenv");
dotenv.config();

// Import logger
// var logger = require("./logger").logger;

//Generic basic auth Authorization header field parser for whatever.
var auth = require("basic-auth");

var compare = require("tsscmp");

const express = require("express");
const compression = require("compression");
const exphbs = require("express-handlebars");
const bodyParser = require("body-parser");
const morgan = require("morgan");
const logger = require("./config/logger");
const session = require("express-session");
const cookieParser = require("cookie-parser");
const path = require("path");
//const db = require('./config/database');
const cors = require("cors");
const helmet = require("helmet");
const errorHandler = require("errorhandler");
const app = express();

//for socket
const http = require("http").createServer(app);
const io = require("socket.io")({
  allowEIO3: true, // false by default
  cors: {
    origin: [
      "http://localhost:4200",
      "http://localhost:4300",
      "http://test.alqaryahcarsauction.com",
      "http://web.alqaryahcarsauction.com",
      "http://localhost:63499",
    ],
    methods: ["GET", "POST"],
    // allowedHeaders: ["my-custom-header"],
    credentials: true,
  },
}).listen(http);

const message = require("./config/message");
// Set Body data as Json
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
const mongoose = require("mongoose");
const mongodbUri = require("mongodb-uri");
const MongoStore = require("connect-mongodb-session")(session);
const config = require("./config");

const swaggerJsDoc = require("swagger-jsdoc");
const swaggerUI = require("swagger-ui-express");

app.use(morgan("tiny", { stream: logger.stream }));
//handle bodyParser.json() errors
app.use((err, req, res, next) => {
  if (err) {
    res.status(400).json({ status: false, message: message.invalidRequest });
  } else {
    next();
  }
});
// set server home directory
app.locals.rootDir = __dirname;

//Configure mongoose's promise to global promise
mongoose.promise = global.Promise;
const isProduction = process.env.NODE_ENV === "production";
app.use(cors({ origin: true }));
app.options("*", cors());
app.use(
  session({
    secret: "passport-validation",
    cookie: { maxAge: 6000000000000 },
    resave: false,
    saveUninitialized: false,
  })
);
if (!isProduction) {
  app.use(errorHandler());
}
app.enable("trust proxy");
app.use(helmet());
app.use(compression());
app.use(cookieParser("5TOCyfH3HuszKGzFZntk"));

app.use(function (req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header(
    "Access-Control-Allow-Headers",
    "Origin, X-Requested-With, Content-Type, Accept"
  );
  next();
});

app.use(
  session({
    resave: true,
    saveUninitialized: true,
    secret: "pAgGxo8Hzg7PFlv1HpO8Eg0Y6xtP7zYx",
    cookie: {
      path: "/",
      httpOnly: true,
      maxAge: 3600000 * 24,
    },
    store: "",
  })
);

//set static folder
app.use(express.static(path.join(__dirname, "public")));
app.use("/public/videos/", express.static(__dirname + "/public/videos"));
app.use("/public/temp/", express.static(__dirname + "/public/temp"));

app.use(
  "/public/thumbnails/",
  express.static(__dirname + "/public/thumbnails")
);

// set template engin
app.engine("handlebars", exphbs({ defaultLayout: "main" }));
app.set("view engine", "handlebars");

// const options = {
//   definition: {
//     openapi: "3.0.0",
//     info: {
//       title: "ACA-API",
//       version: "1.0.0",
//       description: "API Documentation",
//     },
//     servers: [
//       {
//         url: "http://test.alqaryahcarsauction.com/api",
//       },
//       {
//         url: "http://localhost:5000/api",
//       },
//     ],
//     components: {
//       securitySchemes: {
//         // jwt: {
//         //   type: "apiKey",
//         //   name: "x-access-token",
//         //   in: "header",
//         //   bearerFormat: "JWT",
//         // },
//                 // basicAuth: {
//                 //     type:   'http',
//                 //     scheme: 'basic'
//                 // }
//       },
//     },
//     security: [
//       {
//         jwt: [],
//       },
//     ],
//   },
//   apis: ["./swagger/*.js"],
// };

// const specs = swaggerJsDoc(options);
// app.use("/api-docs", swaggerUI.serve, swaggerUI.setup(specs));

// require('./routes/api')(app);

// Extended: https://swagger.io // swagger configuration
const swaggerOptions = {
  definition: {
    info: {
      title: "ACA Api Documentations",
      version: "1.0.0",
    },
    servers: [
      {
        url: "http://test.alqaryahcarsauction.com/api",
      },
      {
        url: "http://localhost:5000/api",
      },
    ],
  },
  apis: [
    "./modules/sap/index.js",
    "./modules/user/index.js",
    "./modules/account/index.js",
    "./modules/auction/index.js",
    "./modules/bid/apiRoute.js",
    "./modules/inventory/index.js",
    "./modules/reciept/index.js",
    "./modules/saleReciept/index.js",
    "./modules/vin/index.js",
    "./modules/upload/index.js",
    "./modules/master/index.js",
    "./modules/qwaiting/index.js",
    "./modules/order/index.js",
    "./routes/voucher.route.js",
    "./routes/analytics.route.js",
    "./routes/comment.route.js",
    "./routes/termscondition.route.js",
    "./routes/customInvoice.route.js",
  ], // files containing annotations as above
};

const swaggerDoc = swaggerJsDoc(swaggerOptions);
app.use("/api-docs", swaggerUI.serve, swaggerUI.setup(swaggerDoc));

app.get("/health", function (req, res) {
  res.writeHead(200, {
    "Content-Type": "text/html",
  });
  res.write("sucess");
  res.end();
});

//Load basic auth

const basicAuth = require("./middleware/basic-auth");
app.use(basicAuth.basicAuthentication);

/*
app.get('/', (req, res) => {
    res.send("Riyadh API's")
})*/

// Verify JWT token
const jwtToken = require("./middleware/jwt-auth");
const {
  noCounterOfferBidsCron,
  calculateLedgerClosingBalanceCron,
  calculateSellerStorageCron,
} = require("./crons/scheduler");
const logRequest = require("./middleware/logRequest");

//console.log("===================================After jwt auth");
app.use(jwtToken);

global.__basedir = __dirname;

// Call API Route
//app.use('/', require('./routes/api'))(app);
app.use(logRequest);
require("./routes/api")(app);
//set PORT

// Ran on all routes
app.use((req, res, next) => {
  res.setHeader("Cache-Control", "no-cache, no-store");
  res.setHeader("Connection", "close");
  next();
});

app.on("uncaughtException", (err) => {
  console.error(colors.red(err.stack));
  logger.error(err.stack);
  process.exit(2);
});

// mongoose.connect(
//   // config.connectionURL.mongoProduction,
//   process.env.MONGODB_WRITE_URI,
//   {
//     useNewUrlParser: true,
//     useUnifiedTopology: true,
//   },
//   function (err, db) {
//     if (err) {
//       throw new Error(err);
//     } else {
//       require('./config/database')
//       mongoose.set("debug", true);
//       global.defaultSettings = { language: "eng" };
//       console.log("DataBase conection established.");
//     }
//   }
// );

require("./config/database");

const PORT = process.env.PORT || 5000;
/// Initalizing app on the specific PORT
// http.listen(3000, () => console.log("listening on http://localhost:3000"));
// app
//   .listen(PORT, () => {
http
  .listen(PORT, () => {
    // require("./middleware/redisConnection").connect();
    // require('./userScript').init()
    logger.info(`Server started on port ${PORT}`);
    require("./modules/bid/index")(io);
  })
  //   Fix the Error EADDRINUSE
  .on("error", function (err) {
    process.once("SIGUSR2", function () {
      process.kill(process.pid, "SIGUSR2");
    });
    process.on("SIGINT", function () {
      // this is only called on ctrl+c, not restart
      process.kill(process.pid, "SIGINT");
    });
  });

// const { newAuctionUser, getIndividualAuctionUsers, getActiveUser } = require('./config/auctionUserHelper')

// io.on("connection", function(socket) {
//   console.log("socket connected "+socket.id);
//   socket.on('disconnect', () => {
//     console.log('user disconnected');
//   });
//   // io.emit("user connected");
//   socket.on("message", (msg)=> {
//    console.log("msg",msg);
//    io.emit('message', "hi washi");
//   });
//   socket.on('grabMsg', () => {
//     let ms = 'max'
//     io.emit("thatText",ms);
//   });

//   socket.on('joinAuction', (data) => {
//     const user = newAuctionUser(socket.id, data.userId, data.auctionId);

//     socket.join(user?.room);
//     // io.emit('bidHistory', "hi washi2 in room "+user.room);
//     //Send to everyone in the room except the sender
//     socket.broadcast.to(user.room).emit('bidHistory', 'New User has joined! in room '+user.room)
//     // Current active users and room name
//     io.to(user.room).emit('auctionUsers', {
//         auction_id: user.room,
//         users: getIndividualAuctionUsers(user.room),
//         onlineUsers: socket?.client?.conn?.server?.clientsCount,
//     });
// });

// socket.on('bidAction',(data)=>{
//   const user = getActiveUser(socket.id);
//   console.log(user?.room);
//   let bidMsg="Bid now "+data.bidAmount+ " by user "+data?.userId+" in room "+user?.room;
//   // io.emit('bidHistory', bidMsg);
//   //send to everyone in the room
//   io.to(user?.room).emit('bidHistory', bidMsg)
// })

//  });
//  process.env.TZ = "Asia/Calcutta";
//  //console.log("==========================================================",new Date().toString());

//  module.exports = { app, io };

// * SEEDERS
if (isProduction) {
  require("./seeders/smsToken.seeder");
}

// * CRONS
noCounterOfferBidsCron.start();
calculateLedgerClosingBalanceCron.start();
calculateSellerStorageCron.start();
