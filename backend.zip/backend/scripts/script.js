const { defaultSort } = require("../config");
const {
  isArrayWithLength,
  manipulateDate,
  daysPassedFromToday,
  makeObjectId,
  isNumberLessThanZero,
  formatDate,
} = require("../functions/global.functions");
const {
  Find,
  FindById,
  FindByIdAndUpdate,
  FindOne,
} = require("../models/factory");
const { Auctionvehicle } = require("../modules/auction/auctionModal");
const {
  Inventory,
  Sellermappingbranch,
  Carwisesellerplan,
  Getpass,
} = require("../modules/inventory/inventoryModal");
const { Sellerplan } = require("../modules/master/masterModal");
const { Reciept } = require("../modules/reciept/recieptModal");
const { Sellerservice } = require("../modules/saleReciept/saleRecieptModal");
const { User } = require("../modules/user/userModal");
const { log, error: _error } = console;

const ETL = async () => {
  throw new Error("DANGER!");

  try {
    let totalUpdated = 0;

    const filter = {
      referenceType: "reciept",
      direction: "out",
    };

    const projection = { referenceId: 1 };

    const gatePasses = await Find(Getpass, filter, projection);

    if (!isArrayWithLength(gatePasses)) {
      _error("NO GATE PASSES FOUND!");
      return;
    }

    log("TOTAL GATE PASSES ARE: ", gatePasses.length);

    for (const gatePass of gatePasses) {
      const { _id: gatePassId, referenceId } = gatePass;

      const projection = { transDate: 1 };
      const receipt = await FindById(Reciept, referenceId, projection);

      if (!receipt) {
        _error("NO RECEIPT FOUND!");
        continue;
      }

      const { transDate } = receipt;

      const trans = formatDate(transDate);
      const expiryDate = manipulateDate(trans, "add", 7);

      const gatePassExpiredDate = new Date(expiryDate);
      let parkedDays = daysPassedFromToday(gatePassExpiredDate);
      if (isNumberLessThanZero(parkedDays)) {
        parkedDays = 0;
      }

      const update = { gatePassExpiredDate, parkedDays };
      const project = { new: true };

      const updateGatePass = await FindByIdAndUpdate(
        Getpass,
        gatePassId,
        update,
        project
      );

      if (updateGatePass) {
        totalUpdated++;
      }
    }

    log("TOTAL GATE PASSES UPDATED ARE: ", totalUpdated);
  } catch (error) {
    _error("Error during ETL:", error);
    throw error;
  }
};

module.exports = ETL;
