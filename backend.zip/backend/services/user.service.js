const logger = require("../config/logger");
const { userRoles, userTypeStatus } = require("../config");
const {
  FindOne,
  FindByIdWithKey,
  FindById,
  Count,
} = require("../models/factory");
const { User } = require("../modules/user/userModal");
const { sendCombineMail } = require("./email.service");
const { sendCombineSMS, makeSmsNumber } = require("./sms.service");
const { createOTP } = require("./otp.service");

const {
  checkRequiredArguments,
  generateOTP,
} = require("../functions/global.functions");

const checkUniqueEmail = async (email) => {
  if (!checkRequiredArguments(email)) return;

  try {
    const filter = { email };
    const existingUser = await FindOne(User, filter);

    if (existingUser) {
      return {
        status: false,
        message: "You have already registered with this email, kindly login!",
      };
    }

    return { status: true };
  } catch (error) {
    logger.error(error);
  }
};

const matchPassword = async (email, phone, role, password) => {
  if (!checkRequiredArguments(password)) return;

  try {
    const filter = {};

    if (email) {
      filter.email = email;
    }

    if (phone && role) {
      const userType = userTypeStatus[role];

      filter.$and = [{ phone }, { userType: { $in: userType } }];
    }

    const projection = { email: 1, password: 1 };
    const user = await FindOne(User, filter, projection);

    if (!user) {
      return {
        status: false,
        message: "User not found!",
      };
    }

    const match = user.validPassword(password);

    if (!match) {
      return {
        status: false,
        message: "Incorrect password!",
      };
    }

    return { status: true };
  } catch (error) {
    logger.error(error);
  }
};

const checkUserWithPhoneAndRole = async (phone, userType) => {
  if (!checkRequiredArguments(phone, userType)) return;

  const userTypesFilter = {
    1: { phone, userType: 1 },
    2: { phone, userType: { $in: [2, 3] } },
    3: { phone, userType: { $in: [2, 3] } },
    4: { phone, userType: { $in: [4, 5] } },
    5: { phone, userType: { $in: [4, 5] } },
  };

  try {
    const existingUserType = await FindOne(User, userTypesFilter[userType]);

    if (existingUserType) {
      const role = userRoles[existingUserType.userType];
      return {
        status: false,
        message: `You have already registered as ${role} with this phone number!`,
      };
    }

    return { status: true };
  } catch (error) {
    logger.error(error);
    return {
      status: false,
      message: "An error occurred while checking for an existing user!",
    };
  }
};

const sendOTP = async (email, phone, mode) => {
  if (!checkRequiredArguments(email, phone, mode)) return;

  try {
    const otp = generateOTP(4);

    const otpData = { email, phone, otp };
    const otpDoc = await createOTP(otpData);

    if (!otpDoc) {
      logger.error("Failed to create OTP doc!");
      return;
    }

    sendCombineMail(email, otp, mode);
    await sendCombineSMS(phone, otp, mode);
  } catch (error) {
    logger.error(error.message);
  }
};

const sendEmailOTP = async (email, mode) => {
  if (!checkRequiredArguments(email, mode)) return;

  try {
    const otp = generateOTP(4);

    const otpData = { email, otp };
    const otpDoc = await createOTP(otpData);

    if (!otpDoc) {
      logger.error("Failed to create OTP doc!");
      return;
    }

    sendCombineMail(email, otp, mode);
  } catch (error) {
    logger.error(error.message);
  }
};

const sendSmsOTP = async (phone, mode) => {
  if (!checkRequiredArguments(phone, mode)) return;

  try {
    const otp = generateOTP(4);

    const otpData = { phone, otp };
    const otpDoc = await createOTP(otpData);

    if (!otpDoc) {
      logger.error("Failed to create OTP doc!");
      return;
    }

    await sendCombineSMS(phone, otp, mode);
  } catch (error) {
    logger.error(error.message);
  }
};

const checkEmailOrPhoneChange = async (previousUser, newUser, mode) => {
  if (!checkRequiredArguments(previousUser, newUser, mode)) return;

  try {
    const {
      email: previousEmail,
      phone: previousPhone,
      isEmailVerified,
      isPhoneVerified,
    } = previousUser;

    const { newEmail, newCountryCode, newPhone } = newUser;

    const isEmailChanged = previousEmail !== newEmail;
    const isPhoneChanged = previousPhone !== newPhone;

    // * check if first time verify || email||phone changed
    const shouldSendEmailOTP = !isEmailVerified || isEmailChanged;
    const shouldSendPhoneOTP = !isPhoneVerified || isPhoneChanged;

    if (shouldSendEmailOTP) {
      await sendEmailOTP(newEmail, mode);
    }

    if (shouldSendPhoneOTP) {
      const phone = makeSmsNumber(newCountryCode, newPhone);
      await sendSmsOTP(phone, mode);
    }
  } catch (error) {
    logger.error(error);
  }
};

const checkUserVerification = async (email, phone, role) => {
  try {
    const filter = {};

    if (email) {
      filter.email = email;
    }

    if (phone && role) {
      const userType = userTypeStatus[role];

      filter.$and = [{ phone }, { userType: { $in: userType } }];
    }

    const user = await FindOne(User, filter);

    if (!user) {
      logger.error("User not found!");
      return;
    }

    const { isEmailVerified, isPhoneVerified } = user;

    const isVerified = isEmailVerified || isPhoneVerified;

    if (!isVerified) {
      return {
        status: false,
        step: "otp",
        message: "Please complete your OTP verification!",
        user,
      };
    }

    return { status: true };
  } catch (error) {
    logger.error(error);
  }
};

const checkUserProfileCompletion = async (email, phone, role) => {
  try {
    const filter = {};

    if (email) {
      filter.email = email;
    }

    if (phone && role) {
      const userType = userTypeStatus[role];

      filter.$and = [{ phone }, { userType: { $in: userType } }];
    }

    const user = await FindOne(User, filter);

    if (!user) {
      logger.error("User not found!");
      return;
    }

    const { isProfileCompleted } = user;

    if (!isProfileCompleted) {
      return {
        status: false,
        step: "profile",
        message: "Please complete your profile!",
        user,
      };
    }

    return { status: true };
  } catch (error) {
    logger.error(error);
  }
};

const checkEmailOrPhoneValidation = async (user) => {
  if (!checkRequiredArguments(user)) return;

  const errors = {};

  try {
    const {
      userId,
      email: newEmail,
      phone: newPhone,
      countryCode: newCountryCode,
      userType: newUserType,
    } = user;

    if (newEmail) {
      const previousEmail = await FindByIdWithKey(User, userId, "email");

      if (!previousEmail) {
        logger.error("user not found!");
        return;
      }

      if (previousEmail !== newEmail) {
        const checkEmail = await checkUniqueEmail(newEmail);
        if (!checkEmail.status) errors.email = "Email already exists!";
      }
    }

    if (newPhone && newCountryCode && newUserType) {
      const projection = { phone: 1, countryCode: 1, userType: 1 };
      const previousUser = await FindById(User, userId, projection);

      if (!previousUser) {
        logger.error("user not found!");
        return;
      }

      const { phone: previousPhone, countryCode: previousCountryCode } =
        previousUser;

      const previousUserPhone = `${previousCountryCode}${previousPhone}`;
      const newUserPhone = `${newCountryCode}${newPhone}`;

      if (previousUserPhone !== newUserPhone) {
        const userPhoneWithType = await checkUserWithPhoneAndRole(
          newPhone,
          newUserType
        );
        if (!userPhoneWithType.status) errors.phone = "Phone already exists!";
      }
    }

    if (Object.keys(errors).length > 0) {
      return {
        status: false,
        errors,
      };
    }

    return { status: true };
  } catch (error) {
    logger.error(error.message);
  }
};

module.exports = {
  checkUniqueEmail,
  matchPassword,
  checkUserWithPhoneAndRole,
  sendOTP,
  sendEmailOTP,
  sendSmsOTP,
  checkEmailOrPhoneChange,
  checkUserVerification,
  checkUserProfileCompletion,
  checkEmailOrPhoneValidation,
};
