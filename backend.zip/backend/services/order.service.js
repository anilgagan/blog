const { log: info, error: _error } = console;
const logger = require("../config/logger");
const {
  checkRequiredArguments,
  makeObjectId,
  daysPassedFromToday,
  todayDate,
  ceilToDecimal,
  isArrayWithLength,
  manipulateDate,
} = require("../functions/global.functions");
const {
  Getpass,
  Inventory,
  Carwisesellerplan,
} = require("../modules/inventory/inventoryModal");
const { Reciept } = require("../modules/reciept/recieptModal");
const { Sellerservice } = require("../modules/saleReciept/saleRecieptModal");
const cmethod = require("../middleware/common-fun");
const { getInventoryStatus } = require("../helpers/inventory.helper");
const {
  FindById,
  FindOne,
  Find,
  FindByIdAndUpdate,
  FindOneAndUpdate,
  Create,
  Count,
} = require("../models/factory");
const { defaultSort } = require("../config");

const calculateBuyerDueAmount = async (buyerId) => {
  try {
    if (!checkRequiredArguments(buyerId)) return;

    const filter = { buyerId: makeObjectId(buyerId) };
    const pipeline = [
      {
        $match: filter,
      },
      {
        $group: {
          _id: "$buyerId",
          totalAmount: {
            $sum: "$totalAmount",
          },
          paidAmount: {
            $sum: "$paidAmount",
          },
        },
      },
      {
        $project: {
          _id: 0,
          dueAmount: {
            $round: [{ $subtract: ["$totalAmount", "$paidAmount"] }, 1],
          },
        },
      },
    ];

    const [{ dueAmount = 0 } = {}] = await Reciept.aggregate(pipeline);

    return dueAmount;
  } catch (error) {
    logger.error(error);
  }
};

const calculateSellerStorage = async () => {
  info("STARTING SELLER STORAGE CALCULATOR");

  try {
    const today = todayDate();

    const filter = {
      $and: [
        { gatePassExpired: { $lt: today } }, // * less than today
        { direction: "out" },
        { referenceType: "inventory" },
        {
          $or: [{ status: "pending" }, { status: "in warehouse" }],
        },
      ],
    };

    const gatePasses = await Getpass.find(filter);

    info("TOTAL GATE PASSES ARE:", gatePasses.length);

    if (!isArrayWithLength(gatePasses)) {
      logger.error("Gate passes not found!");
      return;
    }

    for (const gatePass of gatePasses) {
      await calculateStorage(gatePass);
    }

    info("EVERYTHING DONE!!!");
  } catch (error) {
    logger.error("Error in calculate-storage with: ", error);
  }
};

const calculateStorage = async (gatePass) => {
  const { _id: gatePassId, inventoryId, gatePassExpired, status } = gatePass;

  // #region // * INVENTORY
  const inventory = await FindById(Inventory, inventoryId);

  if (!inventory) {
    logger.error(`inventory (${inventoryId}) not found!`);
    return;
  }

  const { sellerId } = inventory;
  // #endregion

  // #region // * CAR WISE PLAN
  const cFilter = {
    inventoryId: makeObjectId(inventoryId),
    sellerId: makeObjectId(sellerId),
  };
  const carWisePlan = await FindOne(Carwisesellerplan, cFilter);

  if (!carWisePlan) {
    logger.error(
      `car wise seller plan should not be empty with inventoryId ${inventoryId} and sellerId ${sellerId}`
    );
    return;
  }

  const { storage: carWiseStorageFee = 0 } = carWisePlan;

  if (carWiseStorageFee === 0) return;
  // #endregion

  // #region // * SELLER SERVICE
  const Model = Sellerservice;

  const commonFilter = {
    sellerId: makeObjectId(sellerId),
    inventoryId: makeObjectId(inventoryId),
    serviceType: "storage",
    status: { $nin: ["pending", "process", "paid"] },
  };

  const pendingFilter = {
    ...commonFilter,
    status: "pending",
    gatePassStatus: "pending",
  };

  const processFilter = {
    ...commonFilter,
    status: "process",
    gatePassStatus: "pending",
  };

  const totalStorageServices = await Count(Model, commonFilter);

  const projection = { gatePassParkingDays: 1, gatePassExpiredDate: 1 };
  const pendingStorageService = await Find(
    Model,
    pendingFilter,
    projection,
    defaultSort
  );
  const processStorageService = await Find(
    Model,
    processFilter,
    projection,
    defaultSort
  );

  const expiredDate = new Date(gatePassExpired);
  const gatePassExpiredDate = daysPassedFromToday(expiredDate);

  const isPendingService =
    status === "pending" && pendingStorageService.length > 0;
  const isProcessService =
    ["pending", "in warehouse"].includes(status) &&
    processStorageService.length > 0;
  const isNewService = !totalStorageServices;

  if (isPendingService) {
    const [
      {
        gatePassParkingDays: parkingDays = 0,
        gatePassExpiredDate: expiredDate,
      } = {},
    ] = pendingStorageService;

    const daysPassed = daysPassedFromToday(expiredDate);
    const shouldUpdate = daysPassed - parkingDays > 0;

    if (shouldUpdate) {
      const serviceCharge = daysPassed * carWiseStorageFee;
      const vat = serviceCharge * (5 / 100);
      const vatAmount = ceilToDecimal(vat);
      const totalPayment = serviceCharge + vatAmount;

      const gUpdate = { parkingDays: gatePassExpiredDate, status: "pending" };
      await FindByIdAndUpdate(Getpass, gatePassId, gUpdate);

      const sFilter = {
        sellerId: makeObjectId(sellerId),
        inventoryId: makeObjectId(inventoryId),
        serviceType: "storage",
        status: "pending",
      };
      const sUpdate = {
        serviceCharge,
        vatAmount,
        totalPayment,
        gatePassParkingDays: daysPassed,
      };

      await FindOneAndUpdate(Sellerservice, sFilter, sUpdate, {}, defaultSort);
    }
  } else if (isProcessService) {
    const [
      {
        _id: processStorageId,
        gatePassParkingDays: parkingDays = 0,
        gatePassExpiredDate: expiredDate,
      } = {},
    ] = processStorageService;

    const daysPassed = daysPassedFromToday(expiredDate);
    const shouldUpdate = daysPassed - parkingDays > 0;

    if (shouldUpdate) {
      const actualDaysPassed = daysPassed - parkingDays;
      const serviceCharge = actualDaysPassed * carWiseStorageFee;
      const vat = serviceCharge * (5 / 100);
      const vatAmount = ceilToDecimal(vat);
      const totalPayment = serviceCharge + vatAmount;

      const saleOrderNo = await cmethod.getSaleOrderNo();
      const gatePassExpiryDate = manipulateDate(todayDate(), "subtract", 1); // * set previous date as expired

      const service = {
        saleOrderNo,
        sellerId,
        inventoryId,
        serviceType: "storage",
        serviceStatus: getInventoryStatus(inventory.inventoryStatus),
        serviceCharge,
        vatAmount,
        totalPayment,
        status: "pending",
        gatePassParkingDays: actualDaysPassed,
        gatePassExpiredDate: gatePassExpiryDate,
      };

      const gUpdate = { parkingDays: gatePassExpiredDate, status: "pending" };
      await FindByIdAndUpdate(Getpass, gatePassId, gUpdate);

      const sUpdate = { gatePassStatus: "process" };
      await FindByIdAndUpdate(Sellerservice, processStorageId, sUpdate);

      await Sellerservice.create(service);
    }
  } else if (isNewService) {
    const parkingDays = totalStorageServices; // * 0 first time
    const daysPassed = daysPassedFromToday(expiredDate);
    const shouldUpdate = daysPassed - parkingDays > 0;

    if (shouldUpdate) {
      const serviceCharge = daysPassed * carWiseStorageFee;
      const vat = serviceCharge * (5 / 100);
      const vatAmount = ceilToDecimal(vat);
      const totalPayment = serviceCharge + vatAmount;

      const saleOrderNo = await cmethod.getSaleOrderNo();

      const service = {
        saleOrderNo,
        sellerId,
        inventoryId,
        serviceType: "storage",
        serviceStatus: getInventoryStatus(inventory.inventoryStatus),
        serviceCharge,
        vatAmount,
        totalPayment,
        status: "pending",
        gatePassParkingDays: daysPassed,
        gatePassExpiredDate: expiredDate,
      };

      const gUpdate = { parkingDays: gatePassExpiredDate, status: "pending" };
      await FindByIdAndUpdate(Getpass, gatePassId, gUpdate);
      await Create(Sellerservice, service);
    }
  }
  // #endregion
};

module.exports = {
  calculateBuyerDueAmount,
  calculateSellerStorage,
};
