const sgMail = require("@sendgrid/mail");
const config = require("../config");
const logger = require("../config/logger");
const { modes } = config.email;

const {
  checkRequiredArguments,
  isValidEmail,
} = require("../functions/global.functions");

const sendEmail = (email, message) => {
  sgMail.setApiKey(config.email.SENDGRID_KEY);

  const msg = {
    to: email.to,
    from: email.from || config.email.SENDER,
    subject: email.subject,
    html: "<strong>" + email.body + "</strong>",
  };

  sgMail.send(msg);
  logger.info(message);
};

const sendEmailTemplate = (email) => {
  sgMail.setApiKey(config.email.SENDGRID_KEY);

  sgMail
    .send(email)
    .then((result) => {
      console.log("success" + JSON.stringify(result));
    })
    .catch((err) => {
      console.log("error" + err);
    });
};

const sendCombineMail = (email, otp, mode) => {
  if (!checkRequiredArguments(email, otp, mode)) return;

  try {
    const isEmailValid = isValidEmail(email);
    if (!isEmailValid) {
      logger.info(`Email (${email}) is not valid!`);
      return;
    }

    if (!modes[mode]) {
      logger.error(`Email template (${mode}) is not valid!`);
      return;
    }

    const { subject, body, message } = modes[mode](otp, email);

    const mail = {
      to: email,
      subject,
      body,
    };

    sendEmail(mail, message);
  } catch (error) {
    logger.error(error.message);
  }
};

module.exports = {
  sendEmail,
  sendEmailTemplate,
  sendCombineMail,
};
