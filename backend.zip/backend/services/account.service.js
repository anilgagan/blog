const FNS = require("date-fns");
const { error: _error } = console;
const logger = require("../config/logger");
const { markAccountIds, defaultSort } = require("../config");
const {
  makeObjectId,
  checkRequiredArguments,
  findAndJoinByKey,
  joinWithSymbol,
  getValuesByKey,
  todayDate,
  isArrayWithLength,
  createNewMongoDoc,
  removeFieldsFromObject,
  findByKeyValue,
  checkBoolean,
} = require("../functions/global.functions");
const {
  Accountmaster,
  Accountledger,
  Accountledgertemp,
} = require("../modules/account/accountModal");
const { SellerPayable } = require("../modules/saleReciept/saleRecieptModal");
const {
  updateGatePassOnPayment,
  updateSellerServiceAndSellerReceiptByPayableNo,
  updateInventoryPaymentCleared,
  sellerSaleEntries,
  updateGatePassBySellerPayableNo,
  addSellerPayable,
  updateSellerPayable,
} = require("./sellerReceipt.service");
const { Closing, CustomInvoice } = require("../models");
const {
  FindById,
  FindByIdAndUpdate,
  Create,
  Aggregate,
  FindOneAndUpdate,
  FindByIdWithKey,
} = require("../models/factory");
const { updateCommonLog } = require("./comment.service");
const { Reciept, Salesreturn } = require("../modules/reciept/recieptModal");
const { Inventory, Getpass } = require("../modules/inventory/inventoryModal");
const { User, Commentlog } = require("../modules/user/userModal");
const {
  Lookup,
  Unwind,
  ExactMatch,
  Project,
} = require("../functions/mongoose.functions");
const common = require("../middleware/common-fun");

const createAccountLedger = async ({
  markAccountId,
  glAccountId,
  branchId = "",
  voucherNo,
  transactionType,
  paymentType = "",
  payAmount,
  description = "",
  referenceType = "",
  referenceNo = "",
  referenceNo2 = "",
  sellerNo = "",
  buyerNo = "",
  createdBy = "system",
  transDate = new Date(),
  closingStatus = "",
  addedFrom = "",
  transactionOf = "",
}) => {
  try {
    let accountMasterId = glAccountId;

    if (markAccountId) {
      const accountMaster = await Accountmaster.findOne(
        { markAccountId },
        {
          markAccountId: 1,
        }
      ).sort({ createdAt: -1 });

      if (!accountMaster) throw new Error("markAccountId not found!");

      ({ _id: accountMasterId } = accountMaster);
    }

    const accountLedger = {
      voucherNo,
      branchId: makeObjectId(branchId),
      glAccountId: makeObjectId(accountMasterId),
      transactionType,
      paymentType,
      payAmount: Number(payAmount),
      description,
      referenceType,
      referenceNo,
      referenceNo2,
      transDate,
      sellerNo,
      buyerNo,
      createdBy,
      transDate,
      closingStatus,
      addedFrom,
      transactionOf,
    };

    return await Accountledger.create(accountLedger);
  } catch (error) {
    _error(error);
  }
};

const getGLByPaymentMethod = async (paymentType, branchId) => {
  try {
    if (!checkRequiredArguments(paymentType)) return;

    const accountType = markAccountIds[paymentType];

    let filter = {};
    const projection = { _id: 1 };

    if (Array.isArray(accountType)) {
      filter = {
        markAccountId: { $in: accountType },
        branchId: makeObjectId(branchId),
      };
    } else {
      filter = { markAccountId: accountType };
    }

    const glAccount = await Accountmaster.findOne(filter, projection).sort(
      defaultSort
    );

    if (!glAccount) {
      logger.error("markAccountId not found!");
      return;
    }

    const { _id: glAccountId } = glAccount;

    return glAccountId;
  } catch (error) {
    logger.error(error);
  }
};

const updateTempGLSpecialCaseAR = async (body) => {
  try {
    if (!checkRequiredArguments(body)) return;

    const {
      glId,
      isAR,
      voucherNo: voucherNO,
      branchId: branchID,
      transactionFee = 0,
      payAmount,
      createdBy = "system",
      ...rest
    } = body;

    // #region - // * UPDATE BOTH TEMP LEDGER ENTRIES
    const { paymentType, status } = rest;
    const commonFilter = { voucherNo: voucherNO };

    // * Update Temp Account Ledger Both Entries
    await Accountledgertemp.updateMany(commonFilter, rest);
    // #endregion

    // #region // * REJECT CASE
    if (status !== "paid") {
      const accountLedgerTemp = await FindById(Accountledgertemp, glId);

      if (!accountLedgerTemp) {
        logger.error("account ledger temp doc not found!");
        return true;
      }

      const { referenceId, referenceNo: payableNo } = accountLedgerTemp;

      await updateSellerServiceAndSellerReceiptByPayableNo(payableNo, status); // * status: rejected

      // * log hierarchy
      await updateCommonLog({
        action: "Rejected",
        from: "Payment(IP)",
        id: referenceId,
        no: payableNo,
        by: createdBy,
      });

      return true;
    }
    // #endregion

    // #region // * TRANSACTION-FEE
    const accountId = await getGLByPaymentMethod(paymentType, branchID);

    let totalPayAmount = payAmount;

    if (paymentType === "card") totalPayAmount += transactionFee;
    // #endregion

    // #region // * UPDATE TEMP LEDGER DR ENTRY
    const id = makeObjectId(glId);
    const drUpdate = {
      $set: { glAccountId: accountId, payAmount: totalPayAmount },
    };
    const projection = { new: true };
    const accountLedgerTemp = await Accountledgertemp.findByIdAndUpdate(
      id,
      drUpdate,
      projection
    );

    if (!accountLedgerTemp) {
      logger.error("Failed to find and update temp account ledger");
      return;
    }

    const {
      branchId,
      voucherNo,
      referenceNo: payableNo,
      payableType,
      glAccountId,
      description,
      referenceType,
      referenceId,
      referenceNo,
      referenceNo2,
      sellerNo,
      transDate,
      transactionOf,
      paymentType: paymentMethod,
      transDate: transactionDate,
    } = accountLedgerTemp;
    // #endregion

    // #region - // * UPDATE SELLER PAYABLE
    const filter = { payableNo, balanceType: payableType };
    const update = {
      glAccountId,
      paymentMethod,
      transactionDate,
      netPayBalance: totalPayAmount,
    };

    const sellerDoc = await SellerPayable.findOneAndUpdate(
      filter,
      update,
      projection
    );
    // #endregion

    // #region - // * LEDGER ENTRIES
    const aFilter = { voucherNo };
    const accountLedgerTemps = await Accountledgertemp.find(aFilter);

    const ledgerVoucherNo = await common.getVoucherNo();

    for (const temp of accountLedgerTemps) {
      const tempObj = {
        voucherNo: ledgerVoucherNo,
        branchId: temp?.branchId,
        glAccountId: temp?.glAccountId,
        transactionType: temp?.transactionType,
        paymentType: temp?.paymentType,
        payAmount:
          temp.transactionType === "dr" ? totalPayAmount : temp?.payAmount,
        description: temp?.description,
        referenceType: temp?.referenceType || "",
        referenceNo: temp?.referenceNo,
        referenceNo2: temp?.referenceNo2 || "",
        transDate: temp?.transDate,
        createdBy: temp?.createdBy,
        closingStatus: temp?.closingStatus,
        addedFrom: temp?.addedFrom,
        sellerNo: temp?.sellerNo,
        transactionOf: temp?.transactionOf,
      };

      await createAccountLedger(tempObj);
    }

    if (paymentType === "card") {
      const transactionAccountId = await getGLByPaymentMethod(
        "transaction-fee"
      );

      const transactionObj = {
        voucherNo: ledgerVoucherNo,
        branchId: makeObjectId(branchId),
        glAccountId: makeObjectId(transactionAccountId),
        transactionType: "cr",
        paymentType: paymentMethod,
        payAmount: transactionFee,
        description,
        referenceType,
        referenceNo,
        referenceNo2,
        sellerNo,
        transDate,
        transactionOf,
      };

      await createAccountLedger(transactionObj);
    }
    // #endregion

    // * Sale Ledger Entries
    await sellerSaleEntries(
      payableNo,
      ledgerVoucherNo,
      paymentMethod,
      getGLByPaymentMethod,
      createAccountLedger
    );

    const {
      inventoryId: [inventoryId] = [],
      sellerId,
      sellerServiceOrderNumbers,
    } = sellerDoc;

    // * Update Seller Receipt & Seller Services Status
    await updateSellerServiceAndSellerReceiptByPayableNo(payableNo, status);

    // * Update Gate pass
    await updateGatePassOnPayment(
      inventoryId,
      sellerId,
      sellerServiceOrderNumbers
    );

    // * Update Inventory Payment Status
    await updateInventoryPaymentCleared(inventoryId);

    // * log hierarchy
    await updateCommonLog({
      action: "Paid",
      from: "Payment(IP)",
      id: referenceId,
      no: referenceNo,
      by: createdBy,
    });

    return accountLedgerTemp;
  } catch (error) {
    logger.error(error);
  }
};

const updateTempGLCustomInvoice = async (body) => {
  try {
    if (!body) return;

    const {
      glId,
      isCustomInvoice,
      voucherNo: voucherNO,
      branchId: branchID,
      transactionFee = 0,
      payAmount,
      createdBy = "system",
      ...rest
    } = body;

    const { paymentType, status } = rest;
    const commonFilter = { voucherNo: voucherNO };

    // * Update Temp Account Ledger Both Entries
    await Accountledgertemp.updateMany(commonFilter, rest);

    if (status !== "paid") {
      const accountLedgerTemp = await FindById(Accountledgertemp, glId);

      if (!accountLedgerTemp) {
        logger.error("Custom invoice not found!");
        return true;
      }

      const { referenceId: customInvoiceId, referenceNo: invoiceNo } =
        accountLedgerTemp;

      const update = { status };
      await FindByIdAndUpdate(CustomInvoice, customInvoiceId, update);

      // * log hierarchy
      await updateCommonLog({
        action: "Rejected",
        from: "Payment(IP)",
        id: customInvoiceId,
        no: invoiceNo,
        by: createdBy,
      });

      return true;
    }

    const accountId = await getGLByPaymentMethod(paymentType, branchID);

    let totalPayAmount = payAmount;

    if (paymentType === "card") totalPayAmount += transactionFee;

    // * Update Temp Account Ledger DR Entry
    const id = makeObjectId(glId);
    const drUpdate = {
      $set: { glAccountId: accountId, payAmount: totalPayAmount },
    };
    const projection = { new: true };
    const accountLedgerTemp = await Accountledgertemp.findByIdAndUpdate(
      id,
      drUpdate,
      projection
    );

    if (!accountLedgerTemp) {
      logger.error("Failed to find and update temp account ledger");
      return;
    }

    const {
      branchId,
      voucherNo,
      description,
      referenceType,
      referenceId,
      referenceNo,
      referenceNo2,
      buyerNo,
      transDate,
      transactionOf,
      paymentType: paymentMethod,
    } = accountLedgerTemp;

    // * Ledger Entries
    const aFilter = { voucherNo };
    const accountLedgerTemps = await Accountledgertemp.find(aFilter);

    const ledgerVoucherNo = await common.getVoucherNo();

    for (const temp of accountLedgerTemps) {
      const tempObj = {
        voucherNo: ledgerVoucherNo,
        branchId: temp?.branchId,
        glAccountId: temp?.glAccountId,
        transactionType: temp?.transactionType,
        paymentType: temp?.paymentType,
        payAmount:
          temp.transactionType === "dr" ? totalPayAmount : temp?.payAmount,
        description: temp?.description,
        referenceType: temp?.referenceType || "",
        referenceNo: temp?.referenceNo,
        referenceNo2: temp?.referenceNo2 || "",
        transDate: temp?.transDate,
        createdBy: temp?.createdBy,
        closingStatus: temp?.closingStatus,
        addedFrom: temp?.addedFrom,
        buyerNo: temp?.buyerNo,
        transactionOf: temp?.transactionOf,
      };

      await createAccountLedger(tempObj);
    }

    if (paymentType === "card") {
      const transactionAccountId = await getGLByPaymentMethod(
        "transaction-fee"
      );

      const transactionObj = {
        voucherNo: ledgerVoucherNo,
        branchId: makeObjectId(branchId),
        glAccountId: makeObjectId(transactionAccountId),
        transactionType: "cr",
        paymentType: paymentMethod,
        payAmount: transactionFee,
        description,
        referenceType,
        referenceNo,
        referenceNo2,
        buyerNo,
        transDate,
        transactionOf,
      };

      await createAccountLedger(transactionObj);
    }

    // * log hierarchy
    await updateCommonLog({
      action: "Paid",
      from: "Payment(IP)",
      id: referenceId,
      no: referenceNo,
      by: createdBy,
    });

    const update = { status: "paid" };
    await FindByIdAndUpdate(CustomInvoice, referenceId, update);

    return accountLedgerTemp;
  } catch (error) {
    logger.error(error);
  }
};

const calculateClosingBalance = async (entity) => {
  try {
    if (!checkRequiredArguments(entity)) return;

    logger.info("STARTING ACCOUNT LEDGER BALANCE CALCULATOR!!!");

    const today = new Date();
    const yesterday = FNS.subDays(today, 1);
    const date = FNS.format(yesterday, "yyyy-MM-dd");

    yesterday.setHours(0, 0, 0, 0);

    const startOfYesterday = FNS.startOfDay(yesterday); // * start of yesterday (12:00 AM)
    const endOfYesterday = FNS.endOfDay(yesterday); // * end of yesterday (11:59:59.999 PM)

    const entityType = `${entity}No`;

    const filter = {
      transactionOf: entity,
      [entityType]: { $exists: true, $nin: [null, ""] },
      transactionType: { $in: ["cr", "dr"] },
      transDate: {
        $gte: startOfYesterday,
        $lt: endOfYesterday,
      },
    };

    // * calculate opening balances for all sellers
    const openingBalances = {};
    const previousDayClosingBalances = await Closing.find(
      { date: yesterday },
      { type: 1, closingBalance: 1, _id: 0 }
    );

    previousDayClosingBalances.forEach((balance) => {
      openingBalances[balance.type] = balance.closingBalance;
    });

    // * calculate closing balances for all sellers separately
    const totalBalance = await Accountledger.aggregate([
      {
        $match: filter,
      },
      {
        $group: {
          _id: `$${entityType}`,
          crTotal: {
            $sum: {
              $cond: [{ $eq: ["$transactionType", "cr"] }, "$payAmount", 0],
            },
          },
          drTotal: {
            $sum: {
              $cond: [{ $eq: ["$transactionType", "dr"] }, "$payAmount", 0],
            },
          },
        },
      },
    ]);

    for (const result of totalBalance) {
      const { _id: typeId, crTotal, drTotal } = result;
      const openingBalance = openingBalances[typeId] || 0;
      const closingBalance = openingBalance + drTotal - crTotal;

      // * save the daily balance summary for each seller
      const dailyBalance = new Closing({
        type: entity,
        typeId,
        date,
        openingBalance,
        closingBalance,
      });

      await dailyBalance.save();
    }

    logger.info("FINISHED CALCULATING CLOSING BALANCE!!!");
  } catch (error) {
    logger.error(error);
  }
};

const getEntityBalance = async (type, typeId) => {
  try {
    if (!checkRequiredArguments(type, typeId)) return;

    const filter = { type, typeId };
    const getBalance = await Closing.findOne(filter).sort(defaultSort);

    if (!getBalance) return;

    return ({ openingBalance, closingBalance } = getBalance);
  } catch (error) {
    logger.error(error);
  }
};

const approveSecurityDeposit = async (data) => {
  if (!checkRequiredArguments(data)) return;

  try {
    const {
      _id: outgoingCashId,
      branchId,
      referenceId,
      paymentMethod,
      amount,
      voucherNo,
      transDate,
      comments,
      createdBy,
    } = data;

    const update = { securityClaim: 1 };
    const receipt = await FindByIdAndUpdate(Reciept, referenceId, update);

    const { inventoryId, buyerId } = receipt;

    const iFilter = { _id: makeObjectId(inventoryId) };
    const inventories = await Inventory.find(iFilter, { vin: 1 });

    const vin = findAndJoinByKey(inventories, "vin");
    const buyerNo = await FindByIdWithKey(User, buyerId, "uniqueIdentifier");
    const info = joinWithSymbol(", ", vin, buyerNo, voucherNo);
    const comment = comments ? `${comments} - ` : "";
    const description = `SECURITY DEPOSIT RETURN - ${comment}${info}`;

    const vinNo = getValuesByKey(inventories, "vin", "single");

    // * Account Ledger Temp Entries
    const filter = { markAccountId: "cash-in-hand" };
    const option = { markAccountId: 1 };
    const glAccountData = await Accountmaster.findOne(filter, option).sort(
      defaultSort
    );

    const voucherNoUnique = await common.getempGlNo();

    const accountLedgerCR = {
      branchId,
      voucherNo: voucherNoUnique,
      glAccountId: glAccountData?._id,
      transactionType: "cr",
      paymentType: paymentMethod || "",
      payAmount: amount,
      description,
      referenceType: "outgoing security claim",
      referenceId: outgoingCashId,
      referenceNo: voucherNo,
      referenceNo2: vinNo,
      balanceAmount: amount,
      createdBy: "system",
      transDate: transDate || todayDate(),
      addedFrom: "op",
      createdFrom: "Outgoing Cash List",
      status: "approved",
      buyerNo,
      transactionOf: "buyer",
    };

    await Accountledgertemp.create(accountLedgerCR);

    const accountLedgerDR = {
      branchId,
      voucherNo: voucherNoUnique,
      glAccountId: glAccountData?._id,
      transactionType: "dr",
      paymentType: paymentMethod || "",
      payAmount: amount,
      description,
      referenceType: "outgoing security claim",
      referenceId: outgoingCashId,
      referenceNo: voucherNo,
      referenceNo2: vinNo,
      balanceAmount: amount,
      createdBy: "system",
      transDate: transDate || todayDate(),
      addedFrom: "op",
      createdFrom: "Outgoing Cash List",
      status: "approved",
      buyerNo,
      transactionOf: "buyer",
    };

    await Accountledgertemp.create(accountLedgerDR);

    // * log hierarchy
    await updateCommonLog({
      action: "Approved",
      from: "Account(SD Approval)",
      id: outgoingCashId,
      no: voucherNo,
      by: createdBy,
    });
  } catch (error) {
    logger.error(error);
  }
};

const rejectSecurityDeposit = async (data) => {
  if (!checkRequiredArguments(data)) return;

  try {
    const { _id: outgoingCashId, voucherNo, createdBy } = data;

    await updateCommonLog({
      action: "Rejected",
      from: "Account(SD Approval)",
      id: outgoingCashId,
      no: voucherNo,
      by: createdBy,
    });
  } catch (error) {
    logger.error(error);
  }
};

const approveZeroRatedSecurityDeposit = async (data) => {
  if (!checkRequiredArguments(data)) return;

  try {
    const {
      _id: outgoingCashId,
      referenceId: receiptId,
      referenceNo,
      paymentMethod,
      amount,
      voucherNo,
      transDate,
      comments,
      createdBy,
    } = data;

    // #region - // * GET RECEIPT
    const receipt = await FindById(Reciept, receiptId);

    if (!receipt) {
      logger.error("receipt not found!");
      return;
    }

    const {
      recieptNo: receiptNo,
      branchId,
      paidAmount,
      zeroRatedExportCountry,
    } = receipt;
    //#endregion

    // #region - // * CREATE SALES RETURN
    const salesReturnNo = await common.getSalesReturnNo();
    const returnData = {
      salesReturnNo,
      branchId,
      recieptId: receiptId,
      returnAmount: 0,
      type: "return",
      otherIncome: paidAmount,
      status: "approved",
      refundStatus: "no",
      createdBy,
      transDate: todayDate(),
    };
    const salesReturn = await Create(Salesreturn, returnData);

    if (!salesReturn) {
      logger.error("failed to create and approve sales return!");
      return;
    }

    await updateCommonLog({
      action: "Created",
      from: "Sales(Sales Return)",
      id: receiptId,
      no: referenceNo,
      by: createdBy,
    });

    const { transDate: saleReturnTransDate } = salesReturn;
    // #endregion

    // #region - // * REVERSE LEDGER ENTRIES
    const pipeline = [];
    const reverseLedgerArr = [];
    const cashBankEntries = [];
    const reverseEntriesWithoutCashInHand = [];

    // * accountMaster
    Lookup(pipeline, "accountmasters", "glAccountId", "_id", "accountMaster");
    Unwind(pipeline, "$accountMaster");

    // * match
    ExactMatch(pipeline, "referenceNo", receiptNo);

    // * project
    const project = {
      branchId: 1,
      voucherNo: 1,
      glAccountId: 1,
      transactionType: 1,
      paymentType: 1,
      payAmount: 1,
      description: 1,
      referenceType: 1,
      referenceNo: 1,
      referenceNo2: 1,
      balanceAmount: 1,
      createdBy: 1,
      closingStatus: 1,
      transDate: 1,
      buyerNo: 1,
      sellerNo: 1,
      transactionOf: 1,
      markAccountId: "$accountMaster.markAccountId",
      accountName: "$accountMaster.accountName",
    };
    Project(pipeline, project);

    // * ledgers
    const ledgers = await Aggregate(Accountledger, pipeline);

    if (!isArrayWithLength(ledgers)) {
      logger.error("no ledger data found!");
      return;
    }

    const voucherNoUnique = await common.getVoucherNo();

    for (let i = 0; i < ledgers.length; i++) {
      const transactionType =
        ledgers[i]?.transactionType === "cr" ? "dr" : "cr";

      const excludedAccounts = [
        "cash-in-bank",
        "cash-in-bank-sajja",
        "cash-in-bank-ind",
        "cash-in-bank-sharj",
        "transaction-fee",
        "cash-in-hand",
      ];

      if (excludedAccounts.includes(ledgers[i]?.markAccountId)) {
        const glAccountId = ledgers[i]?.glAccountId;

        cashBankEntries.push({
          branchId: ledgers[i]?.branchId,
          voucherNo: voucherNoUnique,
          glAccountId: glAccountId,
          transactionType: transactionType,
          paymentType: ledgers[i]?.paymentType,
          payAmount: ledgers[i]?.payAmount,
          description: ledgers[i]?.description ? ledgers[i]?.description : "",
          referenceType: ledgers[i]?.referenceType,
          referenceNo: ledgers[i]?.referenceNo,
          referenceNo2: ledgers[i]?.referenceNo2,
          balanceAmount: ledgers[i]?.balanceAmount,
          createdBy: ledgers[i]?.createdBy,
          closingStatus: 0,
          transDate: saleReturnTransDate || null,
          buyerNo: ledgers[i]?.buyerNo,
          sellerNo: ledgers[i]?.sellerNo,
          transactionOf: ledgers[i]?.transactionOf,
        });
      } else {
        const glAccountId = ledgers[i]?.glAccountId;

        reverseEntriesWithoutCashInHand.push({
          branchId: ledgers[i]?.branchId,
          voucherNo: voucherNoUnique,
          glAccountId: glAccountId,
          transactionType: transactionType,
          paymentType: ledgers[i]?.paymentType,
          payAmount: ledgers[i]?.payAmount,
          description: ledgers[i]?.description ? ledgers[i]?.description : "",
          referenceType: ledgers[i]?.referenceType,
          referenceNo: ledgers[i]?.referenceNo,
          referenceNo2: ledgers[i]?.referenceNo2,
          balanceAmount: ledgers[i]?.balanceAmount,
          createdBy: ledgers[i]?.createdBy,
          closingStatus: 0,
          transDate: saleReturnTransDate || null,
          buyerNo: ledgers[i]?.buyerNo,
          sellerNo: ledgers[i]?.sellerNo,
          transactionOf: ledgers[i]?.transactionOf,
        });
      }
    }

    // * combining excludedAccounts entries into one
    const groupedCashBankEntries =
      cashBankEntries.reduce((amount, curr, index, arr) => {
        const totalAmount = amount + curr.payAmount;

        if (index === arr.length - 1) {
          const lastEntry = {
            ...curr,
            payAmount: totalAmount,
          };

          return Object.keys(lastEntry).length > 0 ? [lastEntry] : [];
        }

        return totalAmount;
      }, 0) || [];

    reverseLedgerArr.push(
      ...reverseEntriesWithoutCashInHand,
      ...groupedCashBankEntries
    );

    if (isArrayWithLength(reverseLedgerArr)) {
      await Accountledger.insertMany(reverseLedgerArr);
    }
    // #endregion

    // #region - // * RECEIPT CLONE
    let receiptReplica = createNewMongoDoc(receipt);
    receiptReplica = removeFieldsFromObject(
      receiptReplica,
      "isZeroRated",
      "zeroRatedExportCountry"
    );

    const newReceiptNo = await common.getRecieptNo();

    receiptReplica.recieptNo = newReceiptNo;
    receiptReplica.securityClaim = 1;
    receiptReplica.export = true;
    receiptReplica.exportCountry = zeroRatedExportCountry;

    const newReceipt = await Create(Reciept, receiptReplica);

    if (!newReceipt) {
      logger.error("Unable to create receipt!");
      return;
    }

    const { _id: newReceiptId, inventoryId, buyerId } = newReceipt;
    // #endregion

    // #region - // * CHANGING LOG HIERARCHY
    const cFilter = {
      referenceName: referenceNo,
      referenceId: receiptId,
    };
    const cUpdate = {
      referenceName: voucherNo,
      referenceId: outgoingCashId,
    };

    await FindOneAndUpdate(Commentlog, cFilter, cUpdate);

    await updateCommonLog({
      action: "Created",
      from: "Sales(Receipt)",
      id: outgoingCashId,
      no: voucherNo,
      by: createdBy,
    });
    // #endregion

    // #region - // * NEW RECEIPT LEDGER ENTRIES
    const salesAccountId = await getGLByPaymentMethod("sales");
    const vatAccountId = await getGLByPaymentMethod("vat");

    const salesObj = findByKeyValue(
      reverseEntriesWithoutCashInHand,
      "glAccountId",
      salesAccountId
    );
    const vatObj = findByKeyValue(
      reverseEntriesWithoutCashInHand,
      "glAccountId",
      vatAccountId
    );

    const newReceiptPaymentLedgerEntries = groupedCashBankEntries.flatMap(
      (item) => [
        { ...item, transactionType: "dr", referenceNo: newReceiptNo },
        {
          ...salesObj,
          transactionType: "cr",
          referenceNo: newReceiptNo,
        },
        {
          ...vatObj,
          transactionType: "cr",
          referenceNo: newReceiptNo,
        },
      ]
    );

    if (isArrayWithLength(newReceiptPaymentLedgerEntries)) {
      await Accountledger.insertMany(newReceiptPaymentLedgerEntries);
    }
    // #endregion

    // #region - // * RECEIPT RELATED ENTITIES UPDATE
    const filter = {
      direction: "out",
      referenceType: "reciept",
      referenceNo: receiptNo,
      referenceId: makeObjectId(receiptId),
    };
    const update = { referenceNo: newReceiptNo, referenceId: newReceiptId };
    const projection = { new: true };
    const updateGatePass = await FindOneAndUpdate(
      Getpass,
      filter,
      update,
      projection
    );

    if (!updateGatePass) {
      logger.error("Unable to update gate pass with new receipt reference!");
      return;
    }
    // #endregion

    // #region - // * OP PAYMENT
    const iFilter = { _id: makeObjectId(inventoryId) };
    const inventories = await Inventory.find(iFilter, { vin: 1 });
    const vin = findAndJoinByKey(inventories, "vin");
    const buyerNo = await FindByIdWithKey(User, buyerId, "uniqueIdentifier");
    const info = joinWithSymbol(", ", vin, buyerNo, voucherNo);
    const comment = comments ? `${comments} - ` : "";
    const description = `SECURITY DEPOSIT RETURN - ${comment}${info}`;
    const vinNo = getValuesByKey(inventories, "vin", "single");

    // * Account Ledger Temp Entries
    const aFilter = { markAccountId: "cash-in-hand" };
    const option = { markAccountId: 1 };
    const glAccountData = await Accountmaster.findOne(aFilter, option).sort(
      defaultSort
    );

    const voucherNO = await common.getempGlNo();

    const accountLedgerCR = {
      branchId,
      voucherNo: voucherNO,
      glAccountId: glAccountData?._id,
      transactionType: "cr",
      paymentType: paymentMethod || "",
      payAmount: amount,
      description,
      referenceType: "outgoing security claim",
      referenceId: outgoingCashId,
      referenceNo: voucherNo,
      referenceNo2: vinNo,
      balanceAmount: amount,
      createdBy: "system",
      transDate: transDate || todayDate(),
      addedFrom: "op",
      createdFrom: "Outgoing Cash List",
      status: "approved",
      buyerNo,
      transactionOf: "buyer",
    };

    await Accountledgertemp.create(accountLedgerCR);

    const accountLedgerDR = {
      branchId,
      voucherNo: voucherNO,
      glAccountId: glAccountData?._id,
      transactionType: "dr",
      paymentType: paymentMethod || "",
      payAmount: amount,
      description,
      referenceType: "outgoing security claim",
      referenceId: outgoingCashId,
      referenceNo: voucherNo,
      referenceNo2: vinNo,
      balanceAmount: amount,
      createdBy: "system",
      transDate: transDate || todayDate(),
      addedFrom: "op",
      createdFrom: "Outgoing Cash List",
      status: "approved",
      buyerNo,
      transactionOf: "buyer",
    };

    await Accountledgertemp.create(accountLedgerDR);
    // #endregion

    // #region - // * UPDATE OLD RECEIPT CANCELLED
    const rUpdate = { invoiceStatus: "cancelled", recieptType: "cancelled" };
    await FindByIdAndUpdate(Reciept, receiptId, rUpdate);
    // #endregion
  } catch (error) {
    logger.error(error);
  }
};

const rejectZeroRatedSecurityDeposit = async (data) => {
  if (!checkRequiredArguments(data)) return;

  try {
    const { referenceId, referenceNo, createdBy } = data;

    await updateCommonLog({
      action: "Rejected",
      from: "Account(SD Approval)",
      id: referenceId,
      no: referenceNo,
      by: createdBy,
    });
  } catch (error) {
    logger.error(error);
  }
};

const updateIncomingOutgoingPayment = async (data) => {
  if (!checkRequiredArguments(data)) return;

  const {
    isAR,
    isCustomInvoice,
    transDate,
    paidDate,
    createdBy = "system",
  } = data;

  try {
    if (checkBoolean(isAR)) {
      const accountLedgerTemp = await updateTempGLSpecialCaseAR(data);

      if (!accountLedgerTemp) {
        logger.error("Unable to update seller payable AR case!");
        return;
      }

      return accountLedgerTemp;
    } else if (checkBoolean(isCustomInvoice)) {
      const accountLedgerTemp = await updateTempGLCustomInvoice(data);

      if (!accountLedgerTemp) {
        logger.error("Unable to update custom invoice AR case!");
        return;
      }

      return accountLedgerTemp;
    } else {
      // #region - // * TEMP ENTRY UPDATE
      const { glId, ...rest } = data;

      const projection = { new: true };
      const accountLedgerTemp = await FindByIdAndUpdate(
        Accountledgertemp,
        glId,
        rest,
        projection
      );

      if (!accountLedgerTemp) {
        logger.error("Unable to update temp entry!");
        return;
      }
      // #endregion

      // #region - // * IP/AR - OP/AP - [INCOMING PAYMENT - OUTGOING PAYMENT - SELLER PAYABLE - OUTGOING CASH LIST - CUSTOM INVOICE]
      const {
        _id: accountLedgerTempId,
        status,
        voucherNo,
        referenceId,
        referenceNo,
        createdFrom,
        payableStatus,
        paymentType,
      } = accountLedgerTemp;

      if (status === "approved") {
        const filter = { voucherNo };
        const update = { status };

        await Accountledgertemp.updateMany(filter, update);

        // * log hierarchy
        await updateCommonLog({
          action: "Approved",
          from: "Payment",
          id: accountLedgerTempId,
          no: voucherNo,
          by: createdBy,
        });
      }

      if (status === "rejected") {
        const filter = { voucherNo };
        const update = { status };

        await Accountledgertemp.updateMany(filter, update);

        if (createdFrom === "Seller Payable") {
          await updateSellerServiceAndSellerReceiptByPayableNo(
            referenceNo,
            status
          );

          await updateCommonLog({
            action: "Rejected",
            from: "Payment(OP)",
            id: referenceId,
            no: referenceNo,
            by: createdBy,
          });
        } else if (createdFrom === "Outgoing Cash List") {
          await updateCommonLog({
            action: "Rejected",
            from: "Payment(OP)",
            id: referenceId,
            no: referenceNo,
            by: createdBy,
          });
        } else if (createdFrom === "Custom Invoice") {
          await updateCommonLog({
            action: "Rejected",
            from: "Payment(OP)",
            id: referenceId,
            no: referenceNo,
            by: createdBy,
          });
        } else {
          await updateCommonLog({
            action: "Rejected",
            from: "Payment(OP)",
            id: accountLedgerTempId,
            no: voucherNo,
            by: createdBy,
          });
        }
      }

      if (status === "paid") {
        // #region - // * LEDGER ENTRIES
        const ledgerArr = [];

        const filter = { voucherNo };
        const update = { transDate, paidDate };
        await Accountledgertemp.updateMany(filter, update);

        const voucherNoUnique = await common.getVoucherNo();
        const tempData = await Accountledgertemp.find(
          { voucherNo },
          {
            branchId: 1,
            glAccountId: 1,
            transactionType: 1,
            paymentType: 1,
            payAmount: 1,
            description: 1,
            referenceType: 1,
            referenceNo: 1,
            transDate: 1,
            createdBy: 1,
            closingStatus: 1,
            addedFrom: 1,
            transactionOf: 1,
          }
        ).sort({ createdAt: 1 });

        for (let i = 0; i < tempData.length; i++) {
          ledgerArr.push({
            voucherNo: voucherNoUnique,
            branchId: makeObjectId(tempData[i]?.branchId),
            glAccountId: makeObjectId(tempData[i]?.glAccountId),
            transactionType: tempData[i]?.transactionType,
            paymentType: tempData[i]?.paymentType,
            payAmount: tempData[i]?.payAmount,
            description: tempData[i]?.description,
            referenceType: tempData[i]?.referenceType
              ? tempData[i]?.referenceType
              : "",
            referenceNo: tempData[i]?.referenceNo,
            referenceNo2: tempData[i]?.referenceNo2
              ? tempData[i]?.referenceNo2
              : "",
            transDate: tempData[i]?.transDate,
            createdBy: tempData[i]?.createdBy,
            closingStatus: tempData[i]?.closingStatus,
            addedFrom: tempData[i]?.addedFrom,
            transactionOf: tempData[i]?.transactionOf,
          });
        }

        if (ledgerArr.length) {
          const payAmount = getValuesByKey(ledgerArr, "payAmount", "single");
          payAmount > 0 && (await Accountledger.insertMany(ledgerArr));
        }
        // #endregion

        if (createdFrom === "Seller Payable") {
          // * Sale Ledger Entries
          await sellerSaleEntries(
            referenceNo,
            voucherNoUnique,
            paymentType,
            getGLByPaymentMethod,
            createAccountLedger
          );

          await updateSellerServiceAndSellerReceiptByPayableNo(
            referenceNo,
            status
          );

          // * unsold case will come in OP in case of discount, selfBid may come either in IP/OP
          if (["unsold", "selfBid"].includes(payableStatus)) {
            updateGatePassBySellerPayableNo(referenceNo);
          }

          const filter = { payableNo: referenceNo };
          const sellerPayable = await SellerPayable.findOne(filter);

          if (!sellerPayable) {
            logger.error("Seller Payable not found!");
            return;
          }

          const {
            inventoryId: [inventoryId],
          } = sellerPayable;

          // * Update Inventory Payment Status
          await updateInventoryPaymentCleared(inventoryId);

          // * log hierarchy
          await updateCommonLog({
            action: "Paid",
            from: "Payment(OP)",
            id: referenceId,
            no: referenceNo,
            by: createdBy,
          });
        } else if (createdFrom === "Outgoing Cash List") {
          await updateCommonLog({
            action: "Paid",
            from: "Payment(OP)",
            id: referenceId,
            no: referenceNo,
            by: createdBy,
          });
        } else if (createdFrom === "Custom Invoice") {
          await updateCommonLog({
            action: "Paid",
            from: "Payment(OP)",
            id: referenceId,
            no: referenceNo,
            by: createdBy,
          });
        } else if (createdFrom === "Sales Return") {
          await updateCommonLog({
            action: "Paid",
            from: "Payment(OP)",
            id: referenceId,
            no: referenceNo,
            by: createdBy,
          });
        } else {
          await updateCommonLog({
            action: "Paid",
            from: "Payment(OP)",
            id: accountLedgerTempId,
            no: voucherNo,
            by: createdBy,
          });
        }
      }

      return accountLedgerTemp;
      // #endregion
    }
  } catch (error) {
    logger.error(error);
  }
};

const addStoragePayment = async (data) => {
  if (!checkRequiredArguments(data)) return;

  // #region - // * SELLER PAYABLE
  const createSellerPayable = await addSellerPayable(data);

  if (!createSellerPayable) {
    logger.error("Failed to create seller payable!");
    return;
  }

  const { _id: payableId, createdBy, balanceType } = createSellerPayable;
  // #endregion

  const approvePayable = {
    sellerpaybaleId: payableId,
    status: "approved",
    createdBy,
  };

  const tempLedgerEntry = await updateSellerPayable(approvePayable);

  if (!tempLedgerEntry) {
    logger.error("Failed to update seller payable or create temp ledger!");
    return;
  }

  const {
    _id: tempLedgerId = "",
    voucherNo,
    payAmount,
  } = tempLedgerEntry || {};

  const tempLedgerUpdate = {
    AR: {
      glId: tempLedgerId,
      status: "paid",
      createdBy,
      isAR: true,
      voucherNo,
      paymentType: "cash",
      transDate: todayDate(),
      payAmount,
      paidDate: todayDate(),
    },
    AP: {
      glId: tempLedgerId,
      status: "paid",
      createdBy,
      paidDate: todayDate(),
      transDate: todayDate(),
    },
  };

  const payment = await updateIncomingOutgoingPayment(
    tempLedgerUpdate[balanceType]
  );

  return payment;
};

module.exports = {
  createAccountLedger,
  getGLByPaymentMethod,
  updateTempGLSpecialCaseAR,
  updateTempGLCustomInvoice,
  calculateClosingBalance,
  getEntityBalance,
  approveSecurityDeposit,
  rejectSecurityDeposit,
  approveZeroRatedSecurityDeposit,
  rejectZeroRatedSecurityDeposit,
  updateIncomingOutgoingPayment,
  addStoragePayment,
};
