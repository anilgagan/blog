const { sms } = require("../config");
const logger = require("../config/logger");

const {
  checkRequiredArguments,
  makeAxiosRequest,
  bearerToken,
  onlyNumbersString,
  removeSpecialCharacters,
} = require("../functions/global.functions");
const { getSMSToken, updateSMSToken } = require("./token.service");

const {
  SM_LOGIN_URL,
  SM_LOGIN_USERNAME,
  SM_LOGIN_PASSWORD,
  SM_MESSAGE_CATEGORY,
  SM_CONTENT_TYPE,
  SM_SENDER_ADDRESS,
  SM_DND_CATEGORY,
  SM_CLIENT_TXN,
  SM_SEND_SMS_URL,
  modes,
} = sms;

const smLogin = async () => {
  try {
    const url = SM_LOGIN_URL;
    const method = "POST";
    const data = {
      username: SM_LOGIN_USERNAME,
      password: SM_LOGIN_PASSWORD,
    };

    const login = await makeAxiosRequest(url, method, data);

    if (!login) {
      logger.error("Failed to login with smart messaging service!");
      return;
    }

    return login.token;
  } catch (error) {
    logger.error(error);
  }
};

const sendSMS = async (phone, msg, token) => {
  const data = {
    msgCategory: SM_MESSAGE_CATEGORY,
    contentType: SM_CONTENT_TYPE,
    senderAddr: SM_SENDER_ADDRESS,
    dndCategory: SM_DND_CATEGORY,
    priority: 1,
    clientTxnId: SM_CLIENT_TXN,
    recipient: phone,
    msg: msg,
    dr: "1",
  };

  const url = SM_SEND_SMS_URL;
  const method = "POST";
  const headers = bearerToken(token);

  return await makeAxiosRequest(url, method, data, headers);
};

const handleSMSResponse = (statusCode, info = "") => {
  const codes = {
    201: info,
    401: "Failed to send SMS, Invalid username/password. Kindly login again!",
  };

  const message = codes[statusCode] || "Failed to send SMS!";
  logger[statusCode === 201 ? "info" : "error"](message);
};

const smSend = async (phone, msg, message) => {
  if (!checkRequiredArguments(phone, msg)) return;

  try {
    const smsToken = await getSMSToken();

    if (!smsToken) {
      logger.error("Failed to get sms token, kindly run seeder!");
      return;
    }

    const sendSMSResponse = await sendSMS(phone, msg, smsToken.token);

    if (!sendSMSResponse) {
      logger.error("Failed to send sms with smart messaging!");
      return;
    }

    const {
      statusCode: successCode,
      response: { data: { statusCode: errorCode } = {} } = {},
    } = sendSMSResponse;
    const status = successCode || errorCode;

    if (status === 401) {
      logger.info("Trying to login and get a new token!");

      const newToken = await smLogin();

      if (!newToken) {
        logger.error("Failed to get a new token!");
        return;
      }

      // * update-token
      await updateSMSToken(newToken);

      const retrySendSMSResponse = await sendSMS(phone, msg, newToken);

      if (!retrySendSMSResponse) {
        logger.error("Failed to send sms again!");
        return;
      }

      const {
        statusCode: successCode,
        response: { data: { statusCode: errorCode } = {} } = {},
      } = retrySendSMSResponse;

      const retryStatus = successCode || errorCode;
      handleSMSResponse(retryStatus, message);

      return retryStatus;
    } else {
      handleSMSResponse(status, message);
      return status;
    }
  } catch (error) {
    logger.error(error);
  }
};

const sendCombineSMS = async (phone, otp, mode) => {
  if (!checkRequiredArguments(phone, otp, mode)) return;

  try {
    const isPhoneValid = onlyNumbersString(phone);
    if (!isPhoneValid) {
      logger.info(`Phone (${phone}) is not valid!`);
      return;
    }

    if (!modes[mode]) {
      logger.error(`SMS template (${mode}) is not valid!`);
      return;
    }

    const { body, message } = modes[mode](otp, phone);

    await smSend(phone, body, message);
  } catch (error) {
    logger.error(error.message);
  }
};

const makeSmsNumber = (countryCode, phone) => {
  if (!checkRequiredArguments(countryCode, phone)) return;

  try {
    const phoneNo = `${countryCode}${phone}`;
    const phoneNumber = removeSpecialCharacters(phoneNo);

    return phoneNumber;
  } catch (error) {
    logger.error(error);
  }
};

module.exports = {
  smLogin,
  sendCombineSMS,
  makeSmsNumber,
};
