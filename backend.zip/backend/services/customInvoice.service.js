const { CustomInvoice } = require("../models");
const { defaultSort, userRole } = require("../config");
const {
  checkRequiredArguments,
  todayDate,
  isEmptyString,
  joinWithSymbol,
} = require("../functions/global.functions");

const {
  ExactMatch,
  RegexSearch,
  Project,
  Sort,
  Skip,
  Limit,
  IDMatch,
  Lookup,
  Unwind,
} = require("../functions/mongoose.functions");

const {
  Create,
  MultiAggregate,
  FindByIdAndUpdate,
  DeleteById,
  FindById,
  Aggregate,
} = require("../models/factory");

const common = require("../middleware/common-fun");
const logger = require("../config/logger");
const { Accountledgertemp } = require("../modules/account/accountModal");
const { User } = require("../modules/user/userModal");
const { updateCommonLog } = require("./comment.service");
const { getGLByPaymentMethod } = require("./account.service");

const createCustomInvoice = async (body) => {
  if (!checkRequiredArguments(body)) return;

  const customInvoice = await Create(CustomInvoice, body);
  return customInvoice;
};

const getCustomInvoices = async (query = {}) => {
  const {
    customInvoiceId,
    invoiceNo,
    serviceName,
    serviceId,
    serviceGlId,
    branchId,
    userId,
    status,
    createdBy,
    search,
    page,
    pageLimit,
  } = query;

  const pipeline = [];

  if (customInvoiceId) IDMatch(pipeline, "_id", customInvoiceId);
  if (invoiceNo) ExactMatch(pipeline, "invoiceNo", invoiceNo);
  if (serviceName) ExactMatch(pipeline, "serviceName", serviceName);
  if (serviceId) IDMatch(pipeline, "serviceId", serviceId);
  if (serviceGlId) IDMatch(pipeline, "serviceGlId", serviceGlId);
  if (branchId) IDMatch(pipeline, "branchId", branchId);
  if (userId) IDMatch(pipeline, "userId", userId);
  if (status) ExactMatch(pipeline, "status", status);
  if (createdBy) ExactMatch(pipeline, "createdBy", createdBy);
  if (search) {
    const searchFields = [
      "invoiceNo",
      "serviceName",
      "serviceId",
      "serviceGlId",
      "branchId",
      "userId",
      "status",
      "createdBy",
    ];
    RegexSearch(pipeline, searchFields, search);
  }

  // * customService
  Lookup(pipeline, "customservices", "serviceId", "_id", "customService");
  Unwind(pipeline, "$customService");

  // * branch
  Lookup(pipeline, "branchs", "branchId", "_id", "branch");
  Unwind(pipeline, "$branch");

  // * user
  Lookup(pipeline, "users", "userId", "_id", "user");
  Unwind(pipeline, "$user");

  const project = {
    invoiceNo: 1,
    serviceName: 1,
    serviceId: 1,
    serviceGlId: 1,
    branchId: 1,
    userId: 1,
    serviceCharges: 1,
    serviceVat: 1,
    total: 1,
    status: 1,
    createdBy: 1,
    description: 1,
    processedBy: 1,
    processedDate: 1,
    processedComments: 1,
    createdAt: 1,
    services: "$customService.services",
    branch: {
      name: "$branch.branchName",
      fullName: "$branch.fullbranchName",
      email: "$branch.branchEmail",
      mobile: "$branch.branchMobile",
      trnNo: "$branch.Trnno",
      address: "$branch.branchAddress",
      description: "$branch.branchDesc",
    },
    user: {
      name: "$user.name",
      phone: "$user.phone",
      userType: "$user.userType",
      EID: "$user.eid",
      companyDetails: "$user.companyDetails",
    },
  };

  Project(pipeline, project);

  Sort(pipeline, defaultSort);

  const count = [...pipeline];
  count.push({ $count: "totalCount" });

  if (page) {
    Skip(pipeline, common.pageOffset(page, pageLimit));
    Limit(pipeline, common.pageLimit(pageLimit));
  }

  const [result, [{ totalCount = 0 } = {}] = []] = await MultiAggregate(
    CustomInvoice,
    [pipeline, count]
  );

  return { result, totalCount };
};

const getCustomInvoice = async (id) => {
  if (!checkRequiredArguments(id)) return;

  const getInvoice = await FindById(CustomInvoice, id);

  if (!getInvoice) {
    logger.error("Custom invoice not found!");
    return;
  }

  return getInvoice;
};

const updateCustomInvoice = async (id, body) => {
  if (!checkRequiredArguments(id, body)) return;

  const projection = { new: true };
  const updateInvoice = await FindByIdAndUpdate(
    CustomInvoice,
    id,
    body,
    projection
  );

  if (!updateInvoice) {
    logger.error("Custom invoice not found!");
    return;
  }

  const { _id: invoiceId, invoiceNo: no, processedBy, status } = updateInvoice;

  const createdBy = isEmptyString(processedBy) ? "system" : processedBy;

  if (status === "approved") {
    await approveInvoice(updateInvoice);

    // * log hierarchy
    const log = {
      action: "Approved",
      from: "Account(Custom Invoice)",
      id: invoiceId,
      no,
      by: createdBy,
    };

    await updateCommonLog(log);
  } else if (status === "rejected") {
    // * log hierarchy
    await updateCommonLog({
      action: "Rejected",
      from: "Account(Custom Invoice)",
      id: invoiceId,
      no,
      by: createdBy,
    });
  }

  return updateInvoice;
};

const deleteCustomInvoice = async (id) => {
  if (!checkRequiredArguments(id)) return;

  const deleteInvoice = await DeleteById(CustomInvoice, id);

  if (!deleteInvoice) {
    logger.error("Custom invoice not found!");
    return;
  }

  return deleteInvoice;
};

const approveInvoice = async (invoice) => {
  if (!checkRequiredArguments(invoice)) return;

  const {
    _id: customInvoiceId,
    invoiceNo,
    serviceGlId,
    branchId,
    userId,
    serviceCharges,
    serviceVat,
    total,
    processedComments,
  } = invoice;

  try {
    const projection = { userType: 1, uniqueIdentifier: 1 };
    const user = await FindById(User, userId, projection);

    if (!user) {
      logger.error("User not found!, kindly look to it ASAP!");
      return;
    }

    const { userType, uniqueIdentifier = "" } = user;
    const transactionOf = userRole[userType];
    const consumerType = transactionOf === "seller" ? "sellerNo" : "buyerNo";
    const voucherNo = await common.getempGlNo();
    const pre = `CUSTOM INVOICE (${invoiceNo})`;
    const description = joinWithSymbol(" - ", pre, processedComments);

    const tempLedgerEntries = [];
    const vatAccountId = await getGLByPaymentMethod("vat");

    // * service charges - cr
    tempLedgerEntries.push({
      branchId,
      voucherNo,
      glAccountId: serviceGlId,
      transactionType: "cr",
      paymentType: "",
      payAmount: serviceCharges,
      description,
      referenceType: "CUSTOM INVOICE",
      referenceId: customInvoiceId,
      referenceNo: invoiceNo,
      balanceAmount: serviceCharges,
      createdBy: "system",
      transDate: todayDate(),
      addedFrom: "ip",
      createdFrom: "Custom Invoice",
      status: "approved",
      [consumerType]: uniqueIdentifier,
      transactionOf,
      payableType: "Invoice",
    });

    // * service vat - cr
    tempLedgerEntries.push({
      branchId,
      voucherNo,
      glAccountId: vatAccountId,
      transactionType: "cr",
      paymentType: "",
      payAmount: serviceVat,
      description,
      referenceType: "CUSTOM INVOICE",
      referenceId: customInvoiceId,
      referenceNo: invoiceNo,
      balanceAmount: serviceVat,
      createdBy: "system",
      transDate: todayDate(),
      addedFrom: "ip",
      createdFrom: "Custom Invoice",
      status: "approved",
      [consumerType]: uniqueIdentifier,
      transactionOf,
      payableType: "Invoice",
    });

    // * total - dr
    tempLedgerEntries.push({
      branchId,
      voucherNo,
      glAccountId: null,
      transactionType: "dr",
      paymentType: "",
      payAmount: total,
      description,
      referenceType: "CUSTOM INVOICE",
      referenceId: customInvoiceId,
      referenceNo: invoiceNo,
      balanceAmount: total,
      createdBy: "system",
      transDate: todayDate(),
      addedFrom: "ip",
      createdFrom: "Custom Invoice",
      status: "approved",
      [consumerType]: uniqueIdentifier,
      transactionOf,
      payableType: "Invoice",
    });

    await Accountledgertemp.create(tempLedgerEntries);
  } catch (error) {
    logger.error(error.message);
  }
};

const getCustomDocs = async (id) => {
  if (!checkRequiredArguments(id)) return;

  const pipeline = [];

  IDMatch(pipeline, "_id", id);

  // * customService
  Lookup(pipeline, "customservices", "serviceId", "_id", "customService");
  Unwind(pipeline, "$customService");

  // * branch
  Lookup(pipeline, "branchs", "branchId", "_id", "branch");
  Unwind(pipeline, "$branch");

  // * user
  Lookup(pipeline, "users", "userId", "_id", "user");
  Unwind(pipeline, "$user");

  const project = {
    invoiceNo: 1,
    serviceName: 1,
    serviceId: 1,
    serviceGlId: 1,
    branchId: 1,
    userId: 1,
    serviceCharges: 1,
    serviceVat: 1,
    total: 1,
    status: 1,
    createdBy: 1,
    description: 1,
    processedBy: 1,
    processedDate: 1,
    processedComments: 1,
    createdAt: 1,
    services: "$customService.services",
    branch: {
      name: "$branch.branchName",
      fullName: "$branch.fullbranchName",
      email: "$branch.branchEmail",
      mobile: "$branch.branchMobile",
      trnNo: "$branch.Trnno",
      address: "$branch.branchAddress",
      description: "$branch.branchDesc",
    },
    user: {
      name: "$user.name",
      phone: "$user.phone",
      userType: "$user.userType",
      EID: "$user.eid",
      companyDetails: "$user.companyDetails",
    },
  };

  Project(pipeline, project);

  const result = await Aggregate(CustomInvoice, pipeline);

  return result;
};

module.exports = {
  createCustomInvoice,
  getCustomInvoices,
  getCustomInvoice,
  updateCustomInvoice,
  deleteCustomInvoice,
  getCustomDocs,
};
