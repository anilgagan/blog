const logger = require("../config/logger");
const { checkRequiredArguments } = require("../functions/global.functions");
const { OTP } = require("../models");
const { Create, FindOne } = require("../models/factory");

const createOTP = async (body) => {
  if (!checkRequiredArguments(body)) return;

  try {
    const otp = await Create(OTP, body);
    return otp;
  } catch (error) {
    logger.error(error.message);
  }
};

const getOTP = async (filter) => {
  if (!checkRequiredArguments(filter)) return;

  try {
    const otp = await FindOne(OTP, filter);
    return otp;
  } catch (error) {
    logger.error(error.message);
  }
};

module.exports = {
  createOTP,
  getOTP,
};
