const mongoose = require("mongoose");

const { creditCalHistory } = require("../modules/order/orderModel");
const { Reciept } = require("../modules/reciept/recieptModal");
const { User } = require("../modules/user/userModal");
const { Sellerservice } = require("../modules/saleReciept/saleRecieptModal");
const { getGLByPaymentMethod } = require("./account.service");
const {
  Accountledger,
  Outgoingcash,
} = require("../modules/account/accountModal");
const { defaultSort } = require("../config");

const common = require("../middleware/common-fun");
const logger = require("../config/logger");

const {
  getFivePercentVat,
  checkRequiredArguments,
  getFivePercentVatWithAmount,
  roundToDecimal,
  formatDate,
  toUpperCase,
  todayDate,
} = require("../functions/global.functions");
const {
  FindOne,
  FindOneAndUpdate,
  FindById,
  Create,
  Aggregate,
  FindByIdAndUpdate,
} = require("../models/factory");
const {
  Getpass,
  Getdocument,
  Inventory,
} = require("../modules/inventory/inventoryModal");
const {
  RegexSearch,
  Project,
  Sort,
  Match,
  Lookup,
  Unwind,
} = require("../functions/mongoose.functions");
const { updateCommonLog, createCommonLog } = require("./comment.service");

const updateUserCreditLimitAndHistory = async (userId, paidAmount) => {
  // * Update User Credit Limit
  const uUpdate = {
    $inc: {
      creditLimit: Math.floor(paidAmount),
    },
  };

  await User.findByIdAndUpdate(userId, uUpdate);

  //   * Add Credit History
  const cData = {
    userId,
    deposit: 0,
    creditLimit: paidAmount,
    creditType: "CR",
    balance: paidAmount,
  };

  await creditCalHistory.create(cData);
};

const addCustomerPayment = async (receiptArr) => {
  return new Promise((resolve, reject) => {
    receiptArr.forEach(async (value) => {
      try {
        // * first reciept update
        await Reciept.updateOne(
          { _id: value.recieptId },
          {
            $set: {
              paidAmount: value.newPaidAmount,
              totalStoragePaid: value.totalStoragePaid,
              payStatus: value.payStatus,
              dueBalance: value.dueAmount,
            },
          }
        );

        // * second decrement user's wallet balance
        await User.updateOne(
          { _id: mongoose.Types.ObjectId(value.buyerId) },
          {
            $inc: {
              walletAmount: -Math.floor(value.newPaidAmount),
            },
          }
        );

        if (value.payStatus == 1) {
          await Getpass.updateOne(
            { referenceId: mongoose.Types.ObjectId(value?.recieptId) },
            { $set: { status: "in warehouse" } }
          );

          await Getdocument.updateOne(
            { referenceId: mongoose.Types.ObjectId(value?.recieptId) },
            { $set: { status: "in warehouse" } }
          );

          if (value.isCreditApplied) {
            await updateUserCreditLimitAndHistory(
              value.buyerId,
              value.saleAmount
            );
          }
        }
      } catch (error) {
        logger.error(error);
      }
    });

    resolve();
  });
};

const adjustSelfBidAuctionCharges = async (saleOrderNo) => {
  if (!checkRequiredArguments(saleOrderNo)) return;

  try {
    const filter = {
      saleOrderNo,
      serviceType: "auction",
      serviceStatus: "selfBid",
    };

    const auctionService = await FindOne(Sellerservice, filter);

    if (!auctionService) {
      logger.error("Auction seller service not found!");
      return;
    }

    const { saleTotalAmount: advance, auctionFee, listingFee } = auctionService;

    const totalCharges = auctionFee + listingFee;

    if (advance > totalCharges) {
      const listingVat = getFivePercentVat(listingFee);
      const listingTotal = listingFee + listingVat;
      const adjustedAuctionWithVat = advance - listingTotal;
      let { amount: adjustedAuctionFee, vat: adjustedAuctionVat } =
        getFivePercentVatWithAmount(adjustedAuctionWithVat);
      adjustedAuctionFee = roundToDecimal(adjustedAuctionFee);
      adjustedAuctionVat = roundToDecimal(adjustedAuctionVat);

      // * adjusted
      const adjustedCombinedVat = adjustedAuctionVat + listingVat;
      const adjustedServiceCharge = adjustedAuctionFee + listingFee;
      const adjustedTotalPayment = adjustedServiceCharge + adjustedCombinedVat;

      const update = {
        auctionFee: adjustedAuctionFee,
        vatAmount: adjustedCombinedVat,
        serviceCharge: adjustedServiceCharge,
        totalPayment: adjustedTotalPayment,
        isRefundAdjusted: true,
      };

      const projection = { new: true };
      const auctionService = await FindOneAndUpdate(
        Sellerservice,
        filter,
        update,
        projection
      );

      if (!auctionService) {
        logger.error(
          `Failed to update auction seller service of: ${saleOrderNo}`
        );
      }
    }
  } catch (error) {
    logger.error(error);
  }
};

const addReceiptPayment = async (data) => {
  if (!checkRequiredArguments(data)) return;

  const {
    payAmount,
    dueAmount,
    paidAmount,
    payStorageAmount,
    recieptId,
    paymentMethod,
    createdBy,
    transDate,
  } = data;

  const receiptArr = [];
  const ledgerArr = [];

  for (let i = 0; i < payAmount.length; i++) {
    const payBalance = Number(payAmount[i]);
    const dueBalance = Number(dueAmount[i]);
    const storageBalance = Number(payStorageAmount[i]);

    if (payBalance > 0 || payStorageAmount > 0) {
      // * voucherNo
      const voucherNo = await common.getVoucherNo();

      // #region - // * RECEIPT
      const receiptId = recieptId[i];
      const receiptProjection = {
        recieptNo: 1,
        branchId: 1,
        inventoryId: 1,
        buyerId: 1,
        saleAmount: 1,
        dueBalance: 1,
        isCreditApplied: 1,
        totalStoragePaid: 1,
      };

      const receipt = await FindById(Reciept, receiptId, receiptProjection);

      if (!receipt) {
        logger.error("Receipt not found!");
        return;
      }

      const {
        recieptNo,
        branchId,
        inventoryId,
        buyerId,
        saleAmount,
        isCreditApplied,
        totalStoragePaid,
      } = receipt;
      // #endregion

      // #region - // * INVENTORY
      const inventoryProjection = { vin: 1, sellerId: 1 };
      const inventory = await FindById(
        Inventory,
        inventoryId,
        inventoryProjection
      );

      if (!inventory) {
        logger.error("Inventory not found!");
        return;
      }

      const { vin: vinNo, sellerId } = inventory;
      // #endregion

      // #region - // * SELLER
      const userProjection = {
        name: 1,
        uniqueIdentifier: 1,
      };
      const seller = await FindById(User, sellerId, userProjection);

      const { name: sellerNAME = "", uniqueIdentifier: sellerNo = "" } =
        seller || {};
      const sellerName = toUpperCase(sellerNAME);
      // #endregion

      // #region - // * BUYER
      const buyer = await FindById(User, buyerId, userProjection);
      const { name: buyerNAME = "", uniqueIdentifier: buyerNo = "" } =
        buyer || {};
      const buyerName = toUpperCase(buyerNAME);
      // #endregion

      // #region - // * LEDGER ENTRIES
      const description = `TO RECORD BALANCE RECEIVED FROM ${buyerName} AGAINST ${sellerName} VIN# ${vinNo} INV NO# ${recieptNo}`;

      let groupAccountId;
      if (paymentMethod[i] === "cash") {
        groupAccountId = await getGLByPaymentMethod("cash");
      } else if (paymentMethod[i] === "card") {
        groupAccountId = await getGLByPaymentMethod("card", branchId);
      } else {
        groupAccountId = await getGLByPaymentMethod("online");
      }

      if (payBalance > 0) {
        let transactionFee = 0;

        if (paymentMethod[i] === "card") {
          const transactionAccountId = await getGLByPaymentMethod(
            "transaction-fee"
          );

          transactionFee = Math.round((payBalance * 2) / 100);

          ledgerArr.push({
            branchId: mongoose.Types.ObjectId(branchId),
            glAccountId: mongoose.Types.ObjectId(transactionAccountId),
            voucherNo,
            transactionType: "cr",
            paymentType: paymentMethod[i],
            payAmount: transactionFee,
            referenceType: "reciept",
            description,
            referenceNo: recieptNo,
            referenceNo2: vinNo,
            buyerNo: buyerNo,
            sellerNo: sellerNo,
            createdBy: createdBy[i],
            transDate: transDate[i] || null,
            transactionOf: "buyer",
          });
        }

        // * balance amount
        ledgerArr.push({
          branchId: mongoose.Types.ObjectId(branchId),
          glAccountId: mongoose.Types.ObjectId(groupAccountId),
          voucherNo,
          transactionType: "dr",
          paymentType: paymentMethod[i],
          payAmount: payBalance + transactionFee,
          referenceType: "reciept",
          description,
          referenceNo: recieptNo,
          referenceNo2: vinNo,
          buyerNo: buyerNo,
          sellerNo: sellerNo,
          createdBy: createdBy[i],
          transDate: transDate[i] || null,
          transactionOf: "buyer",
        });

        // * receivable or due amount
        const receivableAccountId = await getGLByPaymentMethod("receivable");
        ledgerArr.push({
          branchId: mongoose.Types.ObjectId(branchId),
          glAccountId: mongoose.Types.ObjectId(receivableAccountId),
          voucherNo,
          transactionType: "cr",
          paymentType: paymentMethod[i],
          payAmount: payBalance,
          referenceType: "reciept",
          description,
          referenceNo: recieptNo,
          referenceNo2: vinNo,
          buyerNo: buyerNo,
          sellerNo: sellerNo,
          createdBy: createdBy[i],
          transDate: transDate[i] || null,
          transactionOf: "buyer",
        });
      }

      if (storageBalance > 0) {
        // * storage
        const { amount, vat } = getFivePercentVatWithAmount(storageBalance);

        const storageAmount = roundToDecimal(amount);
        const storageVat = roundToDecimal(vat);

        if (storageAmount > 0) {
          let transactionFee = 0;

          if (paymentMethod[i] === "card") {
            const transactionAccountId = await getGLByPaymentMethod(
              "transaction-fee"
            );

            transactionFee = Math.round((storageBalance * 2) / 100);

            ledgerArr.push({
              branchId: mongoose.Types.ObjectId(branchId),
              glAccountId: mongoose.Types.ObjectId(transactionAccountId),
              voucherNo,
              transactionType: "cr",
              paymentType: paymentMethod[i],
              payAmount: transactionFee,
              referenceType: "reciept",
              description,
              referenceNo: recieptNo,
              referenceNo2: vinNo,
              buyerNo: buyerNo,
              sellerNo: sellerNo,
              createdBy: createdBy[i],
              transDate: transDate[i] || null,
              transactionOf: "buyer",
            });
          }

          const storageCharge = storageAmount;
          const vatStorage = storageVat;

          // * storage
          // const receivableAccountId = await getGLByPaymentMethod("receivable");
          ledgerArr.push({
            branchId: mongoose.Types.ObjectId(branchId),
            glAccountId: mongoose.Types.ObjectId(groupAccountId),
            voucherNo,
            transactionType: "dr",
            paymentType: paymentMethod[i],
            payAmount:
              Number(storageCharge) +
              Number(vatStorage) +
              Number(transactionFee),
            referenceType: "reciept",
            description,
            referenceNo: recieptNo,
            referenceNo2: vinNo,
            buyerNo: buyerNo,
            sellerNo: sellerNo,
            createdBy: createdBy[i],
            transDate: transDate[i] || null,
            transactionOf: "buyer",
            ...(storageBalance > 0 && { accountMasterType: "storage" }), // * to find out storage cash entries
          });

          // * storage - storage
          const storageAccountId = await getGLByPaymentMethod("storage");
          ledgerArr.push({
            branchId: mongoose.Types.ObjectId(branchId),
            glAccountId: mongoose.Types.ObjectId(storageAccountId),
            voucherNo,
            transactionType: "cr",
            paymentType: paymentMethod[i],
            payAmount: Number(storageCharge),
            referenceType: "reciept",
            description,
            referenceNo: recieptNo,
            referenceNo2: vinNo,
            buyerNo: buyerNo,
            sellerNo: sellerNo,
            createdBy: createdBy[i],
            transDate: transDate[i] || null,
            transactionOf: "buyer",
          });

          // * storage - vat
          const storageVatAccountId = await getGLByPaymentMethod("storage-vat");
          ledgerArr.push({
            branchId: mongoose.Types.ObjectId(branchId),
            glAccountId: mongoose.Types.ObjectId(storageVatAccountId),
            voucherNo,
            transactionType: "cr",
            paymentType: paymentMethod[i],
            payAmount: Number(vatStorage),
            referenceType: "reciept",
            description,
            referenceNo: recieptNo,
            referenceNo2: vinNo,
            buyerNo: buyerNo,
            sellerNo: sellerNo,
            createdBy: createdBy[i],
            transDate: transDate[i] || null,
            transactionOf: "buyer",
          });
        }
      }
      // #endregion

      // #region - // * DATA FORMATION
      if (dueBalance === 0) {
        receiptArr.push({
          recieptId: mongoose.Types.ObjectId(receiptId),
          buyerId,
          saleAmount,
          paidAmount: Number(paidAmount[i]),
          totalStoragePaid: Number(payStorageAmount[i] + totalStoragePaid), // * fresh paid + previous paid
          payStatus: 1,
          isCreditApplied,
          createdBy: createdBy[i],
        });
      } else {
        receiptArr.push({
          recieptId: mongoose.Types.ObjectId(receiptId),
          buyerId,
          saleAmount,
          paidAmount: Number(paidAmount[i]),
          totalStoragePaid: Number(payStorageAmount[i] + totalStoragePaid), // * fresh paid + previous paid
          payStatus: 0,
          isCreditApplied,
          createdBy: createdBy[i],
        });
      }
      // #endregion
    }
  }

  // #region - // * LEDGER + RECEIPT
  if (!ledgerArr.length > 0) {
    logger.error("Amount can not be empty!");
    return;
  }

  const ledgerEntries = await Create(Accountledger, ledgerArr);

  if (!ledgerEntries) {
    logger.error("Unable to create ledger entries!");
    return;
  }

  if (receiptArr.length > 0) {
    receiptArr.forEach(async (value) => {
      await Reciept.updateOne(
        { _id: value.recieptId },
        {
          $set: {
            paidAmount: value.paidAmount,
            totalStoragePaid: value.totalStoragePaid,
            payStatus: value.payStatus,
          },
        }
      );

      if (value.payStatus == 1) {
        const gatePassUpdate = {
          status: "in warehouse",
          parkingDays: 0,
        };

        const gatePass = await Getpass.findOne(
          { referenceId: mongoose.Types.ObjectId(value?.recieptId) },
          {
            gatePassExpired: 1,
          }
        ).sort(defaultSort);

        const newGatePassExpiryDate = formatDate(new Date());

        if (new Date() >= new Date(gatePass?.gatePassExpired)) {
          gatePassUpdate["gatePassExpired"] = newGatePassExpiryDate;

          await Reciept.updateOne(
            { _id: value.recieptId },
            {
              $set: {
                gatePassExpired: newGatePassExpiryDate,
              },
            }
          );
        }

        await Getpass.updateOne(
          { referenceId: mongoose.Types.ObjectId(value?.recieptId) },
          {
            $set: gatePassUpdate,
          }
        );

        await Getdocument.updateOne(
          { referenceId: mongoose.Types.ObjectId(value?.recieptId) },
          {
            $set: {
              status: "in warehouse",
              gatePassExpired: newGatePassExpiryDate,
            },
          }
        );

        if (value.isCreditApplied) {
          await updateUserCreditLimitAndHistory(
            value.buyerId,
            value.saleAmount
          );
        }
      }
    });
  }
  // #endregion

  return true;
};

const createTaxReceipt = async (data) => {
  if (!checkRequiredArguments(data)) return;

  const { receiptId, exportCountry, outgoingFile, createdBy } = data;

  // * receipt
  const update = {
    taxType: "security",
    isZeroRated: true,
    zeroRatedExportCountry: exportCountry,
  };
  const projection = { new: true };

  const receipt = await FindByIdAndUpdate(
    Reciept,
    receiptId,
    update,
    projection
  );

  if (!receipt) {
    logger.error("Unable to convert to security receipt!");
    return;
  }

  const { _id: receiptID, branchId, recieptNo, securityAmount } = receipt;

  await createCommonLog({
    action: "Created",
    from: "Account(Security Deposit - 0 Rated Invoice)",
    id: receiptID,
    of: "reciept",
    no: recieptNo,
    by: createdBy,
  });

  // * outgoing cash
  const securityDepositNo = await common.getDocNo("security");

  const outgoingData = {
    voucherNo: securityDepositNo,
    referenceId: receiptID,
    branchId,
    referenecType: "security",
    paymentMethod: "cash",
    referenceNo: recieptNo,
    amount: securityAmount,
    file: outgoingFile,
    status: "pending",
    transDate: todayDate(),
  };

  const outgoingDoc = await Create(Outgoingcash, outgoingData);

  if (!outgoingDoc) {
    logger.error("Unable to create outgoing cash document!");
    return;
  }

  await updateCommonLog({
    action: "Created",
    from: "Account(Security Deposit)",
    id: receiptID,
    no: recieptNo,
    by: createdBy,
  });

  return receipt;
};

const getTaxReceipts = async (query = {}) => {
  const { search } = query;

  const pipeline = [];

  const match = {
    securityClaim: 0,
    recieptType: "sold",
    invoiceStatus: { $ne: "cancelled" },
    taxType: "tax",
    payStatus: 1,
  };

  // * match
  Match(pipeline, match);

  // * inventory
  Lookup(pipeline, "inventorys", "inventoryId", "_id", "inventory");
  Unwind(pipeline, "$inventory");

  // * make
  Lookup(pipeline, "makes", "inventory.make", "_id", "make");
  Unwind(pipeline, "$make");

  // * model
  Lookup(pipeline, "models", "inventory.model", "_id", "model");
  Unwind(pipeline, "$model");

  // * exteriorColor
  Lookup(
    pipeline,
    "exteriorcolors",
    "inventory.exteriorcolorId",
    "_id",
    "exteriorColor"
  );
  Unwind(pipeline, "$exteriorColor");

  // * seller
  Lookup(pipeline, "users", "inventory.sellerId", "_id", "seller");
  Unwind(pipeline, "$seller");

  // * buyer
  Lookup(pipeline, "users", "buyerId", "_id", "buyer");
  Unwind(pipeline, "$buyer");

  // * search
  if (search) {
    const searchFields = [
      "recieptNo",
      "inventory.vin",
      "buyer.name",
      "buyer.eid",
    ];
    RegexSearch(pipeline, searchFields, search);
  }

  const project = {
    _id: 0,
    receiptId: "$_id",
    receiptNo: "$recieptNo",
    saleAmount: 1,
    paidAmount: 1,
    totalNetAmount: 1,
    taxType: 1,
    taxAmount: "$securityAmount",
    inventory: {
      vin: "$inventory.vin",
      carDescription: {
        $concat: [
          { $ifNull: ["$inventory.year", ""] },
          " ",
          { $ifNull: ["$make.makeName", ""] },
          " ",
          { $ifNull: ["$model.modelName", ""] },
          //" ",
          //{ $ifNull: ["$exteriorColor.colorName", ""] },
        ],
      },
    },
    buyer: {
      name: "$buyer.name",
      phone: "$buyer.phone",
      uniqueIdentifier: "$buyer.uniqueIdentifier",
      userType: "$buyer.userType",
      companyDetails: "$buyer.companyDetails",
    },
    seller: {
      name: "$seller.name",
      phone: "$seller.phone",
      uniqueIdentifier: "$seller.uniqueIdentifier",
      userType: "$seller.userType",
      companyDetails: "$seller.companyDetails",
    },
  };

  Project(pipeline, project);

  Sort(pipeline, defaultSort);

  const result = await Aggregate(Reciept, pipeline);

  return result;
};

const updateReceipt = async (id, body) => {
  if (!checkRequiredArguments(id, body)) return;

  const projection = { new: true };
  const receipt = await FindByIdAndUpdate(Reciept, id, body, projection);

  if (!receipt) {
    logger.error("Receipt not found!");
    return;
  }

  return receipt;
};

module.exports = {
  updateUserCreditLimitAndHistory,
  addCustomerPayment,
  adjustSelfBidAuctionCharges,
  addReceiptPayment,
  createTaxReceipt,
  getTaxReceipts,
  updateReceipt,
};
