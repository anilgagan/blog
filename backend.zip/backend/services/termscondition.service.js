const { UserTnm, TnmAcceptLog, User } = require("../modules/user/userModal");
const { Find } = require("../models/factory");
const { defaultSort } = require("../config");

const getcreateUserTrn = async (body) => {
  await UserTnm.updateMany({ status: 1 }, { $set: { status: 0 } });
  const usertnm = await UserTnm.create(body);
  if (usertnm) {
    console.log("usertnm========>");
    await User.updateMany({}, { $set: { tnm: false } });

  }
  return usertnm;
};

const gettermsandConditions = async (Status, options) => {
  const { projection = {}, sort = defaultSort } = options || {};
  const Model = UserTnm;
  if (Status) {
    return await Find(Model, Status, projection, sort);
  } else {
    return await Find(Model, projection, sort);
  }

};
const acceptUser = async (body) => {

  const checkuseexist = await TnmAcceptLog.findOne({
    userId: body.userId,
  });
  if (checkuseexist) {
    const sFilter = {
      userId: body.userId
    };
    const sUpdate = {
      $set: {
        status: 0
      },
    };
    console.log("checkuseexist========>");
    await TnmAcceptLog.updateMany(sFilter, sUpdate);
  }

  //update tnm value in user table
  let savetnmdata = {
    tnmId: body.tnmId,
    userId: body.userId
  }
  const accept = await TnmAcceptLog.create(savetnmdata);

  //update tnm value in user table
  if (accept) {
    const sFilter = {
      _id: body.userId
    };
    const sUpdate = {
      $set: {
        tnm: true
      },
    };
    console.log("acceptUser========>");
    await User.updateOne(sFilter, sUpdate);
  }
  return accept;

};

module.exports = {
  getcreateUserTrn,
  gettermsandConditions,
  acceptUser
};
