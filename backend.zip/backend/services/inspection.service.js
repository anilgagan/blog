const logger = require("../config/logger");
const { Inspection } = require("../models");
const { Create, FindOneAndUpdate } = require("../models/factory");
const { checkRequiredArguments } = require("../functions/global.functions");

const createInspection = async (body) => {
  if (!checkRequiredArguments(body)) return;

  try {
    const inspection = await Create(Inspection, body);

    return inspection;
  } catch (error) {
    logger.error(error.message);
  }
};

const updateInspection = async (filter, update, options = {}) => {
  if (!checkRequiredArguments(filter, update)) return;

  try {
    const inspection = await FindOneAndUpdate(
      Inspection,
      filter,
      update,
      options
    );

    return inspection;
  } catch (error) {
    logger.error(error.message);
  }
};

module.exports = {
  createInspection,
  updateInspection,
};
