const logger = require("../config/logger");
const {
  makeObjectId,
  checkRequiredArguments,
  getFivePercentVat,
  customSort,
  todayDate,
  findAndJoinByKey,
  joinWithSymbol,
  getValuesByKey,
  uniqueItemsToArray,
  isNumberLessThanZero,
  makeAbsoluteNumber,
  makeObjectIds,
} = require("../functions/global.functions");
const {
  FindByIdAndUpdate,
  FindAndSort,
  FindOne,
  FindOneAndUpdate,
  Find,
  FindByIdWithKey,
  Create,
} = require("../models/factory");
const { Getpass, Inventory } = require("../modules/inventory/inventoryModal");
const {
  Sellerservice,
  SellerPayable,
  Salereciept,
} = require("../modules/saleReciept/saleRecieptModal");
const {
  Accountledger,
  Accountledgertemp,
} = require("../modules/account/accountModal");
const { defaultSort } = require("../config");
const { User } = require("../modules/user/userModal");
const common = require("../middleware/common-fun");
const { createCommonLog, updateCommonLog } = require("./comment.service");
const {
  updateSellerServiceAuctionEntries,
  updateSellerServiceStorageEntries,
  reverseCalculateAuctionServiceCharges,
  reverseCalculateStorageServiceCharges,
} = require("../helpers/saleReceipt.helper");

const updateGatePassOnPayment = async (
  inventoryId,
  sellerId,
  sellerServiceOrderNumbers
) => {
  try {
    if (
      !checkRequiredArguments(inventoryId, sellerId, sellerServiceOrderNumbers)
    )
      return;

    const Model = Sellerservice;

    const sFilter = {
      sellerId: makeObjectId(sellerId),
      inventoryId: makeObjectId(inventoryId),
      serviceType: "sold",
      recieptId: { $eq: null },
      serviceStatus: { $ne: "selfBid" }, // * to exclude self-bid case for updating gate pass
    };

    const isSoldService = await Find(Model, sFilter);

    // * Gate pass will only update AR payments
    // * Gate pass will not update for AP payments in which inventory is sold
    // * Update Seller Service Transaction Except Sold (Unsold + Self-bid)
    // * Update Gate pass with "in warehouse"
    if (!isSoldService.length > 0) {
      const filter = {
        inventoryId: makeObjectId(inventoryId),
        serviceType: "storage",
        status: "paid",
        saleOrderNo: { $in: sellerServiceOrderNumbers },
      };

      const update = { gatePassStatus: "issued" };
      await FindOneAndUpdate(Sellerservice, filter, update);

      const sFilter = {
        sellerId: makeObjectId(sellerId),
        inventoryId: makeObjectId(inventoryId),
        serviceType: "storage",
        status: { $nin: ["paid", "rejected"] },
      };

      // * check if all storages services are paid
      const areAllStorageServicesPaid = await Find(Model, sFilter);

      if (!areAllStorageServicesPaid.length > 0) {
        const filter = {
          referenceType: "inventory",
          status: "pending",
          inventoryId: makeObjectId(inventoryId),
        };

        const update = {
          status: "in warehouse",
          parkingDays: 0,
          gatePassExpired: todayDate(),
        };

        await FindOneAndUpdate(Getpass, filter, update);
      }
    }
  } catch (error) {
    logger.error(error);
  }
};

const updateGatePassBySellerPayableNo = async (payableNo) => {
  try {
    if (!checkRequiredArguments(payableNo)) return;

    const filter = { payableNo };
    const sellerPayable = await SellerPayable.findOne(filter);

    if (!sellerPayable) {
      logger.error("Seller Payable not found!");
      return;
    }

    const {
      inventoryId: [inventoryId],
      sellerId,
      sellerServiceOrderNumbers,
    } = sellerPayable;

    await updateGatePassOnPayment(
      inventoryId,
      sellerId,
      sellerServiceOrderNumbers
    );
  } catch (error) {
    logger.error(error);
  }
};

const updateSellerServiceAndSellerReceiptByPayableNo = async (
  payableNo,
  status
) => {
  if (!checkRequiredArguments(payableNo, status)) return;

  const filter = { payableNo };
  const update = { status };
  const sellerPayable = await SellerPayable.findOneAndUpdate(filter, update);

  if (!sellerPayable) {
    logger.error("Seller Payable not found!");
    return;
  }

  const {
    inventoryId: inventoryIds,
    sellerId,
    sellerServiceOrderNumbers,
  } = sellerPayable;

  for (const inventoryId of inventoryIds) {
    const sellerServiceFilter = {
      inventoryId: makeObjectId(inventoryId),
      sellerId: makeObjectId(sellerId),
      saleOrderNo: { $in: sellerServiceOrderNumbers },
    };
    const sellerReceiptFilter = {
      inventoryId: makeObjectId(inventoryId),
      sellerId: makeObjectId(sellerId),
    };

    const updateStatus = status === "rejected" ? "pending" : status;

    const update = { $set: { status: updateStatus } };

    await Sellerservice.updateMany(sellerServiceFilter, update);
    await Salereciept.findOneAndUpdate(sellerReceiptFilter, update);
  }
};

const updateInventoryPaymentCleared = async (inventoryId) => {
  try {
    if (!checkRequiredArguments(inventoryId)) return;

    const update = { isPaymentCleared: true };
    await FindByIdAndUpdate(Inventory, inventoryId, update);
  } catch (error) {
    logger.error(error);
  }
};

const processSellerData = async (
  inventoryId,
  sellerId,
  sellerServiceOrderNumbers
) => {
  const sortKey = "serviceType";
  const sortOrder = ["sold", "auction", "storage"];

  const filter = {
    sellerId: makeObjectId(sellerId),
    inventoryId: { $in: inventoryId },
    saleOrderNo: { $in: sellerServiceOrderNumbers },
  };

  const sellerServices = await FindAndSort(
    Sellerservice,
    filter,
    {},
    customSort(sortKey, sortOrder)
  );

  const data = [];

  if (sellerServices) {
    sellerServices.forEach((item) => {
      if (item.serviceType === "sold" && item.saleAmount > 0) {
        data.push({
          serviceType: item.serviceType,
          amount: item.saleAmount,
          discount: 0,
          taxableAmount: item.saleAmount,
          tax: "5%",
          vat: item.vatAmount,
          total: item.totalPayment,
        });
      }
      if (item.serviceType === "auction" && item.auctionFee > 0) {
        const auctionVat = Math.ceil(getFivePercentVat(item.auctionFee));
        data.push({
          serviceType: item.serviceType,
          amount: item.auctionFee + item.auctionDiscount,
          discount: item.auctionDiscount,
          taxableAmount: item.auctionFee - item.auctionDiscount,
          vat: auctionVat,
          tax: "5%",
          total: item.auctionFee + auctionVat,
        });
      }
      if (item.serviceType === "auction" && item.listingFee > 0) {
        const listingVat = Math.ceil(getFivePercentVat(item.listingFee));
        data.push({
          serviceType: "handling",
          amount: item.listingFee + item.listingDiscount,
          discount: item.listingDiscount,
          taxableAmount: item.listingFee - item.listingDiscount,
          vat: listingVat,
          tax: "5%",
          total: item.listingFee + listingVat,
        });
      }
      if (item.serviceType === "storage" && item.serviceCharge > 0) {
        data.push({
          serviceType: item.serviceType,
          amount: item.serviceCharge + item.storageDiscount,
          discount: item.storageDiscount,
          taxableAmount:
            item.serviceCharge + item.storageDiscount - item.storageDiscount,
          vat: item.vatAmount,
          tax: "5%",
          total: item.serviceCharge + item.vatAmount,
        });
      }
    });
  }

  return data;
};

// * circular dependency issue here, need to be fixed
const sellerSaleEntries = async (
  payableNo,
  voucherNo,
  paymentMethod,
  getGLByPaymentMethod,
  createAccountLedger
) => {
  if (!checkRequiredArguments(payableNo, voucherNo)) return;

  try {
    const filter = { payableNo };
    const sellerPayable = await FindOne(SellerPayable, filter);

    if (!sellerPayable) {
      logger.error("seller payable not found!");
      return;
    }

    const {
      _id: payableId,
      sellerId,
      branchId,
      balanceType,
      totalPayable,
      transactionDate,
      inventoryId: inventoryIds,
    } = sellerPayable;

    const iIds = inventoryIds.map((iId) => makeObjectId(iId));

    const iFilter = { _id: { $in: iIds } };
    const inventories = await Inventory.find(iFilter, { vin: 1 });

    const vin = findAndJoinByKey(inventories, "vin");
    const sellerNo = await FindByIdWithKey(User, sellerId, "uniqueIdentifier");
    const description = joinWithSymbol(", ", vin, sellerNo, payableNo);
    const vinNo = getValuesByKey(inventories, "vin", "single");

    const ledgerData = [];

    // #region - // * AUCTION CHARGES
    const sFilter = {
      inventoryId: { $in: iIds },
      sellerId: makeObjectId(sellerId),
      serviceType: "auction", // * sold|unsold|selfBid
      status: { $ne: "paid" },
    };

    const projection = {
      auctionFee: 1,
      listingFee: 1,
      vatAmount: 1,
      totalPayment: 1,
    };

    const auctionSellerService = await FindOne(
      Sellerservice,
      sFilter,
      projection,
      defaultSort
    );

    if (auctionSellerService) {
      const { auctionFee, listingFee, vatAmount } = auctionSellerService;

      // * auction-fee
      if (auctionFee > 0) {
        const auctionAccountId = await getGLByPaymentMethod("auction-fee");

        ledgerData.push({
          branchId: makeObjectId(branchId),
          glAccountId: makeObjectId(auctionAccountId),
          voucherNo: voucherNo,
          transactionType: "cr",
          paymentType: paymentMethod,
          payAmount: Number(auctionFee),
          description,
          referenceType: "seller auction receipt",
          referenceNo: payableNo,
          referenceNo2: vinNo,
          sellerNo: sellerNo,
          createdBy: "system",
          transDate: new Date(),
          transactionOf: "seller",
        });
      }

      // * handling-fee
      if (listingFee > 0) {
        const handlingAccountId = await getGLByPaymentMethod("handling-fee");

        ledgerData.push({
          branchId: makeObjectId(branchId),
          glAccountId: makeObjectId(handlingAccountId),
          voucherNo: voucherNo,
          transactionType: "cr",
          paymentType: paymentMethod,
          payAmount: Number(listingFee),
          description,
          referenceType: "seller listing receipt",
          referenceNo: payableNo,
          referenceNo2: vinNo,
          sellerNo: sellerNo,
          createdBy: "system",
          transDate: new Date(),
          transactionOf: "seller",
        });
      }

      // * storage-vat
      if (vatAmount > 0) {
        const storageVatAccountId = await getGLByPaymentMethod("storage-vat");

        ledgerData.push({
          branchId: makeObjectId(branchId),
          glAccountId: makeObjectId(storageVatAccountId),
          voucherNo: voucherNo,
          transactionType: "cr",
          paymentType: paymentMethod,
          payAmount: Number(vatAmount),
          description,
          referenceType: "seller storage-vat receipt",
          referenceNo: payableNo,
          referenceNo2: vinNo,
          sellerNo: sellerNo,
          createdBy: "system",
          transDate: new Date(),
          transactionOf: "seller",
        });
      }

      if (ledgerData.length > 0) await Accountledger.insertMany(ledgerData);
    }
    // #endregion

    // #region - // * STORAGE CHARGES
    const storageFilter = {
      inventoryId: { $in: iIds },
      sellerId: makeObjectId(sellerId),
      serviceType: "storage", // * storage
      status: { $ne: "paid" },
    };

    const storageProjection = {
      serviceCharge: 1,
      vatAmount: 1,
      totalPayment: 1,
    };

    const storageSellerService = await FindOne(
      Sellerservice,
      storageFilter,
      storageProjection,
      defaultSort
    );

    if (storageSellerService) {
      const { serviceCharge, vatAmount: storageVatAmount } =
        storageSellerService;

      // * storage - service charges
      if (serviceCharge > 0) {
        const ledgerStorage = {
          markAccountId: "storage",
          branchId,
          voucherNo,
          transactionType: "cr",
          paymentType: paymentMethod,
          payAmount: serviceCharge,
          description,
          referenceType: "seller storage receipt",
          referenceNo: payableNo,
          referenceNo2: vinNo,
          sellerNo,
          transactionOf: "seller",
        };

        await createAccountLedger(ledgerStorage);
      }

      // * storage - vat charges
      if (storageVatAmount > 0) {
        const ledgerStorageVat = {
          markAccountId: "storage-vat",
          branchId,
          voucherNo,
          transactionType: "cr",
          paymentType: paymentMethod,
          payAmount: storageVatAmount,
          description,
          referenceType: "seller storage-vat receipt",
          referenceNo: payableNo,
          referenceNo2: vinNo,
          sellerNo,
          transactionOf: "seller",
        };

        await createAccountLedger(ledgerStorageVat);
      }
    }
    // #endregion

    // #region - // * AP - PAYABLE-TO-SELLER
    if (balanceType === "AP" && totalPayable > 0) {
      const ledgerPayableToSeller = {
        branchId,
        voucherNo,
        markAccountId: "payable-to-seller",
        transactionType: balanceType === "AP" ? "dr" : "cr",
        paymentType: paymentMethod || "",
        payAmount: totalPayable,
        description,
        referenceType: "seller payable",
        referenceId: payableId,
        referenceNo: payableNo,
        referenceNo2: vinNo,
        transDate: transactionDate || null,
        addedFrom: balanceType === "AP" ? "op" : "ip",
        sellerNo,
        transactionOf: "seller",
      };

      await createAccountLedger(ledgerPayableToSeller);
    }
    // #endregion
  } catch (error) {
    logger.error(error);
  }
};

const addSellerPayable = async (data) => {
  if (!checkRequiredArguments(data)) return;

  const { netPayBalance } = data;

  try {
    const payableNo = await common.addPayable();
    const checkType = isNumberLessThanZero(netPayBalance);
    data.payableNo = payableNo;
    data.netPayBalance = makeAbsoluteNumber(netPayBalance);

    if (checkType) {
      data.balanceType = "AR";
      data.status = "processed";
    } else {
      data.balanceType = "AP";
    }

    const {
      auctionCharges,
      storageCharges,
      sale_order_no,
      auction_order_no,
      storage_order_no,
      createdBy = "system",
      ...rest
    } = data;

    const saleOrderNo = uniqueItemsToArray(
      sale_order_no,
      auction_order_no,
      storage_order_no
    );

    rest.sellerServiceOrderNumbers = saleOrderNo;

    const sellerPayable = await Create(SellerPayable, rest);

    if (!sellerPayable) {
      logger.error("Unable to create seller payable!");
      return false;
    }

    const {
      _id: payableId,
      payableNo: no,
      sellerId,
      inventoryId: [inventoryId],
    } = sellerPayable;

    const serviceFilter = {
      inventoryId: makeObjectId(inventoryId),
      saleOrderNo: { $in: saleOrderNo },
    };
    const receiptFilter = {
      inventoryId: makeObjectId(inventoryId),
    };

    const update = { status: "process" };

    await Sellerservice.updateMany(serviceFilter, update);
    await Salereciept.findOneAndUpdate(receiptFilter, update);

    await updateSellerServiceAuctionEntries(
      inventoryId,
      sellerId,
      auctionCharges
    );

    await updateSellerServiceStorageEntries(
      inventoryId,
      sellerId,
      storageCharges
    );

    await createCommonLog({
      action: "Created",
      from: "Sales",
      id: payableId,
      of: "seller",
      no,
      by: createdBy,
    });

    return sellerPayable;
  } catch (error) {
    logger.error(error);
  }
};

const updateSellerPayable = async (data) => {
  if (!checkRequiredArguments(data)) return;

  const { sellerpaybaleId: sellerPayableId, ...rest } = data;

  try {
    const projection = { new: true };
    const sellerPayable = await FindByIdAndUpdate(
      SellerPayable,
      sellerPayableId,
      rest,
      projection
    );

    if (!sellerPayable) {
      logger.error("Seller payable not found!");
      return;
    }

    const {
      _id: payableId,
      inventoryId: inventoryIds,
      inventoryId: [inventoryId] = [],
      sellerId,
      payableNo,
      status,
      createdBy = "system",
      sellerServiceOrderNumbers,
    } = sellerPayable;

    if (status === "approved") {
      const {
        branchId,
        paymentMethod,
        netPayBalance,
        glAccountId,
        transactionDate,
        balanceType,
        payableStatus,
      } = sellerPayable;

      const iFilter = { _id: { $in: makeObjectIds(inventoryIds) } };
      const inventories = await Inventory.find(iFilter, { vin: 1 });

      const vin = findAndJoinByKey(inventories, "vin");
      const sellerNo = await FindByIdWithKey(
        User,
        sellerId,
        "uniqueIdentifier"
      );
      const description = joinWithSymbol(", ", vin, sellerNo, payableNo);

      const vinNo = getValuesByKey(inventories, "vin", "single");

      // * Account Ledger Temp Entries
      const voucherNoUnique = await common.getempGlNo();

      const accountLedgerAPCR = {
        branchId,
        voucherNo: voucherNoUnique,
        glAccountId,
        transactionType: balanceType === "AP" ? "cr" : "dr",
        paymentType: paymentMethod || "",
        payAmount: netPayBalance,
        description,
        referenceType: "seller payable",
        referenceId: payableId,
        referenceNo: payableNo,
        referenceNo2: vinNo,
        balanceAmount: netPayBalance,
        createdBy: "system",
        transDate: transactionDate || null,
        addedFrom: balanceType === "AP" ? "op" : "ip",
        createdFrom: "Seller Payable",
        status: "approved",
        sellerNo,
        transactionOf: "seller",
        payableType: balanceType,
        payableStatus,
      };

      const tempEntry = await Accountledgertemp.create(accountLedgerAPCR);

      // * log hierarchy
      await updateCommonLog({
        action: "Approved",
        from: "Sales",
        id: payableId,
        no: payableNo,
        by: createdBy,
      });

      return tempEntry;
    }

    if (status === "processed") {
      await updateCommonLog({
        action: "Processed",
        from: "Sales",
        id: payableId,
        no: payableNo,
        by: createdBy,
      });
    }

    if (status === "rejected") {
      // * status-update
      const sellerServiceFilter = {
        inventoryId: { $in: inventoryIds },
        sellerId: makeObjectId(sellerId),
        saleOrderNo: { $in: sellerServiceOrderNumbers },
      };
      const sellerReceiptFilter = {
        inventoryId: makeObjectId(inventoryId),
        sellerId: makeObjectId(sellerId),
      };
      const update = { status: "pending" };

      await Sellerservice.updateMany(sellerServiceFilter, update);
      await Salereciept.findOneAndUpdate(sellerReceiptFilter, update);

      // * reverse-entries
      await reverseCalculateAuctionServiceCharges(
        inventoryId,
        sellerId,
        sellerServiceOrderNumbers
      );

      await reverseCalculateStorageServiceCharges(
        inventoryId,
        sellerId,
        sellerServiceOrderNumbers
      );

      await updateCommonLog({
        action: "Rejected",
        from: "Sales",
        id: payableId,
        no: payableNo,
        by: createdBy,
      });
    }
  } catch (error) {
    logger.error(error);
  }
};

module.exports = {
  updateGatePassOnPayment,
  updateGatePassBySellerPayableNo,
  updateSellerServiceAndSellerReceiptByPayableNo,
  updateInventoryPaymentCleared,
  processSellerData,
  sellerSaleEntries,
  addSellerPayable,
  updateSellerPayable,
};
