const { Commentlog } = require("../modules/user/userModal");
const { Find, UpdateOne, Aggregate } = require("../models/factory");
const { defaultSort, dateFormats } = require("../config");
const {
  checkRequiredArguments,
  todayDate,
} = require("../functions/global.functions");
const {
  Project,
  ExactMatch,
  IDMatch,
  Sort,
  Limit,
} = require("../functions/mongoose.functions");

const createComment = async (body) => {
  const comment = await Commentlog.create(body);
  return comment;
};

const getComment = async (filter, options) => {
  const { projection = {}, sort = defaultSort } = options || {};

  const Model = Commentlog;

  return await Find(Model, filter, projection, sort);
};

const updateComment = async (filter, update) => {
  const Model = Commentlog;

  return await UpdateOne(Model, filter, update);
};

const createCommonLog = async (data) => {
  if (!checkRequiredArguments(data)) return;

  const { action, from, id, of, no, by } = data;

  const message = `${from} - ${action}: ${no} By ${by} At ${todayDate(
    dateFormats.DateTime24Hr
  )}`;

  const comment = {
    referenceName: no,
    referenceType: of,
    referenceId: id,
    commentBy: by,
    hierarchy: {
      message,
      by,
    },
  };

  await createComment(comment);
};

const updateCommonLog = async (data) => {
  if (!checkRequiredArguments(data)) return;

  const { action, from, id, no, by } = data;

  const message = `${from} - ${action}: ${no} By ${by} At ${todayDate(
    dateFormats.DateTime24Hr
  )}`;

  const hierarchy = {
    message,
    by,
  };

  const filter = { referenceId: id, referenceName: no };
  const update = { $push: { hierarchy } };

  await updateComment(filter, update);
};

const getCommentHierarchy = async (query) => {
  const { referenceName, referenceType, referenceId } = query;

  const pipeline = [];

  if (referenceName) ExactMatch(pipeline, "referenceName", referenceName);
  if (referenceType) ExactMatch(pipeline, "referenceType", referenceType);
  if (referenceId) IDMatch(pipeline, "referenceId", referenceId);

  const project = {
    hierarchy: 1,
    createdAt: 1,
  };

  Project(pipeline, project);

  Sort(pipeline, defaultSort);
  Limit(pipeline, 1);

  const results = await Aggregate(Commentlog, pipeline);

  return results;
};

module.exports = {
  createComment,
  getComment,
  updateComment,
  createCommonLog,
  updateCommonLog,
  getCommentHierarchy,
};
