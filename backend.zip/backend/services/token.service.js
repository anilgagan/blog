const logger = require("../config/logger");
const { checkRequiredArguments } = require("../functions/global.functions");
const { Token } = require("../models");
const { Create, FindOne, FindOneAndUpdate } = require("../models/factory");

const {
  tokenTypes: { SMS },
} = require("../config/tokens");

const createToken = async (body) => {
  if (!checkRequiredArguments(body)) return;

  try {
    const token = await Create(Token, body);
    return token;
  } catch (error) {
    logger.error(error.message);
  }
};

const getToken = async (filter) => {
  if (!checkRequiredArguments(filter)) return;

  try {
    const token = await FindOne(Token, filter);
    return token;
  } catch (error) {
    logger.error(error.message);
  }
};

const updateToken = async (filter, update, options) => {
  if (!checkRequiredArguments(filter, update, options)) return;

  try {
    const token = await FindOneAndUpdate(Token, filter, update, options);
    return token;
  } catch (error) {
    logger.error(error.message);
  }
};

const getSMSToken = async () => {
  try {
    const filter = { type: SMS };
    const token = await getToken(filter);
    return token;
  } catch (error) {
    logger.error(error.message);
  }
};

const updateSMSToken = async (token) => {
  if (!checkRequiredArguments(token)) return;

  try {
    const filter = { type: SMS };
    const update = { token };
    const projection = { new: true };
    const newToken = await updateToken(filter, update, projection);
    return newToken;
  } catch (error) {
    logger.error(error.message);
  }
};

module.exports = {
  createToken,
  getToken,
  updateToken,
  getSMSToken,
  updateSMSToken,
};
