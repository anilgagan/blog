const mongoose = require("mongoose");
const { Bid, bidHistoryLog } = require("../modules/bid/bidModal");
const { Auction, Auctionvehicle } = require("../modules/auction/auctionModal");
const { Watchlist, Inventory } = require("../modules/inventory/inventoryModal");
const {
  makeObjectId,
  checkRequiredArguments,
} = require("../functions/global.functions");
const logger = require("../config/logger");
const {
  FindByIdAndUpdate,
  FindOneAndUpdate,
  Delete,
  FindOne,
} = require("../models/factory");
const { defaultSort } = require("../config");

const createBidHistoryLog = async (auctionId, inventoryId) => {
  try {
    if (!checkRequiredArguments(auctionId, inventoryId)) return;

    const data = await Bid.find({
      auctionId: mongoose.Types.ObjectId(auctionId),
      inventoryId: mongoose.Types.ObjectId(inventoryId),
    });

    bidHistoryLog.insertMany(data).then(async (result) => {
      const ids = data.map((ele) => {
        return mongoose.Types.ObjectId(ele._id);
      });

      const auctionIds = data.map((ele) => {
        return mongoose.Types.ObjectId(ele.auctionId);
      });

      Bid.remove({ _id: { $in: ids } }).then(async (result) => {
        await Auction.updateMany(
          { _id: { $in: auctionIds } },
          { $set: { isAuctionEnded: true } }
        );
      });
    });
  } catch (error) {
    logger.error(error);
  }
};

const removeInventoryFromWatchList = async (userId, inventoryId) => {
  if (!checkRequiredArguments(userId, inventoryId)) return;

  const filter = {
    inventoryId: makeObjectId(inventoryId),
    buyerId: makeObjectId(userId),
  };

  const watchDoc = await Watchlist.findOne(filter);

  if (!watchDoc) return;

  await watchDoc.remove();
};

const removeInventoriesFromWatchList = async (auctionId, inventoryId) => {
  if (!checkRequiredArguments(auctionId, inventoryId)) return;

  const filter = {
    auctionId: makeObjectId(auctionId),
    inventoryId: makeObjectId(inventoryId),
  };

  await Delete(Watchlist, filter);
};

const handleRejectedBid = async (id, body) => {
  if (!checkRequiredArguments(id, body)) return;

  const { comments } = body;
  const projection = { new: true };

  // * Bid History
  const bUpdate = { comments, status: "UnSold" };
  const bidDoc = await FindByIdAndUpdate(
    bidHistoryLog,
    id,
    bUpdate,
    projection
  );

  // * Auction Vehicle
  const { auctionId, inventoryId } = bidDoc;
  const aFilter = { auctionId, inventoryId };
  const aUpdate = { status: "unsold" };
  await FindOneAndUpdate(Auctionvehicle, aFilter, aUpdate, projection);

  // * Inventory
  const iUpdate = { inventoryStatus: 1 };
  await FindByIdAndUpdate(Inventory, inventoryId, iUpdate);

  return bidDoc;
};

const getBid = async (auctionId, inventoryId) => {
  try {
    const filter = {
      auctionId: makeObjectId(auctionId),
      inventoryId: makeObjectId(inventoryId),
    };

    const projection = { calcAmount: 1 };

    const bid = await FindOne(Bid, filter, projection, defaultSort);

    return bid;
  } catch (error) {
    logger.error(error);
  }
};

const checkReserveStatus = async (
  auctionId,
  inventoryId,
  startingBid,
  reservePrice
) => {
  try {
    const bid = await getBid(auctionId, inventoryId);
    let isApproved;

    if (bid) {
      if (bid.calcAmount >= reservePrice) {
        isApproved = true;
      } else if (startingBid >= reservePrice) {
        isApproved = true;
      } else {
        isApproved = false;
      }
    }

    return isApproved;
  } catch (error) {
    logger.error(error);
  }
};

module.exports = {
  createBidHistoryLog,
  removeInventoryFromWatchList,
  removeInventoriesFromWatchList,
  handleRejectedBid,
  getBid,
  checkReserveStatus,
};
