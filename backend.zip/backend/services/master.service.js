const { CustomService } = require("../modules/master/masterModal");
const { defaultSort } = require("../config");
const { checkRequiredArguments } = require("../functions/global.functions");

const {
  ExactMatch,
  RegexSearch,
  Project,
  Sort,
  Skip,
  Limit,
  IDMatch,
  Lookup,
  Unwind,
} = require("../functions/mongoose.functions");

const {
  Create,
  MultiAggregate,
  FindByIdAndUpdate,
  DeleteById,
  FindById,
} = require("../models/factory");

const common = require("../middleware/common-fun");
const logger = require("../config/logger");

const createCustomService = async (body) => {
  if (!checkRequiredArguments(body)) return;

  const createService = await Create(CustomService, body);
  return createService;
};

const getCustomServices = async (query) => {
  const { name, glId, status, search, page, pageLimit } = query;

  const pipeline = [];

  if (name) ExactMatch(pipeline, "name", name);
  if (glId) IDMatch(pipeline, "glId", glId);
  if (status) ExactMatch(pipeline, "status", status);
  if (search) {
    const searchFields = ["name", "glId", "services", "status"];
    RegexSearch(pipeline, searchFields, search);
  }

  // * accountMaster
  Lookup(pipeline, "accountmasters", "glId", "_id", "accountMaster");
  Unwind(pipeline, "$accountMaster");

  const project = {
    name: 1,
    glId: 1,
    status: 1,
    services: 1,
    createdAt: 1,
    accountMaster: 1,
  };

  Project(pipeline, project);

  Sort(pipeline, defaultSort);

  const count = [...pipeline];
  count.push({ $count: "totalCount" });

  if (page) {
    Skip(pipeline, common.pageOffset(page, pageLimit));
    Limit(pipeline, common.pageLimit(pageLimit));
  }

  const [result, [{ totalCount } = {}] = []] = await MultiAggregate(
    CustomService,
    [pipeline, count]
  );

  return { result, totalCount };
};

const getCustomService = async (id) => {
  if (!checkRequiredArguments(id)) return;

  const getService = await FindById(CustomService, id);

  if (!getService) {
    logger.error("Custom service not found!");
    return;
  }

  return getService;
};

const updateCustomService = async (id, body) => {
  if (!checkRequiredArguments(id, body)) return;

  const projection = { new: true };
  const updateService = await FindByIdAndUpdate(
    CustomService,
    id,
    body,
    projection
  );

  if (!updateService) {
    logger.error("Custom service not found!");
    return;
  }

  return updateService;
};

const deleteCustomService = async (id) => {
  if (!checkRequiredArguments(id)) return;

  const deleteService = await DeleteById(CustomService, id);

  if (!deleteService) {
    logger.error("Custom service not found!");
    return;
  }

  return deleteService;
};

module.exports = {
  createCustomService,
  getCustomServices,
  getCustomService,
  updateCustomService,
  deleteCustomService,
};
