const { docPrefix } = require("../config");
const logger = require("../config/logger");
const Voucher = require("../models/voucher.model");

/**
 * Create vouchers
 * @param {Object} body
 * @returns {Promise<Voucher>}
 */
const createVouchers = async (body) => {
  const voucherArray = [];

  const prefixes = await Voucher.distinct("name");

  const objPrefixes = Object.keys(docPrefix);

  const missingPrefixes = objPrefixes.filter(
    (prefix) => !prefixes.includes(prefix)
  );

  for (const name of missingPrefixes) {
    const prefix = docPrefix[name];
    const value = 100101;
    const uniqueNo = prefix + String(value);

    voucherArray.push({
      name,
      prefix,
      value,
      uniqueNo,
    });
  }

  const vouchers = await Voucher.create(voucherArray);
  return vouchers;
};

/**
 * Get a unique incremented voucher no
 * @param {String} prefix
 * @param {String} uniqueNo
 * @returns {Number} uniqueNO
 */

// const case1 = null; // first time, new
// const case2 = "SRC100101"; // found one from start
// const case3 = "SRC100101"; // failed to update
// const case4 = "SRC100113"; // found one but already started - same prefix | different value
// const case5 = "S100115"; //  prefix and value changed from old to new - different prefix & value

const getUniqueVoucherNo = async (prefix, uniqueNo) => {
  // console.log("here in getUniqueVoucherNo and prefix is:", prefix);
  // console.log("here in getUniqueVoucherNo and uniqueNo is:", uniqueNo);
  try {
    let uniqueNO = 0;

    if (uniqueNo === "0") {
      logger.error("Failed to get a unique voucher number: uniqueNo is '0'");
      throw new Error("Failed to get a unique voucher number: uniqueNo is '0'");
    }

    if (uniqueNo) {
      const stringNumber = extractStringAndNumber(uniqueNo);
      const filter = { prefix, uniqueNo };
      const projection = { new: true, projection: { uniqueNo: 1 } };

      const doc = await Voucher.findOne(filter);

      if (!doc) {
        const filter = { prefix };
        const previousUniqueNumber = await Voucher.findOne(filter);

        const { prefix: thisPrefix, number: thisNumber } = stringNumber;
        const {
          prefix: docPrefix,
          value: docValue,
          uniqueNo: docUniqueNo,
        } = previousUniqueNumber;

        // * case 3
        if (
          thisPrefix === docPrefix &&
          uniqueNo !== docUniqueNo &&
          thisNumber < docValue
        ) {
          // console.log("here in CASE 3 ==============================");
          const uniqueNumber = await Voucher.findOne(
            { prefix },
            { uniqueNo: 1 }
          );
          uniqueNO = uniqueNumber.uniqueNo;
        } else if (
          thisPrefix === docPrefix &&
          uniqueNo !== docUniqueNo &&
          thisNumber > docValue
        ) {
          // * case 4
          // console.log("here in CASE 4 ==============================");
          let previousValue = stringNumber.number;
          const previousUniqueNo = `${
            previousUniqueNumber.prefix
          }${++previousValue}`;

          const update = {
            value: previousValue,
            uniqueNo: previousUniqueNo,
          };

          const updatedDoc = await Voucher.findOneAndUpdate(
            filter,
            update,
            projection
          );

          if (updatedDoc) uniqueNO = updatedDoc.uniqueNo;
        } else {
          // * case 5
          // console.log("here in CASE 5 ==============================");
          let previousValue = stringNumber.number;
          const previousUniqueNo = `${prefix}${++previousValue}`;

          const update = {
            value: previousValue,
            uniqueNo: previousUniqueNo,
          };

          const updatedDoc = await Voucher.findOneAndUpdate(
            filter,
            update,
            projection
          );

          if (updatedDoc) uniqueNO = updatedDoc.uniqueNo;
        }
      } else {
        // console.log("here in CASE 2 ==============================");
        // * case2
        const incrementUniqueNo = `${doc.prefix}${++doc.value}`;

        const update = {
          $inc: { value: 1 },
          uniqueNo: incrementUniqueNo,
        };

        const updatedDoc = await Voucher.findOneAndUpdate(
          filter,
          update,
          projection
        );

        if (updatedDoc) uniqueNO = updatedDoc.uniqueNo;
      }
    } else {
      // console.log("here in CASE 1 ==============================");
      // * case 1
      const uniqueNumber = await Voucher.findOne({ prefix }, { uniqueNo: 1 });
      uniqueNO = uniqueNumber.uniqueNo;
    }

    if (uniqueNO === 0) {
      logger.error("Failed to generate a unique voucher number: uniqueNO is 0");
      throw new Error(
        "Failed to generate a unique voucher number: uniqueNO is 0"
      );
    }

    return uniqueNO;
  } catch (error) {
    console.error(error.message);
  }
};

const extractStringAndNumber = (input) => {
  const match = input.match(/([A-Z]+)(\d+)/);

  if (match) {
    const extractedString = match[1];
    const extractedNumber = parseInt(match[2]);
    return { prefix: extractedString, number: extractedNumber };
  } else {
    console.error("Invalid input format");
  }
};

module.exports = {
  createVouchers,
  getUniqueVoucherNo,
};
