const { makeObjectId } = require("../functions/global.functions");
const { Inventory } = require("../modules/inventory/inventoryModal");

/**
 * Get Seller Analytics
 * @param {ObjectId} userId
 * @returns {Promise<Analytics>}
 */

const getSellerDashboardAnalytics = async (userId) => {
  try {
    const filter = { sellerId: makeObjectId(userId) };

    const uAggregate = [
      {
        $match: filter,
      },
      {
        $lookup: {
          from: "auctionvehicles",
          let: {
            inventoryId: "$_id",
          },
          pipeline: [
            {
              $match: {
                $expr: {
                  $and: [
                    { $eq: ["$inventoryId", "$$inventoryId"] },
                    { $eq: ["$status", "unsold"] },
                  ],
                },
              },
            },
          ],
          as: "auctionVehicles",
        },
      },
      {
        $unwind: { path: "$auctionVehicles", preserveNullAndEmptyArrays: true },
      },
      {
        $group: {
          _id: null,
          count: { $sum: 1 },
        },
      },
      {
        $project: {
          _id: 0,
          count: 1,
        },
      },
    ];

    const aAggregate = [
      {
        $match: filter,
      },
      {
        $lookup: {
          from: "auctions",
          let: {
            inventoryId: "$_id",
          },
          pipeline: [
            {
              $match: {
                $expr: {
                  $and: [
                    { $in: ["$$inventoryId", "$inventoryId"] },
                    { $eq: ["$isAuctionEnded", false] },
                  ],
                },
              },
            },
          ],
          as: "auctions",
        },
      },
      {
        $unwind: "$auctions",
      },
      {
        $group: {
          _id: null,
          count: { $sum: 1 },
        },
      },
      {
        $project: {
          _id: 0,
          count: 1,
        },
      },
    ];

    const sAggregate = [
      {
        $match: filter,
      },
      {
        $lookup: {
          from: "sellerservices",
          let: { inventoryId: "$_id", sellerId: "$sellerId" },
          pipeline: [
            {
              $match: {
                $expr: {
                  $and: [
                    { $eq: ["$inventoryId", "$$inventoryId"] },
                    { $eq: ["$sellerId", "$$sellerId"] },
                    { $eq: ["$status", "process"] },
                    { $eq: ["$serviceType", "storage"] },
                  ],
                },
              },
            },
          ],
          as: "storage",
        },
      },
      { $unwind: "$storage" },
      {
        $group: {
          _id: null,
          totalStorage: { $sum: "$storage.totalPayment" },
        },
      },
      {
        $project: {
          _id: 0,
          totalStorage: "$totalStorage",
        },
      },
    ];

    const pAggregate = [
      {
        $match: filter,
      },
      {
        $lookup: {
          from: "sellerpayables",
          let: { inventoryId: "$_id" },
          pipeline: [
            {
              $match: {
                $expr: {
                  $and: [
                    { $in: ["$$inventoryId", "$inventoryId"] },
                    { $eq: ["$status", "approved"] },
                  ],
                },
              },
            },
          ],
          as: "payable",
        },
      },
      { $unwind: "$payable" },
      {
        $group: {
          _id: "$payable._id",
          totalPayable: { $sum: "$payable.totalPayable" },
          totalReceivable: { $sum: "$payable.totalReceivable" },
        },
      },
      {
        $group: {
          _id: null,
          totalPayable: { $sum: "$totalPayable" },
          totalReceivable: { $sum: "$totalReceivable" },
        },
      },
      {
        $project: {
          _id: 0,
          totalPayable: "$totalPayable",
          totalReceivable: "$totalReceivable",
        },
      },
    ];

    const totalVehicles = await Inventory.countDocuments(filter);

    const totalPendingVehicles = await Inventory.countDocuments({
      ...filter,
      inventoryStatus: 1,
    });

    const totalApprovedVehicles = await Inventory.countDocuments({
      ...filter,
      inventoryStatus: 0,
    });

    const runAggregate = async (pipeline) => {
      const result = await Inventory.aggregate(pipeline);
      return result.length > 0 ? result : [];
    };
    const getMetricCount = async (payStatus) => {
      const pipeline = [
        { $match: filter },
        {
          $lookup: {
            from: "reciepts",
            let: { inventoryId: "$_id" },
            pipeline: [
              {
                $match: {
                  $expr: {
                    $and: [
                      { $eq: ["$inventoryId", "$$inventoryId"] },
                      { $eq: ["$payStatus", payStatus] },
                    ],
                  },
                },
              },
            ],
            as: "receipts",
          },
        },
        { $unwind: "$receipts" },
        {
          $group: {
            _id: null,
            count: { $sum: 1 },
          },
        },
        {
          $project: {
            _id: 0,
            count: 1,
          },
        },
      ];

      return await runAggregate(pipeline);
    };

    const [{ count: totalSoldVehicles = 0 } = {}] = await getMetricCount(1);
    const [{ count: totalHoldbackVehicles = 0 } = {}] = await getMetricCount(0);
    const [{ count: totalUnsoldVehicles = 0 } = {}] = await runAggregate(
      uAggregate
    );
    const [{ count: totalVehiclesInAuction = 0 } = {}] = await runAggregate(
      aAggregate
    );
    const [{ totalStorage: totalStorage = 0 } = {}] = await runAggregate(
      sAggregate
    );
    const [
      {
        totalPayable: totalPayable = 0,
        totalReceivable: totalReceivable = 0,
      } = {},
    ] = await runAggregate(pAggregate);

    const analytics = {
      totalVehicles,
      totalPendingVehicles,
      totalApprovedVehicles,
      totalSoldVehicles,
      totalHoldbackVehicles,
      totalUnsoldVehicles,
      totalVehiclesInAuction,
      totalVehiclesPayable: Math.round(totalPayable),
      totalVehiclesReceivable: Math.round(totalReceivable),
      totalVehiclesStorage: Math.round(totalStorage),
      totalVehiclesEarning: Math.max(
        Math.round(totalPayable - totalReceivable - totalStorage),
        0
      ),
    };

    return analytics;
  } catch (error) {
    console.error("Error fetching seller analytics: ", error);
  }
};

module.exports = {
  getSellerDashboardAnalytics,
};
