const logger = require("../config/logger");
const {
  makeObjectId,
  createNewMongoDoc,
  checkRequiredArguments,
  removeFieldsFromObject,
  manipulateDate,
  todayDate,
} = require("../functions/global.functions");
const {
  FindOneWithKey,
  FindById,
  FindOneAndUpdate,
  FindOne,
  FindByIdAndUpdate,
  Create,
} = require("../models/factory");
const {
  Inventory,
  Carwisesellerplan,
  Getpass,
  Getdocument,
  Sellermappingbranch,
} = require("../modules/inventory/inventoryModal");
const { Sellerplan } = require("../modules/master/masterModal");
const { Vinimage } = require("../modules/vin/vinModal");

const makeInventoryRelatedCopies = async (inventoryId, copyType, createdBy) => {
  try {
    if (!checkRequiredArguments(inventoryId, copyType)) return;
    const oldInventoryUpdate = {
      unsold: {
        $set: { inventcopy: 1, inventoryStatus: 5, forReAuction: true },
      },
      return: { $set: { inventcopy: 1 } },
    };

    const oldGatePassStatus = {
      unsold: "re-auction",
      return: "cancelled",
    };

    const inventoryUpdate = oldInventoryUpdate[copyType];
    const gatePassStatus = oldGatePassStatus[copyType];

    // * makeInventoryCopy
    const {
      _id: newInventoryId,
      sellerId,
      branchId,
    } = await makeInventoryCopy(inventoryId, inventoryUpdate, createdBy);

    // * carWiseSellerPlanCopy
    await carWiseSellerPlanCopy(newInventoryId, sellerId, branchId);

    // * vinImagesCopy
    await vinImagesCopy(inventoryId, newInventoryId);

    // * update gate pass and document pass with status: gatePassStatus and inventoryId
    const filter = { direction: "out", inventoryId: makeObjectId(inventoryId) };
    const update = {
      $set: { status: gatePassStatus },
    };

    await Getpass.updateOne(filter, update);
    await Getdocument.updateOne(filter, update);

    return true;
  } catch (error) {
    console.error("makeInventoryRelatedCopies error : ", error);
  }
};

const makeInventoryCopy = async (inventoryId, inventoryUpdate, createdBy) => {
  const filter = { _id: makeObjectId(inventoryId) };

  const inventory = await Inventory.findOneAndUpdate(filter, inventoryUpdate);
  if (!inventory) {
    console.error("inventory not found!");
    return;
  }

  let newInventory = createNewMongoDoc(inventory);
  newInventory = removeFieldsFromObject(
    newInventory,
    "isPaymentCleared",
    "forReAuction",
    "completeRuns"
  );
  newInventory.inventoryStatus = 1;
  newInventory.createdBy = createdBy;

  const newInventoryDoc = await Inventory.create(newInventory);
  return newInventoryDoc;
};

const carWiseSellerPlanCopy = async (newInventoryId, sellerId, branchId) => {
  const newInventoryID = makeObjectId(newInventoryId);
  const sellerID = makeObjectId(sellerId);
  const branchID = makeObjectId(branchId);

  const filter = {
    sellerId: sellerID,
    branchId: branchID,
  };

  const planId = await FindOneWithKey(Sellermappingbranch, filter, "planId");

  const sellerPlan = await FindById(Sellerplan, planId);

  if (!sellerPlan) {
    console.error("seller plan not found!");
    return;
  }

  const newCarWiseSellerPlan = createNewMongoDoc(sellerPlan);
  newCarWiseSellerPlan.inventoryId = newInventoryID;
  newCarWiseSellerPlan.sellerId = sellerID;
  newCarWiseSellerPlan.branchId = branchID;

  await Carwisesellerplan.create(newCarWiseSellerPlan);
};

const vinImagesCopy = async (oldInventoryId, newInventoryId) => {
  const newVinImages = [];
  const filter = {
    referenceId: makeObjectId(oldInventoryId),
  };

  const vinImages = await Vinimage.find(filter);
  if (!vinImages.length) {
    console.error("vin images not found!");
    return;
  }

  for (const vinImage of vinImages) {
    let newVinImage = createNewMongoDoc(vinImage);
    newVinImage.referenceId = makeObjectId(newInventoryId);
    newVinImages.push(newVinImage);
  }

  await Vinimage.create(newVinImages);
};

const updateCarWisePlanWithInventoryId = async (inventoryId) => {
  if (!checkRequiredArguments(inventoryId)) return;

  try {
    const iProjection = { sellerId: 1, branchId: 1 };
    const inventory = await FindById(Inventory, inventoryId, iProjection);

    if (!inventory) {
      logger.error("Inventory not found!");
      return;
    }

    const { sellerId, branchId } = inventory;

    const sFilter = { sellerId, branchId };
    const planId = await FindOneWithKey(Sellermappingbranch, sFilter, "planId");

    const sellerPlan = await FindById(Sellerplan, planId);

    const {
      listingFee,
      runs,
      auctionTypeFee,
      increment,
      amountValue,
      status,
      parkingDays,
      storage,
      initialfee,
      planName,
    } = sellerPlan;

    const cFilter = {
      sellerId,
      branchId,
      inventoryId,
    };
    const cUpdate = {
      listingFee,
      runs,
      auctionTypeFee,
      increment,
      amountValue,
      status,
      parkingDays,
      storage,
      initialfee,
      planName,
    };

    const cOptions = { upsert: true, new: true, setDefaultsOnInsert: true };
    await FindOneAndUpdate(Carwisesellerplan, cFilter, cUpdate, cOptions);

    return true;
  } catch (error) {
    logger.error(error);
    return false;
  }
};

const getSellerGatePassExpiryDate = async (inventoryId) => {
  if (!checkRequiredArguments(inventoryId)) return;

  try {
    const iProjection = { branchId: 1, sellerId: 1 };
    const inventory = await FindById(Inventory, inventoryId, iProjection);

    if (!inventory) {
      logger.error("inventory not found!");
      return;
    }

    const { sellerId, branchId } = inventory;

    const cFilter = {
      inventoryId,
      sellerId,
      branchId,
    };
    let parkingDays = await FindOneWithKey(
      Carwisesellerplan,
      cFilter,
      "parkingDays"
    );

    if (!parkingDays) {
      logger.error("car wise parking days not found, shifting to default: 0");
      parkingDays = 0;
    }

    const gatePassExpiryDate = manipulateDate(todayDate(), "add", parkingDays);
    return gatePassExpiryDate;
  } catch (error) {
    logger.error(error);
  }
};

const withdrawInventory = async (inventoryId, type, common) => {
  if (!checkRequiredArguments(inventoryId)) return;

  try {
    // * inventory check
    inventoryId = makeObjectId(inventoryId);

    const filter = {
      _id: inventoryId,
      inventoryStatus: { $in: [0, 1, 2] },
      inventoryType: "indirect",
    };

    const projection = { sellerId: 1, vin: 1, branchId: 1, warehosId: 1 };

    const inventory = await FindOne(Inventory, filter, projection);

    if (!inventory) {
      throw new Error("inventory not found or should be indirect in [0, 1, 2]");
    }

    const { sellerId, vin, branchId, warehosId } = inventory;

    // * service charge

    const unsoldCharges = await common.unsoldcalauctionwithsellerservice(
      inventoryId,
      sellerId,
      null,
      type
    );

    if (!unsoldCharges) {
      throw new Error("error while calculating service charge");
    }

    // * gate pass

    const gatePassExpired = await getSellerGatePassExpiryDate(inventoryId);
    const passNoUnique = await common.getPassNo();
    const docNoUnique = await common.getDocumentpass();

    const gatePass = {
      passNo: passNoUnique,
      direction: "out",
      referenceType: "inventory",
      referenceNo: vin,
      inventoryId,
      status: "pending",
      gatePassExpired,
      gatePassExpiredDate: gatePassExpired,
      createdBy: "system",
    };

    await Create(Getpass, gatePass);

    // * document pass

    const documentPass = {
      passNo: docNoUnique,
      direction: "out",
      referenceType: "inventory",
      referenceNo: vin,
      status: "pending",
      inventoryId,
      branchId,
      warehosId,
      createdBy: "system",
    };

    await Create(Getdocument, documentPass);

    // * inventory unsold

    const update = { inventoryStatus: 4 };
    const project = { new: true };

    return await FindByIdAndUpdate(Inventory, inventoryId, update, project);
  } catch (error) {
    throw error;
  }
};

module.exports = {
  makeInventoryRelatedCopies,
  updateCarWisePlanWithInventoryId,
  getSellerGatePassExpiryDate,
  withdrawInventory,
};
