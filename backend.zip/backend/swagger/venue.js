/**
 * @swagger
 * definitions:
 *  VenueList:
 *   type: object
 *   properties:
 *    cId:
 *     type: string
 *     description: category id
 *     example: ''
 *    cType:
 *     type: string
 *     description: category id
 *     example: 'venue'
 *    page:
 *     type: string
 *     description: page no.
 *     example: '1'
 *    pageLimit:
 *     type: string
 *     description: page limit
 *     example: '10'
 *    search:
 *     type: string
 *     description: search by name
 *     example: ''
 *
 */















/**
 * @swagger
 *
 *
 * /category/list?WRONG:
 *   post:
 *     summary: List of venue
 *     consumes:
 *      -application/json
 *     requestBody:
 *      content:
 *       application/json:
 *        schema:
 *         $ref: '#/definitions/VenueList'
 *     tags: [Venue]
 *     responses:
 *       200:
 *         description: The list of the users
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *
 *
 */



