/**
 * @swagger
 * definitions:
 *  ZoneList:
 *   type: object
 *   properties:
 *    cId:
 *     type: string
 *     description: category id
 *     example: ''
 *    cType:
 *     type: string
 *     description: category id
 *     example: 'zone'
 *    page:
 *     type: string
 *     description: page no.
 *     example: '1'
 *    pageLimit:
 *     type: string
 *     description: page limit
 *     example: '10'
 *    search:
 *     type: string
 *     description: search by name
 *     example: ''
 *
 *  ZoneUpdate:
 *   type: object
 *   properties:
 *    cId:
 *     type: string
 *     description: category id
 *     example: '616a993adb0fe75068e4d30c'
 *    cType:
 *     type: string
 *     description: category id
 *     example: 'merchandise'
 *    image:
 *     type: string
 *     description: image
 *     example: 'https://riyadh-assets.s3.amazonaws.com/thumbnails/2021/10/16/1634375979128-myFile-1634375979123.jpg'
 *    name:
 *     type: string
 *     description: name title
 *     example: 'Merchandise007'
 *    url:
 *     type: string
 *     description: url
 *     example: 'http://google.com'
 *
 */














/**
 * @swagger
 *
 *
 * /category/list:
 *   post:
 *     summary: List of zone/vanue/amenties/sponsor/merchandise/nearby/restaurant/request/requestCall   by passing cType
 *     consumes:
 *      -application/json
 *     requestBody:
 *      content:
 *       application/json:
 *        schema:
 *         $ref: '#/definitions/ZoneList'
 *     tags: [zone/vanue/amenties/sponsor/merchandise/nearby/restaurant/request/requestCall]
 *     responses:
 *       200:
 *         description: The list of the users
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *
 *
 * /category/update:
 *   post:
 *     summary: Update of zone/vanue/amenties/sponsor/merchandise/nearby/restaurant/request/requestCall   by passing cType
 *     consumes:
 *      -application/json
 *     requestBody:
 *      content:
 *       application/json:
 *        schema:
 *         $ref: '#/definitions/ZoneUpdate'
 *     tags: [zone/vanue/amenties/sponsor/merchandise/nearby/restaurant/request/requestCall]
 *     responses:
 *       200:
 *         description: The list of the users
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *
 *
 */



