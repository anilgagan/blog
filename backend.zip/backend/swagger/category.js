/**
 * @swagger
 * definitions:
 *  CreateCategory:
 *   type: object
 *   properties:
 *    cType:
 *     type: string
 *     description: category type
 *     example: '12345'
 *    name:
 *     type: string
 *     description: category name
 *     example: 'HELLO'
 *    image:
 *     type: string
 *     description: category image
 *     example: 'http://dfjdhfjh.jpg'
 *
 *  AreaList:
 *   type: object
 *   properties:
 *    cId:
 *     type: string
 *     description: category id
 *     example: '12345'
 *    page:
 *     type: string
 *     description: page no.
 *     example: '1'
 *    pageLimit:
 *     type: string
 *     description: page limit
 *     example: '10'
 *    search:
 *     type: string
 *     description: search by name
 *     example: ''
 *
 */















/**
 * @swagger
 *
 * /category/create:
 *   post:
 *     summary: Create Category
 *     consumes:
 *      -application/json
 *     requestBody:
 *      content:
 *       application/json:
 *        schema:
 *         $ref: '#/definitions/CreateCategory'
 *     tags: [Category]
 *     responses:
 *       200:
 *         description: The list of the users
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *
 * /category/area:
 *   post:
 *     summary: List of area of interest
 *     consumes:
 *      -application/json
 *     requestBody:
 *      content:
 *       application/json:
 *        schema:
 *         $ref: '#/definitions/AreaList'
 *     tags: [Category]
 *     responses:
 *       200:
 *         description: The list of the users
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *
 *
 */



