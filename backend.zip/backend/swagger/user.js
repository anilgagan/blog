/**
 * @swagger
 * definitions:
 *  Register:
 *   type: object
 *   properties:
 *    email:
 *     type: string
 *     description: Email of the user     
 *    phone:
 *     type: string
 *     description: add new password 
 *    cCode:
 *     type: string
 *     description: Login by username password or social media account
 *     example: 'inApp'
 *    password:
 *     type: string
 *     description: mobile device uniquer id
 *    name:
 *     type: string
 *     description: mobile device uniquer id
 *    gender:
 *     type: string
 *     description: mobile device uniquer id
 *    age:
 *     type: string
 *     description: mobile device uniquer id
 *    loginType:
 *     type: string
 *     description: mobile device uniquer id
 *    deviceType:
 *     type: string
 *     description: mobile device uniquer id
 *    deviceId:
 *     type: string
 *     description: mobile device uniquer id
 *    userType:
 *     type: string
 *     description: mobile device uniquer id
 *    terms:
 *     type: string
 *     description: mobile device uniquer id
 *    fcmToken:
 *     type: string
 *     description: mobile device uniquer id
 *    lang:
 *     type: string
 *     description: mobile device uniquer id
 *    areasInterest:
 *     type: array
 *     description: mobile device uniquer id
 *
 *  Social-login:
 *   type: object
 *   properties:
 *    socialId:
 *     type: string
 *     description: Email of the user
 *    phone:
 *     type: string
 *     description: add new password
 *    cCode:
 *     type: string
 *     description: Login by username password or social media account
 *     example: 'inApp'
 *    password:
 *     type: string
 *     description: mobile device uniquer id
 *    name:
 *     type: string
 *     description: mobile device uniquer id
 *    gender:
 *     type: string
 *     description: mobile device uniquer id
 *    age:
 *     type: string
 *     description: mobile device uniquer id
 *    loginType:
 *     type: string
 *     description: mobile device uniquer id
 *    deviceType:
 *     type: string
 *     description: mobile device uniquer id
 *    deviceId:
 *     type: string
 *     description: mobile device uniquer id
 *    userType:
 *     type: string
 *     description: mobile device uniquer id
 *    terms:
 *     type: string
 *     description: mobile device uniquer id
 *    fcmToken:
 *     type: string
 *     description: mobile device uniquer id
 *    lang:
 *     type: string
 *     description: mobile device uniquer id
 *    areasInterest:
 *     type: array
 *     description: mobile device uniquer id
 *
 *  Login:
 *   type: object
 *   properties:
 *    email:
 *     type: string
 *     description: Email of the user
 *    password:
 *     type: string
 *     description: add new password
 *    userType:
 *     type: string
 *     description: Login by username password or social media account
 *     example: 'inApp'
 *
 *  Logout:
 *   type: object
 *   properties:
 *    userId:
 *     type: string
 *     description: User id of logout a user
 *
 *  ResetPassword:
 *   type: object
 *   properties:
 *    email:
 *     type: string
 *     description: email of the user
 *     example: 'abc@gmail.com'
 *
 *  ChangePassword:
 *   type: object
 *   properties:
 *    userId:
 *     type: string
 *     description: user id
 *     example: 'abc@gmail.com'
 *    oldPass:
 *     type: string
 *     description: old password
 *     example: '123456'
 *    newPass:
 *     type: string
 *     description: new password
 *     example: '123456'
 *
 *  UpdateUser:
 *   type: object
 *   properties:
 *    userId:
 *     type: string
 *     description: user id
 *     example: '12345'
 *    name:
 *     type: string
 *     description: old password
 *     example: 'HELLO'
 *
 */















/**
 * @swagger
 * /user/register:
 *   post:
 *     summary: register new user
 *     consumes:
 *      -application/json
 *     requestBody:      
 *      content:
 *       application/json:
 *        schema:
 *         $ref: '#/definitions/Register'
 *     tags: [Users]   
 *     responses:
 *       200:
 *         description: Login existing user get details
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *
 * /user/social-login:
 *   post:
 *     summary: social-login existing user
 *     consumes:
 *      -application/json
 *     requestBody:
 *      content:
 *       application/json:
 *        schema:
 *         $ref: '#/definitions/Social-login'
 *     tags: [Users]
 *     responses:
 *       200:
 *         description: Login existing user get details
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *
 * /user/login:
 *   post:
 *     summary: Login existing user
 *     consumes:
 *      -application/json
 *     requestBody:
 *      content:
 *       application/json:
 *        schema:
 *         $ref: '#/definitions/Login'
 *     tags: [Users]
 *     responses:
 *       200:
 *         description: Login existing user get details
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *
 * /user/logout:
 *   patch:
 *     summary: logout existing user
 *     consumes:
 *      -application/json
 *     requestBody:
 *      content:
 *       application/json:
 *        schema:
 *         $ref: '#/definitions/Logout'
 *     tags: [Users]
 *     responses:
 *       200:
 *         description: Login existing user get details
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *
 * /user/reset-password:
 *   patch:
 *     summary: Forgot password generate opt
 *     consumes:
 *      -application/json
 *     requestBody:
 *      content:
 *       application/json:
 *        schema:
 *         $ref: '#/definitions/ResetPassword'
 *     tags: [Users]
 *     responses:
 *       200:
 *         description: The list of the users
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *
 * /user/change-password:
 *   patch:
 *     summary: Forgot password generate opt
 *     consumes:
 *      -application/json
 *     requestBody:
 *      content:
 *       application/json:
 *        schema:
 *         $ref: '#/definitions/ChangePassword'
 *     tags: [Users]
 *     responses:
 *       200:
 *         description: The list of the users
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *
 *
 * /user/remove:
 *   delete:
 *     summary: Delete User
 *     consumes:
 *      -application/json
 *     tags: [Users]
 *     responses:
 *       200:
 *         description: The list of the users
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *
 *
 * /user/update:
 *   patch:
 *     summary: Update User Profile
 *     consumes:
 *      -application/json
 *     requestBody:
 *      content:
 *       application/json:
 *        schema:
 *         $ref: '#/definitions/UpdateUser'
 *     tags: [Users]
 *     responses:
 *       200:
 *         description: The list of the users
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *
 */



