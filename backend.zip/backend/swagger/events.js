/**
 * @swagger
 * definitions:
 *  CreateEvent:
 *   type: object
 *   properties:
 *    category:
 *     type: string
 *     description: category type
 *     example: '12345'
 *    name:
 *     type: string
 *     description: category name
 *     example: 'HELLO'
 *    subCategory:
 *     type: array
 *     description: sub category id
 *     example: []
 *    parentId:
 *     type: string
 *     description:  parent id
 *     example: '12345'
 *    subEvent:
 *     type: array
 *     description: sub event id
 *     example: []
 *    zone:
 *     type: array
 *     description: zone id
 *     example: []
 *    venue:
 *     type: array
 *     description: venue id
 *     example: []
 *    image:
 *     type: array
 *     description: image url
 *     example: []
 *    description:
 *     type: string
 *     description: description
 *     example: 'nice comment'
 *    startDate:
 *     type: string
 *     description: startDate
 *     example: ''
 *    endDate:
 *     type: string
 *     description: sendDate
 *     example: ''
 *    hours:
 *     type: string
 *     description: hours
 *     example: ''
 *    aAge:
 *     type: array
 *     description: aAge
 *     example: [8, 18]
 *    aGender:
 *     type: array
 *     description: aGender
 *     example: []
 *    price:
 *     type: string
 *     description: price
 *     example: '10'
 *    merchandise:
 *     type: array
 *     description: merchandise id
 *     example: []
 *    nearby:
 *     type: array
 *     description: nearby id
 *     example: []
 *    sponsor:
 *     type: array
 *     description: sponsor id
 *     example: []
 *    amenties:
 *     type: array
 *     description: amenties id
 *     example: []
 *    feature:
 *     type: string
 *     description: feature
 *     example: ''
 *    twitter:
 *     type: string
 *     description: twitter id
 *     example: 'abc'
 *    tiktok:
 *     type: string
 *     description: tiktok id
 *     example: ''
 *    youtube:
 *     type: string
 *     description: youtube id
 *     example: ''
 *    facebook:
 *     type: string
 *     description: facebook id
 *     example: ''
 *    ticketTier:
 *     type: string
 *     description: ticketTier id
 *     example: ''
 *
 *  UpdateEvent:
 *   type: object
 *   properties:
 *    eId:
 *     type: string
 *     description: event id
 *     example: ''
 *    category:
 *     type: string
 *     description: category type
 *     example: '12345'
 *    name:
 *     type: string
 *     description: category name
 *     example: 'HELLO'
 *    subCategory:
 *     type: array
 *     description: sub category id
 *     example: []
 *    parentId:
 *     type: string
 *     description:  parent id
 *     example: '12345'
 *    subEvent:
 *     type: array
 *     description: sub event id
 *     example: []
 *    zone:
 *     type: array
 *     description: zone id
 *     example: []
 *    venue:
 *     type: array
 *     description: venue id
 *     example: []
 *    image:
 *     type: array
 *     description: image url
 *     example: []
 *    description:
 *     type: string
 *     description: description
 *     example: 'nice comment'
 *    startDate:
 *     type: string
 *     description: startDate
 *     example: ''
 *    endDate:
 *     type: string
 *     description: sendDate
 *     example: ''
 *    hours:
 *     type: string
 *     description: hours
 *     example: ''
 *    aAge:
 *     type: array
 *     description: aAge
 *     example: [8, 18]
 *    aGender:
 *     type: array
 *     description: aGender
 *     example: []
 *    price:
 *     type: string
 *     description: price
 *     example: '10'
 *    merchandise:
 *     type: array
 *     description: merchandise id
 *     example: []
 *    nearby:
 *     type: array
 *     description: nearby id
 *     example: []
 *    sponsor:
 *     type: array
 *     description: sponsor id
 *     example: []
 *    amenties:
 *     type: array
 *     description: amenties id
 *     example: []
 *    feature:
 *     type: string
 *     description: feature
 *     example: ''
 *    twitter:
 *     type: string
 *     description: twitter id
 *     example: 'abc'
 *    tiktok:
 *     type: string
 *     description: tiktok id
 *     example: ''
 *    youtube:
 *     type: string
 *     description: youtube id
 *     example: ''
 *    facebook:
 *     type: string
 *     description: facebook id
 *     example: ''
 *    ticketTier:
 *     type: string
 *     description: ticketTier id
 *     example: ''
 *    webUrl:
 *     type: string
 *     description: webUrl id
 *     example: ''
 *    zoneEvent:
 *     type: string
 *     description: ticketTier id
 *     example: '1'
 *    disablity:
 *     type: boolean
 *     description: disablity
 *     example: true
 *    eventstatus:
 *     type: string
 *     description: eventstatus
 *     example: '1'
 *    eventGuidLine:
 *     type: string
 *     description: eventGuidLine
 *     example: 'xyz'
 *    evtType:
 *     type: string
 *     description: evtType
 *     example: '1'
 *    keyword:
 *     type: string
 *     description: keyword for search
 *     example: '1'
 *    kidAllow:
 *     type: boolean
 *     description: kidAllow
 *     example: true
 *    kioskTicket:
 *     type: boolean
 *     description: kioskTicket
 *     example: true
 *    kioskTicketOnGate:
 *     type: boolean
 *     description: kioskTicketOnGate
 *     example: true
 *    priceFrom:
 *     type: string
 *     description: priceFrom
 *     example: '1'
 *    priceTo:
 *     type: string
 *     description: priceTo
 *     example: '1'
 *    protoGuidLine:
 *     type: string
 *     description: protoGuidLine
 *     example: '1'
 *    rating:
 *     type: string
 *     description: rating
 *     example: '1'
 *    restEvent:
 *     type: string
 *     description: restEvent
 *     example: '1'
 *    supportNumber:
 *     type: string
 *     description: supportNumber
 *     example: '1'
 *    ticket_mix_id:
 *     type: string
 *     description: ticket_mix_id id
 *     example: '1'
 *    ticket_mix_url:
 *     type: string
 *     description: ticket_mix_url id
 *     example: '1'
 *
 *
 *
 *
 *
 *
 *
 *  EventList:
 *   type: object
 *   properties:
 *    eId:
 *     type: string
 *     description: event id
 *     example: ''
 *    page:
 *     type: string
 *     description: page no.
 *     example: '1'
 *    pageLimit:
 *     type: string
 *     description: page limit
 *     example: ''
 *    search:
 *     type: string
 *     description: search by name
 *     example: ''
 *    filter:
 *     type: array
 *     description: search by name
 *     example: [{"dateRange":["2021-09-30T23:51:26.000000Z","2021-10-03T23:51:26.000000Z"]}]
 *
 */















/**
 * @swagger
 *
 * /event/create:
 *   post:
 *     summary: Create Event
 *     consumes:
 *      -application/json
 *     requestBody:
 *      content:
 *       application/json:
 *        schema:
 *         $ref: '#/definitions/CreateEvent'
 *     tags: [Event]
 *     responses:
 *       200:
 *         description: The list of the users
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *
 * /event/list:
 *   post:
 *     summary: List of events
 *     consumes:
 *      -application/json
 *     requestBody:
 *      content:
 *       application/json:
 *        schema:
 *         $ref: '#/definitions/EventList'
 *     tags: [Event]
 *     responses:
 *       200:
 *         description: The list of the users
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *
 *
 * /event/update:
 *   patch:
 *     summary: List of events
 *     consumes:
 *      -application/json
 *     requestBody:
 *      content:
 *       application/json:
 *        schema:
 *         $ref: '#/definitions/UpdateEvent'
 *     tags: [Event]
 *     responses:
 *       200:
 *         description: The list of the users
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *
 *
 */
