/**
   * @swagger
   * /reciept/list:
   *   post:
   *     tags: [Reciept]
   *     produces:
   *       - application/json
   *     parameters:
   *       - name: accessToken
   *         in: header
   *         required: true
   *         type: string
   *         description: Authorization Token
   *       - name: recieptType
   *         in: formData
   *         type: string
   *         required: true
   *         description: 
   *       - name: Search
   *         in: formData
   *         type: string
   *         required: false
   *         description: 
   *       - name: recieptId
   *         in: formData
   *         type: string
   *         required: false
   *         description: 
   *       - name: pageLimit
   *         in: formData
   *         type: number 
   *         required: false
   *         description: 
   *       - name: page
   *         in: formData
   *         type: string
   *         required: true
   *         description: 
   *     responses:
   *       200:
   *         description: Reciepts.
   *
 */