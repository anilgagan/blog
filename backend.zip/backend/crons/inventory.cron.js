const moment = require("moment");
const { log: info, error: _error } = console;
const { bidHistoryLog } = require("../modules/bid/bidModal");
const { makeObjectId } = require("../functions/global.functions");
const { Auctionvehicle } = require("../modules/auction/auctionModal");
const { Inventory } = require("../modules/inventory/inventoryModal");
const common = require("../middleware/common-fun");
const { markUnderApprovalToUnsoldTime } = require("../config");

const markUnderApprovalBidsUnSold = async () => {
  info("STARTING NO COUNTER OFFER BID CHECKING CRON");

  try {
    const _24Hours = moment()
      .subtract(markUnderApprovalToUnsoldTime, "hours")
      .toDate();

    // * no inventory must be in UnderApproval state after 24 hours
    const filter = {
      status: "UnderApproval",
      bidType: "Current",
      createdAt: { $lte: _24Hours },
    };

    const pipeline = [
      { $match: filter },
      {
        $lookup: {
          from: "auctions",
          localField: "auctionId",
          foreignField: "_id",
          as: "auctions",
        },
      },
      { $unwind: { path: "$auctions", preserveNullAndEmptyArrays: true } },
      {
        $project: {
          inventoryId: 1,
          bidAmount: "$calcAmount",
          auctionId: "$auctions._id",
          title: "$auctions.title",
          auctionDate: "$auctions.auctionDate",
          auctionTime: "$auctions.auctionTime",
        },
      },
    ];

    const underApprovalBids = await bidHistoryLog.aggregate(pipeline);

    if (!underApprovalBids.length) {
      _error("No Counter Offer Bids Found!");
      return;
    }

    info(
      "TOTAL NUMBER OF NO COUNTER OFFER BIDS FOUND:",
      underApprovalBids.length
    );

    for (const bid of underApprovalBids) {
      const { _id: bidId, auctionId, inventoryId, bidAmount } = bid;

      const bUpdate = {
        $set: { status: "UnSold", isMarkedUnSoldByCron: true },
      };

      await bidHistoryLog.findByIdAndUpdate(bidId, bUpdate);

      const aFilter = {
        $and: [
          { auctionId: makeObjectId(auctionId) },
          { inventoryId: makeObjectId(inventoryId) },
          { status: "UnderApproval" },
        ],
      };

      const aUpdate = {
        $set: { status: "unsold", bidAmount },
      };

      const auctionVehicle = await Auctionvehicle.findOneAndUpdate(
        aFilter,
        aUpdate
      );

      if (!auctionVehicle) throw new Error("Auction Vehicle Not Found!");

      const iUpdate = {
        $set: { inventoryStatus: 1 },
      };

      const inventory = await Inventory.findByIdAndUpdate(inventoryId, iUpdate);

      if (!inventory) throw new Error("Inventory Not Found!");

      await common.checkVehicleUnsold(auctionId, [inventoryId]);
    }

    info("EVERYTHING DONE!!!");
  } catch (error) {
    _error(error);
    throw new Error(error.message);
  }
};

module.exports = {
  markUnderApprovalBidsUnSold,
};
