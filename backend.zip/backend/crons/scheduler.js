const cron = require("node-cron");
const { markUnderApprovalBidsUnSold } = require("./inventory.cron");
const { calculateClosingBalance } = require("../services/account.service");
const {
  userTypes: { SELLER, BUYER },
} = require("../config");
const { calculateSellerStorage } = require("../services/order.service");

const noCounterOfferBidsCron = cron.schedule(
  "0 */12 * * *", // * after every 12 hours
  async () => await markUnderApprovalBidsUnSold()
);

const calculateLedgerClosingBalanceCron = cron.schedule(
  "0 3 * * *", // * daily at 03:00AM night
  async () => {
    await calculateClosingBalance(SELLER);
    await calculateClosingBalance(BUYER);
  }
);

const calculateSellerStorageCron = cron.schedule(
  "0 2 * * *", // * daily at 02:00AM night
  async () => await calculateSellerStorage()
);

module.exports = {
  noCounterOfferBidsCron,
  calculateLedgerClosingBalanceCron,
  calculateSellerStorageCron,
};
