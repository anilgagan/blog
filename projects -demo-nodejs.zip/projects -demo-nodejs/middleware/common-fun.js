module.exports = {
    returnSuccess: function (res, result, hasMore, message, totalCount) {
        res.status(200).json({
            status: true,
            result: result,
            message: message,
            hasMore: hasMore,
            totalCount: totalCount,
        });
    },
    returrnErrorMessage(res, message) {
        res.status(200).json({ status: false, message: message });
    },
    returnSreverError: function (res, message, error, errorCode) {
        res.status(500).json({
            status: false,
            message: message,
            errorCode: errorCode,
            error: error,
        });
    },
    returnNotFoundError: function (res, message, error, errorCode) {
        res.status(400).json({
            status: false,
            message: message,
            errorCode: errorCode,
        });
    },
};