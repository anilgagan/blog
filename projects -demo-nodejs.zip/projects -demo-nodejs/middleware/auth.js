"use strict";
var config = require('../config');
const messages = require('../utils/lang/messages');

var adminAuth = function (req, res, next) {
    
    const accessToken = req.headers['x-access-token'];
    if (accessToken == "admin") {
        next();
    } else {
        res.status(404).send({ status: false, error: messages.eng.adminAccess, errorCode: 404 })
    }
}
module.exports = {
    adminAuth
}
