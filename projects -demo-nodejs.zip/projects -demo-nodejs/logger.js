const path = require("path");
const fs = require("fs");
const winston = require("winston");
const DailyRotateFile = require("winston-daily-rotate-file");

const logsDirectory = path.join(__dirname+"/projects/", "..", "logs");
console.log('1=====',logsDirectory);
console.log('2=====',process.env.NODE_ENV);


if (!fs.existsSync(logsDirectory)) fs.mkdirSync(logsDirectory);

const isDevelopment = process.env.NODE_ENV === "development";

const enumerateErrorFormat = winston.format((info) => {
  if (info instanceof Error) Object.assign(info, { message: info.stack });
  return info;
});

const logger = winston.createLogger({
  level: isDevelopment ? "debug" : "info",
  format: winston.format.combine(
    enumerateErrorFormat(),
    isDevelopment ? winston.format.colorize() : winston.format.uncolorize(),
    winston.format.splat(),
    winston.format.timestamp(),
    winston.format.printf(({ timestamp, level, message }) => {
      return `${timestamp} [${level}]: ${message}`;
    })
  ),
  transports: [
    new DailyRotateFile({
      filename: `${logsDirectory}/info-%DATE%.log`,
      datePattern: "YYYY-MM-DD",
      level: "info",
      zippedArchive: true,
      maxSize: "20m",
      maxFiles: "14d",
    }),

    new DailyRotateFile({
      filename: `${logsDirectory}/error-%DATE%.log`,
      datePattern: "YYYY-MM-DD",
      level: "error",
      zippedArchive: true,
      maxSize: "20m",
      maxFiles: "14d",
    }),

    new winston.transports.Console(),
  ],
});

logger.stream = {
  write: function (message, encoding) {
    logger.info(message.trim());
  },
};

module.exports = logger;
