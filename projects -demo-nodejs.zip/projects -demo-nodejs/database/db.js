const { DB_PORT, DB_NAME, USER_NAME, PASS_WORD } = require('../config');

var mysql = require('mysql2');
var con = mysql.createConnection({
    host: "localhost",
    port: process.env.DB_PORT,
    database: process.env.DB_NAME,
    user: process.env.USER_NAME,
    password: process.env.PASS_WORD
});

con.connect(function (err) {
    if (err) throw err;
    console.log("Mysql Connected anilgagan----!");
});
module.exports = con;