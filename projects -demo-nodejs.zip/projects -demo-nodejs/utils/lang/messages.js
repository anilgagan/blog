module.exports = {
  eng: {
    Notfound: "API not found!",
    Notoken: "No token provided",
    Unauthorized: "Unauthorized Access.",
    Invaliddata: "Invalid data!",
    technicalError: " Oops! something went wrong",
    signupMsg: "You've successfully signed up, Welcome on Gyftr!",
    invalidRequest: "Invalid request data.",
    otpverify: "OTP verify successfully",
    notpverify: "OTP not verify successfully",
    adminAccess:"Only Admin can access !"
  }
};
