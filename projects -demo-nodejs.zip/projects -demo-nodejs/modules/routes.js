const express = require('express');
const User = require('./user');
var app = express();
var bodyParser = require('body-parser');
var con = require('../database/db');
const commonMethod = require("../middleware/common-fun");
const messages = require('../utils/lang/messages');
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
    extended: true
}));
const logger = require("../logger");
const Auth = require("../middleware/auth");

// Create a new user
app.post('/registration',Auth.adminAuth, async (req, res) => {

    const { name, phone, email } = req.body;
    const user = new User({ name, phone, email });
    if (user.name) {
        try {
            var regsql = await con.promise().query('call USER_REGISTRATION(?, ?, ?)', [name, phone, email])
            if (regsql) {
                return commonMethod.returnSuccess(res, regsql[0], false, messages.eng.signupMsg);
            } else {
                return commonMethod.returrnErrorMessage(res, messages.eng.invalidRequest);
            }

        } catch (error) {
            return commonMethod.returnSreverError(res, messages.eng.technicalError, error);
        }

    } else {
        return commonMethod.returrnErrorMessage(res, messages.eng.Invaliddata);
    }

});

// Verify users
app.get('/verification', async (req, res) => {
    const { phone, otp } = req.body;
    try {
        var verifysql = await con.promise().query('call VERIFY_OTP(?, ?)', [phone, otp])
        if (verifysql) {
            return commonMethod.returnSuccess(res, verifysql[0], false, messages.eng.otpverify);
        } else {
            return commonMethod.returrnErrorMessage(res, messages.eng.notpverify);
        }

    } catch (error) {
        return commonMethod.returnSreverError(res, messages.eng.technicalError, error);
    }
});

module.exports = app;