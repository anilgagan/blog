const express = require('express');
const path = require("path");
const bodyParser = require('body-parser');
const db = require('./database/db');
const routes = require('./modules/routes');
const app = express();
const logger = require("./logger")

let PORT = process.env.PORT || 3000;
const swaggerUi = require('swagger-ui-express');
const swaggerDocument = require('./docs/swagger');

app.use(express.static(path.join(__dirname, "public")));
app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerDocument));
app.use(bodyParser.json());

app.use(function (req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header(
        "Access-Control-Allow-Headers",
        "Origin, X-Requested-With, Content-Type, Accept"
    );
    next();
});

const basicAuth = require("./middleware/basic-auth");
app.use(basicAuth.basicAuthentication);
//const adminAccess = require("./middleware/auth");
//app.use(adminAccess.adminAuth);


app.use('/api', routes);

app.listen(PORT, () => {
    console.log('http://localhost:3000/api');
    logger.info( `Server Listening On Port ${PORT} ...`);
   
});

