const dotenv = require('dotenv');
dotenv.config();
//module.exports = process.env.PORT;

const NODE_ENV = process.env.NODE_ENV;

module.exports = Object.freeze({
    ENV: NODE_ENV,
    STG: "staging",
    DEV: "development",
    PROD: "production",
    isDev: function () {
        return this.ENV === this.DEV ? true : false;
    },
    isProd: function () {
        return this.ENV === this.PROD ? true : false;
    },
    isStag: function () {
        return this.ENV === this.STG ? true : false;
    },
    platform: {
        ADMIN: "admin",
        USER: "user",
      },
    basicAuth: {
        username: "Gyftr!@#$%^",
        password: "Gyftr!@#$%^&&",
        passURL: [
            "/api/registration",
            "/api/verification",
        ],
    },
    existURL: [
        "/api/registration",
        "/api/verification",
    ]

});

